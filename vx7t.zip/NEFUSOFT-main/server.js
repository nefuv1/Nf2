require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const { scrapeOngoing, scrapeListPage, scrapeDetail, scrapeGenres, scrapeRandomQuote, scrapeStreamData } = require('./scraper');
const { URL } = require('url');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('trust proxy', 1);

const limiter = rateLimit({
	windowMs: 15 * 60 * 1000,
	max: 150,
	standardHeaders: true,
	legacyHeaders: false,
});
app.use(limiter);

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use((req, res, next) => {
    if (req.path.endsWith('/') && req.path.length > 1) {
        res.redirect(301, req.path.slice(0, -1) + (req.url.slice(req.path.length) || ''));
    } else {
        next();
    }
});

app.use('/api', (req, res, next) => {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.set('Pragma', 'no-cache');
    res.set('Expires', '0');
    next();
});

const cache = new Map();
const urlMap = new Map();
const CACHE_TTL = 15 * 60 * 1000;

const getFromCacheOrScrape = async (key, scrapeFunction, ...args) => {
    const cached = cache.get(key);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
        return cached.data;
    }
    const data = await scrapeFunction(...args);
    if (data && (typeof data !== 'object' || Object.keys(data).length > 0)) {
        cache.set(key, { timestamp: Date.now(), data });
    }
    return data;
};

const extractSlugFromUrl = (url) => {
    if (!url) return '';
    try {
        const path = new URL(url).pathname;
        return path.split('/').filter(Boolean).pop();
    } catch (e) {
        return '';
    }
};

const warmUpUrlMap = async () => {
    console.log('[Startup/Refresh] Warming up urlMap with ongoing anime...');
    try {
        const ongoingRaw = await scrapeOngoing();
        const allOngoingAnimes = Object.values(ongoingRaw).flat();
        let count = 0;
        allOngoingAnimes.forEach(anime => {
            const slug = extractSlugFromUrl(anime.detailUrl);
            if (slug && !urlMap.has(slug)) {
                urlMap.set(slug, { url: anime.detailUrl, timestamp: Date.now() });
                count++;
            }
        });
        console.log(`[Startup/Refresh] urlMap warmed up with ${count} unique ongoing animes.`);
    } catch (error) {
        console.error('[Startup/Refresh] Failed to warm up urlMap:', error);
    }
};

const fetchAndCacheHomeData = async () => {
    try {
        const ongoingRaw = await scrapeOngoing();
        const allOngoingAnimes = Object.values(ongoingRaw).flat();
        
        allOngoingAnimes.forEach(anime => {
            const slug = extractSlugFromUrl(anime.detailUrl);
            if (!urlMap.has(slug)) urlMap.set(slug, { url: anime.detailUrl, timestamp: Date.now() });
            anime.slug = slug;
        });

        const bannerAnimes = allOngoingAnimes.slice(0, 7);
        const bannerDetailsPromises = bannerAnimes.map(async (bannerAnime) => {
            const detailData = await getFromCacheOrScrape(`detail-no-streams:${bannerAnime.slug}`, scrapeDetail, bannerAnime.detailUrl);
            return detailData ? { ...bannerAnime, ...detailData } : null;
        });

        const bannerData = (await Promise.all(bannerDetailsPromises)).filter(Boolean);

        const homeData = { bannerData, ongoingData: allOngoingAnimes };
        cache.set('home-data', { timestamp: Date.now(), data: homeData });
        console.log('[Cache] Home data has been refreshed in the background.');
        return homeData;
    } catch (e) {
        console.error("[Background Refresh] Error fetching home data:", e);
    }
};

app.get('/', (req, res) => res.render('welcome'));
app.get('/anime', (req, res) => res.render('anime'));

app.get('/api/home-data', async (req, res) => {
    const cachedData = cache.get('home-data');
    if (cachedData && Date.now() - cachedData.timestamp < CACHE_TTL) {
       return res.json(cachedData.data);
    }
    const homeData = await fetchAndCacheHomeData();
    if (homeData) {
        res.json(homeData);
    } else {
        res.status(500).json({ error: "Gagal memuat data." });
    }
});

app.get('/api/detail/:slug', async (req, res) => {
    const { slug } = req.params;
    const mapEntry = urlMap.get(slug);
    const primarySourceUrl = process.env.NEFUSOFT_URL || '';
    let detailUrl = mapEntry ? mapEntry.url : `${primarySourceUrl}/anime/${slug}`;
    try {
        const data = await getFromCacheOrScrape(`detail-no-streams:${slug}`, scrapeDetail, detailUrl);
        if (!data) return res.status(404).json({ error: 'Detail not found.' });
        if (!mapEntry && data.url) urlMap.set(slug, { url: data.url, timestamp: Date.now() });
        res.json(data);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch details.' });
    }
});

app.get('/api/clear-cache', (req, res) => {
    const { secret } = req.query;
    if (secret !== process.env.CACHE_SECRET) {
        return res.status(401).json({ error: 'Unauthorized' });
    }
    cache.clear();
    urlMap.clear();
    warmUpUrlMap();
    res.status(200).json({ message: 'Cache and URL map cleared successfully.' });
});

app.get('/api/random-quote', async (req, res) => {
    try {
        const quote = await scrapeRandomQuote();
        if (!quote) return res.status(500).json({ error: 'Gagal mengambil kutipan.' });
        res.json(quote);
    } catch (e) {
        res.status(500).json({ error: "Gagal memuat kutipan." });
    }
});

app.get('/detail/:slug', async (req, res, next) => {
    const { slug } = req.params;
    const mapEntry = urlMap.get(slug);
    const primarySourceUrl = process.env.NEFUSOFT_URL || '';
    let detailUrl = mapEntry ? mapEntry.url : `${primarySourceUrl}/anime/${slug}`;
    try {
        const data = await getFromCacheOrScrape(`detail-no-streams:${slug}`, scrapeDetail, detailUrl);
        if (!data) return next();
        if (!mapEntry && data.url) urlMap.set(slug, { url: data.url, timestamp: Date.now() });
        res.render('detail', { data, slug });
    } catch (error) {
        return next(error);
    }
});

app.get('/stream/:slug/episode-:epNum', async (req, res, next) => {
    const { slug, epNum } = req.params;
    const mapEntry = urlMap.get(slug);
    if (!mapEntry) {
        console.error(`[SERVER ERROR] Slug "${slug}" not found in urlMap.`);
        return next();
    }
    try {
        const data = await getFromCacheOrScrape(`detail-no-streams:${mapEntry.url}`, scrapeDetail, mapEntry.url);
        if (!data || !data.episodes) return next();
        const currentEpisode = data.episodes.find(ep => ep.episodeNum == epNum);
        if (!currentEpisode) return next();
        res.render('stream', { data, slug, currentEpisode });
    } catch (error) {
        return next(error);
    }
});

app.get('/api/stream/:slug/episode-:epNum', async (req, res) => {
    const { slug, epNum } = req.params;
    const mapEntry = urlMap.get(slug);
    if (!mapEntry) {
        return res.status(404).json({ error: 'Anime not found in map.' });
    }
    try {
        const cacheKey = `stream:${mapEntry.url}:ep:${epNum}`;
        const episodeData = await getFromCacheOrScrape(cacheKey, scrapeStreamData, mapEntry.url, epNum);
        
        if (!episodeData || !episodeData.streams) {
             return res.status(404).json({ error: 'Stream data not found.' });
        }
        
        res.json(episodeData);

    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch stream data.' });
    }
});

app.get('/search', (req, res) => {
    const { q } = req.query;
    if (!q) {
        return res.redirect('/anime');
    }
    res.render('search', { searchQuery: q });
});

app.get('/api/search', async (req, res) => {
    const { q } = req.query;
    const primarySourceUrl = process.env.NEFUSOFT_URL || '';
    if (!q) return res.status(400).json({ error: 'Query "q" dibutuhkan.' });
    try {
        const url = `${primarySourceUrl}/?s=${encodeURIComponent(q)}&post_type=post`;
        const listData = await scrapeListPage(url);
        listData.anime.forEach(anime => {
            const slug = extractSlugFromUrl(anime.detailUrl);
            if (!urlMap.has(slug)) urlMap.set(slug, { url: anime.detailUrl, timestamp: Date.now() });
            anime.slug = slug;
        });
        res.json(listData.anime);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.get('/api/genres', async (req, res) => {
    try {
        const genres = await getFromCacheOrScrape('genres', scrapeGenres);
        res.json(genres);
    } catch (e) {
        res.status(500).json({ error: "Gagal memuat genre." });
    }
});

app.get('/genre/:genreSlug', (req, res) => {
    const { genreSlug } = req.params;
    const genreName = genreSlug.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    res.render('genre', { genreName, genreSlug });
});

app.get('/api/genre/:genreSlug', async (req, res) => {
    const { genreSlug } = req.params;
    const page = req.query.page || '1';
    const primarySourceUrl = process.env.NEFUSOFT_URL || '';
    const pageUrlPart = parseInt(page, 10) > 1 ? `/page/${page}/` : '/';
    const url = `${primarySourceUrl}/category/${genreSlug}${pageUrlPart}`;
    const cacheKey = `genre:${genreSlug}:${page}`;

    try {
        const listData = await getFromCacheOrScrape(cacheKey, scrapeListPage, url);
        listData.anime.forEach(anime => {
            const slug = extractSlugFromUrl(anime.detailUrl);
            if (!urlMap.has(slug)) urlMap.set(slug, { url: anime.detailUrl, timestamp: Date.now() });
            anime.slug = slug;
        });
        res.json({
            anime: listData.anime.filter(item => item && item.title && item.slug),
            totalPages: listData.totalPages
        });
    } catch (e) {
        res.status(500).json({ error: `Gagal memuat data untuk genre ${genreSlug}.` });
    }
});

app.use((req, res, next) => {
    res.status(404).render('error', { message: '404 - Halaman Tidak Ditemukan' });
});

app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).render('error', { message: '500 - Terjadi Kesalahan Internal' });
});

app.listen(PORT, () => {
    console.log(`🚀 Server berjalan di http://localhost:${PORT}`);
    warmUpUrlMap();
});
