const enrichAnimeCovers = (animeData, containerElement) => {
    if (!animeData || !containerElement) return;

    animeData.forEach(anime => {
        if (!anime.slug) return;
        fetch(`/api/detail/${anime.slug}`)
            .then(response => {
                if (!response.ok) return null;
                return response.json();
            })
            .then(detailData => {
                const imgWrapper = containerElement.querySelector(`.img-wrapper[data-slug='${anime.slug}']`);
                if (imgWrapper && detailData && detailData.thumbnail) {
                    const img = document.createElement('img');
                    img.src = detailData.thumbnail;
                    img.alt = anime.title;
                    img.className = 'card-img';
                    img.loading = 'lazy';
                    
                    img.onload = () => {
                        imgWrapper.innerHTML = ''; // Hapus placeholder
                        imgWrapper.appendChild(img);
                        imgWrapper.classList.remove('placeholder');
                    };
                    img.onerror = () => {
                        // Jika gagal, biarkan placeholder atau tampilkan fallback
                        imgWrapper.classList.remove('placeholder');
                    };
                }
            })
            .catch(error => {
                console.error(`Gagal mengambil detail untuk ${anime.slug}:`, error);
            });
    });
};

document.addEventListener('DOMContentLoaded', () => {
    const contextMenu = document.getElementById('custom-context-menu');
    document.addEventListener("contextmenu", e => {
        e.preventDefault();
        if (contextMenu) {
            contextMenu.style.top = `${e.pageY}px`;
            contextMenu.style.left = `${e.pageX}px`;
            contextMenu.style.display = "block";
        }
    });

    document.addEventListener("click", () => {
        if (contextMenu) {
            contextMenu.style.display = "none";
        }
    });
});
