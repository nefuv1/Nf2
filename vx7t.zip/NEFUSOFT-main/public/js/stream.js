function initializePlayer(episodeData) {
    const player = document.getElementById('video-player');
    const playerContainer = document.querySelector('.plyr-container');
    const loadingOverlay = document.querySelector('.plyr-loading-overlay');
    const serverButtonsContainer = document.getElementById('server-buttons-container');
    const skipIndicator = document.getElementById('skip-indicator');

    const controls = {
        play: document.querySelector('[data-plyr="play"]'),
        rewind: document.querySelector('[data-plyr="rewind"]'),
        forward: document.querySelector('[data-plyr="forward"]'),
        progress: document.querySelector('.plyr-progress'),
        currentTime: document.querySelector('.plyr-current-time'),
        duration: document.querySelector('.plyr-duration'),
        settingsBtn: document.querySelector('[data-plyr="settings"]'),
        settingsMenu: document.getElementById('settings-menu-options'),
        speedBtn: document.querySelector('[data-plyr="speed"]'),
        speedMenu: document.getElementById('speed-menu-options'),
        fullscreen: document.querySelector('[data-plyr="fullscreen"]'),
    };

    let accumulatedSkipTime = 0;
    let skipTimer = null;

    const showError = (message) => {
        if (playerContainer) {
            playerContainer.innerHTML = `<div class="plyr-error-overlay" style="display: flex; justify-content: center; align-items: center; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.8); color: white; text-align: center; padding: 15px;"><p>${message}</p></div>`;
        }
    };
    
    if (!episodeData || !episodeData.streams || episodeData.streams.length === 0) {
        showError("Video stream tidak tersedia untuk episode ini.");
        return;
    }
    
    const streams = episodeData.streams;
    let activeResolution = streams.find(s => s.resolution === '720p')?.resolution || streams[0]?.resolution;

    const updateSource = (url) => {
        if (!url || !player) return;
        loadingOverlay.classList.remove('hidden');
        player.src = url;
        player.load();
        player.play().catch(e => console.error("Autoplay dicegah:", e));
    };

    const handleSkip = (seconds) => {
        clearTimeout(skipTimer);
        accumulatedSkipTime += seconds;

        if (skipIndicator) {
            skipIndicator.textContent = `${accumulatedSkipTime > 0 ? '+' : ''}${accumulatedSkipTime}`;
            skipIndicator.classList.add('visible');
        }

        skipTimer = setTimeout(() => {
            const targetTime = player.currentTime + accumulatedSkipTime;
            player.currentTime = Math.max(0, Math.min(targetTime, player.duration));
            accumulatedSkipTime = 0;
            if (skipIndicator) {
                skipIndicator.classList.remove('visible');
            }
        }, 2000);
    };

    const buildUI = () => {
        const firstUrl = streams.find(s => s.resolution === activeResolution)?.providers[0]?.url;
        if (firstUrl) {
            updateSource(firstUrl);
        } else {
            showError("Tidak ada URL video yang valid.");
        }
    };
    
    // Sisa fungsi UI tetap sama
    const formatTime = (time) => { if (isNaN(time)) return '00:00'; const seconds = Math.floor(time % 60); const minutes = Math.floor(time / 60) % 60; const hours = Math.floor(time / 3600); return `${hours > 0 ? String(hours).padStart(2, '0') + ':' : ''}${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`; };
    const buildResolutionMenu = () => { if (!controls.settingsMenu) return; controls.settingsMenu.innerHTML = '<div class="plyr-menu-title">Resolusi</div>'; streams.forEach(stream => { const button = document.createElement('button'); button.textContent = stream.resolution; if (stream.resolution === activeResolution) button.classList.add('active'); button.addEventListener('click', () => { activeResolution = stream.resolution; buildServerButtons(); controls.settingsMenu.querySelectorAll('button').forEach(b => b.classList.remove('active')); button.classList.add('active'); const firstProvider = streams.find(s => s.resolution === activeResolution)?.providers[0]; if (firstProvider) updateSource(firstProvider.url); controls.settingsMenu.style.display = 'none'; controls.settingsBtn.classList.remove('active'); }); controls.settingsMenu.appendChild(button); }); };
    const buildServerButtons = () => { serverButtonsContainer.innerHTML = ''; const stream = streams.find(s => s.resolution === activeResolution); if (stream && stream.providers) { stream.providers.forEach((provider, index) => { const button = document.createElement('button'); button.className = 'server-button'; button.textContent = provider.provider; button.dataset.url = provider.url; if (index === 0) button.classList.add('active'); button.addEventListener('click', () => { serverButtonsContainer.querySelectorAll('.server-button').forEach(btn => btn.classList.remove('active')); button.classList.add('active'); updateSource(provider.url); }); serverButtonsContainer.appendChild(button); }); } };
    const buildSpeedMenu = () => { if (!controls.speedMenu || !controls.speedBtn) return; controls.speedMenu.innerHTML = '<div class="plyr-menu-title">Kecepatan</div>'; [0.5, 0.75, 1, 1.25, 1.5, 2].forEach(speed => { const button = document.createElement('button'); button.textContent = speed === 1 ? 'Normal' : `${speed}x`; if (speed === player.playbackRate) button.classList.add('active'); button.addEventListener('click', (e) => { e.stopPropagation(); player.playbackRate = speed; controls.speedBtn.textContent = speed === 1 ? '1x' : `${speed}x`; controls.speedMenu.querySelectorAll('button').forEach(b => b.classList.remove('active')); button.classList.add('active'); controls.speedMenu.style.display = 'none'; controls.speedBtn.classList.remove('active'); }); controls.speedMenu.appendChild(button); }); };
    const toggleMenu = (btn, menu) => { const otherMenu = menu === controls.speedMenu ? controls.settingsMenu : controls.speedMenu; const otherBtn = btn === controls.speedBtn ? controls.settingsBtn : controls.speedBtn; if(otherMenu) otherMenu.style.display = 'none'; if(otherBtn) otherBtn.classList.remove('active'); const isVisible = menu.style.display === 'block'; menu.style.display = isVisible ? 'none' : 'block'; btn.classList.toggle('active', !isVisible); };
    
    buildResolutionMenu();
    buildServerButtons();
    buildSpeedMenu();
    buildUI();

    const updatePlayPauseIcon = () => { if (controls.play) controls.play.classList.toggle('is-playing', !player.paused); };
    player.addEventListener('play', updatePlayPauseIcon);
    player.addEventListener('pause', updatePlayPauseIcon);
    player.addEventListener('timeupdate', () => { if (!controls.progress || !isFinite(player.duration)) return; const value = player.duration > 0 ? (player.currentTime / player.duration) * 100 : 0; controls.progress.value = value; controls.progress.style.background = `linear-gradient(to right, var(--primary-color) ${value}%, rgba(255, 255, 255, 0.3) ${value}%)`; if (controls.currentTime) controls.currentTime.textContent = formatTime(player.currentTime); });
    player.addEventListener('loadedmetadata', () => { if (controls.duration) controls.duration.textContent = formatTime(player.duration); });
    player.addEventListener('waiting', () => loadingOverlay.classList.remove('hidden'));
    player.addEventListener('canplay', () => { loadingOverlay.classList.add('hidden'); player.play().catch(e => {}); });
    player.addEventListener('playing', () => loadingOverlay.classList.add('hidden'));
    player.addEventListener('error', () => showError("Gagal memuat video. Coba server/resolusi lain."));
    playerContainer.addEventListener('click', (e) => { if (e.target === playerContainer || e.target === player) { playerContainer.classList.toggle('controls-visible'); } });
    
    if (controls.play) controls.play.addEventListener('click', (e) => { e.stopPropagation(); player.paused ? player.play() : player.pause(); });
    if (controls.rewind) controls.rewind.addEventListener('click', (e) => { e.stopPropagation(); handleSkip(-10); });
    if (controls.forward) controls.forward.addEventListener('click', (e) => { e.stopPropagation(); handleSkip(10); });
    if (controls.progress) controls.progress.addEventListener('input', (e) => { if(isFinite(player.duration)) player.currentTime = (e.target.value / 100) * player.duration; });
    
    if (controls.fullscreen) controls.fullscreen.addEventListener('click', (e) => { e.stopPropagation(); if (document.fullscreenElement) { document.exitFullscreen(); } else { playerContainer.requestFullscreen().catch(err => console.error(`Gagal fullscreen: ${err.message}`)); } });
    document.addEventListener('fullscreenchange', () => { playerContainer.classList.toggle('is-fullscreen', !!document.fullscreenElement); try { if (document.fullscreenElement) { if (screen.orientation && typeof screen.orientation.lock === 'function') { screen.orientation.lock('landscape').catch(e => {}); } } else { if (screen.orientation && typeof screen.orientation.unlock === 'function') { screen.orientation.unlock(); } } } catch (err) {} });
    
    if (controls.speedBtn) controls.speedBtn.addEventListener('click', (e) => { e.stopPropagation(); toggleMenu(controls.speedBtn, controls.speedMenu); });
    if (controls.settingsBtn) controls.settingsBtn.addEventListener('click', (e) => { e.stopPropagation(); toggleMenu(controls.settingsBtn, controls.settingsMenu); });
    
    document.addEventListener('click', (e) => {
        if (!playerContainer.contains(e.target)) {
            if (controls.speedMenu) controls.speedMenu.style.display = 'none';
            if (controls.settingsMenu) controls.settingsMenu.style.display = 'none';
            if (controls.speedBtn) controls.speedBtn.classList.remove('active');
            if (controls.settingsBtn) controls.settingsBtn.classList.remove('active');
        }
    });
}
