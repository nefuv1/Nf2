document.addEventListener('DOMContentLoaded', () => {
    if (typeof genreSlug === 'undefined') return;

    const grid = document.getElementById('genre-grid');
    const loadMoreContainer = document.getElementById('load-more-container');
    let currentPage = 1;
    let isLoading = false;
    let totalPages = 1;

    const enrichCard = (cardPlaceholder, animeData) => {
        fetch(`/api/detail/${animeData.slug}`)
            .then(response => response.ok ? response.json() : Promise.reject())
            .then(detailData => {
                const finalCard = document.createElement('a');
                finalCard.href = `/detail/${animeData.slug}`;
                finalCard.className = 'anime-card';
                finalCard.style.opacity = 0;

                finalCard.innerHTML = `
                    <div class="img-wrapper placeholder">
                        <img src="${detailData.thumbnail || animeData.thumbnail}" alt="${detailData.title}" class="card-img" loading="lazy">
                    </div>
                    <div class="card-content">
                        <p class="card-title">${detailData.title}</p>
                    </div>`;
                
                cardPlaceholder.replaceWith(finalCard);
                
                const img = finalCard.querySelector('img');
                const imgWrapper = finalCard.querySelector('.img-wrapper');
                
                const onImageLoad = () => {
                    imgWrapper.classList.remove('placeholder');
                    finalCard.style.opacity = 1;
                    finalCard.classList.add('is-visible');
                };

                img.onload = onImageLoad;
                img.onerror = onImageLoad; 
                if (img.complete && img.naturalHeight !== 0) {
                    onImageLoad();
                }
            })
            .catch(() => {
                cardPlaceholder.remove();
            });
    };
    
    const updateLoadMoreButton = () => {
        loadMoreContainer.innerHTML = '';
        if (currentPage < totalPages) {
            const button = document.createElement('button');
            button.textContent = 'Muat Lebih Banyak';
            button.className = 'load-more-btn';
            button.addEventListener('click', () => {
                fetchAndDisplayGenre(currentPage + 1);
            });
            loadMoreContainer.appendChild(button);
        }
    };

    const fetchAndDisplayGenre = async (page) => {
        if (isLoading) return;
        isLoading = true;

        const existingButton = loadMoreContainer.querySelector('button');
        if (existingButton) {
            existingButton.textContent = 'Memuat...';
            existingButton.disabled = true;
        }

        if (page === 1) {
            grid.innerHTML = Array.from({ length: 12 }, () => `
                <div class="anime-card placeholder">
                    <div class="img-wrapper placeholder"></div>
                    <div class="card-content"><div class="placeholder-text short"></div></div>
                </div>`).join('');
            window.scrollTo(0, 0);
        }

        try {
            const response = await fetch(`/api/genre/${genreSlug}?page=${page}`);
            if (!response.ok) throw new Error('Network response was not ok');
            const data = await response.json();
            
            totalPages = data.totalPages || 1;
            currentPage = page;
            
            if (page === 1) {
                grid.innerHTML = ''; 
            }
            
            if (!data.anime || data.anime.length === 0) {
                if (page === 1) {
                    grid.innerHTML = '<p style="text-align: center; grid-column: 1 / -1;">Tidak ada anime untuk genre ini.</p>';
                }
                loadMoreContainer.innerHTML = '';
                return;
            }

            const fragment = document.createDocumentFragment();
            data.anime.forEach(anime => {
                const cardPlaceholder = document.createElement('div');
                cardPlaceholder.className = 'anime-card placeholder';
                cardPlaceholder.innerHTML = `
                    <div class="img-wrapper placeholder"></div>
                    <div class="card-content"><div class="placeholder-text short"></div></div>`;
                fragment.appendChild(cardPlaceholder);
                enrichCard(cardPlaceholder, anime);
            });
            grid.appendChild(fragment);
            
            updateLoadMoreButton();

        } catch (error) {
            if (page === 1) {
                grid.innerHTML = '<p style="text-align: center; grid-column: 1 / -1;">Gagal memuat data. Coba lagi nanti.</p>';
            }
        } finally {
            isLoading = false;
        }
    };
    
    fetchAndDisplayGenre(1);
});
