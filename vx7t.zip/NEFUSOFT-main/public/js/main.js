document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('search-input');
    const searchResults = document.getElementById('search-results');
    const menuButton = document.getElementById('menu-button');
    const sideNav = document.getElementById('side-nav');
    const sideNavOverlay = document.getElementById('side-nav-overlay');
    let bannerInterval;

    const toggleSideNav = () => {
        sideNav.classList.toggle('active');
        sideNavOverlay.classList.toggle('active');
        document.body.classList.toggle('side-nav-active');
    };

    if (menuButton) menuButton.addEventListener('click', toggleSideNav);
    if (sideNavOverlay) sideNavOverlay.addEventListener('click', toggleSideNav);

    const loadGenres = async () => {
        const genreListContainer = document.getElementById('genre-list-container');
        if (!genreListContainer) return;
        try {
            const response = await fetch('/api/genres');
            if (!response.ok) throw new Error('Network response was not ok');
            const genres = await response.json();
            const genreDropdown = document.getElementById('genre-dropdown');
            
            if (genreDropdown && genres.length > 0) {
                genreDropdown.innerHTML = genres.map(genre => {
                    return `<li><a href="/genre/${genre.slug}">${genre.name}<span class="genre-count">(${genre.count})</span></a></li>`;
                }).join('');
            } else {
                genreDropdown.innerHTML = '<li><a>Gagal memuat.</a></li>';
            }
            const genreToggle = document.getElementById('genre-dropdown-toggle');
            if (genreToggle) {
                genreToggle.addEventListener('click', (e) => {
                    e.preventDefault();
                    genreListContainer.classList.toggle('open');
                });
            }
        } catch (error) {
            const genreDropdown = document.getElementById('genre-dropdown');
            if (genreDropdown) genreDropdown.innerHTML = '<li><a>Gagal memuat.</a></li>';
        }
    };
    
    const buildBanner = (bannerData) => {
        const bannerSection = document.querySelector('.banner-section');
        const contentWrapper = document.getElementById('banner-content-wrapper');
        const imageWrapper = document.getElementById('banner-image-wrapper');
        const indicatorsWrapper = document.getElementById('banner-indicators');
        
        if (!bannerData || bannerData.length === 0) return;
        
        bannerSection.classList.remove('placeholder');
        
        imageWrapper.innerHTML = bannerData.map(banner => `<div class="banner-image-slide" style="background-image: url('${banner.bannerImageForHome}')"></div>`).join('');
        contentWrapper.innerHTML = bannerData.map(banner => {
            const firstEpisode = banner.episodes && banner.episodes.length > 0 ? banner.episodes[0].episodeNum : 1;
            const genres = (banner.information.kategori || "").split(",").map(g => `<span class="genre">${g.trim()}</span>`).join("");
            return `<div class="banner-content"><h1 class="anime-title">${banner.title}</h1><div class="anime-details-banner"><span>${banner.information.studio?.replace(/,/g, '') || 'N/A'}</span> • <span>${banner.information.type || 'N/A'}</span> • <span>${banner.information.musim_rilis || 'N/A'}</span></div><div class="anime-genres">${genres}</div><div class="banner-buttons"><a href="/stream/${banner.slug}/episode-${firstEpisode}" class="banner-button watch"><span class="material-icons">play_arrow</span> Watch Now</a><a href="/detail/${banner.slug}" class="banner-button detail"><span class="material-icons">info</span> Detail</a></div></div>`;
        }).join('');
        
        indicatorsWrapper.innerHTML = bannerData.map(() => '<span></span>').join('');

        const imageSlides = imageWrapper.querySelectorAll('.banner-image-slide');
        const contentSlides = contentWrapper.querySelectorAll('.banner-content');
        const indicators = indicatorsWrapper.querySelectorAll('span');
        let currentBannerIndex = 0;
        
        if (imageSlides.length > 0) {
            const slides = [imageSlides, contentSlides];
            
            const updateBanner = () => {
                const nextBannerIndex = (currentBannerIndex + 1) % imageSlides.length;

                slides.forEach(slideSet => {
                    slideSet[currentBannerIndex].classList.add('previous');
                    slideSet[nextBannerIndex].classList.remove('previous');
                    slideSet[nextBannerIndex].classList.add('active');
                });
                
                indicators[currentBannerIndex].classList.remove('active');
                indicators[nextBannerIndex].classList.add('active');

                setTimeout(() => {
                    slides.forEach(slideSet => {
                         slideSet[currentBannerIndex].classList.remove('active');
                         slideSet[currentBannerIndex].classList.remove('previous');
                    });
                    currentBannerIndex = nextBannerIndex;
                }, 1200);
            };
            
            slides.forEach(slideSet => slideSet[0].classList.add('active'));
            indicators[0].classList.add('active');
            
            clearInterval(bannerInterval);
            if (imageSlides.length > 1) bannerInterval = setInterval(updateBanner, 5000);
        }
    };

    const enrichCard = (cardPlaceholder, animeData) => {
        fetch(`/api/detail/${animeData.slug}`)
            .then(response => response.ok ? response.json() : Promise.reject())
            .then(detailData => {
                const finalCard = document.createElement('a');
                finalCard.href = `/detail/${animeData.slug}`;
                finalCard.className = 'anime-card';
                finalCard.innerHTML = `
                    <div class="img-wrapper placeholder">
                        <img src="${detailData.thumbnail || animeData.thumbnail}" alt="${detailData.title}" class="card-img" loading="lazy">
                    </div>
                    <div class="card-content">
                        <p class="card-title">${detailData.title}</p>
                        <span class="card-episodes">${animeData.latestEpisode || 'N/A'}</span>
                    </div>`;
                
                cardPlaceholder.replaceWith(finalCard);
                
                const img = finalCard.querySelector('img');
                const imgWrapper = finalCard.querySelector('.img-wrapper');
                img.onload = () => imgWrapper.classList.remove('placeholder');
                img.onerror = () => imgWrapper.classList.remove('placeholder');
                if (img.complete && img.naturalHeight !== 0) {
                    imgWrapper.classList.remove('placeholder');
                }
                finalCard.classList.add('is-visible');
            })
            .catch(() => {
                cardPlaceholder.remove();
            });
    };

    const buildOngoing = (ongoingData) => {
        const ongoingGrid = document.getElementById('ongoing-grid');
        if (!ongoingGrid) return;
        ongoingGrid.innerHTML = ongoingData.map(anime => `
            <div class="anime-card placeholder" id="card-${anime.slug}">
                <div class="img-wrapper placeholder"></div>
                <div class="card-content">
                   <div class="placeholder-text short"></div>
                   <div class="placeholder-text tiny"></div>
                </div>
            </div>`).join('');
        
        ongoingData.forEach(anime => {
            const cardPlaceholder = document.getElementById(`card-${anime.slug}`);
            if (cardPlaceholder) enrichCard(cardPlaceholder, anime);
        });
    };

    const loadAndDisplayQuote = async () => {
        const quoteSection = document.getElementById('quote-section');
        if (!quoteSection) return;
        try {
            const response = await fetch('/api/random-quote');
            if (!response.ok) return;
            const data = await response.json();
            const html = `
                <div class="quote-wrapper">
                    <div class="quote-img-placeholder placeholder">
                         <img src="${data.foto}" alt="${data.nama}" class="quote-char-img" loading="lazy">
                    </div>
                    <div class="quote-text-content">
                        <p class="quote-text">"${data.quote}"</p>
                        <p class="quote-char-name">- ${data.nama}</p>
                    </div>
                </div>`;
            quoteSection.innerHTML = html;
            const newImage = quoteSection.querySelector('.quote-char-img');
            if(newImage) {
                newImage.onload = () => newImage.parentElement.classList.remove('placeholder');
                if(newImage.complete) newImage.parentElement.classList.remove('placeholder');
            }
        } catch (error) {
        }
    };
    
    const loadHomePageData = async () => {
        try {
            const response = await fetch('/api/home-data');
            const data = await response.json();
            buildBanner(data.bannerData);
            buildOngoing(data.ongoingData);
        } catch (error) {
            document.getElementById('ongoing-grid').innerHTML = '<p>Gagal memuat data. Coba lagi nanti.</p>';
            document.querySelector('.banner-section').classList.remove('placeholder');
        }
    };
    
    if (document.body.classList.contains('anime-page')) {
        loadHomePageData();
        loadGenres();
        loadAndDisplayQuote();
    }

    let searchTimeout;
    const handleSearch = async (query) => {
        try {
            const response = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
            const data = await response.json();
            searchResults.innerHTML = data.length > 0 
                ? data.map(anime => `<a href="/detail/${anime.slug}" class="search-result-item"><img src="${anime.thumbnail}" loading="lazy"><div><p>${anime.title}</p></div></a>`).join('') 
                : '<div class="search-result-item"><p>Tidak ada hasil.</p></div>';
        } catch (error) { 
            searchResults.innerHTML = '<div class="search-result-item"><p>Error pencarian.</p></div>'; 
        }
    };
    
    searchInput.addEventListener('input', () => {
        clearTimeout(searchTimeout);
        const query = searchInput.value.trim();
        if (query.length < 1) {
            searchResults.classList.remove('visible');
            return;
        }
        searchResults.classList.add('visible');
        searchResults.innerHTML = '<div class="search-result-item"><p>Mencari...</p></div>';
        searchTimeout = setTimeout(() => handleSearch(query), 300);
    });
    
    searchInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            const query = searchInput.value.trim();
            if (query) {
                window.location.href = '/search?q=' + encodeURIComponent(query);
            }
        }
    });

    document.addEventListener('click', (e) => {
        if (searchResults && !e.target.closest('.search-container')) {
            searchResults.classList.remove('visible');
        }
    });
});
