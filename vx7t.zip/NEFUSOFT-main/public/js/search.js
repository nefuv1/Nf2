document.addEventListener('DOMContentLoaded', () => {
    if (typeof searchQuery === 'undefined' || !searchQuery) return;

    const grid = document.getElementById('search-grid');
    const section = document.getElementById('search-result-section');

    const enrichCard = (cardPlaceholder, animeData) => {
        fetch(`/api/detail/${animeData.slug}`)
            .then(response => response.ok ? response.json() : Promise.reject())
            .then(detailData => {
                const finalCard = document.createElement('a');
                finalCard.href = `/detail/${animeData.slug}`;
                finalCard.className = 'anime-card is-visible';
                finalCard.innerHTML = `
                    <div class="img-wrapper placeholder">
                        <img src="${detailData.thumbnail || animeData.thumbnail}" alt="${detailData.title}" class="card-img" loading="lazy">
                    </div>
                    <div class="card-content">
                        <p class="card-title">${detailData.title}</p>
                    </div>`;
                
                cardPlaceholder.replaceWith(finalCard);
                
                const img = finalCard.querySelector('img');
                const imgWrapper = finalCard.querySelector('.img-wrapper');
                img.onload = () => imgWrapper.classList.remove('placeholder');
                img.onerror = () => imgWrapper.classList.remove('placeholder');
                if (img.complete && img.naturalHeight !== 0) imgWrapper.classList.remove('placeholder');
            })
            .catch(() => {
                cardPlaceholder.remove();
            });
    };

    const fetchAndDisplayResults = async () => {
        try {
            const response = await fetch(`/api/search?q=${encodeURIComponent(searchQuery)}`);
            if (!response.ok) throw new Error('Network response was not ok');
            const data = await response.json();

            if (data.length === 0) {
                section.innerHTML = `
                    <div class="no-results-container">
                        <img src="https://nefyu.my.id/dbnl.png" alt="Tidak ditemukan">
                        <h1>Hasil untuk "${searchQuery}" tidak ditemukan.</h1>
                    </div>`;
                return;
            }

            grid.innerHTML = data.map((anime, index) => `
                <div class="anime-card placeholder" id="search-card-${index}">
                    <div class="img-wrapper placeholder"></div>
                    <div class="card-content">
                       <div class="placeholder-text short"></div>
                    </div>
                </div>`).join('');
            
            data.forEach((anime, index) => {
                const cardPlaceholder = document.getElementById(`search-card-${index}`);
                if (cardPlaceholder) enrichCard(cardPlaceholder, anime);
            });

        } catch (error) {
            section.innerHTML = '<p style="text-align: center; width: 100%;">Gagal memuat hasil pencarian. Coba lagi nanti.</p>';
        }
    };

    fetchAndDisplayResults();
});
