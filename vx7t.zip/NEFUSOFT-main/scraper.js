const axios = require('axios');
const cheerio = require('cheerio');
const { URL } = require('url');
const PRIMARY_SOURCE_URL = process.env.NEFUSOFT_URL;
const COVER_SOURCE_URL = process.env.NEFUSOFT_COVER;

const fetchHTML = async (url) => {
    try {
        const { data, request } = await axios.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
        return { data, finalUrl: request.res.responseUrl || url };
    } catch (error) {
        console.error(`[SCRAPER ERROR] Gagal mengambil HTML dari: ${url}`, error.message);
        return null;
    }
};

const getExternalCover = async (primaryTitle, alternativeTitle) => {
    const trySearch = async (title) => {
        if (!title || !COVER_SOURCE_URL) return null;
        try {
            const searchUrl = `${COVER_SOURCE_URL}/search?q=${encodeURIComponent(title)}`;
            const searchResult = await fetchHTML(searchUrl);
            if (!searchResult || !searchResult.data) return null;
            
            const $s = cheerio.load(searchResult.data);
            const detailPath = $s('section h2.headerA:contains("Anime")').first().next('ul.covers').find('li a.anime-item').first().attr('href');
            if (!detailPath) return null;

            const detailUrl = new URL(detailPath, COVER_SOURCE_URL).toString();
            const detailResult = await fetchHTML(detailUrl);
            if (!detailResult || !detailResult.data) return null;

            const $d = cheerio.load(detailResult.data);
            const coverImg = $d('#details-cover');
            return coverImg.attr('data-src') || coverImg.attr('src') || null;
        } catch (e) {
            console.warn(`[SCRAPER WARN] Gagal mencari cover untuk judul: "${title}"`, e.message);
            return null;
        }
    };
    
    const altTitleFirstPart = (alternativeTitle || "").split(/[,.]/)[0].trim();
    let coverUrl = await trySearch(altTitleFirstPart);
    if (!coverUrl) {
        coverUrl = await trySearch(primaryTitle);
    }
    return coverUrl;
};

const scrapeListPage = async (url) => {
    const result = await fetchHTML(url);
    if (!result) return { anime: [], totalPages: 1 };
    
    const { data } = result;
    const $ = cheerio.load(data);
    
    const anime = [];
    $('.archive-a article').each((i, el) => {
        const titleElement = $(el).find('h2 a');
        const imgElement = $(el).find('.thumbnail img');
        
        anime.push({
            title: titleElement.text().trim(),
            detailUrl: titleElement.attr('href'),
            thumbnail: imgElement.attr('src') || imgElement.attr('data-src'),
        });
    });

    let totalPages = 1;
    const paginationLinks = $('.pagination a');
    if (paginationLinks.length > 0) {
        let maxPage = 1;
        paginationLinks.each((i, el) => {
            const pageNumText = $(el).text().trim();
            const pageNum = parseInt(pageNumText, 10);
            if (!isNaN(pageNum) && pageNum > maxPage) {
                maxPage = pageNum;
            }
        });
        totalPages = maxPage;
    }
    
    return { anime, totalPages };
};

const scrapeOngoing = async () => {
    const result = await fetchHTML(`${PRIMARY_SOURCE_URL}/anime-terbaru-sub-indo/`);
    if (!result) return {};
    const $ = cheerio.load(result.data);
    const ongoingData = {};
    $('.rilis_ongoing .wrapper-3, .schedule-widget .post-3').each((i, dayElement) => {
        const day = $(dayElement).find('h3.title').text().trim();
        let animeList = [];
        $(dayElement).find('article').each((j, el) => {
            const img = $(el).find('.thumbnail img');
            animeList.push({
                title: $(el).find('h3 a').text().trim(),
                detailUrl: $(el).find('h3 a').attr('href'),
                latestEpisode: $(el).find('.eps_ongo').text().trim(),
                thumbnail: img.attr('data-src') || img.attr('src'),
            });
        });
        if (day && animeList.length > 0) {
            ongoingData[day.toLowerCase().replace("'",'')] = animeList;
        }
    });
    return ongoingData;
};

const scrapeGenres = async () => {
    const result = await fetchHTML(`${PRIMARY_SOURCE_URL}/genre-category-list/`);
    if (!result) return [];
    const $ = cheerio.load(result.data);
    const genres = [];
    $('.terms_all a').each((i, el) => {
        const fullText = $(el).text().trim();
        const url = $(el).attr('href');
        if (!fullText || !url) return;

        const match = fullText.match(/(.+) \((\d+)\)/);
        if (match) {
            genres.push({
                name: match[1].trim(),
                slug: url.split('/').filter(Boolean).pop(),
                count: parseInt(match[2], 10)
            });
        }
    });
    return genres;
};

const scrapeStreamData = async (detailPageUrl, episodeNum) => {
    const detailResult = await fetchHTML(detailPageUrl);
    if (!detailResult || !detailResult.data) {
        console.error(`[SCRAPER ERROR] Could not fetch detail page for streams: ${detailPageUrl}`);
        return null;
    }
    
    const $ = cheerio.load(detailResult.data);
    let episodeToScrape = null;

    $('.download_box .download > h4').each((i, el) => {
        const currentTitle = $(el).text().trim();
        const currentEpNumMatch = currentTitle.match(/Episode\s*(\d+(\.\d+)?)/i);
        const currentEpNum = currentEpNumMatch ? parseFloat(currentEpNumMatch[1]) : null;

        if (currentEpNum == episodeNum) {
            episodeToScrape = {
                episodeTitle: currentTitle.replace(' Sub Indo', ''),
                escapedTitle: currentTitle.replace(' Sub Indo', '').replace(/"/g, '\\"'),
                episodeNum: currentEpNum
            };
            return false;
        }
    });

    if (!episodeToScrape) {
        console.error(`[SCRAPER ERROR] Episode ${episodeNum} not found on page ${detailPageUrl}`);
        return null;
    }
    
    const streamDataBase64 = $(`.streaming_eps_box .list_eps_stream li[title*="${episodeToScrape.escapedTitle}"]`).attr('data');
    
    if (!streamDataBase64) {
        console.error(`[SCRAPER ERROR] No stream data found for: ${episodeToScrape.episodeTitle}`);
        return { ...episodeToScrape, streams: [] };
    }

    try {
        const decoded = Buffer.from(streamDataBase64, 'base64').toString('utf-8');
        const resolutionLinks = JSON.parse(decoded);
        const streams = await Promise.all(resolutionLinks.map(async (resLink) => {
            const streamingPageUrl = resLink.url[0];
            if (!streamingPageUrl) return null;

            console.log(`[SCRAPER LOG] Found intermediate stream page: ${streamingPageUrl}`);
            const streamingPageResult = await fetchHTML(streamingPageUrl);

            if (!streamingPageResult || !streamingPageResult.data) {
                console.log(`[SCRAPER WARN]   => Failed to fetch content from the intermediate page.`);
                return null;
            }

            const $streamPage = cheerio.load(streamingPageResult.data);
            const providers = $streamPage('.daftar_server ul li').map((idx, liEl) => {
                const providerName = $streamPage(liEl).text().trim();
                const videoUrl = $streamPage(liEl).attr('data-url');
                if (videoUrl) {
                    console.log(`[SCRAPER LOG]   => Found final .mp4 URL (${providerName}): ${videoUrl}`);
                    return { provider: providerName, url: videoUrl };
                }
                return null;
            }).get().filter(Boolean);

            if (providers.length === 0) {
                console.log(`[SCRAPER WARN]   => No final URLs found on page: ${streamingPageUrl}`);
            }

            return { resolution: resLink.format, providers };
        }));
        
        return { ...episodeToScrape, streams: streams.filter(s => s && s.providers.length > 0) };
    } catch (e) {
        console.error(`[SCRAPER ERROR] Failed to process stream data for "${episodeToScrape.episodeTitle}":`, e);
        return { ...episodeToScrape, streams: [] };
    }
};

const scrapeDetail = async (url) => {
    const result = await fetchHTML(url);
    if (!result) return null;
    const { data, finalUrl } = result;
    const $ = cheerio.load(data);
    const detail = {};
    
    detail.url = finalUrl;
    
    const info = {};
    $('.info2 table tr').each((i, el) => {
        const key = $(el).find('td.tablex').text().split(':')[0].trim().toLowerCase().replace(/[\s/]+/g, '_');
        const value = $(el).find('td:not(.tablex)').text().trim() || $(el).find('td:not(.tablex) a').text().trim();
        if (key && value) info[key] = value;
    });
    detail.information = info;
    
    detail.title = info.judul || $('h1.title').text().trim().replace(/ Sub Indo : Episode.*$/, '');
    detail.synopsis = $('#Sinopsis p').map((i, el) => $(el).text().trim()).get().join('\n\n');
    
    const releaseInfo = {};
    $('.single .info ul li').each((i, el) => {
        const icon = $(el).find('i').attr('class');
        if (icon && icon.includes('fa-calendar-alt')) releaseInfo.date = $(el).text().trim();
        if (icon && icon.includes('fa-clock')) releaseInfo.time = $(el).text().trim();
    });
    detail.releaseInfo = releaseInfo;

    const episodes = $('.download_box .download > h4').map((i, el) => {
        const episodeTitle = $(el).text().trim().replace(' Sub Indo', '');
        const episodeNumMatch = episodeTitle.match(/Episode\s*(\d+(\.\d+)?)/i);
        const episodeNum = episodeNumMatch ? parseFloat(episodeNumMatch[1]) : i + 1;
        return { episodeNum, episodeTitle };
    }).get();
    
    detail.episodes = episodes.sort((a,b) => a.episodeNum - b.episodeNum);

    const externalCover = await getExternalCover(info.judul, info.judul_alternatif);
    const primaryPosterImg = $('.coverthumbnail img');
    const primaryPoster = primaryPosterImg.attr('data-src') || primaryPosterImg.attr('src') || '';
    const primaryBannerImg = $('.thumbnail-a img');
    const primaryBanner = primaryBannerImg.attr('data-src') || primaryBannerImg.attr('src') || '';

    detail.thumbnail = externalCover || primaryPoster || '';
    detail.bannerImageForHome = externalCover || primaryBanner || primaryPoster || '';
    detail.bannerImageForDetail = primaryBanner || externalCover || primaryPoster || '';
    
    return detail;
};

const scrapeRandomQuote = async () => {
    try {
        const randomPage = Math.floor(Math.random() * 150) + 1;
        const url = `https://otakotaku.com/quote/feed/${randomPage}`;
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);
        const quotes = [];

        $('.kotodama-list').each((index, element) => {
            const quoteElement = $(element);
            const img = quoteElement.find('.kotodama-char .char-img img');
            quotes.push({
                foto: img.attr('data-src') || img.attr('src'),
                quote: quoteElement.find('.kotodama-content .quote').text().trim(),
                nama: quoteElement.find('.kotodama-char .char-info .char-name').text().trim()
            });
        });

        if (quotes.length === 0) return null;
        const randomIndex = Math.floor(Math.random() * quotes.length);
        return quotes[randomIndex];

    } catch (error) {
        return null;
    }
};

module.exports = { scrapeOngoing, scrapeListPage, scrapeDetail, scrapeGenres, scrapeRandomQuote, scrapeStreamData };
