/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');

const PASTEBIN_API_KEY = 'gRMUACB9zrW6bbsttUFfSuw2C_pYYzPl';
const PASTEBIN_API_URL = 'https://pastebin.com/api/api_post.php';

async function uploadToPastebin(code, title = 'Untitled') {
    try {
        if (!code || code.trim() === '') {
            return { success: false, error: 'Code cannot be empty!' };
        }

        const params = new URLSearchParams();
        params.append('api_dev_key', PASTEBIN_API_KEY);
        params.append('api_option', 'paste');
        params.append('api_paste_code', code);
        params.append('api_paste_private', '0');
        params.append('api_paste_name', title);
        params.append('api_paste_expire_date', '10M');
        params.append('api_paste_format', 'text');

        const response = await axios.post(PASTEBIN_API_URL, params);
        const data = response.data;

        if (data.includes('https://pastebin.com/')) {
            const pasteId = data.split('/').pop();
            const rawUrl = `https://pastebin.com/raw/${pasteId}`;
            return { success: true, url: data, raw: rawUrl };
        } else {
            return { success: false, error: data };
        }
    } catch (err) {
        return { success: false, error: err.response ? err.response.data : err.message };
    }
}

module.exports = {
    help: ['pastebin'],
    tags: 'utility',
    use: '/developer/',
    aliases: ['paste'],
    run: async (m, { text, conn, usedPrefix, command, Func }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingPastebin = user.isProcessingPastebin || false;

        if (user.isProcessingPastebin) throw global.status.previously;

        try {
            if (!text) throw `Please provide script.\n\n*Example* : ${usedPrefix + command} console.log('Hello, world!');`;

            user.isProcessingPastebin = true;
            conn.sendReact(m.chat, global.react, m.key);

            const { success, url, raw, error } = await uploadToPastebin(text, 'Code Upload');

            if (success) {
                m.reply(`${raw}`);
            } else {
                throw error;
            }

        } catch (e) {
            throw Func.jsonFormat(e);
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingPastebin = false;
            }
        }
    }
};