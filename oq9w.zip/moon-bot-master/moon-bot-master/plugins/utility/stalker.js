/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const fetch = require('node-fetch')
const axios = require('axios')
const cheerio = require('cheerio')

// Roblox Stalker
const robloxInfo = async (username) => {
    try {
        const fetchJson = async function (url, options) {
            return (await fetch(url, options)).json();
        };

        const getUsernameData = async function () {
            return fetchJson("https://users.roblox.com/v1/usernames/users", {
                method: "POST",
                body: JSON.stringify({ "usernames": [username] }),
                headers: { "Content-Type": "application/json" }
            });
        };

        const getUserData = async function (id) {
            return fetchJson("https://users.roblox.com/v1/users/" + id);
        };
        
        const getProfile = async function (id) {
            return fetchJson("https://thumbnails.roblox.com/v1/users/avatar?userIds=" + id + "&size=720x720&format=Png&isCircular=false");
        };

        const getPresenceData = async function (id) {
            return fetchJson("https://presence.roblox.com/v1/presence/users", {
                method: "POST",
                body: JSON.stringify({ "userIds": [parseInt(id)] }),
                headers: { "Content-Type": "application/json" }
            });
        };

        const { data } = await getUsernameData();
        if (!data || data.length === 0) throw 'User not found!';
        
        const id = data[0].id;
        const userDetails = await getUserData(id);
        const profileDetails = (await getProfile(id)).data[0].imageUrl;
        const lastOnline = (await getPresenceData(id)).userPresences[0].lastOnline;

        return { userDetails, lastOnline, profileDetails };
    } catch (error) {
        throw error.message || 'Failed to fetch Roblox data';
    }
};

// TikTok Stalker
function formatNumber(number) {
    if (number >= 1e6) return (number / 1e6).toFixed(1).replace(/\.0$/, '') + 'm';
    if (number >= 1e3) return (number / 1e3).toFixed(1).replace(/\.0$/, '') + 'k';
    return number.toString();
}

async function tiktokStalk(username) {
    try {
        const response = await axios.get(`https://www.tiktok.com/@${username}?_t=ZS-8tHANz7ieoS&_r=1`);
        const html = response.data;
        const $ = cheerio.load(html);
        const scriptData = $('#__UNIVERSAL_DATA_FOR_REHYDRATION__').html();
        const parsedData = JSON.parse(scriptData);

        const userDetail = parsedData.__DEFAULT_SCOPE__?.['webapp.user-detail'];
        if (!userDetail) {
            throw new Error('User not found');
        }

        const userInfo = userDetail.userInfo?.user;
        const stats = userDetail.userInfo?.stats;

        const metadata = {
            userInfo: {
                id: userInfo?.id || null,
                username: userInfo?.uniqueId || null,
                nama: userInfo?.nickname || null,
                avatar: userInfo?.avatarLarger || null,
                bio: userInfo?.signature || null,
                verifikasi: userInfo?.verified || false,
                totalfollowers: stats?.followerCount || 0,
                totalmengikuti: stats?.followingCount || 0,
                totaldisukai: stats?.heart || 0,
                totalvideo: stats?.videoCount || 0,
                totalteman: stats?.friendCount || 0,
            }
        };

        return metadata;
    } catch (error) {
        throw error.message || 'Failed to fetch TikTok data';
    }
}

// NPM Stalker
async function npmstalk(packageName) {
  let stalk = await axios.get("https://registry.npmjs.org/"+packageName)
  let versions = stalk.data.versions
  let allver = Object.keys(versions)
  let verLatest = allver[allver.length-1]
  let verPublish = allver[0]
  let packageLatest = versions[verLatest]
  return {
    name: packageName,
    versionLatest: verLatest,
    versionPublish: verPublish,
    versionUpdate: allver.length,
    latestDependencies: Object.keys(packageLatest.dependencies).length,
    publishDependencies: Object.keys(versions[verPublish].dependencies).length,
    publishTime: stalk.data.time.created,
    latestPublishTime: stalk.data.time[verLatest]
  }
}

// GitHub Stalker
async function githubStalk(username) {
    let Quer = username.replace("https://github.com/", "").replace("@", "")
    const res = await axios.get(`https://api.github.com/users/${Quer}`)
    
    let {
     login, 
     type,
     name,
     followers, 
     following, 
     created_at, 
     updated_at,
     public_gists,
     public_repos,
     twitter_username,
     bio,
     hireable,
     email,
     location, 
     blog,
     company,
     avatar_url,
     html_url
    } = res.data
    
    return {
        login,
        type,
        name,
        followers, 
        following, 
        created_at, 
        updated_at,
        public_gists,
        public_repos,
        twitter_username,
        bio,
        hireable,
        email,
        location, 
        blog,
        company,
        avatar_url,
        html_url
    }
}

module.exports = {
  help: ['stalker'],
  aliases: ['stalk'],
  tags: 'utility',
  run: async (m, { conn, usedPrefix, command, text, Func }) => {
    if (!text) {
        const list = `*Type* :\n\n1. Roblox\n2. TikTok\n3. NPM\n4. GitHub\n\n*Example* : ${usedPrefix + command} roblox TechBOT`;
        throw list;
    }
    
    const [type, ...usernameParts] = text.split(' ');
    const username = usernameParts.join(' ');
    
    if (!username) throw `Please provide username.\n\n*Example* : ${usedPrefix + command} roblox TechBOT`;
    
    try {
        m.react(global.react)
        
        let result, caption, thumbnail, profileUrl;
        
        switch(type.toLowerCase()) {
            case 'roblox':
                const robloxData = await robloxInfo(username);
                const lastOnlineDate = new Date(robloxData.lastOnline).toLocaleString();
                const createdDate = new Date(robloxData.userDetails.created).toLocaleString();
                
                caption = `*STALKER* (roblox profile)\n\n` +
                    `- *Username* : ${robloxData.userDetails.name}\n` +
                    `- *Display Name* : ${robloxData.userDetails.displayName || robloxData.userDetails.name}\n` +
                    `- *User ID* : ${robloxData.userDetails.id}\n` +
                    `- *Description* : ${robloxData.userDetails.description || 'No description'}\n\n` +
                    `*PROFILE INFO*\n\n` +
                    `- *Banned* : ${robloxData.userDetails.isBanned ? 'Yes' : 'No'}\n` +
                    `- *Verified* : ${robloxData.userDetails.hasVerifiedBadge ? 'Yes' : 'No'}\n` +
                    `- *Created* : ${createdDate}\n` +
                    `- *Last Online* : ${lastOnlineDate}\n\n` +
                    `https://www.roblox.com/users/${robloxData.userDetails.id}/profile`;
                
                thumbnail = robloxData.profileDetails;
                profileUrl = `https://www.roblox.com/users/${robloxData.userDetails.id}/profile`;
                break;
                
            case 'tiktok':
                const tiktokData = await tiktokStalk(username);
                
                caption = `*STALKER* (tiktok profile)\n\n` +
                    `- *Username* : ${tiktokData.userInfo.username}\n` +
                    `- *Name* : ${tiktokData.userInfo.nama}\n` +
                    `- *Bio* : ${tiktokData.userInfo.bio || '-'}\n` +
                    `- *Verified* : ${tiktokData.userInfo.verifikasi ? 'Yes' : 'No'}\n\n` +
                    `*STATISTICS*\n\n` +
                    `- *Followers* : ${formatNumber(tiktokData.userInfo.totalfollowers)}\n` +
                    `- *Following* : ${formatNumber(tiktokData.userInfo.totalmengikuti)}\n` +
                    `- *Likes* : ${formatNumber(tiktokData.userInfo.totaldisukai)}\n` +
                    `- *Videos* : ${tiktokData.userInfo.totalvideo}\n` +
                    `- *Friends* : ${tiktokData.userInfo.totalteman}\n\n` +
                    `https://www.tiktok.com/@${tiktokData.userInfo.username}`;
                
                thumbnail = tiktokData.userInfo.avatar;
                profileUrl = `https://www.tiktok.com/@${tiktokData.userInfo.username}`;
                break;
                
            case 'npm':
                const npmData = await npmstalk(username);
                
                caption = `*STALKER* (npm package)\n\n` +
                    `- *Package Name* : ${npmData.name}\n` +
                    `- *Latest Version* : ${npmData.versionLatest}\n` +
                    `- *First Version* : ${npmData.versionPublish}\n` +
                    `- *Total Versions* : ${npmData.versionUpdate}\n\n` +
                    `*DEPENDENCIES*\n\n` +
                    `- *Latest* : ${npmData.latestDependencies}\n` +
                    `- *First* : ${npmData.publishDependencies}\n\n` +
                    `*TIMELINE*\n\n` +
                    `- *Published* : ${new Date(npmData.publishTime).toLocaleString()}\n` +
                    `- *Last Update* : ${new Date(npmData.latestPublishTime).toLocaleString()}\n\n` +
                    `https://www.npmjs.com/package/${npmData.name}`;
                
                thumbnail = 'https://static.npmjs.com/338e4905a2684ca96e08c7780fc68412.png';
                profileUrl = `https://www.npmjs.com/package/${npmData.name}`;
                break;
                
            case 'github':
                const githubData = await githubStalk(username);
                
                caption = `*STALKER* (github profile)\n\n` +
                    `- *Username* : ${githubData.login}\n` +
                    `- *Name* : ${githubData.name}\n` +
                    `- *Type* : ${githubData.type}\n` +
                    `- *Bio* : ${githubData.bio || 'No bio'}\n\n` +
                    `*STATISTICS*\n\n` +
                    `- *Followers* : ${githubData.followers}\n` +
                    `- *Following* : ${githubData.following}\n` +
                    `- *Public Repos* : ${githubData.public_repos}\n` +
                    `- *Public Gists* : ${githubData.public_gists}\n\n` +
                    `*CONTACT*\n\n` +
                    `- *Email* : ${githubData.email || 'Not set'}\n` +
                    `- *Location* : ${githubData.location || 'Not set'}\n` +
                    `- *Blog* : ${githubData.blog || 'Not set'}\n` +
                    `- *Twitter* : ${githubData.twitter_username || 'Not set'}\n\n` +
                    `${githubData.html_url}`;
                
                thumbnail = githubData.avatar_url;
                profileUrl = githubData.html_url;
                break;
                
            default:
                throw `Type "${type}" not found!\n\nAvailable : roblox, tiktok, npm, github`;
        }
        
        await conn.sendMessageModify(m.chat, caption, m, {
            largeThumb: true,
            thumbnail: thumbnail,
            contextInfo: {
                externalAdReply: {
                    title: `${type.toUpperCase()} • ${username}`,
                    body: '',
                    mediaType: 1,
                    thumbnail: thumbnail,
                    sourceUrl: profileUrl
                }
            }
        });
        
    } catch (e) {
        throw Func.jsonFormat(e);
    }
  }
};