/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const { Converter } = new (require('@znan/wabot'))
const { readFileSync: read, unlinkSync: remove, writeFileSync: create } = require('fs')
const path = require('path')
const { exec } = require('child_process')
const { tmpdir } = require('os')

module.exports = {
   help: ['tomp3', 'tovn'],
   tags: 'utility',
   run: async (m, { conn, command, Func }) => {
      let user = global.db.users[m.sender] || {};
      user.isProcessingTomp3 = user.isProcessingTomp3 || false;

      if (user.isProcessingTomp3) throw global.status.previously;

      try {
         user.isProcessingTomp3 = true;

         if (m.quoted && typeof m.quoted.buttons != 'undefined' && typeof m.quoted.videoMessage != 'undefined') {
            conn.sendReact(m.chat, global.react, m.key)
            const media = await conn.saveMediaMessage(m.quoted.videoMessage)
            const result = Func.filename('mp3')
            exec(`ffmpeg -i ${media} ${result}`, async (err, stderr, stdout) => {
               remove(media)
               if (err) return m.reply('Conversion failed.')
               let buff = read(result)
               if (/tomp3|toaudio/.test(command)) return conn.sendFile(m.chat, buff, 'audio.mp3', '', m).then(() => {
                  remove(result)
               })
               if (/tovn/.test(command)) return conn.sendFile(m.chat, buff, 'audio.mp3', '', m, {
                  ptt: true
               }).then(() => {
                  remove(result)
               })
            })
         } else {
            let q = m.quoted ? m.quoted : m
            let mime = ((m.quoted ? m.quoted : m.msg).mimetype || '')
            if (/ogg/.test(mime)) {
               conn.sendReact(m.chat, global.react, m.key)
               let buffer = await q.download()
               const media = path.join(tmpdir(), Func.filename('mp3'))
               let save = create(media, buffer)
               const result = Func.filename('mp3')
               exec(`ffmpeg -i ${media} ${result}`, async (err, stderr, stdout) => {
                  remove(media)
                  if (err) return m.reply('Conversion failed.')
                  let buff = read(result)
                  if (/tomp3|toaudio/.test(command)) return conn.sendFile(m.chat, buff, 'audio.mp3', '', m).then(() => {
                     remove(result)
                  })
                  if (/tovn/.test(command)) return conn.sendFile(m.chat, buff, 'audio.mp3', '', m, {
                     ptt: true
                  }).then(() => {
                     remove(result)
                  })
               })
            } else if (/audio|video/.test(mime)) {
               conn.sendReact(m.chat, global.react, m.key)
               const buff = await Converter.toAudio(await q.download(), 'mp3')
               if (/tomp3|toaudio/.test(command)) return conn.sendFile(m.chat, buff, 'audio.mp3', '', m)
               if (/tovn/.test(command)) return conn.sendFile(m.chat, buff, 'audio.mp3', '', m, {
                  ptt: true
               })
            } else {
               throw 'Please reply to audio / vn with command.'
            }
         }
      } catch (e) {
         throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingTomp3 = false;
         }
      }
   }
}