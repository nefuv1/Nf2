/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios')
const userSessions = new Map()

class DropMail {
  constructor() {
    this.API = 'https://dropmail.me/api/graphql/web-test-wgq6m5i'
    this.INTERVAL = 10000
    this.id = ''
    this.email = ''
    this.done = new Set()
    this.loop = null
  }

  async create() {
    const q = `mutation { introduceSession { id expiresAt addresses { address } } }`
    const r = await axios.get(`${this.API}?query=${encodeURIComponent(q)}`)
    const s = r.data.data.introduceSession
    this.id = s.id
    this.email = s.addresses[0].address
    return { id: s.id, email: this.email, exp: s.expiresAt }
  }

  async inbox() {
    const q = `query ($id: ID!) { session(id:$id){addresses{address}mails{id fromAddr headerSubject text}}}`
    const v = { id: this.id }
    const r = await axios.get(`${this.API}?query=${encodeURIComponent(q)}&variables=${encodeURIComponent(JSON.stringify(v))}`)
    const d = r.data.data.session
    const mails = d.mails.filter(m => !this.done.has(m.id))
    return { email: d.addresses[0].address, mails, count: mails.length }
  }

  monitor(conn, jid, m) {
    this.loop = setInterval(async () => {
      try {
        const { mails } = await this.inbox()
        for (const mail of mails) {
          let msg = `*DROPMAIL* (message)\n\n- *From* : ${mail.fromAddr}\n- *Subject* : ${mail.headerSubject}\n\n`
          const otp = mail.text.match(/\b\\d{4,6}\b/)
          if (otp) msg += `*OTP Code* : ${otp[0]}\n\n`
          msg += `*Message* :\n${mail.text.slice(0, 300)}${mail.text.length > 300 ? '...' : ''}`
          await m.reply(msg)
          this.done.add(mail.id)
        }
      } catch (e) {
        if (e.message.includes('session_not_found')) {
          this.stop()
          await m.reply('DropMail session expired.')
          userSessions.delete(jid)
        }
      }
    }, this.INTERVAL)
  }

  stop() {
    if (this.loop) clearInterval(this.loop)
  }
}

module.exports = {
  help: ['dropmail'],
  aliases: ['checkmail', 'stopmail'],
  tags: 'utility',
  run: async (m, { conn, usedPrefix, command, Func }) => {
    const user = global.db.users[m.sender] || {}
    const jid = m.sender

    try {
      if (command === 'dropmail') {
        if (userSessions.has(jid))
          return m.reply(`You already have an email: ${userSessions.get(jid).email}\nStop it with: ${usedPrefix}stopmail`)

        const dm = new DropMail()
        const { email, exp } = await dm.create()
        userSessions.set(jid, dm)
        dm.monitor(conn, jid, m)
        await m.reply(`*DROPMAIL*\n\n- *E-Mail* : ${email}\n- *Expires* : ${new Date(exp).toLocaleString()}\n\n_The bot checks inbox every 10s._`)
      }

      if (command === 'checkmail') {
        if (!userSessions.has(jid)) return m.reply('No active DropMail session.')
        const dm = userSessions.get(jid)
        const { email, mails, count } = await dm.inbox()
        if (!count) return m.reply(`${email} has no new messages.`)
        let text = `*${count} new message(s) in ${email}:*\n\n`
        mails.slice(0, 3).forEach((m, i) => {
          text += `${i + 1}. *From:* ${m.fromAddr}\n*Subject:* ${m.headerSubject}\n\n`
          dm.done.add(m.id)
        })
        if (count > 3) text += `...and ${count - 3} more messages.`
        await m.reply(text)
      }

      if (command === 'stopmail') {
        if (!userSessions.has(jid)) return m.reply('No active DropMail session.')
        const dm = userSessions.get(jid)
        dm.stop()
        userSessions.delete(jid)
        await m.reply(`Stopped monitoring ${dm.email} 👍`)
      }
    } catch (e) {
      throw Func.jsonFormat(e)
    }
  }
}