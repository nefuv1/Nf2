/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['img2txt'],
   aliases: ['ocr', 'image2text'],
   tags: 'utility',
   run: async (m, {
      conn,
      usedPrefix,
      Scraper,
      Func,
      Api
   }) => {
      let user = global.db.users[m.sender] || {};
      user.isProcessingImg2txt = user.isProcessingImg2txt || false;

      if (user.isProcessingImg2txt) throw global.status.previously;

      try {
         let q = m.quoted ? m.quoted : m;
         let mime = (q.msg || q).mimetype || '';
         if (!mime) throw 'Please reply / send an image with text.';
         if (!/image\/(jpe?g|png)/.test(mime)) throw 'Only images are supported.';

         user.isProcessingImg2txt = true;
         conn.sendReact(m.chat, global.react, m.key);

         let img = await q.download();
         let image = await Scraper.uploader(img);
         const json = await Api.get('/ocr', {
            image: image.data.url
         });

         if (!json.status) throw json.msg || 'OCR process failed';

         conn.reply(m.chat, json.data.text, m);

      } catch (e) {
         throw Func.jsonFormat(e);
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingImg2txt = false;
         }
      }
   }
}