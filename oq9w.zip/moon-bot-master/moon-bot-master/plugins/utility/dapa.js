/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');

async function getDAPAData(domain, status = 1) {
    try {
        const apiUrl = 'https://panel.seedbacklink.com/api/check/da-pa';
        const response = await axios.get(apiUrl, {
            params: { site: domain, status },
            headers: {
                'Accept': 'application/json, text/javascript, */*; q=0.01'
            }
        });

        return {
            status: 'success',
            code: response.status,
            message: 'DA/PA data retrieved successfully',
            data: {
                domain,
                metrics: {
                    domainAuthority: response.data.data.da_score,
                    pageAuthority: response.data.data.pa_score,
                    backlinks: response.data.data.total_backlink,
                    spamScore: response.data.data.spam_score
                },
                date: {
                    week: response.data.data.week,
                    month: response.data.data.month,
                    year: response.data.data.year,
                    isoDate: new Date().toISOString()
                },
                rawData: response.data
            },
            metadata: {
                source: 'seedbacklink.com',
                requestId: response.headers['x-request-id'] || null,
                responseTime: response.headers['x-response-time'] || null
            }
        };
    } catch (error) {
        if (error.response) {
            return {
                status: 'error',
                code: error.response.status,
                message: error.response.data.msg || 'Failed to fetch DA/PA data',
                error: {
                    type: 'API_ERROR',
                    details: error.response.data
                }
            };
        } else if (error.request) {
            return {
                status: 'error',
                code: 503,
                message: 'No response received from the API server',
                error: {
                    type: 'NETWORK_ERROR',
                    details: error.message
                }
            };
        } else {
            return {
                status: 'error',
                code: 500,
                message: 'Error setting up the API request',
                error: {
                    type: 'REQUEST_ERROR',
                    details: error.message
                }
            };
        }
    }
}

module.exports = {
   help: ['dapa'],
   tags: 'utility',
   use: '/developer/',
   run: async (m, { conn, text, command, usedPrefix, Func }) => {
      let user = global.db.users[m.sender] || {};
      user.isProcessingDapa = user.isProcessingDapa || false;

      if (user.isProcessingDapa) throw global.status.previously;

      try {
         if (!text) throw `Please provide URL.\n\n*Example* : ${usedPrefix}dapa https://profile.agungtech.web.id`;

         user.isProcessingDapa = true;
         conn.sendReact(m.chat, global.react, m.key);

         const domain = text.trim();
         const result = await getDAPAData(domain);

         if (result.status !== 'success') {
            throw result.message;
         }

         const res = result.data;

         let out = `*DA / PA CHECK*\n\n- *Domain* : ${res.domain}\n- *Domain Authority (DA)* : ${res.metrics.domainAuthority}\n- *Page Authority (PA)* : ${res.metrics.pageAuthority}\n- *Backlinks* : ${res.metrics.backlinks}\n- *Spam Score* : ${res.metrics.spamScore}\n\n- *Week* : ${res.date.week}\n- *Month* : ${res.date.month}\n- *Year* : ${res.date.year}\n- *Check Date* : ${new Date().toLocaleDateString('id-ID')}`;

         m.reply(out);

      } catch (e) {
         throw Func.jsonFormat(e);
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingDapa = false;
         }
      }
   }
}