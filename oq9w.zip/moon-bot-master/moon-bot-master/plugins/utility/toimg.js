/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const sharp = require('sharp');

module.exports = {
   help: ['toimg'],
   aliases: ['toimage'],
   tags: 'utility',
   run: async (m, { conn, Func }) => {
      let user = global.db.users[m.sender] || {};
      user.isProcessingToimg = user.isProcessingToimg || false;

      if (user.isProcessingToimg) throw global.status.previously;

      try {
         if (!m.quoted) throw 'Please reply to sticker (IMAGE) with command.';
         
         let mime = m.quoted.mimetype || '';
         if (!/webp/.test(mime)) throw 'Only stickers (IMAGE) are supported.';

         user.isProcessingToimg = true;
         conn.sendReact(m.chat, global.react, m.key);

         let buffer = await m.quoted.download();
         
         let jpegBuffer = await sharp(buffer)
            .jpeg()
            .toBuffer();
         
         await conn.sendFile(m.chat, jpegBuffer, 'image.jpg', '', m);

      } catch (e) {
         throw Func.jsonFormat(e);
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingToimg = false;
         }
      }
   }
}