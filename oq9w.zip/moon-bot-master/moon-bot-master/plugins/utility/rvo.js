/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const { readFileSync: read, unlinkSync: remove, writeFileSync: create } = require('fs')
const path = require('path')
const { exec } = require('child_process')
const { tmpdir } = require('os')

module.exports = {
   help: ['readvo'],
   aliases: ['rvo'],
   tags: 'utility',
   run: async (m, {
      conn,
      Func
   }) => {
      let user = global.db.users[m.sender] || {};
      user.isProcessingRvo = user.isProcessingRvo || false;

      if (user.isProcessingRvo) throw global.status.previously;

      try {
         if (!m.quoted) throw 'Please reply to viewonce message.';

         user.isProcessingRvo = true;
         conn.sendReact(m.chat, global.react, m.key);

         const type = m.quoted?.message ? Object.keys(m.quoted.message)?.[0] : m.quoted?.mimetype
         if (m.quoted && m.quoted?.message) {
            let q = m.quoted?.message?.[type] || m.quoted
            let buffer = await conn.downloadMediaMessage(q)
            if (/(image|video)/.test(type)) {
               conn.sendFile(m.chat, buffer, '', q.caption || '', m)
            } else if (/audio/.test(type)) {
               const media = path.join(tmpdir(), Func.filename('mp3'))
               create(media, buffer)
               const result = Func.filename('mp3')
               exec(`ffmpeg -i ${media} -vn -ar 44100 -ac 2 -b:a 128k ${result}`, async (err, stderr, stdout) => {
                  remove(media)
                  if (err) return m.reply('Conversion failed.')
                  let buff = read(result)
                  conn.sendFile(m.chat, buff, 'audio.mp3', '', m).then(() => {
                     remove(result)
                  })
               })
            } else throw 'Unsupported media type.'
         } else if (m.quoted && !m.quoted?.message) {
            let buffer = await m.quoted.download()
            if (/(image|video)/.test(type)) {
               conn.sendFile(m.chat, buffer, '', m.quoted?.caption || '', m)
            } else if (/audio/.test(type)) {
               const media = path.join(tmpdir(), Func.filename('mp3'))
               create(media, buffer)
               const result = Func.filename('mp3')
               exec(`ffmpeg -i ${media} -vn -ar 44100 -ac 2 -b:a 128k ${result}`, async (err, stderr, stdout) => {
                  remove(media)
                  if (err) return m.reply('Conversion failed.')
                  let buff = read(result)
                  conn.sendFile(m.chat, buff, 'audio.mp3', '', m).then(() => {
                     remove(result)
                  })
               })
            } else throw 'Unsupported media type.'
         } else throw 'Invalid message format.'

      } catch (e) {
         throw Func.jsonFormat(e);
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingRvo = false;
         }
      }
   }
}