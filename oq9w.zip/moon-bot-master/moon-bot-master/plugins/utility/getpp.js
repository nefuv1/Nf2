/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

let fetch = require("node-fetch");

module.exports = {
  help: ['getpp'],
  tags: 'utility',
  run: async (m, { conn, args, command, Func }) => {
    let user = global.db.users[m.sender] || {};
    user.isProcessingGetpp = user.isProcessingGetpp || false;

    if (user.isProcessingGetpp) throw global.status.previously;

    try {
      user.isProcessingGetpp = true;
      conn.sendReact(m.chat, global.react, m.key);

      let who;
      
      if (args[0] && args[0].match(/^\+?\d{5,}/)) {
        let number = args[0].replace(/\D/g, '');
        if (!number.endsWith('@s.whatsapp.net')) number += '@s.whatsapp.net';
        who = number;
      } else if (m.isGroup) {
        who = m.mentionedJid && m.mentionedJid.length
          ? m.mentionedJid[0]
          : m.quoted?.sender || m.sender;
      } else {
        who = m.quoted?.sender || m.sender;
      }

      let pp = await conn.profilePictureUrl(who, 'image')
        .catch(() => "https://telegra.ph/file/24fa902ead26340f3df2c.png");

      conn.sendFile(
        m.chat,
        pp,
        'profile.jpg',
        '',
        m,
        {
          jpegThumbnail: await (await fetch(pp)).buffer()
        }
      );

    } catch (e) {
      throw Func.jsonFormat(e);
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingGetpp = false;
      }
    }
  },
};