/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');

async function Screenshot(url, type = 'fullpage') {
    let endpoint;

    if (type === 'desktop') {
        endpoint = `https://image.thum.io/get/png/desktop/viewportWidth/2400/${url}`;
    } else {
        endpoint = `https://image.thum.io/get/png/fullpage/viewportWidth/2400/${url}`;
    }

    try {
        const response = await axios.get(endpoint, {
            responseType: 'arraybuffer'
        });

        return {
            status: 200,
            type: 'image/png',
            buffer: response.data
        };
    } catch (err) {
        throw Error(err.message);
    }
}

module.exports = {
    help: ['screenshot'],
    tags: 'utility',
    aliases: ['ss', 'ssweb'],
    run: async (m, { args, Func, conn, command, usedPrefix }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingScreenshot = user.isProcessingScreenshot || false;

        if (user.isProcessingScreenshot) throw global.status.previously;

        try {
            if (!args[0]) {
                throw `Please provide URL.\n\n*Example* :\n- ${usedPrefix + command} https://profile.agungtech.web.id\n- ${usedPrefix + command} https://profile.agungtech.web.id desktop\n\n*Styles* :\n1. desktop\n2. fullpage`;
            }

            user.isProcessingScreenshot = true;
            conn.sendReact(m.chat, global.react, m.key);

            let type = 'fullpage';
            let url = args[0];

            if (args[0].toLowerCase() === 'desktop') {
                type = 'desktop';
                url = args[1];
            }

            if (!url || !/^https?:\/\//i.test(url)) {
                throw status.invalid;
            }

            let result = await Screenshot(url, type);

            await conn.sendMessage(m.chat, {
                image: result.buffer,
                caption: ``
            }, { quoted: m });

        } catch (e) {
            throw Func.jsonFormat(e);
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingScreenshot = false;
            }
        }
    }
};