/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require("axios");

async function getElectricityBill(nopel) {
  try {
    const res = await axios.get(`https://listrik.okcek.com/dd.php?nopel=${nopel}`, {
      headers: { "x-requested-with": "XMLHttpRequest" },
    });

    const data = res.data?.data;
    if (!data || data.status !== "success") throw new Error("Bill not found.");

    return {
      billType: data[0][2],
      customerNo: data[1][2],
      customerName: data[2][2],
      powerRate: data[3][2],
      period: data[4][2],
      meterStand: data[5][2],
      total: data[6][2],
    };
  } catch (err) {
    throw err;
  }
}

module.exports = {
  help: ["pln"],
  aliases: ["plnbill", "checkpln", "electricity", "cekpln", "plncek"],
  tags: "utility",
  run: async (m, { conn, usedPrefix, command, args, Func }) => {
    let user = global.db.users[m.sender] || {};
    user.isProcessingPln = user.isProcessingPln || false;

    if (user.isProcessingPln) throw global.status.previously;

    try {
      if (!args[0]) throw `Please provide customer number.\n\n*Example* : ${usedPrefix + command} 443100003506`;

      const nopel = args[0].trim();
      if (!/^\d+$/.test(nopel)) throw "Invalid number. Use digits only.";
      if (nopel.length < 10 || nopel.length > 20) throw "Customer number must be 10–20 digits.";

      user.isProcessingPln = true;
      conn.sendReact(m.chat, global.react, m.key);

      const bill = await getElectricityBill(nopel);
      if (!bill) throw "Failed to fetch data.";

      let msg = `*PLN ELECTRICITY BILL*\n\n`;
      msg += `- *Bill Type* : ${bill.billType || "-"}\n`;
      msg += `- *Customer No* : ${bill.customerNo || "-"}\n`;
      msg += `- *Customer Name* : ${bill.customerName || "-"}\n`;
      msg += `- *Power Rate* : ${bill.powerRate || "-"}\n`;
      msg += `- *Period* : ${bill.period || "-"}\n`;
      msg += `- *Meter Stand* : ${bill.meterStand || "-"}\n`;
      msg += `- *Total* : ${bill.total || "-"}`;

      await conn.sendMessage(m.chat, { text: msg }, { quoted: m });

    } catch (e) {
      throw e.message === "Bill not found."
        ? "Electricity bill data not found. Please check the number."
        : Func.jsonFormat(e);
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingPln = false;
      }
    }
  },
};