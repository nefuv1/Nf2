/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

let { webp2mp4 } = require('../../lib/system/webp2mp4.js')

module.exports = {
   help: ['tomp4'],
   aliases: ['togif', 'tovid'],
   tags: 'utility',
   run: async (m, { conn, Func }) => {
      let user = global.db.users[m.sender] || {};
      user.isProcessingTomp4 = user.isProcessingTomp4 || false;

      if (user.isProcessingTomp4) throw global.status.previously;

      try {
         if (!m.quoted) throw 'Please reply to sticker (GIF) with command.';
         
         let mime = m.quoted.mimetype || '';
         if (!/webp/.test(mime)) throw 'Only stickers (GIF) are supported.';

         user.isProcessingTomp4 = true;
         conn.sendReact(m.chat, global.react, m.key);

         let media = await m.quoted.download();
         let out = Buffer.alloc(0);
         
         if (/webp/.test(mime)) {
            out = await webp2mp4(media);
         }
         
         conn.sendFile(m.chat, out, 'video.mp4', global.db.setting.wm || '', m, true);

      } catch (e) {
         throw Func.jsonFormat(e);
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingTomp4 = false;
         }
      }
   }
}