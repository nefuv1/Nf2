/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
  help: ['script2module'],
  aliases: ['sc2module', 'sc2m', 'tomodule', 'convertmodule'],
  tags: 'utility',
  run: async (m, { conn, command, usedPrefix, text, Func }) => {
    const code = text || m.quoted?.text || m.quoted?.caption;
    if (!code) throw `Please provide script.\n\n*Example* : ${usedPrefix + command} import axios from 'axios'`
    
    try {
      const isESM = /(import\s+.*from|export\s+(default|function|const|class|{))/.test(code);
      const isCJS = /(require\(|module\.exports|exports\.\w+\s*=)/.test(code);
      
      let result, fromType, toType;
      
      if (isESM && !isCJS) {
        // ESM to CJS
        result = convertESMtoCJS(code);
        fromType = 'ESM';
        toType = 'CJS';
      } else if (isCJS && !isESM) {
        // CJS to ESM
        result = convertCJStoESM(code);
        fromType = 'CJS';
        toType = 'ESM';
      } else {
        result = convertESMtoCJS(code);
        fromType = 'Auto-detected';
        toType = 'CJS';
      }
      
      if (!result.trim()) throw 'Invalid code or cannot be converted!';
      
      const header = `// Converted from ${fromType} to ${toType}\n\n`;
      await conn.reply(m.chat, header + result, m);
      
    } catch (e) {
     throw Func.jsonFormat(e)
    }
  }
};

function convertESMtoCJS(esmCode) {
  let cjsCode = esmCode;
  
  cjsCode = cjsCode.replace(/import\s+([^{}\s,]+)\s+from\s+['"](.+)['"]/g, 'const $1 = require(\'$2\')');
  cjsCode = cjsCode.replace(/import\s+\{([^}]+)\}\s+from\s+['"](.+)['"]/g, 'const { $1 } = require(\'$2\')');
  cjsCode = cjsCode.replace(/import\s+([^{}\s,]+),\s*\{([^}]+)\}\s+from\s+['"](.+)['"]/g, 'const $1 = require(\'$3\')\nconst { $2 } = require(\'$3\')');
  
  cjsCode = cjsCode.replace(/export\s+default/g, 'module.exports =');
  cjsCode = cjsCode.replace(/export\s+(async\s+)?function\s+(\w+)/g, 'exports.$2 = $1function');
  cjsCode = cjsCode.replace(/export\s+const\s+(\w+)/g, 'exports.$1 =');
  cjsCode = cjsCode.replace(/export\s+class\s+(\w+)/g, 'exports.$1 = class');
  cjsCode = cjsCode.replace(/export\s*\{([^}]+)\}/g, (match, vars) => 
    vars.split(',').map(v => `exports.${v.trim()} = ${v.trim()}`).join('\n')
  );
  
  return cjsCode;
}

function convertCJStoESM(cjsCode) {
  let esmCode = cjsCode;
  
  esmCode = esmCode.replace(/const\s+([^{}\s,]+)\s+=\s+require\(['"](.+)['"]\)/g, 'import $1 from \'$2\'');
  esmCode = esmCode.replace(/const\s+\{([^}]+)\}\s+=\s+require\(['"](.+)['"]\)/g, 'import { $1 } from \'$2\'');
  
  esmCode = esmCode.replace(/module\.exports\s*=/g, 'export default');
  esmCode = esmCode.replace(/exports\.(\w+)\s*=\s*(async\s+)?function/g, 'export $2function $1');
  esmCode = esmCode.replace(/exports\.(\w+)\s*=\s*class/g, 'export class $1');
  esmCode = esmCode.replace(/exports\.(\w+)\s*=\s*(?!function|class)([^;]+)/g, 'export const $1 = $2');
  esmCode = esmCode.replace(/exports\.(\w+)\s*=\s*(\w+);/g, 'export { $2 as $1 };');
  
  return esmCode;
}