/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');

module.exports = {
    help: ['ipcheck'],
    tags: 'utility',
    use: '/developer/',
    aliases: ['checkip', 'cekip', 'ipcek'],
    run: async (m, { conn, usedPrefix, command, args, Func }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingCheckip = user.isProcessingCheckip || false;

        if (user.isProcessingCheckip) throw global.status.previously;

        try {
            if (!args[0]) throw `Please provide your IP.\n\n*Example* : ${usedPrefix + command} 104.18.32.47`;

            user.isProcessingCheckip = true;
            conn.sendReact(m.chat, global.react, m.key);

            let ipAddress = args[0];

            const response = await axios.get(`https://ipinfo.io/${ipAddress}/json`);
            const ipInfo = response.data;

            const infoMessage = `*IP CHECK*\n\n- *IP* : ${ipInfo.ip || 'Not available'}\n- *Country* : ${ipInfo.country || 'Not available'}\n- *Code* : ${ipInfo.country ? ipInfo.country.toLowerCase() : 'Not available'}\n- *Region* : ${ipInfo.region || 'Not available'}\n- *Region Name* : ${ipInfo.region || 'Not available'}\n- *City* : ${ipInfo.city || 'Not available'}\n- *Zip* : ${ipInfo.zip || 'Not available'}\n- *Lat* : ${ipInfo.loc ? ipInfo.loc.split(',')[0] : 'Not available'}\n- *Lon* : ${ipInfo.loc ? ipInfo.loc.split(',')[1] : 'Not available'}\n- *TimeZone* : ${ipInfo.timezone || 'Not available'}\n- *ISP* : ${ipInfo.org || 'Not available'}\n- *Org* : ${ipInfo.org || 'Not available'}\n- *AS* : ${ipInfo.as || 'Not available'}`;

            await conn.reply(m.chat, infoMessage, m);

        } catch (e) {
            throw Func.jsonFormat(e);
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingCheckip = false;
            }
        }
    }
};