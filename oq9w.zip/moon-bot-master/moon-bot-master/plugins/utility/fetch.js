/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const fetch = require('node-fetch')
const util = require('util')

module.exports = {
   help: ['fetch'],
   aliases: ['get','wget'],
   tags: 'utility',
   use: '/developer/',
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      Func
   }) => {
      let user = global.db.users[m.sender] || {};
      user.isProcessingFetch = user.isProcessingFetch || false;

      if (user.isProcessingFetch) throw global.status.previously;

      try {
         if (!/^https?:\/\//.test(text)) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://ptofile.agungtech.web.id`;

         user.isProcessingFetch = true;
         conn.sendReact(m.chat, global.react, m.key);

         let url = text
         let res = await fetch(url)
         if (res.headers.get('content-length') > 100 * 1024 * 1024 * 1024) {
            delete res
            throw `Content-Length: ${res.headers.get('content-length')}`
         }
         if (!/text|json/.test(res.headers.get('content-type'))) return conn.sendFile(m.chat, url, '', text, m)
         let txt = await res.buffer()
         try {
            txt = util.format(JSON.parse(txt + ''))
         } catch (e) {
            txt = txt + ''
         } finally {
            m.reply(txt.slice(0, 65536) + '')
         }

      } catch (e) {
         throw Func.jsonFormat(e);
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingFetch = false;
         }
      }
   },
}