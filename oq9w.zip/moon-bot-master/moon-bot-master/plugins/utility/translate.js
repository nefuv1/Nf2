/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');
const Translator = require('../../lib/translator');

module.exports = {
    help: ['translate'],
    aliases: ['tr'],
    tags: 'utility',
    run: async (m, { args, conn, usedPrefix, Func, command }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingTranslate = user.isProcessingTranslate || false;

        if (user.isProcessingTranslate) throw global.status.previously;

        try {
            if (!args[0] && !m.quoted) {
                throw `Please provide country code and message.\n\n*Example* : ${usedPrefix + command} id Hello, how are you!\n\n*ID* is the destination language code (for example: *EN* for English, *ID* for Indonesian).`;
            }

            user.isProcessingTranslate = true;
            conn.sendReact(m.chat, global.react, m.key);

            const targetLang = args[0];
            const text = args.slice(1).join(' ') || (m.quoted && m.quoted.text);

            if (!text) {
                throw 'There is no text to translate.';
            }

            try {
                const result = await Translator.translate(text, targetLang, null, "v4");
                m.reply(result);
            } catch (error) {
                console.error('Primary translation failed, trying backup provider...');
                try {
                    const backupResult = await Translator.translate(text, targetLang, null, "v1");
                    m.reply(backupResult);
                } catch (backupError) {
                    throw Func.jsonFormat(backupError);
                }
            }

        } catch (e) {
            throw Func.jsonFormat(e);
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingTranslate = false;
            }
        }
    },
};