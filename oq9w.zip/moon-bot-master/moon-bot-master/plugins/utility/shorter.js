/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const fetch = require('node-fetch');

module.exports = {
    help: ['shorten'],
    tags: 'utility',
    aliases: ['tinyurl', 'shortlink', 'short', 'shorturl'],
    use: '/developer/',    
    run: async (m, { conn, Func, usedPrefix, command, args, text }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingShorten = user.isProcessingShorten || false;

        if (user.isProcessingShorten) throw global.status.previously;

        try {
            if (!text) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://profile.agungtech.web.id`;

            user.isProcessingShorten = true;
            conn.sendReact(m.chat, global.react, m.key);

            let response = await fetch(`https://tinyurl.com/api-create.php?url=${args[0]}`);

            if (!response.ok) throw new Error(`HTTP error! Status : ${response.status}`);

            let shortUrl1 = await response.text();

            if (!shortUrl1 || shortUrl1.startsWith('Error:')) {
                throw new Error(`Failed to shorten URL. TinyURL returns : ${shortUrl1}`);
            }

            let done = `${shortUrl1}`.trim();
            m.reply(done);

        } catch (e) {
            throw Func.jsonFormat(e);
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingShorten = false;
            }
        }
    }
};