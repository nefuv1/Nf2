/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['wame'],
   tags: 'utility',
   run: async (m, { conn, usedPrefix, command, text }) => {
      let user = global.db.users[m.sender] || {};
      user.isProcessingWame = user.isProcessingWame || false;

      if (user.isProcessingWame) throw global.status.previously;

      try {
         user.isProcessingWame = true;
         conn.sendReact(m.chat, global.react, m.key)

         let waMeLink
         let mentionedJid = []

         if (!text && !m.quoted) {
            const userNumber = m.sender.split('@')[0]
            const defaultText = ''
            waMeLink = `https://wa.me/${userNumber}?text=${encodeURIComponent(defaultText)}`
         } else if (!text && m.quoted && m.quoted.sender) {
            const userNumber = m.quoted.sender.split('@')[0]
            const quotedText = m.quoted.text || ''
            waMeLink = `https://wa.me/${userNumber}?text=${encodeURIComponent(quotedText)}`
            mentionedJid = [m.quoted.sender]
         } else if (text.startsWith('@')) {
            const parts = text.split(' ')
            const userMention = parts[0].replace('@', '')
            const message = parts.slice(1).join(' ') || ''

            const userNumber = userMention.split('@')[0]
            waMeLink = `https://wa.me/${userNumber}?text=${encodeURIComponent(message)}`
            mentionedJid = [userNumber + '@s.whatsapp.net']
         } else if (m.quoted && m.quoted.sender) {
            const userNumber = m.quoted.sender.split('@')[0]
            waMeLink = `https://wa.me/${userNumber}?text=${encodeURIComponent(text)}`
            mentionedJid = [m.quoted.sender]
         } else if (text.match(/^\d+/)) {
            const parts = text.split(' ')
            const userNumber = parts[0]
            const message = parts.slice(1).join(' ') || ''
            waMeLink = `https://wa.me/${userNumber}?text=${encodeURIComponent(message)}`
         } else {
            const userNumber = m.sender.split('@')[0]
            waMeLink = `https://wa.me/${userNumber}?text=${encodeURIComponent(text)}`
         }

         const sendOptions = mentionedJid.length > 0
            ? { contextInfo: { mentionedJid } }
            : {}

         m.reply(waMeLink, sendOptions)

      } catch (e) {
         throw Func.jsonFormat(e);
      } finally {
          if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingWame = false;
          }
      }
   }
}