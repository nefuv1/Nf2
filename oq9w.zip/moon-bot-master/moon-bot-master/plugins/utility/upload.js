/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['upload'],
   aliases: ['tourl'],
   tags: 'utility',
   use: '/developer/',   
   run: async (m, {
      conn,
      Scraper,
      Func
   }) => {
      let user = global.db.users[m.sender] || {};
      user.isProcessingUpload = user.isProcessingUpload || false;

      if (user.isProcessingUpload) throw global.status.previously;

      try {
         user.isProcessingUpload = true;
         conn.sendReact(m.chat, global.react, m.key);

         let q = m.quoted ? m.quoted : m;
         let mime = (q.msg || q).mimetype || '';
         if (!mime) throw 'Please reply / send media with command.';

         let media = await q.download();

         const uploadPromises = [
            { name: 'Uploader', func: Scraper.uploader },            
            { name: 'Tmpfiles', func: Scraper.tmpfiles },
            { name: 'Termai', func: Scraper.termai },
            { name: 'Catbox', func: Scraper.catbox },
            { name: 'Pixhost', func: Scraper.pixhost },
            { name: 'Quax', func: Scraper.quax },
            { name: 'ImgBB', func: Scraper.imgbb },
            { name: 'Videy', func: Scraper.videy },
            { name: 'Nefyu', func: Scraper.nefyu },
            { name: 'Picsurf', func: Scraper.picsurf }
         ].map(async ({ name, func }) => {
            try {
               const result = await func(media);
               return { name, result };
            } catch (error) {
               return { name, result: { status: false, msg: error.message } };
            }
         });

         const results = await Promise.allSettled(uploadPromises);

         let message = `*UPLOADER*\n\n`;
         let successCount = 0;
         let urlList = [];

         results.forEach((item, index) => {
            if (item.status === 'fulfilled') {
               const { name, result } = item.value;
               if (result.status && result.data && result.data.url) {
                  successCount++;
                  urlList.push(`*${name}* : ${result.data.url}`);
               } else {
                  urlList.push(`*${name}* : Fail`);
               }
            } else {
               urlList.push(`*${uploadPromises[index].name}* : Error`);
            }
         });

         urlList.forEach((url, index) => {
            message += `${index + 1}. ${url}\n`;
         });

         message += `\n*Total Success* : ${successCount}/${uploadPromises.length}`;

         conn.reply(m.chat, message, m);

      } catch (e) {
         throw Func.jsonFormat(e);
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingUpload = false;
         }
      }
   },
}