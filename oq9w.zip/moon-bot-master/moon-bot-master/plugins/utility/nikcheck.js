/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');

module.exports = {
   help: ['nikcheck'],
   aliases: ['ceknik', 'nikcek', 'ktpcheck', 'checknik'],
   tags: 'utility',
   run: async (m, { conn, usedPrefix, command, args, text, Func }) => {
      let user = global.db.users[m.sender] || {};
      user.isProcessingNik = user.isProcessingNik || false;

      if (user.isProcessingNik) throw global.status.previously;

      try {
         if (!text) throw `Please provide NIK number.\n\n*Example* : ${usedPrefix + command} 3202285909840005`;

         user.isProcessingNik = true;
         conn.sendReact(m.chat, global.react, m.key);

         const nik = text.trim();

         if (!/^\d{16}$/.test(nik)) throw 'NIK must be 16 digits';

         const response = await axios.get(
            `https://api.siputzx.my.id/api/tools/nik-checker?nik=${nik}`,
            {
               headers: {
                  "accept": "*/*",
                  "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36"
               },
               timeout: 30000
            }
         );

         if (!response.data.status) throw response.data.error || 'NIK check failed';

         const result = response.data.data.data;
         const metadata = response.data.data.metadata;

         let message = `*NIK CHECKER*\n\n`;
         message += `- *NIK* : ${response.data.data.nik}\n`;
         message += `- *Nama* : ${result.nama}\n`;
         message += `- *Jenis Kelamin* : ${result.kelamin}\n`;
         message += `- *Tempat/Tgl Lahir* : ${result.tempat_lahir}\n`;
         message += `- *Usia* : ${result.usia}\n`;
         message += `- *Zodiak* : ${result.zodiak}\n`;
         message += `- *Pasaran* : ${result.pasaran}\n`;
         message += `- *Ultah Mendatang* : ${result.ultah_mendatang}\n\n`;

         message += `*ALAMAT*\n`;
         message += `- *Provinsi* : ${result.provinsi}\n`;
         message += `- *Kabupaten* : ${result.kabupaten}\n`;
         message += `- *Kecamatan* : ${result.kecamatan}\n`;
         message += `- *Kelurahan* : ${result.kelurahan}\n`;
         message += `- *TPS* : ${result.tps}\n`;
         message += `- *Alamat* : ${result.alamat}\n\n`;

         if (result.koordinat) {
            message += `*KOORDINAT*\n`;
            message += `- *Latitude* : ${result.koordinat.lat}\n`;
            message += `- *Longitude* : ${result.koordinat.lon}\n\n`;
         }

         message += `*METADATA*\n`;
         message += `- *Metode Pencarian* : ${metadata.metode_pencarian}\n`;
         message += `- *Kode Wilayah* : ${metadata.kode_wilayah}\n`;
         message += `- *Nomor Urut* : ${metadata.nomor_urut}\n`;
         message += `- *Kategori Usia* : ${metadata.kategori_usia}\n`;
         message += `- *Jenis Wilayah* : ${metadata.jenis_wilayah}\n`;

         m.reply(message);

      } catch (e) {
         if (e.response && e.response.status === 404) {
            throw 'NIK not found or invalid';
         } else if (e.response && e.response.status === 400) {
            throw 'Invalid NIK format';
         } else if (e.code === 'ECONNABORTED') {
            throw 'Request timeout, please try again';
         }
         throw Func.jsonFormat(e);
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingNik = false;
         }
      }
   }
}