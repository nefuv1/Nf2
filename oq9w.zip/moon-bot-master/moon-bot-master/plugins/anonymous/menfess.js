/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
    help: ['menfess'],
    aliases: ['menfes'],
    tags: 'anonymous',
    private: true,
    run: async (m, {
        conn,
        text,
        usedPrefix,
        command
    }) => {
        conn.menfess = conn.menfess || {};

        if (!text) {
            return m.reply(`Silakan berikan nomor penerima | nama anonim | pesan.\n\n*Contoh* : ${usedPrefix + command} 628xxx | Anonymous | Hai! 👋\n\n1. *Nomor* : Nomor penerima harus benar dan terdaftar di WhatsApp.\n2. *Nama* : Boleh nama asli atau bisa juga disamarkan.\n3. *Pesan* : Bebas, asalkan hindari pesan yang menyinggung orang lain.`);
        }

        let [jid, namaAnonim, ...pesanArr] = text.split('|');
        let pesan = pesanArr.join('|').trim();

        if (!jid || !namaAnonim || !pesan) {
            return m.reply(`Silakan berikan nomor penerima | nama anonim | pesan.\n\n*Contoh* : ${usedPrefix + command} 628xxx | Anonymous | Hai! 👋\n\n1. *Nomor* : Nomor penerima harus benar dan terdaftar di WhatsApp.\n2. *Nama* : Boleh nama asli atau bisa juga disamarkan.\n3. *Pesan* : Bebas, asalkan hindari pesan yang menyinggung orang lain.`);
        }

        jid = jid.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        let data = (await conn.onWhatsApp(jid))[0] || {};

        if (!data.exists) {
            return m.reply('Nomor tersebut salah atau tidak terdaftar di WhatsApp.');
        }

        if (jid === m.sender) {
            return m.reply('Anda tidak bisa mengirim pesan menfess kepada diri sendiri!');
        }

        let existingSessions = Object.values(conn.menfess).filter(mf => 
            mf.dari === m.sender || mf.penerima === m.sender
        );
        existingSessions.forEach(session => {
            delete conn.menfess[session.id];
        });

        let id = +new Date();
        let messageText = `*MENFESS*
        
Halo! @${data.jid.split("@")[0]}, kamu menerima pesan menfess.

*Detail Pengiriman*
- *Nama* : ${namaAnonim}
- *Pesan* : 
${pesan}

*Cara Membalas*
- Ketik pesan balasan di sini lalu kirim.
- Pesan akan diteruskan kepada "${namaAnonim}"
- Kirim pesan *stop* untuk akhiri sesi.`;

        await conn.sendMessage(data.jid, { 
            text: messageText,
            mentions: [data.jid]
        }).then(() => {
            m.reply(`Pesan berhasil dikirim kepada : @${data.jid.split("@")[0]}\n\n1. Sesi chat aktif selama *3 menit*\n2. Balasan akan diteruskan ke kamu.\n3. Kirimkan pesan *stop* untuk akhiri sesi.`);
            
            conn.menfess[id] = {
                id,
                dari: m.sender, 
                penerima: data.jid,
                namaAnonim: namaAnonim,
                pesanAwal: pesan,
                createdAt: Date.now(),
                lastActivity: Date.now()
            };
            
            console.log(`Sesi Menfess dibuat : ${m.sender} -> ${data.jid}`);
            
            setTimeout(() => {
                if (conn.menfess[id]) {
                    conn.sendMessage(m.sender, { text: "Sesi menfess telah berakhir." });
                    conn.sendMessage(data.jid, { text: "Sesi menfess telah berakhir." });
                    delete conn.menfess[id];
                }
            }, 3 * 60 * 1000);
        }).catch(e => {
            console.error(e);
            throw Func.jsonFormat(e)
        });
    }
};