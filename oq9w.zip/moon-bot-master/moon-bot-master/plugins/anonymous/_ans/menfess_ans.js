module.exports = {
    run: async (m, { conn, Func, usedPrefix, command }) => {
        try {
            if (!m.chat.endsWith('@s.whatsapp.net') || m.isGroup) return;

            conn.menfess = conn.menfess || {};
            
            const activeSessions = Object.values(conn.menfess).filter(room => {
                const isParticipant = room.dari === m.sender || room.penerima === m.sender;
                const isActive = (Date.now() - room.createdAt) < 3 * 60 * 1000;
                return isParticipant && isActive;
            });

            if (activeSessions.length === 0) return;

            const room = activeSessions[0];

            if (m.text && m.text.toLowerCase() === "stop") {
                const otherUser = room.dari === m.sender ? room.penerima : room.dari;
                
                await m.reply("Sesi menfess berhasil dihentikan.")
                await m.reply("Sesi menfess telah dihentikan oleh lawan bicara.")
                
                delete conn.menfess[room.id];
                return;
            }

            let sender, receiver, context;
            
            if (m.sender === room.dari) {
                sender = room.dari;
                receiver = room.penerima;
                context = `💌 "${room.namaAnonim}" Membalas`;
            } else if (m.sender === room.penerima) {
                sender = room.penerima;
                receiver = room.dari;
                context = "💌 *Balasan Menfess*";
            } else {
                return;
            }

            room.lastActivity = Date.now();

            await conn.sendMessage(receiver, { 
                text: `${context}\n_Silakan kirim *stop* untuk mengakhiri sesi_\n👇👇👇` 
            });

            await conn.copyNForward(receiver, m, true);

            await m.reply(`Pesan Dikirim! 👍\n_Sesi akan berakhir dalam *${Math.floor((3*60*1000 - (Date.now() - room.createdAt)) / 1000)} detik*_`)

        } catch (e) {
            console.error(e);
            throw Func.jsonFormat(e)            
        }
    }   
};