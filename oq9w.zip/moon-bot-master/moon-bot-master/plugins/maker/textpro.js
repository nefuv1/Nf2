/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const { textpro } = require('../../lib/textpro.js');

const effects = {
  'blackpink': 'https://textpro.me/blackpink-logo-style-online-1001.html',
  'glitch': 'https://textpro.me/create-a-glitch-text-effect-online-free-1026.html',
  'matrix': 'https://textpro.me/matrix-style-text-effect-online-884.html',
  'bokeh': 'https://textpro.me/bokeh-text-effect-876.html',
  'neon-light': 'https://textpro.me/neon-light-text-effect-online-879.html',
  'firework-sparkle': 'https://textpro.me/firework-sparkle-text-effect-930.html',
  'neon-text': 'https://textpro.me/neon-text-effect-online-963.html',
  'pornhub-style': 'https://textpro.me/generate-a-free-logo-in-pornhub-style-online-977.html', // 2 text
  'marvel-studios': 'https://textpro.me/create-your-own-marvel-studios-style-logo-online--971.html', // 2 text
  'batman-logo': 'https://textpro.me/make-a-batman-logo-online-free-1066.html',
  'minion-3d': 'https://textpro.me/minion-text-effect-3d-online-978.html',
  'steel-3d': 'https://textpro.me/3d-steel-text-effect-877.html',
  'cute-3d-glossy': 'https://textpro.me/create-cute-3d-glossy-text-effects-online-1162.html',
  'gradient-3d': 'https://textpro.me/3d-gradient-text-effect-online-free-1002.html',
  'underwater-3d': 'https://textpro.me/3d-underwater-text-effect-generator-online-1013.html',
  'candy-3d': 'https://textpro.me/online-cute-3d-candy-text-effect-generator-1192.html',
  'summer-3d': 'https://textpro.me/energetic-and-adorable-3d-summer-text-effect-1187.html',
  'rustic-wood': 'https://textpro.me/rustic-text-effect-and-the-timeless-beauty-of-wood-background-1183.html',
  'glossy-chrome-3d': 'https://textpro.me/glossy-metallic-chrome-3d-text-effect-1185.html',
  'grilled-meat-3d': 'https://textpro.me/3d-text-effect-art-brings-grilled-meat-to-life-1178.html',
  'stained-glass': 'https://textpro.me/create-free-online-gradient-stained-glass-text-effects-1173.html',
  'gold-christmas-3d': 'https://textpro.me/create-online-3d-gold-christmas-text-effects-1174.html',
  'shiny-christmas-3d': 'https://textpro.me/create-shiny-3d-christmas-text-effects-online-1175.html',
  'glitch-tiktok': 'https://textpro.me/create-glitch-text-effect-style-tik-tok-983.html', // 2 text
  'holographic-3d': 'https://textpro.me/holographic-3d-text-effect-975.html',
  'summer-neon-light': 'https://textpro.me/create-a-summer-neon-light-text-effect-online-1076.html',
  'glowing-blue-3d': 'https://textpro.me/create-a-3d-text-effect-with-a-glowing-blue-color-1170.html',
  'hellfire': 'https://textpro.me/create-a-free-online-hellfire-text-effect-1152.html',
  'impressive-glitch': 'https://textpro.me/create-impressive-glitch-text-effects-online-1027.html',
  'light-glow-sliced': 'https://textpro.me/create-light-glow-sliced-text-effect-online-1068.html',
  'neon-light-brick': 'https://textpro.me/create-neon-light-on-brick-wall-online-1062.html',
  'thunder': 'https://textpro.me/online-thunder-text-effect-generator-1031.html',
  'wave-metal-3d': 'https://textpro.me/wave-pattern-metal-3d-text-effect-generator-1128.html',
  'titanium': 'https://textpro.me/create-a-titanium-text-effect-for-the-iphone-15-introduction-event-1140.html',
  'rose-gold': 'https://textpro.me/create-rose-gold-style-text-effects-online-1158.html',
  'comic-3d': 'https://textpro.me/create-3d-comic-text-effects-online-1091.html',
  'grunge-metallic-3d': 'https://textpro.me/grunge-metallic-3d-text-effect-online-1115.html',
  'rusted-metal': 'https://textpro.me/create-a-rusted-metal-text-effect-online-1087.html',
  'gold-glitter-3d': 'https://textpro.me/create-decorative-gold-glitter-3d-text-effect-online-1089.html',
  'gradient-shadow': 'https://textpro.me/create-a-gradient-text-shadow-effect-online-1141.html',
  'pokemon-logo': 'https://textpro.me/create-pokemon-logo-style-text-effect-online-1134.html',
  'naruto-logo': 'https://textpro.me/create-naruto-logo-style-text-effect-online-1125.html',
  'pink-soft-gold': 'https://textpro.me/create-pink-soft-gold-text-effect-online-1113.html',
  'burger-3d': 'https://textpro.me/create-burger-3d-text-effect-1111.html',
  'art-paper-cut': 'https://textpro.me/create-art-paper-cut-text-effect-online-1022.html',
  'cloud-sky': 'https://textpro.me/create-a-cloud-text-effect-on-the-sky-online-1004.html',
  'sand-engraved-3d': 'https://textpro.me/sand-engraved-3d-text-effect-989.html',
  'sand-writing': 'https://textpro.me/sand-writing-text-effect-online-990.html',
  'summer-beach-sand': 'https://textpro.me/write-in-sand-summer-beach-free-online-991.html',
  'style-1917': 'https://textpro.me/1917-style-text-effect-online-980.html',
  'glue-3d': 'https://textpro.me/create-3d-glue-text-effect-with-realistic-style-986.html',
  'marvel-studios-ver-metal': 'https://textpro.me/create-logo-style-marvel-studios-ver-metal-972.html',
  'blood-frosted-glass': 'https://textpro.me/blood-text-on-the-frosted-glass-941.html',
  'fruit-juice': 'https://textpro.me/fruit-juice-text-effect-861.html',
  'break-wall': 'https://textpro.me/break-wall-text-effect-871.html',
  'horror-blood': 'https://textpro.me/horror-blood-text-effect-online-883.html',
  'carbon': 'https://textpro.me/carbon-text-effect-833.html',
  'bread': 'https://textpro.me/bread-text-effect-online-887.html',
  'stone-cracked-3d': 'https://textpro.me/3d-stone-cracked-cool-text-effect-1029.html',
  'foggy-window': 'https://textpro.me/write-text-on-foggy-window-online-free-1015.html',
  'wolf-logo': 'https://textpro.me/create-wolf-logo-galaxy-online-936.html',
  'natural-leaves': 'https://textpro.me/natural-leaves-text-effect-931.html',
  'dropwater': 'https://textpro.me/dropwater-text-effect-872.html',
  'road-warning': 'https://textpro.me/road-warning-text-effect-878.html',
  'lucky-red-3d': 'https://textpro.me/create-online-lucky-3d-text-effects-in-red-1155.html',
  'pink-cute-3d': 'https://textpro.me/create-cute-pink-3d-text-effects-online-1161.html',
  'multi-3d-paper-cut': 'https://textpro.me/online-multicolor-3d-paper-cut-text-effect-1016.html',
  'embossed-3d': 'https://textpro.me/create-an-online-3d-embossed-text-effect-1154.html',
  'comic-book-3d': 'https://textpro.me/create-online-3d-comic-book-style-text-effects-1156.html',
  'sale-promo-3d': 'https://textpro.me/sale-promotion-ads-3d-text-effect-1136.html', // 2 text
  'pixel-3d': 'https://textpro.me/online-3d-pixel-text-effect-generator-1138.html',
  'cartoon-3d': 'https://textpro.me/3d-cartoon-text-effect-generator-online-1123.html',
  'box-3d': 'https://textpro.me/3d-box-text-effect-online-880.html',
  'cool-graffiti': 'https://textpro.me/create-a-cool-graffiti-text-on-the-wall-1010.html',
  'wonderful-graffiti': 'https://textpro.me/create-wonderful-graffiti-art-text-effect-1011.html',
  'cool-wall-graffiti': 'https://textpro.me/create-cool-wall-graffiti-text-effect-online-1009.html',
  'ice-cold': 'https://textpro.me/ice-cold-text-effect-862.html',
  'realistic-frozen-3d': 'https://textpro.me/create-realistic-3d-text-effect-frozen-winter-1099.html',
  'beautiful-snow-3d': 'https://textpro.me/create-beautiful-3d-snow-text-effect-online-1101.html',
  'new-year-gold-3d': 'https://textpro.me/new-year-celebration-3d-gold-text-effect-1102.html',
  'lunar-new-year': 'https://textpro.me/create-online-lunar-new-year-greeting-text-effect-1153.html',
  'party-night-event': 'https://textpro.me/party-text-effect-with-the-night-event-theme-1105.html',
  'sci-fi-3d': 'https://textpro.me/create-3d-sci-fi-text-effect-online-1050.html',
  'sparkling-diamonds': 'https://textpro.me/create-a-quick-sparkling-diamonds-text-effect-1077.html',
  'luxury-gold-3d': 'https://textpro.me/3d-luxury-gold-text-effect-online-1003.html',
  'silver-glitter': 'https://textpro.me/silver-glitter-text-effect-837.html',
  'orange-juice-3d': 'https://textpro.me/create-a-3d-orange-juice-text-effect-online-1084.html',
  'chocolate-cake-3d': 'https://textpro.me/create-3d-chocolate-cake-text-effect-online-1135.html',
  'honey': 'https://textpro.me/honey-text-effect-868.html',
  'berry-free': 'https://textpro.me/create-berry-text-effect-online-free-1033.html',
  'dragon-scale-3d': 'https://textpro.me/create-3d-dragon-scale-text-effect-online-1127.html',
  'bagel': 'https://textpro.me/bagel-text-effect-857.html',
  'carved-stone': 'https://textpro.me/create-carved-stone-text-effect-online-1074.html',
  'blackpink-style': 'https://textpro.me/create-blackpink-style-logo-effects-online-1079.html',
  'summer-palm-tree': 'https://textpro.me/create-a-summer-text-effect-with-a-palm-tree-1083.html',
  'sketch': 'https://textpro.me/create-a-sketch-text-effect-online-1044.html',
  'summery-sand-writing': 'https://textpro.me/create-a-summery-sand-writing-text-effect-988.html',
  'realistic-cloud': 'https://textpro.me/create-realistic-cloud-text-effect-online-free-999.html',
  'glowing-neon-3d': 'https://textpro.me/create-a-glowing-3d-neon-light-text-effect-1142.html'
};

module.exports = {
  help: ['textpro'],
  aliases: ['txtpro'],
  tags: 'maker',
  limit: 30,
  premium: true,
  register: true,
  run: async (m, { conn, usedPrefix, command, text, Func }) => {
    let user = global.db.users[m.sender] || {};
    user.isProcessingTextpro = user.isProcessingTextpro || false;

    if (user.isProcessingTextpro) throw global.status.previously;
    user.isProcessingTextpro = true;

    const twoTextEffects = ['pornhub-style', 'marvel-studios', 'glitch-tiktok', 'sale-promo-3d'];

    try {
      const [effectName, ...textParts] = text.split(' ');
      if (!effectName || !textParts.length) {
        let effectList = '*TextPro Styles* :\n\n';
        Object.keys(effects).forEach((effect, index) => {
          const isTwoText = twoTextEffects.includes(effect) ? ' (2 text)' : '';
          effectList += `${index + 1}. ${effect}${isTwoText}\n`;
        });
        effectList += `\n*Example* : ${usedPrefix + command} blackpink TechBOT`;
        throw effectList;
      }

      const effectUrl = effects[effectName.toLowerCase()];
      if (!effectUrl) throw `"${effectName}" Not found / No results!`;

      const texts = textParts.join(' ').split('|').map(t => t.trim());
      
      if (twoTextEffects.includes(effectName.toLowerCase())) {
        if (texts.length < 2) {
          const exampleText = `Here's how to use 2 text :\n\n*Example* : ${usedPrefix + command} ${effectName} Text-1 | Text-2\n\n_Use "|" for text separator._`;
          throw exampleText;
        }
      }

      let resultUrl;
      let key;

      if (twoTextEffects.includes(effectName.toLowerCase())) {
        resultUrl = await textpro(effectUrl, [texts[0], texts[1]]);
      } else {
        resultUrl = await textpro(effectUrl, [texts[0]]);
      }
      
      key = await m.reply(global.status.wait);

      await conn.sendFile(m.chat, resultUrl, 'textpro.jpg', `${texts.join(' | ')}`, m);

      await conn.sendMessage(m.chat, {
        text: "Done. 👍",
        edit: key,
      });

    } catch (e) {
      throw Func.jsonFormat(e);
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingTextpro = false;
      }
    }
  }
};