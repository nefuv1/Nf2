/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const { createCanvas, loadImage, registerFont } = require('canvas');
const axios = require('axios');
const sharp = require('sharp');
const assets = require('@putuofc/assetsku');

const proxy = () => '';

const registerEKTPFonts = () => {
  try {
    registerFont(assets.font.get("ARRIAL"), { family: "Arial" });
    registerFont(assets.font.get("OCR"), { family: "Ocr" });
    registerFont(assets.font.get("SIGN"), { family: "Sign" });
  } catch (error) {
    console.log('Font registration skipped:', error.message);
  }
};

async function scrapeEktpGet(query) {
  const {
    provinsi,
    kota,
    nik,
    nama,
    ttl,
    jenis_kelamin,
    golongan_darah,
    alamat,
    "rt/rw": rt_rw,
    "kel/desa": kel_desa,
    kecamatan,
    agama,
    status,
    pekerjaan,
    kewarganegaraan,
    masa_berlaku,
    terbuat,
    pas_photo,
  } = query;

  registerEKTPFonts();

  const template = await loadImage(assets.image.get("TEMPLATE"));

  let pasPhoto;
  try {
    pasPhoto = await loadImage(proxy() + pas_photo);
  } catch (error) {
    throw new Error(`Failed to load photo from URL: ${error.message}`);
  }

  const width = 850;
  const height = 530;
  const radius = 20;

  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = "#F0F0F0";
  ctx.beginPath();
  ctx.moveTo(radius, 0);
  ctx.lineTo(width - radius, 0);
  ctx.quadraticCurveTo(width, 0, width, radius);
  ctx.lineTo(width, height - radius);
  ctx.quadraticCurveTo(width, height, width - radius, height);
  ctx.lineTo(radius, height);
  ctx.quadraticCurveTo(0, height, 0, height - radius);
  ctx.lineTo(0, radius);
  ctx.quadraticCurveTo(0, 0, radius, 0);
  ctx.closePath();
  ctx.fill();

  ctx.drawImage(template, 0, 0, width, height);

  ctx.fillStyle = "black";
  ctx.font = "bold 25px Arial";
  ctx.textAlign = "center";
  ctx.fillText(`PROVINSI ${provinsi.toUpperCase()}`, width / 2, 45);
  ctx.fillText(`${kota.toUpperCase()}`, width / 2, 75);

  ctx.textAlign = "left";
  ctx.font = "35px Ocr";
  ctx.fillText(nik, 205, 140);

  ctx.font = "bold 20px Arial";

  const valueX = 225;
  ctx.fillText(nama.toUpperCase(), valueX, 180);
  ctx.fillText(ttl.toUpperCase(), valueX, 205);
  ctx.fillText(jenis_kelamin.toUpperCase(), valueX, 230);
  ctx.fillText(golongan_darah.toUpperCase(), 550, 230);
  ctx.fillText(alamat.toUpperCase(), valueX, 255);
  ctx.fillText(rt_rw.toUpperCase(), valueX, 282);
  ctx.fillText(kel_desa.toUpperCase(), valueX, 307);
  ctx.fillText(kecamatan.toUpperCase(), valueX, 332);
  ctx.fillText(agama.toUpperCase(), valueX, 358);
  ctx.fillText(status.toUpperCase(), valueX, 383);
  ctx.fillText(pekerjaan.toUpperCase(), valueX, 409);
  ctx.fillText(kewarganegaraan.toUpperCase(), valueX, 434);
  ctx.fillText(masa_berlaku.toUpperCase(), valueX, 459);

  const photoX = 635;
  const photoY = 150;
  const photoWidth = 180;
  const photoHeight = 240;

  const photoCanvas = createCanvas(photoWidth, photoHeight);
  const photoCtx = photoCanvas.getContext("2d");

  photoCtx.fillStyle = "#FF0000";
  photoCtx.fillRect(0, 0, photoWidth, photoHeight);

  const aspectRatio = pasPhoto.width / pasPhoto.height;
  let srcWidth, srcHeight, srcX, srcY;

  if (aspectRatio > photoWidth / photoHeight) {
    srcHeight = pasPhoto.height;
    srcWidth = srcHeight * (photoWidth / photoHeight);
    srcX = (pasPhoto.width - srcWidth) / 2;
    srcY = 0;
  } else {
    srcWidth = pasPhoto.width;
    srcHeight = srcWidth * (photoHeight / photoWidth);
    srcX = 0;
    srcY = (pasPhoto.height - srcHeight) / 2;
  }

  photoCtx.drawImage(pasPhoto, srcX, srcY, srcWidth, srcHeight, 0, 0, photoWidth, photoHeight);
  ctx.drawImage(photoCanvas, photoX, photoY, photoWidth, photoHeight);

  ctx.textAlign = "center";
  ctx.font = "16px Arial";
  ctx.fillText(kota.toUpperCase(), photoX + photoWidth / 2, photoY + photoHeight + 35);
  ctx.fillText(terbuat, photoX + photoWidth / 2, photoY + photoHeight + 60);

  const signName = nama.split(" ")[0];
  ctx.font = "36px Sign";
  ctx.fillText(signName, photoX + photoWidth / 2, photoY + photoHeight + 110);

  return canvas.toBuffer("image/png", { quality: 0.95 });
}

async function scrapeEktpPost(body, file) {
  const {
    provinsi,
    kota,
    nik,
    nama,
    ttl,
    jenis_kelamin,
    golongan_darah,
    alamat,
    "rt/rw": rt_rw,
    "kel/desa": kel_desa,
    kecamatan,
    agama,
    status,
    pekerjaan,
    kewarganegaraan,
    masa_berlaku,
    terbuat,
  } = body;

  registerEKTPFonts();

  const template = await loadImage(assets.image.get("TEMPLATE"));

  let pasPhoto;
  try {
    pasPhoto = await loadImage(file);
  } catch (error) {
    throw new Error(`Failed to load photo from buffer: ${error.message}`);
  }

  const width = 850;
  const height = 530;
  const radius = 20;

  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext("2d");

  ctx.fillStyle = "#F0F0F0";
  ctx.beginPath();
  ctx.moveTo(radius, 0);
  ctx.lineTo(width - radius, 0);
  ctx.quadraticCurveTo(width, 0, width, radius);
  ctx.lineTo(width, height - radius);
  ctx.quadraticCurveTo(width, height, width - radius, height);
  ctx.lineTo(radius, height);
  ctx.quadraticCurveTo(0, height, 0, height - radius);
  ctx.lineTo(0, radius);
  ctx.quadraticCurveTo(0, 0, radius, 0);
  ctx.closePath();
  ctx.fill();

  ctx.drawImage(template, 0, 0, width, height);

  ctx.fillStyle = "black";
  ctx.font = "bold 25px Arial";
  ctx.textAlign = "center";
  ctx.fillText(`PROVINSI ${provinsi.toUpperCase()}`, width / 2, 45);
  ctx.fillText(`${kota.toUpperCase()}`, width / 2, 75);

  ctx.textAlign = "left";
  ctx.font = "35px Ocr";
  ctx.fillText(nik, 205, 140);

  ctx.font = "bold 20px Arial";

  const valueX = 225;
  ctx.fillText(nama.toUpperCase(), valueX, 180);
  ctx.fillText(ttl.toUpperCase(), valueX, 205);
  ctx.fillText(jenis_kelamin.toUpperCase(), valueX, 230);
  ctx.fillText(golongan_darah.toUpperCase(), 550, 230);
  ctx.fillText(alamat.toUpperCase(), valueX, 255);
  ctx.fillText(rt_rw.toUpperCase(), valueX, 282);
  ctx.fillText(kel_desa.toUpperCase(), valueX, 307);
  ctx.fillText(kecamatan.toUpperCase(), valueX, 332);
  ctx.fillText(agama.toUpperCase(), valueX, 358);
  ctx.fillText(status.toUpperCase(), valueX, 383);
  ctx.fillText(pekerjaan.toUpperCase(), valueX, 409);
  ctx.fillText(kewarganegaraan.toUpperCase(), valueX, 434);
  ctx.fillText(masa_berlaku.toUpperCase(), valueX, 459);

  const photoX = 635;
  const photoY = 150;
  const photoWidth = 180;
  const photoHeight = 240;

  const photoCanvas = createCanvas(photoWidth, photoHeight);
  const photoCtx = photoCanvas.getContext("2d");

  photoCtx.fillStyle = "#FF0000";
  photoCtx.fillRect(0, 0, photoWidth, photoHeight);

  const aspectRatio = pasPhoto.width / pasPhoto.height;
  let srcWidth, srcHeight, srcX, srcY;

  if (aspectRatio > photoWidth / photoHeight) {
    srcHeight = pasPhoto.height;
    srcWidth = srcHeight * (photoWidth / photoHeight);
    srcX = (pasPhoto.width - srcWidth) / 2;
    srcY = 0;
  } else {
    srcWidth = pasPhoto.width;
    srcHeight = srcWidth * (photoHeight / photoWidth);
    srcX = 0;
    srcY = (pasPhoto.height - srcHeight) / 2;
  }

  photoCtx.drawImage(pasPhoto, srcX, srcY, srcWidth, srcHeight, 0, 0, photoWidth, photoHeight);
  ctx.drawImage(photoCanvas, photoX, photoY, photoWidth, photoHeight);

  ctx.textAlign = "center";
  ctx.font = "16px Arial";
  ctx.fillText(kota.toUpperCase(), photoX + photoWidth / 2, photoY + photoHeight + 35);
  ctx.fillText(terbuat, photoX + photoWidth / 2, photoY + photoHeight + 60);

  const signName = nama.split(" ")[0];
  ctx.font = "36px Sign";
  ctx.fillText(signName, photoX + photoWidth / 2, photoY + photoHeight + 110);

  return canvas.toBuffer("image/png", { quality: 0.95 });
}

module.exports = {
  help: ['ektp'],
  aliases: ['ktp', 'idcard'],
  tags: 'maker',
  premium: true,
  limit: 30,
  register: true,
  run: async (m, { 
    conn, 
    text, 
    usedPrefix, 
    command, 
    Scraper, 
    Func 
  }) => {
    let user = global.db.users[m.sender] || {};
    user.isProcessingEktp = user.isProcessingEktp || false;

    if (user.isProcessingEktp) {
      throw global.status.previously;
    }

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';

    if (!text) {
      throw `Please provide valid data.\n\n*Example* : ${usedPrefix + command} Jawa Barat|Bandung|1234567890123456|John Doe|Bandung, 01-01-1990|Laki-laki|O|Jl. Contoh No. 123|001/002|Sukajadi|Sukajadi|Islam|Belum Kawin|Pegawai Swasta|WNI|Seumur Hidup|REPUBLIK INDONESIA`;
    }

    user.isProcessingEktp = true;

    try {
      let photoUrl = "";
      if (/image\/(jpe?g|png)/.test(mime)) {
        let media = await q.download();
        if (!media) throw new Error("Failed to download the photo.");
        let uploaded = await Scraper.uploader(media);
        if (!uploaded?.data?.url) throw new Error("Failed to upload the image.");
        photoUrl = uploaded.data.url;
      } else {
        photoUrl = "https://files.catbox.moe/ocmqt0.jpg";
      }

      let splitted = text.split(/[\|+]/);
      if (splitted.length < 17) {
        throw new Error(`Please provide a valid format.\n\n*Format* : Province|City|NIK|Name|TTL|Gender|BloodType|Address|RT/RW|Kel/Desa|District|Religion|Status|Job|Citizenship|Validity|Terbuat|Reply to photo`);
      }

      let [
        provinsi,
        kota,
        nik,
        nama,
        ttl,
        jenis_kelamin,
        gol_darah,
        alamat,
        rt_rw,
        kel_desa,
        kecamatan,
        agama,
        status,
        pekerjaan,
        kewarganegaraan,
        masa_berlaku,
        terbuat
      ] = splitted;

      let { key } = await m.reply(global.status.wait);

      if (nik.length !== 16) throw new Error("NIK must be 16 digits");
      if (!["Laki-laki", "Perempuan"].includes(jenis_kelamin)) throw new Error("Gender must be 'Laki-laki' or 'Perempuan'");
      if (!["A", "B", "AB", "O", "-"].includes(gol_darah)) throw new Error("Blood type must be 'A', 'B', 'AB', 'O', or '-'");

      const ektpBuffer = await scrapeEktpGet({
        provinsi,
        kota,
        nik,
        nama,
        ttl,
        jenis_kelamin,
        golongan_darah: gol_darah,
        alamat,
        "rt/rw": rt_rw,
        "kel/desa": kel_desa,
        kecamatan,
        agama,
        status,
        pekerjaan,
        kewarganegaraan,
        masa_berlaku,
        terbuat,
        pas_photo: photoUrl
      });

      await conn.sendMessage(m.chat, {
        image: ektpBuffer,
        caption: ``,
        mentions: [m.sender]
      }, { quoted: m });

      await conn.sendMessage(m.chat, {
        text: "Done. 👍",
        edit: key,
      });

    } catch (e) {
      console.error(e);
      throw Func.jsonFormat(e);
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingEktp = false;
      }
    }
  }
};