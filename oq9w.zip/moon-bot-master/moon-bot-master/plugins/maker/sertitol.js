/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');

module.exports = {
    help: ['sertitol'],
    aliases: ['tololcert', 'certtolol'],
    tags: 'maker',
    limit: 10,
    register: true,
    run: async (m, { 
        conn, 
        text, 
        usedPrefix, 
        command,
        Func,
        args 
    }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingSertitol = user.isProcessingSertitol || false;

        if (user.isProcessingSertitol) {
            throw global.status.previously
        }

        let name;
        if (text) {
            name = text;
        } else if (m.quoted && m.quoted.text) {
            name = m.quoted.text;
        } else {
            throw `Please provide name.\n\n*Example* : ${usedPrefix + command} GeniusAI`
        }

        user.isProcessingSertitol = true;

        try {
            
            let { key } = await m.reply(global.status.wait);

            const response = await axios.get(`https://tolol.ibnux.com/img.php?nama=${encodeURIComponent(name)}`, {
                responseType: 'arraybuffer',
                timeout: 30000
            });

            if (response.status === 200) {
                let imageBuffer = Buffer.from(response.data, 'binary');

                await conn.sendMessage(m.chat, {
                    image: imageBuffer,
                    mimetype: 'image/jpeg',
                    caption: ``,
                    mentions: [m.sender]
                }, { quoted: m });

                await conn.sendMessage(m.chat, {
                    text: "Done. 👍",
                    edit: key,
                });
                
            } else {
                throw new Error('Failed to generate certificate. Server returned non-200 status.');
            }
        } catch (e) {
            console.error(e);
           throw Func.jsonFormat(e)
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingSertitol = false;
            }
        }
    }
};