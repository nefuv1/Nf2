/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require("axios");
const fs = require("fs");
const { tmpdir } = require("os");
const path = require("path");

async function generateBook(texts) {
   let payload = {
      color: "#000000",
      font: "arch",
      size: 20,
      text: texts,
   };
   let { data } = await axios.post("https://lemon-write.vercel.app/api/generate-book", payload, {
      responseType: "arraybuffer",
   });
   return data;
}

module.exports = {
    help: ['nulis'],
    aliases: ['magernulis', 'write'],
    tags: 'maker',
    limit: 10,
    register: true,
    run: async (m, { 
        conn, 
        text, 
        Func,
        usedPrefix, 
        command 
    }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingNulis = user.isProcessingNulis || false;

        if (user.isProcessingNulis) {
            throw global.status.previously
        }

        if (!text) {
            throw `Please provide text.\n\n*Example* : ${usedPrefix + command} GeniusAI`
        }

        user.isProcessingNulis = true;

        try {
            
            let { key } = await m.reply(global.status.wait);

            const imageBuffer = await generateBook(text);
            
            const tempDir = tmpdir();
            const fileName = `nulis_${Date.now()}.jpg`;
            const filePath = path.join(tempDir, fileName);
            
            fs.writeFileSync(filePath, imageBuffer);

            await conn.sendMessage(m.chat, {
                image: { url: filePath },
                caption: ``,
                mentions: [m.sender]
            }, { quoted: m });

            await conn.sendMessage(m.chat, {
                text: "Done. 👍",
                edit: key,
            });

            fs.unlinkSync(filePath);

        } catch (e) {
            console.error(e);
           throw Func.jsonFormat(e)
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingNulis = false;
            }
        }
    }
};