/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');
const FormData = require('form-data');
const sharp = require('sharp');

async function uploadImage(imageBuffer) {
    const form = new FormData();
    form.append('file', imageBuffer, {
        filename: 'image.jpg',
        contentType: 'image/jpeg'
    });

    const headers = {
        ...form.getHeaders(),
        'Content-Length': form.getLengthSync()
    };

    const response = await axios.post('https://www.pic.surf/upload.php', form, { headers });
    return `https://www.pic.surf/${response.data.identifier}`;
}

const bigjpg = {
  api: {
    base: 'https://bigjpg.com',
    endpoint: {
      task: '/task',
      free: '/free'
    }
  },

  available: {
    styles: { 'art': 'Artwork', 'photo': 'Photo' },
    noise: { '-1': 'None', '0': 'Low', '1': 'Medium', '2': 'High', '3': 'Highest' }
  },

  headers: {
    'origin': 'https://bigjpg.com',
    'referer': 'https://bigjpg.com/',
    'user-agent': 'Postify/1.0.0',
    'x-requested-with': 'XMLHttpRequest'
  },

  isValid: (style, noise) => {
    if (!style || !noise) {
      return { valid: false, error: "Style and noise are required" };
    }
    if (!bigjpg.available.styles[style]) {
      return { valid: false, error: `Invalid style. Available : ${Object.keys(bigjpg.available.styles).join(', ')}` };
    }
    if (!bigjpg.available.noise[noise]) {
      return { valid: false, error: `Invalid noise level. Available : ${Object.keys(bigjpg.available.noise).join(', ')}` };
    }
    return { valid: true, style: style, noise: noise };
  },

  getImageInfo: async (img) => {
    try {
      const response = await axios.get(img, { responseType: 'arraybuffer' });
      const fileSize = parseInt(response.headers['content-length'] || response.data.length);
      
      if (fileSize > 5 * 1024 * 1024) {
        return { valid: false, error: "File size too large. Max 5MB" };
      }

      let fileName = img.split('/').pop().split('#')[0].split('?')[0] || 'image.jpg';
      if (fileName.endsWith('.webp')) fileName = fileName.replace('.webp', '.jpg');

      return {
        valid: true,
        info: { fileName, fileSize, width: 1200, height: 800 }
      };
    } catch (err) {
      return { valid: false, error: "Invalid image URL" };
    }
  },

  upscale: async (img, options = {}) => {
    const validation = await bigjpg.getImageInfo(img);
    if (!validation.valid) return { success: false, error: validation.error };

    const inputx = bigjpg.isValid(options.style, options.noise);
    if (!inputx.valid) return { success: false, error: inputx.error };

    const config = {
      x2: '2', style: inputx.style, noise: inputx.noise,
      file_name: validation.info.fileName, files_size: validation.info.fileSize,
      file_height: validation.info.height, file_width: validation.info.width, input: img
    };

    try {
      const params = new URLSearchParams();
      params.append('conf', JSON.stringify(config));

      const taskx = await axios.post(`${bigjpg.api.base}${bigjpg.api.endpoint.task}`, params, { headers: bigjpg.headers });
      if (taskx.data.status !== 'ok') return { success: false, error: "Failed to create task" };

      const taskId = taskx.data.info;
      let attempts = 0;

      while (attempts < 20) {
        const res = await axios.get(`${bigjpg.api.base}${bigjpg.api.endpoint.free}?fids=${JSON.stringify([taskId])}`, { headers: bigjpg.headers });
        const result = res.data[taskId];
        
        if (result[0] === 'success') {
          return {
            success: true,
            url: result[1],
            size: result[2],
            config: {
              style: config.style,
              styleName: bigjpg.available.styles[config.style],
              noise: config.noise,
              noiseName: bigjpg.available.noise[config.noise]
            }
          };
        } else if (result[0] === 'error') {
          return { success: false, error: "Upscale failed" };
        }

        await new Promise(resolve => setTimeout(resolve, 15000));
        attempts++;
      }

      return { success: false, error: "Timeout" };
    } catch (err) {
      return { success: false, error: err.message || "Server error" };
    }
  }
};

module.exports = {
  help: ['bigjpg'],
  tags: 'image',
  limit: 5,
  register: true,
  run: async (m, { conn, usedPrefix, command, text, Func }) => {
    let user = global.db.users[m.sender] || {};
    user.isProcessingBigJPG = user.isProcessingBigJPG || false;

    if (user.isProcessingBigJPG) throw global.status.previously;
    user.isProcessingBigJPG = true;

    let keyMsg;

    try {
      const q = m.quoted ? m.quoted : m;
      const mime = (q.msg || q).mimetype || '';
      
      if (!mime) {
        throw 'Please reply / send image with command.';
      }
      
      if (!/image\/(jpe?g|png)/.test(mime)) {
        throw `Only for photo.`;
      }

      const [style, noise] = text.split(' ');
      
      if (!style || !noise) {
        const helpMessage = `Please include an image.\n\n*Styles* :\n\n1. art\n2. photo\n\n*Noise* :\n\n1. 0\n2. 1\n3. 2\n4. 3\n5. -1\n\n*Example* : ${usedPrefix + command} art 0`;
        throw helpMessage;
      }

      let { key } = await m.reply(global.status.wait);
      keyMsg = key;

      let img = await q.download();

      let optimizedImg = await sharp(img)
        .resize(800) // max width 800px (otomatis scale)
        .jpeg({ quality: 80 }) // kompres kualitas 80%
        .toBuffer();

      const imageUrl = await uploadImage(optimizedImg);

      const result = await bigjpg.upscale(imageUrl, { style, noise });
      
      if (!result.success) throw result.error;

      const response = await axios.get(result.url, { responseType: 'arraybuffer' });
      if (!response.data) throw 'BigJPG failed (no data).';

      let buffer = Buffer.from(response.data);

      let date = new Date();
      let formattedDate = `${date.getMonth() + 1}-${date.getDate()}-${date.getFullYear()}`;
      let filename = (q.msg || q).fileName || 'image';
      
      await conn.sendMessage(m.chat, {
        document: buffer,
        mimetype: 'image/png',
        fileName: `${command}-${formattedDate}-${style}-${noise}.png`,
      }, { quoted: m });
      
      await conn.sendMessage(m.chat, {
        text: "Done. 👍",
        edit: keyMsg,
      });

    } catch (e) {
      throw Func.jsonFormat(e);
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingBigJPG = false;
      }
    }
  }
};