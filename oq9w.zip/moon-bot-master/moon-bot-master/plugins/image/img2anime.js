/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const sharp = require('sharp');

module.exports = {
   help: ['img2anime'],
   aliases: ['anime', 'animefy', 'toanime', 'image2anime'],
   tags: 'image',
   limit: 30,
   premium: true,
   register: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      Func,
      Scraper,
      Api
   }) => {
      let user = global.db.users[m.sender] || {};
      user.isProcessingToanime = user.isProcessingToanime || false;

      if (user.isProcessingToanime) throw global.status.previously;

      let keyMsg;
      let old;

      try {
         let q = m.quoted ? m.quoted : m;
         let mime = (q.msg || q).mimetype || '';
         if (!mime) throw 'Please reply / send image with command.';
         if (!/image\/(jpe?g|png)/.test(mime)) throw 'Only for photo.';

         user.isProcessingToanime = true;

         let { key } = await m.reply(global.status.wait);
         keyMsg = key;
         old = new Date();

         let img = await q.download();

         let optimizedImg;
         if (mime.includes('jpeg') || mime.includes('jpg')) {
            optimizedImg = await sharp(img)
               .resize(800) // Max width 800px
               .jpeg({ 
                  quality: 70,
                  mozjpeg: true 
               })
               .toBuffer();
         } else if (mime.includes('png')) {
            optimizedImg = await sharp(img)
               .resize(800) // Max width 800px
               .png({
                  quality: 70,
                  compressionLevel: 8
               })
               .toBuffer();
         }

         let image = await Scraper.uploader(optimizedImg);

         const json = await Api.get('/toanime', {
            image: image.data.url, 
            style: 'anime'
         });

         if (!json.status) throw json.msg || 'Anime conversion failed';

         let date = new Date();
         let formattedDate = `${date.getMonth() + 1}-${date.getDate()}-${date.getFullYear()}`;
         let filename = (q.msg || q).fileName || 'image';
         if (mime.includes('jpeg') || mime.includes('jpg')) {
            filename = filename.replace(/\.[^/.]+$/, ".jpg");
         } else if (mime.includes('png')) {
            filename = filename.replace(/\.[^/.]+$/, ".png");
         }

         await conn.sendMessage(m.chat, {
            image: { url: json.data.url },
//            mimetype: 'image/jpeg',
            caption: ``,
         }, { quoted: m });

         await conn.sendMessage(m.chat, {
            text: `Done. 👍`,
            edit: keyMsg,
         });

      } catch (e) {
         throw Func.jsonFormat(e);
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingToanime = false;
         }
      }
   }
}