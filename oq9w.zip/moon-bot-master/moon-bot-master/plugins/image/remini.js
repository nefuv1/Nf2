/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');
const sharp = require('sharp'); // <--- tambahan

module.exports = {
  help: ['remini'],
  tags: 'image', 
  limit: 5,
  register: true,
  run: async (m, { conn, Scraper, Func, command }) => {
    let user = global.db.users[m.sender] || {};
    user.isProcessingRemini = user.isProcessingRemini || false;

    if (user.isProcessingRemini) throw global.status.previously;
    user.isProcessingRemini = true;

    let keyMsg;

    try {
      let q = m.quoted ? m.quoted : m;
      let mime = (q.msg || q).mimetype || '';
      if (!mime) throw 'Please reply / send image with command.';
      if (!/image\/(jpe?g|png)/.test(mime)) throw `Only for photo.`;

      let { key } = await m.reply(global.status.wait);
      keyMsg = key;

      let img = await q.download();

      let optimizedImg = await sharp(img)
        .resize(800) // max width 800px
        .jpeg({ quality: 70 }) // kualitas 70%
        .toBuffer();

      let image = await Scraper.uploader(optimizedImg);

      const json = await Api.get('/remini', {
        image: image.data.url
      });
      
      if (!json.status) throw Func.jsonFormat(json);

      let date = new Date();
      let formattedDate = `${date.getMonth() + 1}-${date.getDate()}-${date.getFullYear()}`;
      let filename = (q.msg || q).fileName || 'image';
      filename = filename.replace(/\.[^/.]+$/, ".jpg");

      await conn.sendFile(m.chat, json.data.url, `${command}-${formattedDate}-${filename}`, '', m, {
        document: true
      });

      await conn.sendMessage(m.chat, {
        text: "Done. 👍",
        edit: keyMsg,
      });

    } catch (e) {
      throw Func.jsonFormat(e);
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingRemini = false;
      }
    }
  },
};