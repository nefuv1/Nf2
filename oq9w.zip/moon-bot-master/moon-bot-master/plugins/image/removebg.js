/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require("axios");
const Jimp = require("jimp");
const sharp = require("sharp"); // <--- tambahan

module.exports = {
    help: ['removebg'],
    aliases: ['rembg', 'nobg', 'bgcolor'],
    tags: 'image',
    limit: 5,
    register: true,
    run: async (m, { 
        conn, 
        args, 
        usedPrefix, 
        command,
        Func
    }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingRemoveBg = user.isProcessingRemoveBg || false;

        if (user.isProcessingRemoveBg) throw global.status.previously;
        user.isProcessingRemoveBg = true;

        let keyMsg;

        try {
            let q = m.quoted ? m.quoted : m;
            let mime = (q.msg || q).mimetype || "";

            if (!mime) throw `Please reply / send image with command.`;
            if (!/image\/(jpe?g|png)/.test(mime)) throw `Only for photo.`;

            let media = await q.download();

            let optimizedImg = await sharp(media)
                .resize(800) // max width 800px
                .jpeg({ quality: 70 }) // kompres kualitas 70%
                .toBuffer();

            let base64 = optimizedImg.toString("base64");

            let { key } = await m.reply(global.status.wait);
            keyMsg = key;

            const { data } = await axios.post(
                "https://background-remover.com/removeImageBackground",
                {
                    encodedImage: base64,
                    title: `Fiony-${Math.floor(Math.random() * 99999)}.${mime.split('/')[1] || 'jpg'}`,
                    mimeType: mime
                },
                {
                    headers: {
                        "accept": "*/*",
                        "content-type": "application/json; charset=utf-8",
                        "referer": "https://background-remover.com/upload"
                    },
                    timeout: 60000
                }
            );

            let raw = data.encodedImageWithoutBackground?.split(",")[1];
            if (!raw) throw new Error("Failed to remove background (no image returned).");

            let buffer = Buffer.from(raw, "base64");

            if (args[0] && args[0].toLowerCase() !== "transparent") {
                const color = args[0].toLowerCase();
                try {
                    const img = await Jimp.read(buffer);
                    const bg = new Jimp(img.bitmap.width, img.bitmap.height, Jimp.cssColorToHex(color));
                    bg.composite(img, 0, 0);
                    buffer = await bg.getBufferAsync(Jimp.MIME_PNG);
                } catch (err) {
                    throw `Color "${args[0]}" is not recognized in CSS`;
                }
            }

            const date = new Date();
            const formattedDate = `${date.getMonth() + 1}-${date.getDate()}-${date.getFullYear()}`;
            const filename = `${command}-${formattedDate}.png`;

            await conn.sendMessage(m.chat, {
                document: buffer,
                mimetype: 'image/png',
                fileName: filename
            }, { quoted: m });

            await conn.sendMessage(m.chat, {
                text: "Done. 👍",
                edit: keyMsg,
            });

        } catch (e) {
            console.error(e);
            throw Func.jsonFormat(e);
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingRemoveBg = false;
            }
        }
    }
};