/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const sharp = require('sharp');

module.exports = {
   help: ['txt2remover'],
   aliases: ['removetext', 'rmtext', 'cleantext', 'textremover', 'txtrem'],
   tags: 'image',
   limit: 30,
   premium: true,
   register: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      Func,
      Scraper,
      Api
   }) => {
      let user = global.db.users[m.sender] || {};
      user.isProcessingTextremover = user.isProcessingTextremover || false;

      if (user.isProcessingTextremover) throw global.status.previously;

      let keyMsg;
      let old;

      try {
         let q = m.quoted ? m.quoted : m;
         let mime = (q.msg || q).mimetype || '';
         if (!mime) throw 'Please reply / send image with command.';
         if (!/image\/(jpe?g|png)/.test(mime)) throw 'Only for photo.';

         user.isProcessingTextremover = true;

         let { key } = await m.reply(global.status.wait);
         keyMsg = key;
         old = new Date();

         let img = await q.download();

         let optimizedImg;
         if (mime.includes('jpeg') || mime.includes('jpg')) {
            optimizedImg = await sharp(img)
               .resize(800) // Max width 800px
               .jpeg({ 
                  quality: 70,
                  mozjpeg: true 
               })
               .toBuffer();
         } else if (mime.includes('png')) {
            optimizedImg = await sharp(img)
               .resize(800) // Max width 800px
               .png({
                  quality: 70,
                  compressionLevel: 8
               })
               .toBuffer();
         }

         let image = await Scraper.uploader(optimizedImg);

         const json = await Api.get('/text-remover', {
            image: image.data.url
         });

         if (!json.status) throw json.msg || 'Text removal failed';

         let date = new Date();
         let formattedDate = `${date.getMonth() + 1}-${date.getDate()}-${date.getFullYear()}`;
         let filename = (q.msg || q).fileName || 'image';
         if (mime.includes('jpeg') || mime.includes('jpg')) {
            filename = filename.replace(/\.[^/.]+$/, ".jpg");
         } else if (mime.includes('png')) {
            filename = filename.replace(/\.[^/.]+$/, ".png");
         }

         await conn.sendMessage(m.chat, {
            document: { url: json.data.url },
//            mimetype: 'image/jpeg',
            caption: ``,
         }, { quoted: m });

         await conn.sendMessage(m.chat, {
            text: `Done. 👍`,
            edit: keyMsg,
         });

      } catch (e) {
         throw Func.jsonFormat(e);
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingTextremover = false;
         }
      }
   }
}