/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const sharp = require('sharp');

module.exports = {
   help: ['img2nude'],
   aliases: ['nude', 'tonude', 'remcloth', 'clothrem', 'image2nude'],
   tags: 'image',
   premium: true,
   limit: 30,
   register: true,
   private: true,
   run: async (m, { 
      conn,
      usedPrefix,
      command,
      Func,
      Scraper,
      Api
   }) => {
      let user = global.db.users[m.sender] || {};
      user.isProcessingTonude = user.isProcessingTonude || false;

      if (user.isProcessingTonude) throw global.status.previously;

      let keyMsg;
      let old;

      try {
         let q = m.quoted ? m.quoted : m;
         let mime = (q.msg || q).mimetype || '';
         if (!mime) throw 'Please reply / send image with command.';
         if (!/image\/(jpe?g|png)/.test(mime)) throw 'Only for photo.';

         user.isProcessingTonude = true;

         let { key } = await m.reply(global.status.wait);
         keyMsg = key;
         old = new Date();

         let img = await q.download();

         let optimizedImg;
         if (mime.includes('jpeg') || mime.includes('jpg')) {
            optimizedImg = await sharp(img)
               .resize(800) // Max width 800px
               .jpeg({ 
                  quality: 70,
                  mozjpeg: true 
               })
               .toBuffer();
         } else if (mime.includes('png')) {
            optimizedImg = await sharp(img)
               .resize(800) // Max width 800px
               .png({
                  quality: 70,
                  compressionLevel: 8
               })
               .toBuffer();
         }

         let image = await Scraper.uploader(optimizedImg);

         const json = await Api.get('/ai-remove-clothes', {
            image: image.data.url
         });

         if (!json.status) throw json.msg || 'Remove clothes process failed';

         let date = new Date();
         let formattedDate = `${date.getMonth() + 1}-${date.getDate()}-${date.getFullYear()}`;
         let filename = (q.msg || q).fileName || 'image';
         if (mime.includes('jpeg') || mime.includes('jpg')) {
            filename = filename.replace(/\.[^/.]+$/, ".jpg");
         } else if (mime.includes('png')) {
            filename = filename.replace(/\.[^/.]+$/, ".png");
         }

         await conn.sendMessage(m.chat, {
            document: { url: json.data.url },
            mimetype: 'image/jpeg',
            fileName: `${command}-${formattedDate}-${filename}.jpg`,
         }, { quoted: m });

         await conn.sendMessage(m.chat, {
            text: `Done. 👍`,
            edit: keyMsg,
         });

      } catch (e) {
         throw Func.jsonFormat(e);
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingTonude = false;
         }
      }
   }
}