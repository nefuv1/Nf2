/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');
const FormData = require('form-data');
const jimp = require('jimp');
const sharp = require('sharp');

async function upscale(buffer, size = 2, anime = false) {
  try {
    return await new Promise((resolve, reject) => {
      if(!buffer) return reject("undefined buffer input!");
      if(!Buffer.isBuffer(buffer)) return reject("invalid buffer input");
      if(!/(2|4|6|8|16)/.test(size.toString())) return reject("invalid upscale size!")
      jimp.read(Buffer.from(buffer)).then(image => {
        const { width, height } = image.bitmap;
        let newWidth = width * size;
        let newHeight = height * size;
        const form = new FormData();
        form.append("name", "upscale-" + Date.now())
        form.append("imageName", "upscale-" + Date.now())
        form.append("desiredHeight", newHeight.toString())
        form.append("desiredWidth", newWidth.toString())
        form.append("outputFormat", "png")
        form.append("compressionLevel", "none")
        form.append("anime", anime.toString())
        form.append("image_file", buffer, {
          filename: "upscale-" + Date.now() + ".png",
          contentType: 'image/png',
        })
        axios.post("https://api.upscalepics.com/upscale-to-size", form, {
          headers: {
            ...form.getHeaders(),
            origin: "https://upscalepics.com",
            referer: "https://upscalepics.com"
          }
        }).then(res => {
          const data = res.data;
          if(data.error) return reject("something error from upscaler api!");
          resolve({
            status: true,
            image: data.bgRemoved
          })
        }).catch(reject)
      }).catch(reject)
    })
  } catch (e) {
    return { status: false, message: e };
  }
}

module.exports = {
  help: ['unblur'],
  tags: 'image',
  limit: 5,
  register: true,
  run: async (m, { conn, usedPrefix, text, Func }) => {
    let user = global.db.users[m.sender] || {};
    user.isProcessingUnblur = user.isProcessingUnblur || false;

    if (user.isProcessingUnblur) throw global.status.previously;
    user.isProcessingUnblur = true;

    let keyMsg;

    try {
      const defaultScale = 2;
      const defaultEnhance = false;

      const validScales = [2, 4, 6, 8, 16];
      const [scaleArg, enhanceArg] = text.split(' ');
      
      const scale = scaleArg ? parseInt(scaleArg) : defaultScale;
      if (!validScales.includes(scale)) {
        throw `Scale must be one of: ${validScales.join(", ")}.`;
      }

      const enhance = enhanceArg ? enhanceArg === 'true' : defaultEnhance;
      if (enhanceArg && enhanceArg !== 'true' && enhanceArg !== 'false') {
        throw `For anime style use "true", for real style use "false".`;
      }

      let q = m.quoted ? m.quoted : m;
      let mime = (q.msg || q).mimetype || q.mediaType || "";

      if (!mime) {
        throw `Please reply / send image with command.`;
      }

      if (!/image\/(jpe?g|png)/.test(mime)) {
        throw `File type ${mime} not supported!`;
      }

      let { key } = await m.reply(global.status.wait);
      keyMsg = key;

      let img = await q.download();

      let optimizedImg = await sharp(img)
        .resize(800) // max width 800px
        .jpeg({ quality: 80 }) // kompres kualitas 80%
        .toBuffer();

      let response;
      try {
        response = await upscale(optimizedImg, scale, enhance);
      } catch (error) {
        throw `Failed to upscale: ${error.message}`;
      }

      if (!response || !response.status) {
        throw "Failed to upscale.";
      }

      const imageResponse = await axios.get(response.image, { responseType: 'arraybuffer' });
      if (!imageResponse.data) throw 'Unblur failed (no data).';

      let buffer = Buffer.from(imageResponse.data);

      let date = new Date();
      let formattedDate = `${date.getMonth() + 1}-${date.getDate()}-${date.getFullYear()}`;
      
      await conn.sendMessage(m.chat, {
        document: buffer,
        mimetype: 'image/png',
        fileName: `unblur-${formattedDate}-${scale}x-${enhance ? 'anime' : 'real'}.png`,
      }, { quoted: m });

      await conn.sendMessage(m.chat, {
        text: "Done. 👍",
        edit: keyMsg,
      });

    } catch (e) {
      throw Func.jsonFormat(e);
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingUnblur = false;
      }
    }
  }
};