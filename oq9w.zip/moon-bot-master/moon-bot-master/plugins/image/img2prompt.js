/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const sharp = require('sharp'); // <--- tambahan

module.exports = {  
  help: ['img2prompt'],  
  aliases: ['toprompt', 'prompt', 'image2prompt'],  
  tags: 'image',  
  premium: true,  
  limit: 30,  
  register: true,  
  run: async (m, { conn, usedPrefix, command, Scraper, Func }) => {  
    let user = global.db.users[m.sender] || {};  
    user.isProcessingImgPrompt = user.isProcessingImgPrompt || false;  

    if (user.isProcessingImgPrompt) throw global.status.previously;  
    user.isProcessingImgPrompt = true;  

    let keyMsg;  

    try {  
      let q = m.quoted ? m.quoted : m;  
      let mime = (q.msg || q).mimetype 
        || (m.message && m.message.imageMessage && m.message.imageMessage.mimetype) 
        || '';  

      if (!mime) throw `Please reply / send image with command.`;  
      if (!/image\/(jpe?g|png)/.test(mime)) throw `Only for photo.`  

      let media = await conn.downloadMediaMessage(q).catch(() => null);  
      if (!media && q.download) media = await q.download().catch(() => null);  
      if (!media) throw 'Failed to download image.';  

      let optimizedImg = await sharp(media)
        .resize(800) // max width 800px
        .jpeg({ quality: 70 }) // kompres kualitas 70%
        .toBuffer();

      let urlUpload = await Scraper.tmpfiles(optimizedImg);  
      if (!urlUpload || !urlUpload.data || !urlUpload.data.url) {  
        throw new Error('Failed to upload image to server');  
      }  

      let { key } = await m.reply(global.status.wait);  
      keyMsg = key;  

      const response = await fetch('https://fluxai.pro/api/prompts/describe', {  
        method: 'POST',  
        headers: { 'Content-Type': 'application/json' },  
        body: JSON.stringify({  
          url: urlUpload.data.url,  
          type: 'more-detailed' // opsi: simple, detailed, more-detailed
        })  
      });  

      if (!response.ok) throw new Error(`API request failed with status ${response.status}`);  

      const json = await response.json();  
      if (!json.ok || !json.results) throw new Error(json.message || "Failed to generate prompt.");  

      await conn.sendMessage(m.chat, {  
        text: `${json.results}`,  
        edit: keyMsg,  
      });  

    } catch (e) {  
      console.error(e);  
      throw Func.jsonFormat(e);  
    } finally {  
      if (global.db.users[m.sender]) {  
        global.db.users[m.sender].isProcessingImgPrompt = false;  
      }  
    }  
  }  
};