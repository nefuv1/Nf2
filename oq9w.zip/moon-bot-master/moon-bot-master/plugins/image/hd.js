/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');
const sharp = require('sharp');
const FormData = require('form-data');

class UpscaleImageAPI {
  constructor() {
    this.api = null;
    this.server = null;
    this.taskId = null;
    this.token = null;
  }

  async getTaskId() {
    try {
      const { data: html } = await axios.get("https://www.iloveimg.com/upscale-image", {
        headers: {
          "Accept": "*/*",
          "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
          "Connection": "keep-alive",
          "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36",
          "sec-ch-ua": '"Not A(Brand";v="8", "Chromium";v="132"',
          "sec-ch-ua-mobile": "?1",
          "sec-ch-ua-platform": '"Android"',
          "Sec-Fetch-Dest": "document",
          "Sec-Fetch-Mode": "navigate",
          "Sec-Fetch-Site": "none",
          "Sec-Fetch-User": "?1",
        },
      });

      const tokenMatches = html.match(/(ey[a-zA-Z0-9?%-_/]+)/g);
      if (!tokenMatches || tokenMatches.length < 2) {
        throw new Error("Token not found.");
      }
      this.token = tokenMatches[1];

      const configMatch = html.match(/var ilovepdfConfig = ({.*?});/s);
      if (!configMatch) {
        throw new Error("Server configuration not found.");
      }
      const configJson = JSON.parse(configMatch[1]);
      const servers = configJson.servers;
      if (!Array.isArray(servers) || servers.length === 0) {
        throw new Error("Server list is empty.");
      }

      this.server = servers[Math.floor(Math.random() * servers.length)];
      this.taskId = html.match(/ilovepdfConfig\.taskId\s*=\s*['"](\w+)['"]/)?.[1];

      this.api = axios.create({
        baseURL: `https://${this.server}.iloveimg.com`,
        headers: {
          "Accept": "*/*",
          "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
          "Authorization": `Bearer ${this.token}`,
          "Connection": "keep-alive",
          "Origin": "https://www.iloveimg.com",
          "Referer": "https://www.iloveimg.com/",
          "Sec-Fetch-Dest": "empty",
          "Sec-Fetch-Mode": "cors",
          "Sec-Fetch-Site": "same-site",
          "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36",
          "sec-ch-ua": '"Not A(Brand";v="8", "Chromium";v="132"',
          "sec-ch-ua-mobile": "?1",
          "sec-ch-ua-platform": '"Android"',
        },
      });

      if (!this.taskId) throw new Error("Task ID not found!");

      return { taskId: this.taskId, server: this.server, token: this.token };
    } catch (error) {
      throw new Error(`Failed to get Task ID: ${error.message}`);
    }
  }

  async uploadFromUrl(imageUrl) {
    if (!this.taskId || !this.api) {
      throw new Error("Task ID or API not available. Run getTaskId() first.");
    }

    try {
      const imageResponse = await axios.get(imageUrl, {
        responseType: "arraybuffer",
        headers: {
          "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36",
        },
        timeout: 15000,
      });

      const buffer = Buffer.from(imageResponse.data);
      let mimeType = 'image/jpeg';
      if (buffer[0] === 0x89 && buffer[1] === 0x50 && buffer[2] === 0x4E && buffer[3] === 0x47) {
        mimeType = 'image/png';
      } else if (buffer[0] === 0xFF && buffer[1] === 0xD8 && buffer[2] === 0xFF) {
        mimeType = 'image/jpeg';
      } else if (buffer[0] === 0x47 && buffer[1] === 0x49 && buffer[2] === 0x46) {
        mimeType = 'image/gif';
      } else if (buffer[0] === 0x52 && buffer[1] === 0x49 && buffer[2] === 0x46 && buffer[3] === 0x46) {
        mimeType = 'image/webp';
      }

      const fileName = `image.${mimeType.split('/')[1]}`;

      const form = new FormData();
      form.append("name", fileName);
      form.append("chunk", "0");
      form.append("chunks", "1");
      form.append("task", this.taskId);
      form.append("preview", "1");
      form.append("pdfinfo", "0");
      form.append("pdfforms", "0");
      form.append("pdfresetforms", "0");
      form.append("v", "web.0");
      form.append("file", buffer, { filename: fileName, contentType: mimeType });

      const response = await this.api.post("/v1/upload", form, {
        headers: form.getHeaders(),
      });

      return response.data;
    } catch (error) {
      throw new Error(`Failed to upload file: ${error.message}`);
    }
  }

  async upscaleImage(serverFilename, scale = 4) {
    if (!this.taskId || !this.api) {
      throw new Error("Task ID or API not available. Run getTaskId() first.");
    }

    if (scale !== 2 && scale !== 4) {
      throw new Error("Scale can only be 2 or 4.");
    }

    try {
      const form = new FormData();
      form.append("task", this.taskId);
      form.append("server_filename", serverFilename);
      form.append("scale", scale.toString());

      const response = await this.api.post("/v1/upscale", form, {
        headers: form.getHeaders(),
        responseType: "arraybuffer",
      });

      return response.data;
    } catch (error) {
      console.error("Error detail:", error.response ? error.response.data : error);
      throw new Error(`Failed to perform upscaling: ${error.message}`);
    }
  }
}

module.exports = {
  help: ['hd'],
  aliases: ['hade'],
  tags: 'image',
  limit: 5,
  register: true,
  run: async (m, { conn, Scraper, Func, command }) => {
    let user = global.db.users[m.sender] || {};
    user.isProcessingHD = user.isProcessingHD || false;

    if (user.isProcessingHD) throw global.status.previously;
    user.isProcessingHD = true;

    let keyMsg;

    try {
      let q = m.quoted ? m.quoted : m;
      let mime = (q.msg || q).mimetype || '';
      if (!mime) throw 'Please reply / send image with command.';
      if (!/image\/(jpe?g|png|webp)/.test(mime)) throw `Only for photo.`;

      let { key } = await m.reply(global.status.wait);
      keyMsg = key;

      let img = await q.download();

      let optimizedImg = await sharp(img)
        .resize(800) // max width 800px (otomatis scale)
        .jpeg({ quality: 70 }) // kompres kualitas 70%
        .toBuffer();

      let image = await Scraper.uploader(optimizedImg);

      const upscaler = new UpscaleImageAPI();
      
      await upscaler.getTaskId();
      
      const uploadResult = await upscaler.uploadFromUrl(image.data.url);
      
      if (!uploadResult || !uploadResult.server_filename) {
        throw new Error("Failed to upload image to iloveimg.");
      }

      const upscaledBuffer = await upscaler.upscaleImage(uploadResult.server_filename, 4);

      let date = new Date();
      let formattedDate = `${date.getMonth() + 1}-${date.getDate()}-${date.getFullYear()}`;
      let filename = (q.msg || q).fileName || 'image';
      filename = filename.replace(/\.[^/.]+$/, "") + '_hd.jpg';

      await conn.sendMessage(m.chat, {
        document: upscaledBuffer,
        mimetype: 'image/jpeg',
        fileName: `${command}-${formattedDate}-${filename}`,
      }, { quoted: m });

      await conn.sendMessage(m.chat, {
        text: "Done. 👍",
        edit: keyMsg,
      });

    } catch (e) {
      console.error(e);
      throw Func.jsonFormat(e);
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingHD = false;
      }
    }
  },
};