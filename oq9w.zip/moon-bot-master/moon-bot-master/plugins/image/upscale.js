/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require("axios");
const FormData = require("form-data");
const sharp = require("sharp");

class ImgUpscaler {
    constructor() {
        this.apiUrl = "https://get1.imglarger.com/api/UpscalerNew/UploadNew";
        this.statusUrl = "https://get1.imglarger.com/api/UpscalerNew/CheckStatusNew";
        this.headers = {
            accept: "application/json, text/plain, */*",
            "accept-language": "id-ID,id;q=0.9",
            origin: "https://imgupscaler.com",
            referer: "https://imgupscaler.com/",
            "user-agent":
                "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36",
        };
    }

    async upscale({ imgUrl, scale = 2 }) {
        try {
            const { data: fileBuffer, headers } = await axios.get(imgUrl, { responseType: "arraybuffer" });
            const ext = headers["content-type"].split("/")[1];

            let formData = new FormData();
            formData.append("myfile", fileBuffer, {
                filename: `file.${ext}`,
                contentType: `image/${ext}`,
            });
            formData.append("scaleRadio", scale.toString());

            const { data } = await axios.post(this.apiUrl, formData, {
                headers: {
                    ...this.headers,
                    ...formData.getHeaders(),
                },
            });

            if (data.code === 200 && data.data?.code) {
                return await this.pollStatus({ jobCode: data.data.code, scale });
            } else {
                throw new Error("Upload failed or invalid response.");
            }
        } catch (error) {
            console.error("Upload failed : ", error.response?.data || error.message);
            return null;
        }
    }

    async pollStatus({ jobCode, scale }) {
        try {
            while (true) {
                const { data } = await axios.post(
                    this.statusUrl,
                    { code: jobCode, scaleRadio: scale },
                    {
                        headers: {
                            ...this.headers,
                            "content-type": "application/json",
                        },
                    }
                );
                if (data.code === 200 && data.data?.status === "success") {
                    return data.data;
                }
                await new Promise((res) => setTimeout(res, 5000));
            }
        } catch (error) {
            console.error("Polling failed : ", error.response?.data || error.message);
            return null;
        }
    }
}

module.exports = {
    help: ["upscale"],
    tags: "image",
    limit: 5,
    register: true,
    run: async (m, { conn, usedPrefix, command, Func, Scraper }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingUpscale = user.isProcessingUpscale || false;

        if (user.isProcessingUpscale) throw global.status.previously;

        let keyMsg;

        try {
            let q = m.quoted ? m.quoted : m;
            let mime = (q.msg || q).mimetype || "";
            if (!/image\/(jpe?g|png)/.test(mime)) throw `Please reply / send image with command.`;

            user.isProcessingUpscale = true;

            let { key } = await m.reply(global.status.wait);
            keyMsg = key;

            let img = await q.download();

            let optimizedImg;
            if (mime.includes('jpeg') || mime.includes('jpg')) {
                optimizedImg = await sharp(img)
                    .resize(800) // Max width 800px
                    .jpeg({ 
                        quality: 70,
                        mozjpeg: true 
                    })
                    .toBuffer();
            } else if (mime.includes('png')) {
                optimizedImg = await sharp(img)
                    .resize(800) // Max width 800px
                    .png({
                        quality: 70,
                        compressionLevel: 8
                    })
                    .toBuffer();
            }

            let url = await Scraper.uploader(optimizedImg);

            let filename = (q.msg || q).fileName || "image";
            if (mime.includes("jpeg") || mime.includes("jpg")) {
                filename = filename.replace(/\.[^/.]+$/, ".jpg");
            } else if (mime.includes("png")) {
                filename = filename.replace(/\.[^/.]+$/, ".png");
            }

            let date = new Date();
            let formattedDate = `${date.getMonth() + 1}-${date.getDate()}-${date.getFullYear()}`;

            const upscaler = new ImgUpscaler();
            let json = await upscaler.upscale({ imgUrl: url.data.url, scale: 2 });

            if (!json || !json.downloadUrls || json.downloadUrls.length === 0) {
                throw "Upscaling failed or no download URL found."
            }

            const { data: resultBuffer } = await axios.get(json.downloadUrls[0], {
                responseType: 'arraybuffer'
            });

            await conn.sendMessage(
                m.chat,
                {
                    document: Buffer.from(resultBuffer),
                    mimetype: "image/png",
                    fileName: `${command}-${formattedDate}-${filename}.png`,
                },
                { quoted: m }
            );

            await conn.sendMessage(m.chat, { 
                text: "Done. 👍", 
                edit: keyMsg 
            });

        } catch (e) {
            console.log(e);
            throw Func.jsonFormat(e);
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingUpscale = false;
            }
        }
    },
};