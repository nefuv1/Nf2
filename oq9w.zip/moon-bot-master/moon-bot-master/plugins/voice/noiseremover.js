/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');
const crypto = require('crypto');
const FormData = require('form-data');

function cyphereddata(t, r = "cryptoJS") {
    t = t.toString();
    const e = crypto.randomBytes(32);
    const a = crypto.randomBytes(16);
    const i = crypto.pbkdf2Sync(r, e, 999, 32, 'sha512');
    const cipher = crypto.createCipheriv('aes-256-cbc', i, a);
    let encrypted = cipher.update(t, 'utf8', 'base64');
    encrypted += cipher.final('base64');
    return JSON.stringify({
        amtext: encrypted,
        slam_ltol: e.toString('hex'),
        iavmol: a.toString('hex')
    });
}

const NoiseRemover = {
    async run(buffer) {
        const timestamp = Math.floor(Date.now() / 1000);
        const encryptedData = JSON.parse(cyphereddata(timestamp));

        const formData = new FormData();
        formData.append('media', buffer, { filename: crypto.randomBytes(3).toString('hex') + '_input.mp3' });
        formData.append('fingerprint', crypto.randomBytes(16).toString('hex'));
        formData.append('mode', 'pulse');
        formData.append('amtext', encryptedData.amtext);
        formData.append('iavmol', encryptedData.iavmol);
        formData.append('slam_ltol', encryptedData.slam_ltol);

        const response = await axios.post(
            'https://noiseremoval.net/wp-content/plugins/audioenhancer/requests/noiseremoval/noiseremovallimited.php',
            formData,
            {
                headers: {
                    ...formData.getHeaders(),
                    "accept": "*/*",
                    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                    "x-requested-with": "XMLHttpRequest",
                    "Referer": "https://noiseremoval.net/",
                },
            }
        );

        return response.data;
    }
};

module.exports = {
    help: ['removenoise'],
    tags: 'voice',
    aliases: ['noiseremover', 'noiserem', 'remnoise', 'nr'],
    register: true,
    premium: true, 
    limit: 30,   
    run: async (m, { conn, Func, command }) => {

        let user = global.db.users[m.sender] || {};
        user.isProcessingRemnoise = user.isProcessingRemnoise || false;

        if (user.isProcessingRemnoise) throw global.status.previously;
        user.isProcessingRemnoise = true;

        try {
            let quoted = m.quoted || m;
            if (!quoted || !(quoted.mtype === 'audioMessage' || quoted.mtype === 'videoMessage')) {
                throw `Please reply / send video / audio with command.`
            }
            
            m.react(global.react);

            let buffer = await quoted.download();
            let result = await NoiseRemover.run(buffer);

            if (!result || result.error || !result.media?.enhanced?.uri) {
                throw new Error('Failed to process audio.');
            }

            let outputUrl = result.media.enhanced.uri;

            await conn.sendMessage(m.chat, {
                audio: { url: outputUrl },
                mimetype: 'audio/mp4',
                fileName: 'Processed_Audio.mp3'
            }, { quoted: m });

        } catch (e) {
            console.error(e);
            throw Func.jsonFormat(e)
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingRemnoise = false;
            }
        }
    }
};