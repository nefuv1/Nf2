/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const fetch = require('node-fetch');
const FormData = require('form-data');

async function FindSong(buffer) {
    const form = new FormData();
    form.append('file', buffer, { filename: 'audio.mp3', contentType: 'audio/mp3' });
    form.append('sample_size', buffer.length);

    const response = await fetch('https://api.doreso.com/humming', {
        method: 'POST',
        headers: {
            ...form.getHeaders(),
            "accept": "application/json, text/plain, */*",
            "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
            "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": "\"Android\"",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "cross-site",
            "Referer": "https://aha-music.com/",
            "Referrer-Policy": "strict-origin-when-cross-origin"
        },
        body: form
    });

    if (!response.ok) throw new Error(`HTTP Error ${response.status}`);
    return await response.json();
}

module.exports = {
    help: ['findsong'],
    aliases: ['find', 'detectsong'],
    tags: 'voice',
    limit: 5,
    register: true,
    run: async (m, { conn, usedPrefix, Func, command }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingFindsong = user.isProcessingFindsong || false;

        if (user.isProcessingFindsong) throw global.status.previously
        
        let quoted = m.quoted || m;
        if (!quoted || !(quoted.mtype === 'audioMessage' || quoted.mtype === 'videoMessage')) {
            throw `Please reply / send video / audio with command.`
        }

        try {
            user.isProcessingFindsong = true;
            m.react(global.react);

            let buffer = await quoted.download();
            let result = await FindSong(buffer);

            if (!result || !result.data || !result.data.title) {
                throw new Error('Song not found. Try using clearer audio.');
            }

            let { artists, title } = result.data;
            let output = `*FIND SONG*\n\n- *Title* : ${title}\n- *Artist* : ${artists}\n\nSorry if the results are not accurate.`;
            
            m.reply(output);

        } catch (e) {
            console.error(e);
            throw Func.jsonFormat(e)
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingFindsong = false;
            }
        }
    }
};