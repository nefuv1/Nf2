/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const fs = require('fs');
const path = require('path');
const FormData = require('form-data');
const axios = require('axios');
const { exec } = require('child_process');
const { tmpdir } = require('os');

const openAi = {
  maxCharPerRequest: 1000,
  voices: ['Nova', 'Coral', 'Fable', 'Echo', 'Shimmer'],
  defaultVoice: 'Nova',
  api: {
    base: 'https://www.openai.fm/api',
    endpoints: {
      generate: '/generate'
    },
    headers: {
      origin: 'https://www.openai.fm',
      referer: 'https://www.openai.fm/'
    },
  },
  
  chunkText: (text, maxLength = 1000) => {
    const chunks = [];
    for (let i = 0; i < text.length; i += maxLength) {
      chunks.push(text.substring(i, i + maxLength));
    }
    return chunks;
  },
  
  generate: async (input, voice) => {
    try {  
      const formData = new FormData();  
      formData.append('input', input);  
      formData.append('voice', voice.toLowerCase());  

      const { data } = await axios.post(
        `${openAi.api.base}${openAi.api.endpoints.generate}`, 
        formData, 
        {  
          headers: { ...formData.getHeaders(), ...openAi.api.headers },  
          responseType: 'arraybuffer',  
          maxBodyLength: Infinity,  
          maxContentLength: Infinity,  
        }
      );  

      return { status: true, audio: data };  
    } catch (error) {  
      return {  
        status: false,  
        error: error.response?.data || error.message  
      };  
    }
  },
  
  combineAudios: (audioFiles, outputPath) => {
    return new Promise((resolve, reject) => {
      const listPath = path.join(tmpdir(), 'filelist.txt');
      const fileList = audioFiles.map(file => `file '${file}'`).join('\n');
      fs.writeFileSync(listPath, fileList);
      
      const cmd = `ffmpeg -f concat -safe 0 -i "${listPath}" -c copy "${outputPath}"`;
      
      exec(cmd, (error, stdout, stderr) => {
        fs.unlinkSync(listPath);
        if (error) {
          console.error('FFmpeg Error : ', stderr);
          return reject(error);
        }
        resolve(outputPath);
      });
    });
  }
};

module.exports = {
    help: ['txt2speech'],
    aliases: ['tts'],
    tags: 'voice',
    premium: true,
    limit: 30,
    register: true,
    run: async (m, { 
        conn, 
        usedPrefix, 
        command, 
        args,
        Func
    }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingTTS = user.isProcessingTTS || false;

        if (user.isProcessingTTS) {
            throw global.status.previously
        }

        if (!args[0]) {
            throw `Please provide text.\n\n*Example* : ${usedPrefix + command} TechBOT`
        }

        const text = args.join(' ');
        if (text.length > 5000) {
            throw 'Max 5000 characters.'
        }

        user.isProcessingTTS = true;
        let tempDir, outputPath;

        try {
            m.react(global.react);           

            tempDir = path.join(tmpdir(), `tts_${Date.now()}`);
            if (!fs.existsSync(tempDir)) {
                fs.mkdirSync(tempDir);
            }

            const textChunks = openAi.chunkText(text, openAi.maxCharPerRequest);
            const tempFiles = [];
            
            for (const [index, chunk] of textChunks.entries()) {
                const result = await openAi.generate(chunk, openAi.defaultVoice);
                if (!result.status) {
                    throw new Error(result.error);
                }
                
                const tempPath = path.join(tempDir, `part_${index}.mp3`);
                fs.writeFileSync(tempPath, result.audio);
                tempFiles.push(tempPath);
            }

            outputPath = path.join(tempDir, 'combined.mp3');
            
            if (tempFiles.length === 1) {
                await conn.sendMessage(m.chat, {
                    audio: { url: tempFiles[0] },
                    mimetype: 'audio/mpeg',
                    fileName: 'tts.mp3'
                }, { quoted: m });
            } else {
                await openAi.combineAudios(tempFiles, outputPath);
                await conn.sendMessage(m.chat, {
                    audio: { url: outputPath },
                    mimetype: 'audio/mpeg',
                    fileName: 'tts.mp3'
                }, { quoted: m });
            }

        } catch (e) {
            console.error(e);
            throw Func.jsonFormat(e)
        } finally {
            try {
                if (tempDir && fs.existsSync(tempDir)) {
                    const files = fs.readdirSync(tempDir);
                    for (const file of files) {
                        fs.unlinkSync(path.join(tempDir, file));
                    }
                    fs.rmdirSync(tempDir);
                }
            } catch (cleanupErr) {
                console.error(cleanupErr);
            }
            
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingTTS = false;
            }
        }
    }
};