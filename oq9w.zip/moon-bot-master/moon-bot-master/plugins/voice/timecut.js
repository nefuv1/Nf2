/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const fs = require('fs');
const path = require('path');
const ffmpeg = require('fluent-ffmpeg');

async function cutAudio(buffer, startTime, endTime) {
  return new Promise((resolve, reject) => {
    const inputPath = path.join(__dirname, `input_${Date.now()}.mp3`);
    const outputPath = path.join(__dirname, `cut_${Date.now()}.mp3`);

    fs.writeFileSync(inputPath, buffer);

    ffmpeg(inputPath)
      .setStartTime(startTime) // format HH:MM:SS
      .setDuration(calcDuration(startTime, endTime)) // hitung durasi
      .output(outputPath)
      .on('end', () => {
        const result = fs.readFileSync(outputPath);
        fs.unlinkSync(inputPath);
        fs.unlinkSync(outputPath);
        resolve(result);
      })
      .on('error', (err) => {
        if (fs.existsSync(inputPath)) fs.unlinkSync(inputPath);
        if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
        reject(err);
      })
      .run();
  });
}

function calcDuration(start, end) {
  const toSeconds = (time) => {
    const [h, m, s] = time.split(':').map(Number);
    return h * 3600 + m * 60 + s;
  };
  return toSeconds(end) - toSeconds(start);
}

module.exports = {
  help: ['timecut'],
  aliases: ['cut', 'audiocut', 'cutaudio', 'cuttime'],
  tags: 'voice',
  limit: 5,
  register: true,
  run: async (m, { conn, usedPrefix, Func, command, args }) => {
    let user = global.db.users[m.sender] || {};
    user.isProcessingTimecut = user.isProcessingTimecut || false;

    if (user.isProcessingTimecut) throw global.status.previously;
    user.isProcessingTimecut = true;

    let countdownInterval;
    let count = 0;
    let keyMsg;

    try {
      if (args.length < 2) {
        throw `Please specify (minute_start) and (minute_end).\n\n*Example* : ${usedPrefix + command} 00:01:00 00:02:00`;
      }

      let quoted = m.quoted || m;
      if (!quoted || !(quoted.mtype === 'audioMessage' || quoted.mtype === 'videoMessage')) {
        throw `Please reply / send an audio / video with command.`;
      }

      const start = args[0];
      const end = args[1];
      
      let { key } = await m.reply(global.status.wait);
      keyMsg = key;

      countdownInterval = setInterval(async () => {
        count++;
        try {
          await conn.sendMessage(m.chat, {
            text: `${global.status.wait} (${count}s)`,
            edit: keyMsg,
          });
        } catch {}
      }, 1000);

      let buffer = await quoted.download();
      let cutBuffer = await cutAudio(buffer, start, end);

      await conn.sendMessage(
        m.chat,
        {
          audio: cutBuffer,
          mimetype: 'audio/mp4',
          fileName: `CutAudio_${start.replace(/:/g, '-')}_${end.replace(/:/g, '-')}.mp3`
        },
        { quoted: m }
      );

      await conn.sendMessage(m.chat, {
        text: "Done. 👍",
        edit: keyMsg,
      });

    } catch (e) {
      console.error(e);
      throw Func.jsonFormat(e);
    } finally {
      if (countdownInterval) clearInterval(countdownInterval);
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingTimecut = false;
      }
    }
  },
};