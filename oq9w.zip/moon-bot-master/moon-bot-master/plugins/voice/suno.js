/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');

const SonuAI = {
    help: ['suno'],
    tags: 'voice',
    aliases: ['musicai', 'sonu'],
    premium: true,
    limit: 30,
    register: true,
    run: async (m, { conn, text, usedPrefix, command, Func }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingSonu = user.isProcessingSonu || false;

        if (user.isProcessingSonu) throw global.status.previously;
        user.isProcessingSonu = true;

        try {
            if (!text) {
                throw `Please fill in the data first.\n\n*Example* :\n- ${usedPrefix + command} lyrics | style | instruments \n- ${usedPrefix + command} I love you | sad | jazz, classic`;
            }

            const parts = text.split('|').map(a => a.trim());
            const lyricsRaw = parts[0];
            const styleRaw = parts[1] || "Anthem";
            const instrumentRaw = parts[2] || "Classic";

            if (!lyricsRaw) {
                throw `Lyrics cannot be empty.`;
            }

            let waitMsg = await m.reply(`Generating song... `);

            const response = await axios.get(`https://omegatech-api.dixonomega.tech/api/ai/Sonu`, {
                params: {
                    lyrics: lyricsRaw,
                    style: styleRaw,
                    instrument: instrumentRaw
                },
                timeout: 60000
            });

            const json = response.data;

            if (!json.success || !json.results?.length) {
                throw new Error(`Generation failed or no results returned.`);
            }

            for (let i = 0; i < json.results.length; i++) {
                const item = json.results[i];
                
                await conn.sendMessage(m.chat, {
                    audio: { url: item.audio },
                    mimetype: 'audio/mpeg',
                    fileName: `sonu_music_v${i + 1}.mp3`
                }, { quoted: m });

                if (i < json.results.length - 1) {
                    await new Promise(resolve => setTimeout(resolve, 2000));
                }
            }

            await conn.sendMessage(m.chat, {
                text: "Done. 👍",
                edit: waitMsg.key,
            });

        } catch (e) {
            console.error(e);
            throw Func.jsonFormat(e);
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingSonu = false;
            }
        }
    }
};

module.exports = SonuAI;