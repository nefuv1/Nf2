module.exports = {
   run: async (m, {
      conn,
      body,
      isOwner,
      isAdmin,
      groupSet,
      setting,
      isBotAdmin,
      Func
   }) => {
      try {
         if (
            m.isGroup &&
            groupSet.antisticker &&
            /stickerMessage/i.test(m.mtype) &&
            !isAdmin && !isOwner 
         ) {
            global.react("⚠️")
            await conn.sendMessage(m.chat, {
               delete: {
                  remoteJid: m.chat,
                  fromMe: false,
                  id: m.key.id,
                  participant: m.sender
               }
            });
         }
      } catch (e) {
         console.error(e);
      }
   },
   group: true,
   isBotAdmin: true,
   error: false
};