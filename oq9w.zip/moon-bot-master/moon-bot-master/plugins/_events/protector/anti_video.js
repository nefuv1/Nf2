module.exports = {
  run: async (m, { conn, isAdmin, isBotAdmin, groupSet }) => {
    if (m.isBaileys && m.fromMe) return true;
    
    if (groupSet.antivideo && !isAdmin && m.mtype === "videoMessage") {
      if (!isBotAdmin) return true;
      
      try {
        global.react("⚠️")
        await conn.sendMessage(m.chat, {
          delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.sender
          }
        });
      } catch (error) {
        console.error(error);
      }
    }
    return true;
  },
   group: true,
   isAdmin: true,
   error: false
};