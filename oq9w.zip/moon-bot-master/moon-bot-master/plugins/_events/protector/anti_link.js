module.exports = {
   run: async (m, {
      conn,
      body,
      isAdmin,
      isBotAdmin,
      groupSet
   }) => {
      if (groupSet.antilink && !isAdmin && body) {
         if (body.match(/(chat\.whatsapp\.com)/gi) && !body.includes(await conn.groupInviteCode(m.chat))) {
            global.react("⚠️")
            await conn.sendMessage(m.chat, {
               delete: {
                  remoteJid: m.chat,
                  fromMe: false,
                  id: m.key.id,
                  participant: m.sender
               }
            })
            return conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
         }

         if (body.match(/(whatsapp\.com\/channel)/gi)) {
            global.react("⚠️")
            return conn.sendMessage(m.chat, {
               delete: {
                  remoteJid: m.chat,
                  fromMe: false,
                  id: m.key.id,
                  participant: m.sender
               }
            })
         }
      }
   },
   group: true,
   isBotAdmin: true,
   error: false
}