module.exports = {
  run: async (m, { conn, body, groupSet, isAdmin, isBotAdmin }) => {
    if (m.isBaileys && m.fromMe) return true;
    
    let chat = global.db.chats[m.chat] || {};
    let isFoto = m.mtype;
    
    if (groupSet.antifoto && isFoto === "imageMessage") {
      if (isAdmin || !isBotAdmin) {
        return true;
      } else {
        global.react("⚠️")
        setTimeout(async () => {
          try {
            await conn.sendMessage(m.chat, { delete: m.key });
          } catch (error) {
            console.error(error);
          }
        }, 10000);
        return false;
      }
    }
    return true;
  },
   group: true,
   isAdmin: true,
   error: false
};