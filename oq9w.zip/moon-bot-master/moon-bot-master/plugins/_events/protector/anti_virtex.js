module.exports = {
   run: async (m, { conn, groupSet, isBotAdmin, body, Func }) => {
      try {
         if (!isBotAdmin) return
         if (!m.fromMe && body && groupSet.antivirtex) {
            if (body.match(/ﱣﱣﱣﱣﱣﱣﱣ|؀؁؀؁|᥋᥋᥋᥋᥋᥋᥋᥋᥋|[🎩]-𝑬𝒙𝒑𝒍𝒐𝒔𝒊𝒐𝒏-💥|ผิด| ⃢|𒅒ܷܷܷܷܷ֭֭֭֭֭֭֭֭֭ࣧࣧࣧࣧࣧࣧࣧࣧࣧࣧࣧ̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊ࠝࠝࠝࠝࠝࠝࠝ𒅒ܷܷܷܷܷۣۣۣۣۣۣۣۣۣۣۣۣۣۣٚٚٚٚٚٚٚٚٚٚٚٚٚٚٚٚ̂̂̂̂̂̂̂̂̂̂̂̂̂̂̂ۜۜۜۜۜۜ˳֗֗֗֗֗ࠧࠧࠧࠧࠬࠬࠬࠬࠬࠬࠬͦͦͦͦͦͦͦͦࠝࠝࠝࠝ𒅒ۣۣۣۣۣۣۣۣۣ֗֗̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊̊ 𑂺𑂺𑂺𑂺𑂺ۣۣۣۣۣۣۣۣۣۣۣۣۣۜۜۜۜۜۜۜۜۜۜۜ̂̂̂̂̂̂̂̂̂̂̂ࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧࠧ֯֯֯֯֯˳ْْْْْ֛֛֛ۨۨۨۨۨۨۨۨۨۨۨ |؛*.*ࣨࣨ|৭৭৭|๒๒๒|؋.ᄻ.ྜྷ.ᇸ.ྙ|๖ۣۜy๖ۣۜF๖ۣۜr๖|๑๑๑|৭৭৭৭৭৭৭|๑๑๑๑๑๑๑๑|ผิดุท้่เึางืผิดุท้่เึางื|๒๒๒๒২২๒|ผิดุท้่เึางืผิดุท้่เึางื|PLHIPS|๒|๑|ৡ|⃟|Đ.Δ.Μ|ท้่เึางื|virtex|virtek|𖣘𝓜꙰⃢⃠⃠⃠⃠⃠/gi) || body.length > 10000) {
               global.react("⚠️")
               
               await conn.sendMessage(m.chat, {
                  delete: {
                     remoteJid: m.chat,
                     fromMe: false,
                     id: m.key.id,
                     participant: m.sender
                  }
               })

               await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            }
         }
      } catch (e) {
         console.error(e)
         return conn.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   group: true,
   botAdmin: true,
   error: false
}