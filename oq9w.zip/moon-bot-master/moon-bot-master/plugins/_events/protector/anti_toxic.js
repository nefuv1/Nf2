module.exports = {
   run: async (m, {
      conn,
      body,
      groupSet,
      setting,
      isAdmin,
      isBotAdmin,
      Func
   }) => {
      try {
         if (groupSet.antitoxic && !isAdmin && isBotAdmin && !m.fromMe) {
            let toxic = setting.toxic
            if (body && (new RegExp('\\b' + toxic.join('\\b|\\b') + '\\b')).test(body.toLowerCase())) {
               global.react("⚠️")

               if (!groupSet.member[m.sender]) {
                  groupSet.member[m.sender] = { toxicCount: 0, warnCount: 0 }
               }

               let user = groupSet.member[m.sender]

               user.toxicCount += 1

               await conn.sendMessage(m.chat, {
                  delete: {
                     remoteJid: m.chat,
                     fromMe: false,
                     id: m.key.id,
                     participant: m.sender
                  }
               })

               if (user.toxicCount <= 5) return

               user.warnCount += 1

               if (user.warnCount >= 3) {
                  await conn.reply(m.chat, `@${m.sender.split('@')[0]} has received 3 warnings and has been removed from the group.`, m, { mentions: [m.sender] })
                  await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')

                  user.toxicCount = 0
                  user.warnCount = 0
                  return
               }

               return conn.reply(m.chat, `@${m.sender.split('@')[0]} received ${user.warnCount}/3 warnings.
If you reach 3 warnings, you will be removed from the group.`, m, { mentions: [m.sender] })
            }
         }
      } catch (e) {
         return conn.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   group: true,
   botAdmin: true,
   error: false
}