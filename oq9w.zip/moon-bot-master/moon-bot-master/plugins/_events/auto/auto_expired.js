module.exports = {
  run: async (m, {
    conn,
    body,
    isOwner,
    groupSet,
    setting,
    isBotAdmin,
    Func
  }) => {
    try {
      if (!m.isGroup) return;

      if (!global.db || !global.db.groups) return;
      
      const groupsDB = global.db.groups;
      const group = groupsDB[m.chat];

      if (!group || !group.expired || group.expired === 0) return;

      if (Date.now() > group.expired) {
        try {
          await conn.reply(m.chat, 'The group rental period has expired. The bot will exit automatically. For extension, contact the owner.', m);

          group.expired = 0;

          if (Func && typeof Func.delay === 'function') {
            await Func.delay(5000);
          } else {
            await new Promise(resolve => setTimeout(resolve, 5000));
          }

          await conn.groupLeave(m.chat).catch(() => {});

          if (global.db && global.db.groups) {
            delete global.db.groups[m.chat];
          }
        } catch (e) {
          console.log('Error leaving group :', e);
          if (group) group.expired = 0;
        }
      }
    } catch (e) {
      console.log(e);
    }
  },
  group: true,
  error: false
};