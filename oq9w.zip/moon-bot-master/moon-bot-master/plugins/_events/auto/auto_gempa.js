const fetch = require('node-fetch');

const gempaData = {
  lastUpdate: null,
  lastGempa: null,
  interval: null,
  activeChats: new Set()
};

const startPolling = (conn) => {
  if (gempaData.interval) return;

  gempaData.interval = setInterval(async () => {
    try {
      const link = 'https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json';
      const response = await fetch(link);
      const { gempa: newGempa } = (await response.json()).Infogempa;

      if (!gempaData.lastGempa || newGempa.DateTime !== gempaData.lastGempa.DateTime) {
        gempaData.lastUpdate = Date.now();
        gempaData.lastGempa = newGempa;

        if (gempaData.activeChats.size > 0) {
          const formattedDate = new Date(newGempa.Tanggal).toLocaleDateString('en-GB', {
            day: 'numeric',
            month: 'short',
            year: 'numeric'
          });
          const formattedTime = new Date(newGempa.DateTime).toLocaleTimeString('en-GB', {
            hour: '2-digit',
            minute: '2-digit'
          });

          const text = `*GEMPA INFO*

- *Date* : ${formattedDate}
- *Time* : ${formattedTime} WIB
- *Magnitude* : ${newGempa.Magnitude}
- *Coordinates* : ${newGempa.Coordinates}
- *Latitude* : ${newGempa.Lintang}
- *Longitude* : ${newGempa.Bujur}
- *Depth* : ${newGempa.Kedalaman}
- *Region* : ${newGempa.Wilayah}
- *Potential* : ${newGempa.Potensi}
- *Felt* : ${newGempa.Dirasakan || '-'}

*Source* : BMKG (https://bmkg.go.id)`;

          const shakemapUrl = `https://data.bmkg.go.id/DataMKG/TEWS/${newGempa.Shakemap}`;

          for (const chatId of gempaData.activeChats) {
            await conn.sendMessage(chatId, {
              image: { url: shakemapUrl },
              caption: text
            }).catch(err => console.error('Failed to send to', chatId, err));
          }
        }
      }
    } catch (err) {
      console.error(err.message);
    }
  }, 15 * 60 * 1000); // every 15 minutes
};

module.exports = {
  run: async (m, { conn, groupSet }) => {
    if (m.isBaileys) return true;
    
    if (!groupSet.autogempa) {
      gempaData.activeChats.delete(m.chat);
      return true;
    }

    gempaData.activeChats.add(m.chat);

    if (!gempaData.interval) {
      startPolling(conn);
    }

    return true;
  },
  group: true,
  error: false
};
