const cron = require('node-cron');

module.exports = {
  run: async (m, { conn, setting, Func }) => {
    try {
      if (global.autoClean) return;
      global.autoClean = true;

      cron.schedule('0 3 * * *', async () => {
        const now = Date.now(), week = 7 * 24 * 60 * 60 * 1000;
        let del = 0, skip = 0;

        for (let id in global.db.users) {
          const u = global.db.users[id];
          if (!u.registered) return skip++;
          if ([conn.user.jid, setting.owner, ...(setting.owners || [])].map(v => v + '@s.whatsapp.net').includes(id)) return skip++;

          const inactive = now - (u.lastseen || u.lastReg || 0);
          if (
            inactive > week &&
            !u.premium &&
            (u.limit <= (setting.defaultLimit || 15)) &&
            (u.exp <= 100050) &&
            (u.money <= 300050)
          ) {
            console.log(`Delete : ${id} (${Func.toTime(inactive)} ago)`);
            delete global.db.users[id];
            del++;
          } else skip++;
        }

        console.log(`Clean done. Deleted : ${del} || Skipped : ${skip} || Total : ${Object.keys(global.db.users).length}`);
      }, { scheduled: true, timezone: 'Asia/Jakarta' });

      console.log('[ AUTO_DELUSERS ] > Auto Clean User Is Active.');
    } catch (e) {
      console.error(e);
    }
  },
  group: false,
  error: false
};