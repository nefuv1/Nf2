const moment = require('moment-timezone')
const formatNumber = require('../../../lib/formatNumber')

let schedulerStarted = false
const scheduleTimes = ['07:00', '09:00', '12:00', '15:00', '19:00', '21:00']

// Ambil item random dari kategori
function getRandomItems(category, maxCount, maxQuantity) {
  const items = global.itemCategories[category] || []
  if (items.length === 0) return []
  const count = Math.floor(Math.random() * maxCount) + 1
  const selected = []

  for (let i = 0; i < count; i++) {
    const randomItem = items[Math.floor(Math.random() * items.length)]
    const randomQuantity = Math.floor(Math.random() * maxQuantity) + 1
    const exist = selected.find(v => v.name === randomItem)
    if (exist) exist.quantity += randomQuantity
    else selected.push({ name: randomItem, quantity: randomQuantity })
  }
  return selected
}

// Tambahkan ke inventory
function addItemsToInventory(user, items) {
  if (!user.inventory) user.inventory = {}
  for (const item of items)
    user.inventory[item.name] = (user.inventory[item.name] || 0) + item.quantity
}

// Kirim Mystery Box ke grup
async function sendMysteryBox(conn) {
  const now = moment().tz('Asia/Jakarta').format('DD MMMM YYYY, HH:mm')
  const allGroups = Object.keys(global.db.groups || {})

  for (const id of allGroups) {
    const group = global.db.groups[id]
    if (!group || !group.mysterybox) continue
    if (group.lastMysterySent && moment().diff(group.lastMysterySent, 'minutes') < 2) continue

    group.mysteryBoxActive = true
    group.lastMysterySent = new Date().getTime()

    const text = `*MYSTERY BOX*\n\n📦 Mystery Box has been dropped!\nTo open send the command : open\n\nDelivery time : ${now}`

    await conn.sendMessageModify(id, text, null, {
      largeThumb: true,
      thumbnail: 'https://i.ibb.co/rKBqsZ3t/image.jpg'
    })
    console.log(`Mystery Box sent to ${id}`)
  }
}

// Jalankan scheduler otomatis
function startScheduler(conn) {
  if (schedulerStarted) return
  schedulerStarted = true
  console.log('[ AUTO_MYSTERYBOX ] > Auto Mystery Box Is Active.');

  setInterval(async () => {
    const now = moment().tz('Asia/Jakarta').format('HH:mm')
    if (scheduleTimes.includes(now)) {
      console.log('Automatically send Mystery Box at:', now)
      await sendMysteryBox(conn)
      await new Promise(r => setTimeout(r, 60000))
    }
  }, 10 * 1000)
}

module.exports = {
  run: async (m, { conn }) => {
    try {
      if (!schedulerStarted) startScheduler(conn)

//      if (/^open|buka$/i.test(m.text)) {
       if (m.text.toLowerCase() === 'open' || m.text.toLowerCase() === 'buka') { 
        const group = global.db.groups[m.chat]
        if (!group || !group.mysteryBoxActive)
          return m.reply('There are no active Mystery Box.')

        group.mysteryBoxActive = false

        const userId = m.sender
        const user = global.db.users[userId]
        if (!user) return m.reply('You are not registered!')

        // Kemungkinan ZONX (25%)
        if (Math.random() < 0.25) return m.reply('☠️ Zonx!!! You get nothing.')

        let rewardMessage = `🎉 Congratulations! You got :\n\n`
        const rewardTypes = ['money', 'limit', 'bibit', 'barang', 'buah', 'hewan']
        const rewardCount = Math.floor(Math.random() * 5) + 1 // max 5 reward random

        // Acak reward tanpa duplikat
        const chosenTypes = rewardTypes.sort(() => Math.random() - 0.5).slice(0, rewardCount)
        const collectedItems = []

        for (const type of chosenTypes) {
          switch (type) {
            case 'money': {
              const money = Math.floor(Math.random() * 200000) + 1000
              user.money = (user.money || 0) + money
              rewardMessage += `- +${formatNumber(money)} Money\n`
              break
            }
            case 'limit': {
              const limit = Math.floor(Math.random() * 3) + 1
              user.limit = (user.limit || 0) + limit
              rewardMessage += `- +${formatNumber(limit)} Limit\n`
              break
            }
            case 'bibit': {
              const items = getRandomItems('bibit', 3, 5)
              addItemsToInventory(user, items)
              collectedItems.push(...items)
              break
            }
            case 'barang': {
              const items = getRandomItems('barang', 2, 5)
              addItemsToInventory(user, items)
              collectedItems.push(...items)
              break
            }
            case 'buah': {
              const items = getRandomItems('buah', 3, 5)
              addItemsToInventory(user, items)
              collectedItems.push(...items)
              break
            }
            case 'hewan': {
              const items = getRandomItems('hewan', 2, 5)
              addItemsToInventory(user, items)
              collectedItems.push(...items)
              break
            }
          }
        }

        // Tambahkan semua item ke teks
        for (const item of collectedItems) {
          const name = item.name.charAt(0).toUpperCase() + item.name.slice(1)
          rewardMessage += `- +${item.quantity} ${name}\n`
        }

        return m.reply(rewardMessage)
      }
    } catch (e) {
      console.error(e)
    }
  },
  group: true,
  error: false
}