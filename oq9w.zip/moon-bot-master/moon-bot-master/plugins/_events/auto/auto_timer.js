const cron = require('node-cron')

module.exports = {
  run: async (m, { conn }) => {
    try {
      if (global.autoTimerInitialized) return
      global.autoTimerInitialized = true

      console.log('[ AUTO_TIMER ] > Auto Timer Groups Is Active.');

      cron.schedule('0 7 * * *', async () => {
        for (let groupId in global.db.groups) {
          const group = global.db.groups[groupId]
          if (group.autotimer) {
            await conn.groupSettingUpdate(groupId, 'not_announcement')
            await conn.sendMessage(groupId, { text: '🔓 Grup dibuka otomatis pukul 07:00 WIB.' })
          }
        }
      }, { timezone: 'Asia/Jakarta' })

      cron.schedule('0 22 * * *', async () => {
        for (let groupId in global.db.groups) {
          const group = global.db.groups[groupId]
          if (group.autotimer) {
            await conn.groupSettingUpdate(groupId, 'announcement')
            await conn.sendMessage(groupId, { text: '🔒 Grup ditutup otomatis pukul 22:00 WIB.' })
          }
        }
      }, { timezone: 'Asia/Jakarta' })

      const adzanTimes = [
        { time: '45 11 * * *', name: 'Dzuhur' }, // Jam 11:45
        { time: '0 15 * * *', name: 'Ashar' },   // Jam 15:00
        { time: '0 18 * * *', name: 'Maghrib' }, // Jam 18:00
        { time: '0 19 * * *', name: 'Isya' }     // Jam 19:00
      ]

      adzanTimes.forEach(({ time, name }) => {
        cron.schedule(time, async () => {
          for (let groupId in global.db.groups) {
            const group = global.db.groups[groupId]
            if (group.autotimer) {
              try {
                await conn.groupSettingUpdate(groupId, 'announcement')
                await conn.sendMessage(groupId, {
                  text: `🔒 Grup ditutup sementara untuk adzan ${name}. Akan dibuka kembali dalam 15 menit.`
                })

                // Buka lagi setelah 15 menit
                setTimeout(async () => {
                  try {
                    await conn.groupSettingUpdate(groupId, 'not_announcement')
                    await conn.sendMessage(groupId, {
                      text: `🔓 Grup dibuka kembali setelah adzan ${name}.`
                    })
                  } catch (e) {
                    console.error(e)
                  }
                }, 15 * 60 * 1000)
              } catch (e) {
                console.error(e)
              }
            }
          }
        }, { timezone: 'Asia/Jakarta' })
      })

    } catch (error) {
      console.error( error)
    }
  },
  group: true,
  error: false
}