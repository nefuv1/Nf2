const { xpRange, canLevelUp } = new (require('../../../lib/system/levelling'))

module.exports = {
   run: async (m, { conn, users, groupSet, setting, env, Func }) => {
      try {
        if (!groupSet.autolevelup || m.fromMe) return

         let userList = Object.entries(global.db.users).map(([key, value]) => {
            return { ...value, jid: key }
         })

         let { xp, min, max } = xpRange(users.level, env.multiplier)
         let sortedLevel = userList.sort((a, b) => b.level - a.level)

         let before = users.level
         while (canLevelUp(users.level, users.exp, env.multiplier)) {
            users.level++
         }

         if (before !== users.level) {
            await conn.reply(
               m.chat,
               `*LEVEL UP*\n\n*From* : [ ${before} ] ➠ [ ${users.level} ]\nCongratulations you leveled up..`,
               m
            )
         }
      } catch (e) {
         console.error(e)
      }
   },
   group: true,
   error: false
}