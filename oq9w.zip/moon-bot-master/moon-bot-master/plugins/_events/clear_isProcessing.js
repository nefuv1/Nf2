module.exports = {
   run: async (m, { conn, env, Func }) => {
      try {
         let lastCleanupDay = null;
         
         const cleanupIsProcessing = () => {
            let totalCleaned = 0;
            let activeProcesses = 0;
            
            Object.entries(global.db.users).forEach(([jid, user]) => {
               const processingProps = Object.keys(user).filter(key => 
                  key.startsWith('isProcessing')
               );
               
               processingProps.forEach(prop => {
                  if (user[prop] === true) {
                     activeProcesses++;
                  }
                  delete global.db.users[jid][prop];
                  totalCleaned++;
               });
            });
         };
         
         cleanupIsProcessing();
         
         setInterval(async () => {
            const now = new Date();
            const currentDay = now.getDate();
            const hours = now.getHours();
            const minutes = now.getMinutes();
            
            if (hours === 0 && minutes === 0 && lastCleanupDay !== currentDay) {
               let totalCleaned = 0;
               let activeProcesses = 0;
               
               Object.entries(global.db.users).forEach(([jid, user]) => {
                  const processingProps = Object.keys(user).filter(key => 
                     key.startsWith('isProcessing')
                  );
                  
                  processingProps.forEach(prop => {
                     if (user[prop] === false) {
                        delete global.db.users[jid][prop];
                        totalCleaned++;
                     } else if (user[prop] === true) {
                        activeProcesses++;
                     }
                  });
               });
               
               lastCleanupDay = currentDay;
            }
            
         }, 60000);
         
         process.on('beforeExit', (code) => {
            cleanupIsProcessing();
         });
         
         process.on('SIGINT', () => {
            cleanupIsProcessing();
            process.exit(0);
         });
         
         process.on('SIGTERM', () => {
            cleanupIsProcessing();
            process.exit(0);
         });
         
      } catch (e) {
         console.error(e);
      }
   },
   error: false
};