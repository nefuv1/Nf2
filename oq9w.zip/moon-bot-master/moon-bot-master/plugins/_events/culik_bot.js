module.exports = {
  run: async (m, { conn, isBlocked }) => {
    if (isBlocked) return;
    
    // Deteksi pesan undangan grup
    const isGroupInvite = (
      m.mtype === 'groupInviteMessage' ||
      m.text.startsWith('Undangan untuk bergabung') ||
      m.text.startsWith('Invitation to join') ||
      m.text.startsWith('Buka tautan ini')
    );
   
    if (isGroupInvite && !m.isBaileys && !m.isGroup) {
      let teks = `"Untuk menambahkan Bot ke grup Anda sendiri, lakukan langganan terlebih dahulu. Ketik *!dev* untuk info lebih lanjut. Terima kasih!"`;
      
      await conn.reply(m.chat, teks, m);
      
    }
    return true;
  },
  error: false
};