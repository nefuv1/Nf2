/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const fetch = require('node-fetch');
const Translator = require('../../lib/translator');

module.exports = {
  help: ['truth', 'dare', 'wyr', 'nhie', 'paranoia'],
  tags: 'funny',
  register: true,
  run: async (m, { conn, command, Func }) => {
    try {
      m.react(global.react);

      const apiMap = {
        truth: 'https://api.truthordarebot.xyz/v1/truth',
        dare: 'https://api.truthordarebot.xyz/api/dare',
        wyr: 'https://api.truthordarebot.xyz/api/wyr',
        nhie: 'https://api.truthordarebot.xyz/api/nhie',
        paranoia: 'https://api.truthordarebot.xyz/api/paranoia'
      };

      const url = apiMap[command];
      const res = await fetch(url);
      if (!res.ok) throw new Error(`API ${command} Error : ${res.status}`);

      const data = await res.json();

      let translated;
      try {
        translated = await Translator.translate(data.question, 'id', null, 'v1');
      } catch (err) {
        console.log(err);
        try {
          translated = await Translator.translate(data.question, 'id', null, 'v3');
        } catch (e) {
          console.log(e);
          translated = data.question;
        }
      }

      const text = `(${data.rating})\n\n${translated}`;
      
      const sentMsg = await m.reply(text);
      
      if (!global.truthDareMessages) global.truthDareMessages = new Map();
      global.truthDareMessages.set(sentMsg.key.id, {
        command: command,
        timestamp: Date.now(),
        originalText: text
      });

      if (!global.truthDareHandler) {
        global.truthDareHandler = true;
        
        conn.ev.on('messages.upsert', async ({ messages }) => {
          try {
            const msg = messages[0];
            if (!msg.message || msg.key.fromMe) return;
            
            if (msg.message.extendedTextMessage && msg.message.extendedTextMessage.contextInfo) {
              const repliedMsgId = msg.message.extendedTextMessage.contextInfo.stanzaId;
              
              if (global.truthDareMessages.has(repliedMsgId)) {
                const randomEmojis = [
                  '😂', '😄', '😃', '😀', '😊', '😉', '😍', '😘', '😚', '😗',
                  '😙', '😜', '😝', '😛', '😳', '😁', '😔', '😌', '😒', '😞',
                  '😣', '😢', '😂', '😭', '😪', '😥', '😰', '😅', '😓', '😩',
                  '😫', '😨', '😱', '😠', '😡', '😤', '😖', '😆', '😋', '😷',
                  '😎', '😴', '😵', '😲', '😟', '😦', '😧', '🙂', '🤗', '🤔'
                ];
                
                const randomEmoji = randomEmojis[Math.floor(Math.random() * randomEmojis.length)];
                
                await conn.sendMessage(msg.key.remoteJid, {
                  react: {
                    text: randomEmoji,
                    key: msg.key
                  }
                });
                
                console.log(`Users ${msg.pushName} replies to ${command}, giving the reaction : ${randomEmoji}`);
              }
            }
          } catch (error) {
            console.error(error);
          }
        });
        
        setInterval(() => {
          const now = Date.now();
          for (const [msgId, data] of global.truthDareMessages.entries()) {
            if (now - data.timestamp > 30 * 60 * 1000) { // 30 menit
              global.truthDareMessages.delete(msgId);
            }
          }
        }, 10 * 60 * 1000);
      }

    } catch (e) {
      console.error(e);
      throw Func.jsonFormat(e);
    }
  }
};