/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['halah', 'huluh', 'hilih', 'heleh', 'holoh'],
   tags: 'funny',
   register: true,
   run: async (m, {
      conn,
      command,
      text,
      Func
   }) => {
      try {
      
      m.react(global.react)
      
         let ter = command[1].toLowerCase()
         let txt = m.quoted ? m.quoted.text ? m.quoted.text : text ? text : m.text : text ? text : m.text
         await conn.reply(m.chat, txt.replace(/[aiueo]/g, ter).replace(/[AIUEO]/g, ter.toUpperCase()), m)
      } catch (e) {
         console.log(e)
      }
   }
}