/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

let handler = {
   help: ['bisakah'],
   tags: 'funny',
   register: true,
   run: async (m, { conn, text, usedPrefix, command, Func }) => {
      if (!text) return m.reply(`Sertakan teksnya dong.\n\n*Contoh* : ${usedPrefix + command} aku jadi kaya?`);
      
      m.react(global.react)

      let jawaban = Func.random([
         'Iya', 'Bisa', 'Tentu saja bisa', 'Tentu bisa', 'Sudah pasti', 'Sudah pasti bisa',
         'Tidak', 'Tidak bisa', 'Tentu tidak', 'Tentu tidak bisa', 'Sudah pasti tidak',
         'Pasti bisa dong', 'Bisa banget', 'Bisa tapi susah', 'Bisa sih bisa, tapi males',
         'Gak bisa sama sekali', 'Bisa, percaya aja', 'Bisa lah masa enggak', 'Bisa 100%',
         'Bisa tapi butuh waktu', 'Bisa, tapi ribet', 'Hmm... kayaknya bisa', 'Bisa sih, tapi hati-hati',
         'Bisa kalau mau usaha', 'Bisa kalo ada modal', 'Bisa kok gampang itu', 'Gak bisa, jangan maksa',
         'Bisa kalo niat', 'Bisa banget asal mau', 'Bisa, gaskeun aja'
      ]);

      conn.reply(
         m.chat,
         jawaban.trim(),
         m,
         m.mentionedJid ? { contextInfo: { mentionedJid: m.mentionedJid } } : {}
      );
   }
};

module.exports = handler;
