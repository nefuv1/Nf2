/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

let handler = {
   help: ['benarkah'],
   tags: 'funny',
   register: true,
   run: async (m, { conn, text, usedPrefix, command, Func }) => {
      if (!text) return m.reply(`Sertakan teksnya dong.\n\n*Contoh* : ${usedPrefix + command} aku jomblo?`);
      
      m.react(global.react)      

      let jawaban = Func.random([
         'Iya', 'Sudah pasti', 'Sudah pasti benar', 'Tidak', 'Tentu tidak', 'Sudah pasti tidak',
         'Bener banget!', 'Fix ini mah', '100% benar', 'Ah masa sih?', 'Yakin bener nih?',
         'Kayaknya iya deh', 'Kayaknya enggak deh', 'Betul sekali', 'Gak salah lagi', 'Hooh bener',
         'Bener sih', 'Waduh enggak bener itu', 'Benar adanya', 'Negatif', 'Positif banget',
         'Sudah pasti iya', 'Sudah pasti enggak', 'Hmm.. bener sih kayaknya', 'Hampir pasti benar',
         'Gak bener sama sekali', 'Bener parah', 'Bener pol', 'Bener banget asli', 'Bener tapi setengah'
      ]);

      conn.reply(
         m.chat,
         jawaban.trim(),
         m,
         m.mentionedJid ? { contextInfo: { mentionedJid: m.mentionedJid } } : {}
      );
   }
};

module.exports = handler;
