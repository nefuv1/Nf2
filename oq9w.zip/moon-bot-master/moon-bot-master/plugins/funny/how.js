/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['howgay', 'howpintar', 'howcantik', 'howganteng', 'howgabut', 'howgila', 'howlesbi', 'howstress', 'howbucin', 'howjones', 'howsadboy'],
   tags: 'funny',
   register: true,
   run: async (m, {
      conn,
      command,
      text,
      Func
   }) => {
      try {
         if (!text) return m.reply(`Siapa yang *${command.replace('how', '').toUpperCase()}*`)
         
         m.react(global.react)
         
         conn.reply(m.chat, `${command} *${text}* adalah : *${Math.floor(Math.random() * 101)}*% ${command.replace('how', '').toUpperCase()}`.trim(), m, m.mentionedJid ? {
            contextInfo: {
               mentionedJid: m.mentionedJid
            }
         } : {})
      } catch (e) {
         console.log(e)
      }
   },
   error: false
}