/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

let handler = {
   help: ['apakah', 'siapakah', 'kapankah', 'rate'],
   tags: 'funny',
   register: true,
   run: async (m, { conn, usedPrefix, command, text, participants, Func }) => {
      try {
         if (!text && (command === 'apakah' || command === 'rate')) {
            return m.reply(`Sertakan teksnya dong.\n\n*Contoh* : ${usedPrefix + command} aku jomblo?`);
         }
         
      m.react(global.react)         

         if (command === 'apakah') {
            let json = Func.random([
               'Ya', 'Iya', 'Y', 'Mungkin iya', 'Mungkin', 'Bisa jadi', 'Kemungkinan besar iya',
               'Mungkin tidak', 'Tidak', 'Tidak mungkin', 'Kurang tau', 'Kayaknya iya', 'Kayaknya tidak',
               'Sepertinya iya', 'Sepertinya tidak', 'Mustahil', 'Hooh', 'Iyooo', 'Entahlah', 'Gak mungkin',
               'Hampir pasti', '50:50', 'Tergantung kamu', 'Hmm... rahasia', 'Sudah pasti', 'Aku rasa iya',
               'Aku rasa tidak', 'Bisa jadi sih', 'Masih samar-samar', 'Nggak bisa jawab sekarang'
            ]);
            m.reply(json);

         } else if (command === 'kapankah') {
            let satuanWaktu = Func.random([
               'detik', 'menit', 'jam', 'hari', 'minggu', 'bulan', 'tahun',
               'dekade', 'abad', 'milenium', 'kilodetik', 'nano detik', 'selamanya'
            ]);
            m.reply(`${Math.floor(Math.random() * 100)} ${satuanWaktu} lagi ...`);

         } else if (command === 'siapakah') {
            let who;
            if (!m.isGroup) {
               let member = [m.sender, conn.user.jid];
               who = member[Math.floor(Math.random() * member.length)];
            } else {
               let member = participants.map((u) => u.id);
               who = member[Math.floor(Math.random() * member.length)];
            }
            m.reply(`Aku rasa dia 👉 @${who.split`@`[0]}`);

         } else if (command === 'rate') {
            const angka = Func.random(Array.from({ length: 101 }, (_, i) => i.toString())); // 0 - 100
            const tambahanKomentar = Func.random([
               'Mantap!', 'Boleh juga 👍', 'Gak buruk lah', 'Wih keren!', 'Ehh lumayan', 'Waduh 😅',
               'Sangat luar biasa!', 'Hmmm... biasa aja', 'Masih bisa ditingkatkan', 'Perfect!',
               'Epic banget!', 'Gak nyangka', 'Kacau ini mah', 'Keren parah', 'Biasa sih', 'Mengejutkan!'
            ]);
            m.reply(`${text} ${angka}% — ${tambahanKomentar}`)
         }
      } catch (e) {
         console.error(e);
           throw Func.jsonFormat(e)
      }
   }
};

module.exports = handler;
