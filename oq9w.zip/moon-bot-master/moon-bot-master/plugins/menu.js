/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const fs = require('fs')
const path = require('path')

module.exports = {
   aliases: ['help', 'menu'],
   run: async (m, {
      conn,
      usedPrefix,
      args,
      plugins,
      users,
      setting,
      env,
      command,
      Func
   }) => {
      try {
         let plugs = new Set(plugins.values())
         let category = {}
         for (let plugin of plugs) {
            let pluginFileName = path.parse(plugin.filePath).name
            if (!plugin.tags || plugin.tags === 'main' || setting.error?.includes(pluginFileName) || setting.hidden.includes(plugin.tags)) continue
            if (!category[plugin.tags]) category[plugin.tags] = []
            if (Array.isArray(plugin.help)) {
               for (let cmd of plugin.help) {
                  category[plugin.tags].push({
                     command: cmd,
                     use: plugin.use || ''
                  })
               }
            }
         }

         let sortedTags = Object.keys(category).sort()
         let style = setting.style

         let local_size = fs.existsSync('./' + env.database + '.json')
            ? await Func.getSize(fs.statSync('./' + env.database + '.json').size)
            : ''

         const dbInfo = /mongo/.test(process.env.DATABASE_URL)
            ? 'MongoDB'
            : /postgresql/.test(process.env.DATABASE_URL)
               ? 'PostgreSQL'
               : `Local, ${local_size}`

         const styleInfo = setting.style === 2 ? '2/2' : setting.style === 3 ? '3/2' : '1/2'

         const defaultMessage = `Hi @${m.sender.replace(/@.+/, '')}
         
- *Menu style* : ${styleInfo}
- *Database* : ${dbInfo}
- *Donate* : qu.ax/ShcMm.jpg

${setting.style === 2 || setting.style === 3 ? 'Here are the available category :' : 'Here are the available commands :'}`.trim()

         let text = args.join(' ').toLowerCase()

         if (text) {
            if ((style === 2 || style === 3) && text === 'all') {
               let menuMessage = `${defaultMessage}\n\n`
               for (let tag of sortedTags) {
                  let cmd = category[tag].sort((a, b) => a.command.localeCompare(b.command))
                  menuMessage += `━━━━ *${tag.toUpperCase()}* ━━━━\n\n`
                  cmd.forEach(c => {
                     menuMessage += `- ${usedPrefix}${c.command}${c.use ? ` ${c.use}` : ''}\n`
                  })
                  menuMessage += `\nTotal : [ ${cmd.length} ]\n\n`
               }
               return m.reply(menuMessage.trim())
            }

            if (!sortedTags.includes(text)) {
               return m.reply(`Category "${text}" not found.`)
            }

            let cmdList = category[text].sort((a, b) => a.command.localeCompare(b.command))
            let categoryMessage = `━━━━ *${text.toUpperCase()}* ━━━━\n\n`
            cmdList.forEach(c => {
               categoryMessage += `- ${usedPrefix}${c.command}${c.use ? ` ${c.use}` : ''}\n`
            })
            categoryMessage += `\nTotal : [ ${cmdList.length} ]`
            return m.reply(categoryMessage.trim())
         }

         if (style === 1) {
            let menuMessage = `${defaultMessage}\n\n`
            for (let tag of sortedTags) {
               let cmd = category[tag].sort((a, b) => a.command.localeCompare(b.command))
               menuMessage += `━━━━ *${tag.toUpperCase()}* ━━━━\n\n`
               cmd.forEach(c => {
                  menuMessage += `- ${usedPrefix}${c.command}${c.use ? ` ${c.use}` : ''}\n`
               })
               menuMessage += `\nTotal : [ ${cmd.length} ]\n\n`
            }
            return m.reply(menuMessage.trim())
         }

         if (style === 2) {
            let menuMessage = `${defaultMessage}\n\n━━━━ *MENU* ━━━━\n\n`
            menuMessage += `- ${usedPrefix + command} all\n`
            menuMessage += sortedTags.map(tag => `- ${usedPrefix + command} ${tag}`).join('\n')
            return m.reply(menuMessage.trim())
         }

         if (style === 3) {
            let menuMessage = `${defaultMessage}\n\n━━━━ *MENU* ━━━━\n\n`
            menuMessage += `- ${usedPrefix + command} all\n`
            menuMessage += sortedTags.map(tag => `- ${usedPrefix + command} ${tag}`).join('\n')
            return conn.sendMessageModify(m.chat, menuMessage.trim(), m, {
               ads: false,
               largeThumb: true,
               thumbnail: Func.isUrl(setting.cover) ? setting.cover : Buffer.from(setting.cover, 'base64'),
               url: setting.link
            })
         }

      } catch (e) {
         console.error(e)
         throw Func.jsonFormat(e)
      }
   },
   error: false
}