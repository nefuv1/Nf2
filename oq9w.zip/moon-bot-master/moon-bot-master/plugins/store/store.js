module.exports = {
   help: ['prem','sewa'],
   tags: 'store',
   run: async (m, { conn, usedPrefix, command }) => {
      try {
         // Wajib menggunakan global.owner
         let ownerJid = Array.isArray(global.owner) ? global.owner[0] : global.owner;
         let ownerNumber = ownerJid.split('@')[0];

         if (command === 'premium' || command === 'prem' || command === 'vip') {
            let text = `
*PREMIUM BOT*

🕐 *Paket Premium*
- 7 Hari — Rp5.000 
  ➠ Free : +3.000 Limit

- 20 Hari — Rp15.000
  ➠ Free : +5.000 Limit

- 30 Hari — Rp20.000
  ➠ Free : +10.000 Limit 

🎁 *Benefit Premium*
✓ Gratis limit 
✓ Akses fitur premium
✓ Priority support

💳 *Payment*
1. DANA : 0812-3456-7890
2. GO-PAY : 0812-3456-7890
3. QRIS : 0812-3456-7890

📞 *Contact Owner*
@${ownerNumber}

Untuk pemesanan, kirim bukti transfer ke owner!
            `.trim()

            await conn.sendMessage(m.chat, {
               text: text,
               contextInfo: {
                  mentionedJid: [ownerJid]
               }
            }, { quoted: m })

         } else if (command === 'sewa' || command === 'rent' || command === 'sewabot') {
            let text = `
*RENT BOT*

📅 *Paket Sewa*
- 5 Hari — Rp4.500
- 15 Hari — Rp14.500  
- 20 Hari — Rp19.000
- 30 Hari — Rp25.000

🚀 *Fitur Sewa Bot*
✓ Bot aktif 24/7 di group Anda
✓ System Enable/Disable khusus grup
✓ Support 1-on-1 dengan owner
✓ Buat grup menjadi otomatis Open & Close

📝 *Syarat & Ketentuan*
- Minimal sewa 5 hari
- Maksimal sewa 30 hari (server terbatas)
- Bot akan keluar otomatis setelah masa sewa habis
- Tidak menerima refund

💳 *Payment*
1. DANA : 0812-3456-7890
2. GO-PAY : 0812-3456-7890
3. QRIS : 0812-3456-7890

📞 *Contact Owner*
@${ownerNumber}

Hubungi owner untuk info lebih lanjut!
            `.trim()

            await conn.sendMessage(m.chat, {
               text: text,
               contextInfo: {
                  mentionedJid: [ownerJid]
               }
            }, { quoted: m })
         }

      } catch (error) {
         console.error(error)
         throw Func.jsonFormat(error)
      }
   }
}