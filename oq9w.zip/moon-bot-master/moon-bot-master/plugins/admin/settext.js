/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['setwelcome', 'setbye'],
   tags: 'admin',   
   group: true,
   admin: true,   
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      groupSet,
      Func
   }) => {
      if (command == 'setwelcome') {
         if (!text) return conn.reply(m.chat, formatWel(usedPrefix, command), m)
         groupSet.sWelcome = text
         await conn.reply(m.chat, 'Done. 👍', m)
      } else if (/set(bye|left)/i.test(command)) {
         if (!text) return conn.reply(m.chat, formatLef(usedPrefix, command), m)
         groupSet.sBye = text
         await conn.reply(m.chat, 'Done. 👍', m)
      }
   },
   error: false
}

const formatWel = (prefix, command) => {
   return `Teks sambutan tidak boleh kosong. Berikut cara penggunaannya :

1. @tag - (Menyebut anggota baru)
2. @subject - (Menampilkan nama grup)
3. @desc - (Menampilkan deskripsi grup)

*Contoh* : ${prefix + command} Halo @tag, selamat datang di grup @subject.\n\n@desc`
}

const formatLef = (prefix, command) => {
   return `Teks perpisahan tidak boleh kosong. Berikut cara penggunaannya :

1. @tag - (Menyebut anggota baru)
2. @subject - (Menampilkan nama grup)

*Contoh* : ${prefix + command} Selamat tinggal @tag, di grup @subject.`
}