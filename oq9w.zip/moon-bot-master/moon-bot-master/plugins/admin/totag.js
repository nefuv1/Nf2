/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['totag'],
   aliases: ['tag'],
   tags: 'admin',
   group: true,
   admin: true,   
   run: async (m, {
      conn,
      text,
      participants,
      Func
   }) => {
      let users = participants.map(v => v.id).filter(v => v !== conn.user.id)
      if (!m.quoted) return conn.reply(m.chat, 'Silakan balas pesan.', m)
      conn.sendMessage(m.chat, { forward: m.quoted.fakeObj, mentions: users })
   },
   error: false
}