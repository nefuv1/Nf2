/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['tagall'],
   aliases: ['all'],
   tags: 'admin',
   group: true,
   admin: true,
   run: async (m, { conn, text, participants, Func }) => {
      try {
         let member = participants.map(v => v.id);
         let message = (!text) ? 'Halo semuanya, admin menyebut Anda di ' + await (await conn.groupMetadata(m.chat)).subject + ' group.' : text;
         let readmore = String.fromCharCode(8206).repeat(4001);         
         
         let list = member.map((v, i) => `${i + 1}. @${v.replace(/@.+/, '')}`).join('\n');

         conn.reply(m.chat, `${readmore}\n${message}\n\n${list}`, m, {
            mentions: member
         });
      } catch (e) {
         return conn.reply(m.chat, Func.jsonFormat(e), m);
      }
   },
   error: false
};