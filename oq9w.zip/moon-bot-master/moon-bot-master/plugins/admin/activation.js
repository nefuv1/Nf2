/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['mute'],
   tags: 'admin',
   group: true,
   admin: true,
   run: async (m, {
      conn,
      args,
      usedPrefix,
      command,
      groupSet: gc,
      Func
   }) => {
      let opt = ['off', 'on']
      if (!args || !args[0] || !opt.includes(args[0].toLowerCase())) 
         return m.reply(`Silakan pilih salah satu! untuk mute grup.\nStatus : ${gc.mute ? 'Online' : 'Offline'}\n\n1. on - (Mengaktifkan)\n2. off - (Menonaktifkan)\n\n*Contoh* : ${usedPrefix + command} on`)
      
      if (args[0].toLowerCase() === 'on') {
         if (gc.mute) return conn.reply(m.chat, `Sebelumnya sudah dibisukan.`, m)
         gc.mute = true
         conn.reply(m.chat, `Done. 👍`, m)
      } else if (args[0].toLowerCase() === 'off') {
         if (!gc.mute) return conn.reply(m.chat, `Sebelumnya tidak dimatikan.`, m)
         gc.mute = false
         conn.reply(m.chat, `Done. 👍`, m)
      }
   },
   error: false   
}