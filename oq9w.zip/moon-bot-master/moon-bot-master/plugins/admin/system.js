/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['enable', 'disable'],
   aliases: ['on', 'off'],
   tags: 'admin',
   run: async (m, {
      conn,
      usedPrefix,
      command,
      args,
      isAdmin,
      isBotAdmin,
      isOwner,
      groupSet,
      setting,
      Func
   }) => {
      const isEnable = /enable|on/i.test(command);
      const type = (args[0] || '').toLowerCase();
          
      const options = {
        // GROUP settings (require admin rights)
        welcome: { requires: 'admin', target: groupSet },
        left: { requires: 'admin', target: groupSet },
        detect: { requires: 'admin', target: groupSet, botAdmin: true },
        antidelete: { requires: 'admin', target: groupSet },
        antilink: { requires: 'admin', target: groupSet, botAdmin: true },
        antivirtex: { requires: 'admin', target: groupSet, botAdmin: true },
        autosticker: { requires: 'admin', target: groupSet },
        antisticker: { requires: 'admin', target: groupSet, botAdmin: true },
        antitoxic: { requires: 'admin', target: groupSet, botAdmin: true },
        game: { requires: 'admin', target: groupSet },
        rpg: { requires: 'admin', target: groupSet },
        antifoto: { requires: 'admin', target: groupSet, botAdmin: true },
        antivideo: { requires: 'admin', target: groupSet, botAdmin: true },
        autogempa: { requires: 'admin', target: groupSet }, 
        antibot: { requires: 'admin', target: groupSet, botAdmin: true },  
        autolevelup: { requires: 'admin', target: groupSet },
        autotimer: { requires: 'admin', target: groupSet, botAdmin: true },
        antitagsw: { requires: 'admin', target: groupSet, botAdmin: true },
        mysterybox: { requires: 'admin', target: groupSet },        
            
        // OWNER settings (require owner rights)
        autobackup: { requires: 'owner', target: setting },
        antispam: { requires: 'owner', target: setting },
        debug: { requires: 'owner', target: setting },
        groupmode: { requires: 'owner', target: setting },
        privatemode: { requires: 'owner', target: setting },
        multiprefix: { requires: 'owner', target: setting },
        noprefix: { requires: 'owner', target: setting },
        online: { requires: 'owner', target: setting },
        self: { requires: 'owner', target: setting },
        anticall: { requires: 'owner', target: setting }
      };

      if (!type) {
        let adminOptions = Object.keys(options).filter(opt => options[opt].requires === 'admin');
        let ownerOptions = Object.keys(options).filter(opt => options[opt].requires === 'owner');
            
        let message = '*OPTIONS*\n\n';
            
        message += '*Admin* :\n\n';
        message += adminOptions.map((v, i) => {
          const targetObj = options[v].target;
          const isActive = targetObj && typeof targetObj === 'object' && targetObj.hasOwnProperty(v) 
            ? targetObj[v] 
            : false;
          return ` ${i+1}. ${v}${isActive ? ' ✓' : ''}`;
        }).join('\n') + '\n\n';
            
        message += '*Owner* :\n\n';
        message += ownerOptions.map((v, i) => {
          const targetObj = options[v].target;
          const isActive = targetObj && typeof targetObj === 'object' && targetObj.hasOwnProperty(v) 
            ? targetObj[v] 
            : false;
          return ` ${i+1}. ${v}${isActive ? ' ✓' : ''}`;
        }).join('\n') + '\n\n';
            
        message += `*Contoh* : ${usedPrefix + command} welcome`;
        return conn.reply(m.chat, message, m);
      }

      if (!options[type]) {
        return conn.reply(m.chat, `Option "${type}" is not available!`, m);
      }

      const optionConfig = options[type];
          
      if (optionConfig.requires === 'admin') {
        if (!m.isGroup) {
          return conn.reply(m.chat, global.status.group, m);
        }
        if (!isAdmin && !isOwner) {
          return conn.reply(m.chat, global.status.admin, m);
        }
        if (optionConfig.botAdmin && !isBotAdmin) {
          return conn.reply(m.chat, global.status.botAdmin, m);
        }
      } else if (optionConfig.requires === 'owner' && !isOwner) {
        return conn.reply(m.chat, global.status.owner, m);
      }

      if (!optionConfig.target || typeof optionConfig.target !== 'object') {
        return conn.reply(m.chat, `Configuration error for option "${type}".`, m);
      }

      const currentStatus = optionConfig.target.hasOwnProperty(type) 
        ? optionConfig.target[type] 
        : false;
          
      if (currentStatus === isEnable) {
        return conn.reply(m.chat, `${Func.ucword(type)} already ${isEnable ? 'activated' : 'disabled'} previously. 👎`, m);
      }

      optionConfig.target[type] = isEnable;
          
      conn.reply(m.chat, `${Func.ucword(type)} succeed ${isEnable ? 'activated' : 'disabled'}. 👍`, m);
   }
};