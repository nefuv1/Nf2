/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['setdesc', 'setname'],
   tags: 'admin',
   group: true,
   admin: true,
   botAdmin: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      participants,
      Func
   }) => {
      let value = m.quoted ? m.quoted.text : text
      if (command == 'setname') {
         if (!value) return conn.reply(m.chat, `Silakan berikan nama baru grup ini.\n\n*Contoh* : ${usedPrefix + command} TechBOT`, m)
         if (value > 25) return conn.reply(m.chat, `Max 25 characters!`, m)
         await conn.groupUpdateSubject(m.chat, value)
      } else if (command == 'setdesc') {
         if (!value) return conn.reply(m.chat, `Silakan berikan deskripsi baru grup ini.\n\n*Contoh* : ${usedPrefix + command} TechBOT`, m)
         await conn.groupUpdateDescription(m.chat, value)
      }
   },
   error: false
}