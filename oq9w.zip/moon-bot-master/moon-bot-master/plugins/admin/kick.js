/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
  help: ['kick'],
  aliases: ['kik'],
  tags: 'admin',
  group: true,
  admin: true,
  botAdmin: true,
  run: async (m, { conn, text, participants, Func, usedPrefix, command }) => {
    const input = m?.mentionedJid?.[0] || m?.quoted?.sender || text
    if (!input) return m.reply(`Silakan @tag / balas pesan pengguna.\n\n*Contoh* : ${usedPrefix + command} @0`)
    const p = await conn.onWhatsApp(input.trim())
    if (!p.length) return m.reply('Nomor tidak valid.')
    const jid = conn.decodeJid(p[0].jid)
    const number = jid.replace(/@.+/, '')
    let member = participants.find(v => v.id == jid)
    if (!member) return m.reply(`@${number} Telah keluar atau tidak ada dalam grup ini.`, null, { contextInfo: { mentionedJid: [jid] } })
    if (jid === conn.user.id) return m.reply(`Tidak bisa mengeluarkan bot.`)
    try {
      const res = await conn.groupParticipantsUpdate(m.chat, [jid], 'remove')
      m.reply(`${number} telah dikeluarkan dari grup.`, null, { contextInfo: { mentionedJid: [jid] } })
    } catch (e) {
      throw await Func.jsonFormat(e)
    }
  }
}