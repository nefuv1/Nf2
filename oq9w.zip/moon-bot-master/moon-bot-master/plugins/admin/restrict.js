/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['group'],
   aliases: ['g','gc'],   
   tags: 'admin',
   group: true,
   admin: true,  
   botAdmin: true,
   run: async (m, {
      conn,
      args,
      usedPrefix,
      command,
      Func
   }) => {
      if (!args || !args[0]) return conn.reply(m.chat, `*Jenis* :\n\n1. open\n2. close\n\n*Contoh* : ${usedPrefix + command} close`, m)
      if (args[0] == 'open') {
         await conn.groupSettingUpdate(m.chat, 'not_announcement')
      } else if (args[0] == 'close') {
         await conn.groupSettingUpdate(m.chat, 'announcement')
      }
   }
}