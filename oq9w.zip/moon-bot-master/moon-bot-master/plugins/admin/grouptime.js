/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const { Function: Func } = new (require('@znan/wabot'))

module.exports = {
    help: ['grouptime'],
    aliases: ['gctime', 'grouptimer'],
    tags: 'admin',
    group: true,
    admin: true,
    botAdmin: true,
    run: async (m, { conn, args, usedPrefix, command }) => {
        global.grouptime = global.grouptime || {}
        global.grouptimeStatus = global.grouptimeStatus || {}

        const id = m.chat
        const act = (args[0] || '').toLowerCase()
        const time = parseInt(args[1])
        const status = global.grouptimeStatus[id]
        const delay = time * 60 * 1000

        if (act === 'reset') {
            delete global.grouptime[id]
            delete global.grouptimeStatus[id]
            return m.reply('Timer grup telah direset.')
        }

        if (act === 'status') {
            if (global.grouptime[id] && global.grouptime[id] > Date.now()) {
                let sisa = global.grouptime[id] - Date.now()
                let mnt = Math.floor(sisa / 60000), dtk = Math.floor((sisa / 1000) % 60)
                return m.reply(`Grup akan ${status === 'announcement' ? 'ditutup' : 'dibuka'} dalam ${mnt}m ${dtk}d.`)
            }
            return m.reply('Tidak ada timer aktif.')
        }

        const mode = act === 'close' ? 'announcement' : act === 'open' ? 'not_announcement' : null
        if (!mode)
            return m.reply(`*Contoh* :
1. ${usedPrefix + command} open [menit]
2. ${usedPrefix + command} close [menit]
3. ${usedPrefix + command} status
4. ${usedPrefix + command} reset

*Contoh penggunaan* : 
1. ${usedPrefix + command} open 1 - (Buka 1 menit)
2. ${usedPrefix + command} close 5 - (Tutup 5 menit)`)

        if (isNaN(time) || time <= 0)
            return m.reply(`Masukkan angka menit yang valid.\n\n*Contoh* : ${usedPrefix + command} close 1`)

        m.reply(`⏰ Grup akan ${mode === 'announcement' ? 'ditutup' : 'dibuka'} dalam ${time} menit.`)
        global.grouptime[id] = Date.now() + delay
        global.grouptimeStatus[id] = mode

        setTimeout(async () => {
            if (Date.now() >= global.grouptime[id]) {
                try {
                    await conn.groupSettingUpdate(id, mode)
                    m.reply(`${mode === 'announcement' ? '🔒 Grup otomatis ditutup.' : '🔓 Grup otomatis dibuka.'}`)
                } catch {
                    m.reply('Gagal mengubah pengaturan grup. Pastikan bot admin.')
                }
            }
        }, delay)
    }
}