/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['hidetag'],
   aliases: ['h'],
   tags: 'admin',
   group: true,
   admin: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      participants,
      Func
   }) => {
      let txt = m.quoted ? m.quoted.text : text 
      let users = participants.map(v => v.id)
      await conn.reply(m.chat, txt, null, {
         mentions: users
      })
   },
   error: false
}