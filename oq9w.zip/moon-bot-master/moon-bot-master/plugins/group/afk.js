/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['afk'],
   tags: 'group',
   group: true,   
   run: async (m, {
      conn,
      text,
      users,
      Func
   }) => {
      try {
         users.afk = +new Date
         users.afkReason = text
         users.afkObj = m
         return conn.reply(m.chat, `@${m.sender.split`@`[0]} is now AFK!`, m)
      } catch {
         conn.reply(m.chat, global.status.error, m)
      }
   },
   error: false
}