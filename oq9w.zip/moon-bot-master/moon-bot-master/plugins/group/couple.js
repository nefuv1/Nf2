/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const moment = require('moment-timezone')

module.exports = {
   help: ['couple'],
   aliases: ['jadian'],
   tags: 'group',
   group: true,
   run: async (m, {
      conn,
      participants
   }) => {
      let member = participants.map(u => u.jid || u.id)
      let now = new Date * 1
      var tag1 = member[Math.floor(member.length * Math.random())]
      var tag2 = member[Math.floor(member.length * Math.random())]
      if (tag1 == tag2) {
         for (let i = 0; i < 5; i++) {
            var tag1 = member[Math.floor(member.length * Math.random())]
            var tag2 = member[Math.floor(member.length * Math.random())]
            if (tag1 != tag2) {
               break
            }
         }
      }
      conn.reply(m.chat, `@${tag1.replace(/@.+/, '')} 💞 @${tag2.replace(/@.+/, '')}`, m)
   },
   error: false
}