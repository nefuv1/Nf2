/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

global.votes = global.votes || {};

module.exports = {
    help: ['votekick'],
    aliases: ['vote_kick', 'votekik'],
    tags: 'group',
    group: true,
    botAdmin: true,
    run: async (m, { 
        conn, 
        usedPrefix, 
        command,
        participants
    }) => {
        let user = m.mentionedJid[0] || (m.quoted ? m.quoted.sender : null);
        if (!user) return m.reply(`Silakan @tag / balas pesan pengguna.\n\n*Contoh* : ${usedPrefix + command} @0`);

        if (user === conn.user.jid) return m.reply('Tidak dapat memilih bot. 🖕');
        if (global.db.setting.owners.includes(user.replace('@s.whatsapp.net', ''))) {
            return m.reply('Tidak bisa memilih pemilik bot. 🖕');
        }

        let voter = m.sender;
        
        if (!global.votes[user]) {
            global.votes[user] = {
                voters: [],
                timestamp: Date.now()
            };
        }

        if (global.votes[user].voters.includes(voter)) {
            return m.reply('Anda telah vote pengguna ini sebelumnya.');
        }

        global.votes[user].voters.push(voter);
        global.votes[user].timestamp = Date.now();

        let voteCount = global.votes[user].voters.length;
        
        for (const [userId, voteData] of Object.entries(global.votes)) {
            if (Date.now() - voteData.timestamp > 3600000) { // 1 jam
                delete global.votes[userId];
            }
        }

        if (voteCount < 5) {
            return m.reply(`@${user.split('@')[0]} mendapatkan [ ${voteCount}/5 voting ] untuk dikeluarkan. 👍`);
        } else {
            try {
                const groupMembers = participants.map(p => p.id);
                if (!groupMembers.includes(user)) {
                    delete global.votes[user];
                    return m.reply('Pengguna tidak lagi berada dalam grup.');
                }

                await conn.groupParticipantsUpdate(m.chat, [user], 'remove');
                delete global.votes[user];
                
                return m.reply(`${conn.getName(user)} telah dikeluarkan dari grup, mendapatkan [ 5/5 voting ]`);

            } catch (e) {
                console.error(e);
                return m.reply('Gagal mengeluarkan pengguna dari grup. Bot mungkin bukan admin grup.');
            }
        }
    }
};