/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['delete'],
   aliases: ['del','d'],
   tags: 'group',
   run: async (m, {
      conn,
      isBotAdmin
   }) => {
      if (!m.quoted) return
      conn.sendMessage(m.chat, {
         delete: {
            remoteJid: m.chat,
            fromMe: isBotAdmin ? false : true,
            id: m.quoted.id,
            participant: m.quoted.sender
         }
      })
   },
   error: false
}