/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['link'],
   tags: 'group',
   group: true,
   botAdmin: true,
   run: async (m, {
      conn
   }) => {
      await conn.reply(m.chat, 'https://chat.whatsapp.com/' + (await conn.groupInviteCode(m.chat)), m)
   },
   error: false
}