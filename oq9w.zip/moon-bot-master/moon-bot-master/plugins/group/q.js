/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['quoted'],
   aliases: ['q'],
   tags: 'group',
   run: async (m, {
      conn,
      store,
      Func
   }) => {
      try {
         if (!m.quoted) return m.reply('Silakan balas pesan kutipan.')
         const msg = await store.loadMessage(m.chat, m.quoted.id)
         if (msg.quoted === null) return conn.reply(m.chat, `Pesan tidak mengandung kutip.`, m)
         return conn.copyNForward(m.chat, msg.quoted.fakeObj)
      } catch (e) {
         conn.reply(m.chat, `Tidak dapat memuat pesan.`, m)
      }
   },
   error: false
}