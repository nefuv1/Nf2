/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const { Sticker } = require('wa-sticker-formatter'); // bisa dihapus 

function getUserName(sender, targetUser) {
  try {
    if (targetUser && targetUser.username) {
      return targetUser.username.charAt(0).toUpperCase() + targetUser.username.slice(1);
    }
    
    const mention = `@${sender.split('@')[0]}`;
    return mention;
    
  } catch (error) {
    return sender.split('@')[0];
  }
}

module.exports = {
   help: ['semoji'],
   aliases: ['emoji'],
   tags: 'sticker',
   limit: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      setting,
      Func
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingSemoji = user.isProcessingSemoji || false;
         
         if (user.isProcessingSemoji) throw global.status.previously
         if (!text) throw `Please provide style and emoji.\n\n*Example* : ${usedPrefix + command} apple 😀`

         user.isProcessingSemoji = true;

         const isPremium = user.premium || false;
         
         let packName = setting.sk_pack || '';
         let authorName = setting.sk_author || '';
         
         if (isPremium) {
            packName = "Dibuat oleh";
            authorName = getUserName(m.sender, user);
         }

         let [type, ...rest] = text.split(' ')
         let data = rest.join(' ').trim()

         let lists = ['apple', 'google', 'facebook', 'twitter', 'samsung', 'microsoft', 'whatsapp', 'messenger', 'joypixels', 'openmoji', 'emojidex', 'htc', 'lg', 'mozilla', 'softbank', 'au-kddi']

         if (!type || !lists.includes(type.toLowerCase())) {
            let p = `*Styles* :\n\n`
            p += lists.sort().map((v, i) => `${i + 1}. ${v}`).join('\n')
            throw p
         }

         const json = await Api.get('/emoji', {
            emo: data
         })
         if (!json.status) throw Func.jsonFormat(json)

         const result = json.data[type.toLowerCase()]
         if (!result) throw 'Emoji style not found!'

         conn.sendSticker(m.chat, result.image, m, {
            packname: packName,
            author: authorName
         })

      } catch (e) {
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingSemoji = false;
         }
      }
   }
}