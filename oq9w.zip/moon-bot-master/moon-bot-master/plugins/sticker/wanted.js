/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');
const FormData = require('form-data');

async function uploadImage(imageBuffer) {
    const form = new FormData();
    form.append('file', imageBuffer, {
        filename: 'avatar.jpg',
        contentType: 'image/jpeg'
    });

    const headers = {
        ...form.getHeaders(),
        'Content-Length': form.getLengthSync()
    };

    const response = await axios.post('https://www.pic.surf/upload.php', form, { headers });
    return `https://www.pic.surf/${response.data.identifier}`;
}

async function getProfilePicture(userId, conn) {
    try {
        const profile = await conn.profilePictureUrl(userId, 'image');
        const response = await axios.get(profile, { responseType: 'arraybuffer' });
        return Buffer.from(response.data);
    } catch (error) {
        return null;
    }
}

function getUserName(sender, targetUser) {
  try {
    if (targetUser && targetUser.username) {
      return targetUser.username.charAt(0).toUpperCase() + targetUser.username.slice(1);
    }
    
    const mention = `@${sender.split('@')[0]}`;
    return mention;
    
  } catch (error) {
    return sender.split('@')[0];
  }
}

module.exports = {
   help: ['wanted'],
   tags: 'sticker',
   limit: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      setting,
      Func
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingWanted = user.isProcessingWanted || false;
         
         if (user.isProcessingWanted) throw global.status.previously

         user.isProcessingWanted = true;

         const isPremium = user.premium || false;
         
         let packName = setting.sk_pack || '';
         let authorName = setting.sk_author || '';
         
         if (isPremium) {
            packName = "Dibuat oleh";
            authorName = getUserName(m.sender, user);
         }

         let targetUserId = m.sender;
         let targetUser = user;

         if (m.mentionedJid && m.mentionedJid.length > 0) {
             targetUserId = m.mentionedJid[0];
             targetUser = global.db.users[targetUserId] || {};
         }
         
         if (m.quoted && m.quoted.sender) {
             targetUserId = m.quoted.sender;
             targetUser = global.db.users[targetUserId] || {};
         }

         const img = await getProfilePicture(targetUserId, conn);
         
         if (!img) {
             throw 'No profile picture found for the user.';
         }

         conn.sendReact(m.chat, global.react, m.key)

         const avatarUrl = await uploadImage(img);
         
         const wantedUrl = `https://some-random-api.com/canvas/wasted?avatar=${encodeURIComponent(avatarUrl)}`;
         
         await conn.sendSticker(m.chat, wantedUrl, m, {
            packname: packName,
            author: authorName
         })
      } catch (e) {
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingWanted = false;
         }
      }
   },
   error: false
}