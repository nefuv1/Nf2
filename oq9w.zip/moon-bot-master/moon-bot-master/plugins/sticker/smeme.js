/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const { Sticker } = require('wa-sticker-formatter'); // bisa dihapus 

function getUserName(sender, targetUser) {
  try {
    if (targetUser && targetUser.username) {
      return targetUser.username.charAt(0).toUpperCase() + targetUser.username.slice(1);
    }

    const mention = `@${sender.split('@')[0]}`;
    return mention;
    
  } catch (error) {
    return sender.split('@')[0];
  }
}

module.exports = {
   help: ['smeme'],
   tags: 'sticker',
   limit: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      Scraper,
      setting,
      Func
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingSmeme = user.isProcessingSmeme || false;
         
         if (user.isProcessingSmeme) throw global.status.previously
         if (!text) throw `Please provide text.\n\n*Example* : ${usedPrefix + command} TechBOT`
         
         user.isProcessingSmeme = true;
         conn.sendReact(m.chat, global.react, m.key)
         
         const isPremium = user.premium || false;
         
         let packName = setting.sk_pack || '';
         let authorName = setting.sk_author || '';
         
         if (isPremium) {
            packName = "Dibuat oleh";
            authorName = getUserName(m.sender, user);
         }

         let [top, bottom] = text.split`|`
         if (m.quoted ? m.quoted.message : m.msg.viewOnce) {
            let type = m.quoted ? Object.keys(m.quoted.message)[0] : m.mtype
            let q = m.quoted ? m.quoted.message[type] : m.msg
            if (/image|webp/.test(type)) {
               let img = await conn.downloadMediaMessage(q)
               const image = await (await Scraper.uploader(img)).data.url
               const json = `https://api.memegen.link/images/custom/${encodeURIComponent(top ? top : ' ')}/${encodeURIComponent(bottom ? bottom : '')}.png?background=${image}`
               conn.sendSticker(m.chat, json, m, {
                  packname: packName,
                  author: authorName
               })
            } else throw `Only (IMAGE / STICKER) is supported.`
         } else {
            let q = m.quoted ? m.quoted : m
            let mime = (q.msg || q).mimetype || ''
            if (!mime) throw `Reply photo.`
            if (!/webp|image\/(jpe?g|png)/.test(mime)) throw `Only (IMAGE / STICKER) is supported.`
            const image = await (await Scraper.uploader(await q.download())).data.url
            const json = `https://api.memegen.link/images/custom/${encodeURIComponent(top ? top : ' ')}/${encodeURIComponent(bottom ? bottom : '')}.png?background=${image}`
            conn.sendSticker(m.chat, json, m, {
               packname: packName,
               author: authorName
            })
         }
      } catch (e) {
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingSmeme = false;
         }
      }
   },
   error: false
}