/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');
const { Sticker } = require('wa-sticker-formatter'); // bisa dihapus 

function getUserName(sender, targetUser) {
  try {
    if (targetUser && targetUser.username) {
      return targetUser.username.charAt(0).toUpperCase() + targetUser.username.slice(1);
    }
    
    const mention = `@${sender.split('@')[0]}`;
    return mention;
    
  } catch (error) {
    return sender.split('@')[0];
  }
}

module.exports = {
   help: ['brat','bratgif'],
   tags: 'sticker',
   limit: true,
   run: async (m, { conn, usedPrefix, command, Func, args, text, setting }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingBrat = user.isProcessingBrat || false;
         
         if (user.isProcessingBrat) throw global.status.previously
         
         const isGifCommand = command === 'bratgif'
         const hasGifArg = args[0]?.toLowerCase() === 'gif'
         
         let content
         if (isGifCommand) {
            content = text
         } else if (hasGifArg) {
            content = args.slice(1).join(' ')
         } else {
            content = text
         }

         if (!content) throw `Please provide text.\n\nExample: ${usedPrefix}brat TechBOT`
         if (content.length > 50) throw 'Max 50 characters!'

         user.isProcessingBrat = true;
         conn.sendReact(m.chat, global.react, m.key)
         
         const isPremium = user.premium || false;

         let packName = setting.sk_pack || '';
         let authorName = setting.sk_author || '';
         
         if (isPremium) {
            packName = "Dibuat oleh";
            authorName = getUserName(m.sender, user);
         }

         const isGif = isGifCommand || hasGifArg

         if (isGif) {
            const apis = [
               `https://apizell.web.id/tools/bratanimate?q=${encodeURIComponent(content)}`,
               `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(content)}&isAnimated=true`,
               `https://ochinpo-helper.hf.space/brat?text=${encodeURIComponent(content)}&animated=true`
            ]

            let success = false
            for (const apiUrl of apis) {
               try {
                  const response = await axios.get(apiUrl, { responseType: 'arraybuffer', timeout: 10000 })
                  await conn.sendSticker(m.chat, Buffer.from(response.data), m, {
                     packname: packName,
                     author: authorName
                  })
                  success = true
                  break
               } catch (e) {
                  console.log(`API ${apiUrl} failed :`, e.message)
                  continue
               }
            }
            
            if (!success) {
               throw new Error('All gif APIs are not working')
            }

         } else {
            const apis = [
//               `https://brat.caliphdev.com/api/brat?text=${encodeURIComponent(content)}`,
               `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(content)}`,
               `https://ochinpo-helper.hf.space/brat?text=${encodeURIComponent(content)}`,
               `https://aqul-brat.hf.space?text=${encodeURIComponent(content)}`
            ]

            let success = false
            for (const apiUrl of apis) {
               try {
                  const response = await axios.get(apiUrl, { responseType: 'arraybuffer', timeout: 10000 })
                  await conn.sendSticker(m.chat, Buffer.from(response.data), m, {
                     packname: packName,
                     author: authorName
                  })
                  success = true
                  break
               } catch (e) {
                  console.log(`API ${apiUrl} failed :`, e.message)
                  continue
               }
            }
            
            if (!success) {
               throw new Error('All static APIs fail')
            }
         }

      } catch (e) {
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingBrat = false;
         }
      }
   }
}