/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['attp'],
   tags: 'sticker',
   limit: 30,
   premium: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      setting,
      Func
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingAttp = user.isProcessingAttp || false;
         
         if (user.isProcessingAttp) throw global.status.previously
         if (!text) throw `Please provide text.\n\n*Example* : ${usedPrefix + command} TechBOT`
         if (text.length > 50) throw 'Max 50 characters!'
         
         user.isProcessingAttp = true;
         conn.sendReact(m.chat, global.react, m.key)
         
         const json = await Api.get('/attp', {
            text: text
         })
         if (!json.status) throw Func.jsonFormat(json)
         
         conn.sendSticker(m.chat, json.data.url, m, {
            packname: setting.sk_pack,
            author: setting.sk_author
         })
         
      } catch (e) {
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingAttp = false;
         }
      }
   },
   error: false
}