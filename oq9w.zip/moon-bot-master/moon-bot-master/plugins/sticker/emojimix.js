/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const fetch = require('node-fetch');
const { Sticker } = require('wa-sticker-formatter'); // bisa dihapus 

function getUserName(sender, targetUser) {
  try {
    if (targetUser && targetUser.username) {
      return targetUser.username.charAt(0).toUpperCase() + targetUser.username.slice(1);
    }
    
    const mention = `@${sender.split('@')[0]}`;
    return mention;
    
  } catch (error) {
    return sender.split('@')[0];
  }
}

async function fetchJson(url, options) {
  try {
    const response = await fetch(url, options);
    return await response.json();
  } catch (err) {
    throw new Error(`Fetch error : ${err.message}`);
  }
}

module.exports = {
  help: ['emojimix'],
  tags: 'sticker',
  limit: true,
  run: async (m, { conn, Func, text, usedPrefix, command, setting }) => {
    let user = global.db.users[m.sender] || {};
    user.isProcessingEmojimix = user.isProcessingEmojimix || false;

    if (user.isProcessingEmojimix) throw global.status.previously
    if (!text) throw `Please provide 2 emojis.\n\nExample: ${usedPrefix}emojimix 😎+🥴`

    try {
      user.isProcessingEmojimix = true;
      m.react(global.react);

      const isPremium = user.premium || false;
      
      let packName = setting.sk_pack || '';
      let authorName = setting.sk_author || '';
      
      if (isPremium) {
        packName = "Dibuat oleh";
        authorName = getUserName(m.sender, user);
      }

      let [emoji1, emoji2] = text.split('+');
      if (!emoji1 || !emoji2) throw 'Invalid emoji format. Use: emoji1+emoji2'

      let json = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`);

      if (!json.results || json.results.length === 0) {
        throw "No results found for the given emoji."
      }

      for (let res of json.results) {
        try {
          const response = await fetch(res.url);
          const buffer = await response.buffer();
          
          await conn.sendSticker(m.chat, buffer, m, {
            packname: packName,
            author: authorName
          });
        } catch (e) {
          console.error('Error sending sticker : ', e.message);
        }
      }

    } catch (e) {
      console.error(e);
           throw Func.jsonFormat(e)
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingEmojimix = false;
      }
    }
  }
}