/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');

function getUserName(sender, targetUser) {
   try {
      if (targetUser && targetUser.username) {
         return targetUser.username.charAt(0).toUpperCase() + targetUser.username.slice(1);
      }
      const mention = `@${sender.split('@')[0]}`;
      return mention;
   } catch (error) {
      return sender.split('@')[0];
   }
}

module.exports = {
   help: ['stickertelegram'],
   aliases: ['fstik', 'tgstik', 'sticktele', 'stickerset'],
   tags: 'sticker',
   limit: 30,
   premium: true,
   run: async (m, { conn, usedPrefix, command, text, setting, Func }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingFstik = user.isProcessingFstik || false;

         if (user.isProcessingFstik) throw global.status.previously;
         if (!text) throw `Please provide Telegram sticker URL.\n\n*Example* : ${usedPrefix + command} https://t.me/addstickers/BoysClub`;

         user.isProcessingFstik = true;

         const isPremium = user.premium || false;
         let packName = setting.sk_pack || '';
         let authorName = setting.sk_author || '';

         if (isPremium) {
            packName = 'Dibuat oleh';
            authorName = getUserName(m.sender, user);
         }

         let name = text.trim();
         if (name.startsWith('https://t.me/addstickers/')) {
            name = name.split('/addstickers/')[1]?.trim();
         }
         if (!name) throw 'The sticker link from twlegram is invalid!';

         const res = await axios.post(
            'https://api.fstik.app/getStickerSetByName',
            { name, user_token: null },
            {
               headers: {
                  accept: 'application/json, text/plain, */*',
                  'content-type': 'application/json',
                  origin: 'https://webapp.fstik.app',
                  referer: 'https://webapp.fstik.app/',
                  'user-agent': 'NB Android/1.0.0'
               }
            }
         );

         const set = res.data?.result;
         if (!set?.stickers?.length) throw `"${name}" Not found / No results!`;

         const stickers = set.stickers
            .map((s) => {
               const id = s.thumb?.file_id ?? s.thumb?.fileid;
               return id ? `https://api.fstik.app/file/${id}/sticker.webp` : null;
            })
            .filter(Boolean);

         if (!stickers.length) throw 'Empty sticker pack!';

         await conn.sendMessage(m.chat, {
            text: `Sending *${set.title || name}* (${stickers.length} sticker)...`
         }, { quoted: m });

         for (const [i, url] of stickers.entries()) {
            await conn.sendSticker(m.chat, url, m, {
               packname: packName,
               author: authorName
            });
            await Func.delay(2000); // jeda biar gak flood
         }

         await conn.sendMessage(m.chat, {
            text: `Done. 👍\n\n- *Total* : ${stickers.length}\n- *From* : ${set.title || name}`
         }, { quoted: m });

      } catch (e) {
         throw Func.jsonFormat(e);
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingFstik = false;
         }
      }
   }
};