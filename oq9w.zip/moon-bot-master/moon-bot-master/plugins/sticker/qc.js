/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios')
const { Sticker } = require('wa-sticker-formatter'); // bisa dihapus 

function getUserName(sender, targetUser) {
  try {
    if (targetUser && targetUser.username) {
      return targetUser.username.charAt(0).toUpperCase() + targetUser.username.slice(1);
    }
    
    const mention = `@${sender.split('@')[0]}`;
    return mention;
    
  } catch (error) {
    return sender.split('@')[0];
  }
}

module.exports = {
   help: ['qc'],
   tags: 'sticker',
   limit: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      setting,
      Func
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingQc = user.isProcessingQc || false;
         
         if (user.isProcessingQc) throw global.status.previously
         if (!text) throw `Please provide text.\n\n*Example* : ${usedPrefix + command} TechBOT`

         if (text.length > 50) {
            throw `Max 50 characters!`
         }

         user.isProcessingQc = true;

         const isPremium = user.premium || false;
         
         let packName = setting.sk_pack || '';
         let authorName = setting.sk_author || '';
         
         if (isPremium) {
            packName = "Dibuat oleh";
            authorName = getUserName(m.sender, user);
         }

         var pic = await conn.profilePictureUrl(m.quoted ? m.quoted.sender : m.sender, 'image') || 'https://i.ibb.co/NLJdrcJ/image.jpg'
         conn.sendReact(m.chat, global.react, m.key)

         const json = {
            "type": "quote",
            "format": "png",
            "backgroundColor": "#0C0C0C",
            "width": 512,
            "height": 768,
            "scale": 2,
            "messages": [{
               "entities": [],
               "avatar": true,
               "from": {
                  "id": 1,
                  "name": m.quoted ? m.quoted.name : m.name,
                  "photo": {
                     "url": pic
                  }
               },
               "text": text,
               "replyMessage": {}
            }]
         }

         const response = await axios.post('https://bot.lyo.su/quote/generate', json, {
            headers: {
               'Content-Type': 'application/json'
            }
         })
         const buffer = Buffer.from(response.data.result.image, 'base64')
         
         conn.sendSticker(m.chat, buffer, m, {
            packname: packName,
            author: authorName
         })
      } catch (e) {
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingQc = false;
         }
      }
   },
   error: false
}