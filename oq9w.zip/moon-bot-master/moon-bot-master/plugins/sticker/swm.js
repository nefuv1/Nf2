/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
    help: ['swm'],
    aliases: ['wm'],
    tags: 'sticker',
    limit: true,
    run: async (m, { conn, usedPrefix, command, text, Func }) => {
        try {
            let user = global.db.users[m.sender] || {};
            user.isProcessingSwm = user.isProcessingSwm || false;
            
            if (user.isProcessingSwm) throw global.status.previously
            if (!text) throw `Please provide text.\n\n*Example* : ${usedPrefix + command} packname | author`

            user.isProcessingSwm = true;
            
            let [packname, ...author] = text.split('|')
            author = (author || []).join('|').trim()

            let q = m.quoted ? m.quoted : m
            let mime = (q.msg || q).mimetype || ''

            if (/webp/.test(mime)) {
                let img = await q.download()
                if (!img) throw global.status.wrong
                return conn.sendSticker(m.chat, img, m, { packname: packname || '', author: author || '' })
            }

            if (/image\/(jpe?g|png)/.test(mime)) {
                let img = await q.download()
                if (!img) throw global.status.wrong
                return conn.sendSticker(m.chat, img, m, { packname: packname || '', author: author || '' })
            }

            if (/video/.test(mime)) {
                if ((q.msg || q).seconds > 10) throw 'Maximum video duration is 10 seconds.'
                let img = await q.download()
                if (!img) throw global.status.wrong
                return conn.sendSticker(m.chat, img, m, { packname: packname || '', author: author || '' })
            }

            throw `Please reply to *image*, *video (max. 10 seconds)*, or *sticker* and use this format.\n\n*Example* : ${usedPrefix + command} packname | author`

        } catch (e) {
           throw Func.jsonFormat(e)
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingSwm = false;
            }
        }
    },
    error: false
}