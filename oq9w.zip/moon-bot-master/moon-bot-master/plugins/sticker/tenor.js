/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');
const cheerio = require('cheerio');
const { Sticker } = require('wa-sticker-formatter');

async function gifsSearch(q) {
  try {
    const searchUrl = `https://tenor.com/search/${q}-gifs`;
    const { data } = await axios.get(searchUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0"
      }
    });

    const $ = cheerio.load(data);
    const results = [];

    $("figure.UniversalGifListItem").each((i, el) => {
      const $el = $(el);
      const img = $el.find("img");
      const gifUrl = img.attr("src");
      const alt = img.attr("alt") || "No description";
      const detailPath = $el.find("a").first().attr("href");

      if (gifUrl && gifUrl.endsWith('.gif') && detailPath) {
        results.push({
          gif: gifUrl,
          alt,
          link: "https://tenor.com" + detailPath
        });
      }
    });

    return results;
  } catch (error) {
    console.error("Error fetching GIFs : ", error);
    return [];
  }
}

function getUserName(sender, targetUser) {
  try {
    if (targetUser && targetUser.username) {
      return targetUser.username.charAt(0).toUpperCase() + targetUser.username.slice(1);
    }
    
    const mention = `@${sender.split('@')[0]}`;
    return mention;
    
  } catch (error) {
    return sender.split('@')[0];
  }
}

module.exports = {
  help: ['tenor'],
  tags: 'sticker',
  limit: true,
  run: async (m, { conn, text, usedPrefix, command, setting }) => {
    const user = global.db.users[m.sender] || {};
    user.isProcessingTenor = user.isProcessingTenor || false;

    if (user.isProcessingTenor) throw global.status.previously
    if (!text) throw (`Please provide title.\n\n*Example* : ${usedPrefix + command} TechBOT`)
    
    m.react(global.react)

    try {
      user.isProcessingTenor = true;

      const [query, countStr] = text.split(/(?<=^\S+)\s/);
      const count = Math.min(Number(countStr) || 1, 10);

      const results = await gifsSearch(query);
      if (!results.length) throw `"${text}" Not found / No results!`

      const picks = [];
      const usedIndexes = new Set();
      while (picks.length < count && usedIndexes.size < results.length) {
        const i = Math.floor(Math.random() * results.length);
        if (!usedIndexes.has(i)) {
          usedIndexes.add(i);
          picks.push(results[i]);
        }
      }

      const isPremium = user.premium || false;
      
      let packName = setting.sk_pack || '';
      let authorName = setting.sk_author || '';
      
      if (isPremium) {
        packName = "Dibuat oleh";
        authorName = getUserName(m.sender, user);
      }

      for (const pick of picks) {
        try {
          const { data } = await axios.get(pick.gif, { responseType: 'arraybuffer' });

          const sticker = new Sticker(data, {
            type: 'full',
            pack: packName,
            author: authorName,
            quality: 70
          });

          const buffer = await sticker.toBuffer();
          await conn.sendMessage(m.chat, { sticker: buffer }, { quoted: m });
        } catch (e) {
          console.error(`Failed to send sticker : ${pick.gif}`);
        }
      }

    } catch (e) {
      console.error(e);
      throw Func.jsonFormat(e)
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingTenor = false;
      }
    }
  }
}