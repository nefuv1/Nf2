/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const { createCanvas } = require('canvas');
const { Sticker } = require('wa-sticker-formatter'); // bisa dihapus 

function getUserName(sender, targetUser) {
  try {
    if (targetUser && targetUser.username) {
      return targetUser.username.charAt(0).toUpperCase() + targetUser.username.slice(1);
    }
    
    const mention = `@${sender.split('@')[0]}`;
    return mention;
    
  } catch (error) {
    return sender.split('@')[0];
  }
}

module.exports = {
  help: ['canvas'],
  tags: 'sticker',
  limit: true,
  run: async (m, { conn, Func, usedPrefix, command, text, setting }) => {
    try {
      let user = global.db.users[m.sender] || {};
      user.isProcessingBrat = user.isProcessingBrat || false;
      
      if (user.isProcessingBrat) throw global.status.previously
      if (!text) throw `Please provide text.\n\nExample: ${usedPrefix + command} TechBOT`
      if (text.length > 50) throw 'Max 50 characters!'

      user.isProcessingBrat = true;
      m.react(global.react);

      const isPremium = user.premium || false;
      
      let packName = setting.sk_pack || '';
      let authorName = setting.sk_author || '';
      
      if (isPremium) {
        packName = "Dibuat oleh";
        authorName = getUserName(m.sender, user);
      }

      const canvasBuffer = createCanvasSticker(text);
      
      await conn.sendSticker(m.chat, canvasBuffer, m, {
        packname: packName,
        author: authorName
      });

    } catch (e) {
      console.error(e);
           throw Func.jsonFormat(e)
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingBrat = false;
      }
    }
  }
};

function createCanvasSticker(text) {
  const canvas = createCanvas(512, 512); 
  const ctx = canvas.getContext('2d');
  
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle = '#000000';
  let fontSize = 40;
  ctx.font = `bold ${fontSize}px Arial`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  let lines = [];
  let words = text.split(' ');
  let currentLine = words[0];

  for (let i = 1; i < words.length; i++) {
    let word = words[i];
    let width = ctx.measureText(currentLine + " " + word).width;
    if (width < canvas.width - 20) {
      currentLine += " " + word;
    } else {
      lines.push(currentLine);
      currentLine = word;
    }
  }
  lines.push(currentLine);

  const lineHeight = fontSize * 1.2;
  const totalTextHeight = lines.length * lineHeight;
  const startY = (canvas.height - totalTextHeight) / 2;

  lines.forEach((line, index) => {
    ctx.fillText(line, canvas.width / 2, startY + index * lineHeight);
  });

  return canvas.toBuffer('image/png');
}
