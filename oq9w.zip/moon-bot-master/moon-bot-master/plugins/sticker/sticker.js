/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const { Sticker } = require('wa-sticker-formatter'); // bisa dihapus 

function getUserName(sender, targetUser) {
  try {
    if (targetUser && targetUser.username) {
      return targetUser.username.charAt(0).toUpperCase() + targetUser.username.slice(1);
    }
    
    const mention = `@${sender.split('@')[0]}`;
    return mention;
    
  } catch (error) {
    return sender.split('@')[0];
  }
}

module.exports = {
   help: ['sticker'],
   aliases: ['s','stiker'],
   tags: 'sticker',
   limit: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      setting,
      Func
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingSticker = user.isProcessingSticker || false;
         
         if (user.isProcessingSticker) throw global.status.previously
         user.isProcessingSticker = true;

         const isPremium = user.premium || false;
         
         let packName = setting.sk_pack || '';
         let authorName = setting.sk_author || '';
         
         if (isPremium) {
            packName = "Dibuat oleh";
            authorName = getUserName(m.sender, user);
         }

         if (m.quoted ? m.quoted.message : m.msg.viewOnce) {
            let type = m.quoted ? Object.keys(m.quoted.message)[0] : m.mtype
            let q = m.quoted ? m.quoted.message[type] : m.msg
            let img = await conn.downloadMediaMessage(q)
            if (/video/.test(type)) {
               if (q.seconds > 10) throw `Maximum video duration is *10 seconds*.`
               await conn.sendSticker(m.chat, img, m, {
                  packname: packName,
                  author: authorName
               })
               await m.react(global.react)
            } else if (/image/.test(type)) {
               await conn.sendSticker(m.chat, img, m, {
                  packname: packName,
                  author: authorName
               })
               await m.react(global.react)
            }
         } else {
            let q = m.quoted ? m.quoted : m
            let mime = (q.msg || q).mimetype || ''
            if (/image\/(jpe?g|png)/.test(mime)) {
               let img = await q.download()
               if (!img) throw global.status.wrong
               await conn.sendSticker(m.chat, img, m, {
                  packname: packName,
                  author: authorName
               })
               await m.react(global.react)
            } else if (/video/.test(mime)) {
               if ((q.msg || q).seconds > 10) throw `Maximum video duration is *10 seconds*.`
               let img = await q.download()
               if (!img) throw conn.reply(m.chat, global.status.wrong, m)
               await conn.sendSticker(m.chat, img, m, {
                  packname: packName,
                  author: authorName
               })
               await m.react(global.react)
            } else {
               throw `Please reply / send video / image with command.`
               await m.react(global.react)
            }
         }
      } catch (e) {
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingSticker = false;
         }
      }
   },
   error: false
}
