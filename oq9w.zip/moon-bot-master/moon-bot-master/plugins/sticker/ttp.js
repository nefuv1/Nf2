/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['ttp'],
   tags: 'sticker',
   limit: 30,
   premium: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      setting,
      Func
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingTtp = user.isProcessingTtp || false;
         
         if (user.isProcessingTtp) throw global.status.previously
         if (!text) throw `Please provide text.\n\n*Example* : ${usedPrefix + command} TechBOT`
         if (text.length > 50) throw 'Max 50 characters!'
         
         user.isProcessingTtp = true;
         conn.sendReact(m.chat, global.react, m.key)
         
         const json = await Api.get('/ttp', {
            text: text
         })
         if (!json.status) return conn.reply(m.chat, Func.jsonFormat(json), m)
         
         conn.sendSticker(m.chat, json.data.url, m, {
            packname: setting.sk_pack,
            author: setting.sk_author
         })
         
      } catch (e) {
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingTtp = false;
         }
      }
   },
   error: false
}