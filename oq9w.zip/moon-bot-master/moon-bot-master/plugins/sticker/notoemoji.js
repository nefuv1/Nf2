/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const { Sticker } = require('wa-sticker-formatter'); // bisa dihapus 

function getUserName(sender, targetUser) {
  try {
    if (targetUser && targetUser.username) {
      return targetUser.username.charAt(0).toUpperCase() + targetUser.username.slice(1);
    }
    
    const mention = `@${sender.split('@')[0]}`;
    return mention;
    
  } catch (error) {
    return sender.split('@')[0];
  }
}

module.exports = {
  help: ['notoemoji'],
  tags: 'sticker',
  aliases: ['notemoji', 'noto'],
  limit: true,
  run: async (m, { conn, text, Func, setting, usedPrefix, command }) => {
    try {
      let user = global.db.users[m.sender] || {};
      user.isProcessingNotoemoji = user.isProcessingNotoemoji || false;
      
      if (user.isProcessingNotoemoji) throw global.status.previously
      if (!text) throw `Please provide 1 emoji.\n\n*Example* : ${usedPrefix + command} 😎`

      user.isProcessingNotoemoji = true;
      m.react(global.react);

      const isPremium = user.premium || false;
      
      let packName = setting.sk_pack || '';
      let authorName = setting.sk_author || '';
      
      if (isPremium) {
        packName = "Dibuat oleh";
        authorName = getUserName(m.sender, user);
      }

      const codePoint = Array.from(text)[0]?.codePointAt(0)?.toString(16);
      const result = codePoint
        ? `https://fonts.gstatic.com/s/e/notoemoji/latest/${codePoint}/512.webp`
        : null;

      if (!result) throw `"${text}" Not found / No results!`

      conn.sendSticker(m.chat, result, m, {
        packname: packName,
        author: authorName
      });

    } catch (e) {
      console.error(e);
           throw Func.jsonFormat(e)
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingNotoemoji = false;
      }
    }
  }
};
