const { setTimeout: delay } = require('timers/promises')
const formatNumber = require('../../lib/formatNumber')

module.exports = {
    help: ['craft'],
    aliases: ['make'],
    tags: 'rpg',
    group: true,
    rpg: true,
    register: true,
    run: async (m, { usedPrefix, command, args }) => {
        try {
            const user = global.db.users[m.sender]
            if (!user) return m.reply('Data pengguna tidak ada di database.')

            // Daftar item yang bisa dibuat (key = nama asli dengan huruf besar di awal)
            const crafts = {
                atm: { cost: 100000, name: 'ATM' },
                card: { cost: 1000000, name: 'Card' },
                armor: { cost: 500000, name: 'Armor' }
            }

            if (!user.inventory) user.inventory = {}

            // Jika tidak ada argumen, tampilkan daftar item
            if (!args[0]) {
                let msg = `*CRAFT*\n\nDaftar item yang bisa dibuat :\n\n`
                msg += `1. ATM || ${formatNumber(100000)} EXP\n\n`
                msg += `2. Card || ${formatNumber(1000000)} EXP\n\n`
                msg += `3. Armor || ${formatNumber(500000)} EXP\n\n`
                msg += `*Contoh* : ${usedPrefix + command} atm`
                return m.reply(msg)
            }

            // Normalisasi input biar tidak case-sensitive
            const input = args[0].toLowerCase()
            const itemKey = Object.keys(crafts).find(key => key.toLowerCase() === input)

            if (!itemKey)
                return m.reply(
                    `Item tidak dikenali! 👎\n\nSilakan kirim perintah : ${usedPrefix + command} - (Untuk melihat daftar item yang bisa dibuat)`
                )

            const craft = crafts[itemKey]

            // Cek apakah user sudah punya item tersebut
            if (user.inventory[itemKey] >= 1)
                return m.reply(`Kamu sudah memiliki ${craft.name}!\n\nKamu hanya bisa membuat 1 kali.`)

            // Cek apakah exp cukup
            if (user.exp < craft.cost)
                return m.reply(
                    `EXP kamu tidak mencukupi! 👎\n\nDibutuhkan : ${formatNumber(craft.cost)} EXP - (Untuk membuat ${craft.name})`
                )

            // Cek apakah sedang membuat item lain
            if (!global.craftQueue) global.craftQueue = {}
            if (global.craftQueue[m.sender])
                return m.reply('Kamu sedang membuat item lain!\n\nHarap tunggu prosesnya selesai.')

            // Kurangi EXP user
            user.exp -= craft.cost
            global.craftQueue[m.sender] = { item: craft.name, start: Date.now() }

            // Pesan awal proses craft
            m.reply(
                `*CRAFT*\n\n` +
                `Proses pembuatan dimulai!\n` +
                `- *Item* : ${craft.name}\n` +
                `- *Durasi* : 1 menit\n` +
                `- *Status* : Sedang diproses...\n\n` +
                `_Kamu akan menerima pesan jika proses sudah selesai._`
            )

            // Tunggu 1 menit
            await delay(60 * 1000)

            // Tambahkan item ke inventory
            user.inventory[itemKey] = (user.inventory[itemKey] || 0) + 1
            delete global.craftQueue[m.sender]

            // Notifikasi selesai
            m.reply(
                `*CRAFT*\n\n` +
                `Item berhasil dibuat!\n` +
                `- *Item* : ${craft.name}\n` +
                `- *Status* : Sukses. 👍\n\n` +
                `_Item telah ditambahkan ke inventory kamu._`
            )

        } catch (e) {
            console.error(e)
            throw Func.jsonFormat(e)
        }
    }
}