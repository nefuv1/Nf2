const formatNumber = require('../../lib/formatNumber');

module.exports = {
    help: ['mart'],
    aliases: ['buy'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,
    run: async (m, { 
        conn, 
        text, 
        usedPrefix, 
        command,
        args,
        users
    }) => {
        const user = users;
        if (!user) return m.reply("Data pengguna tidak ada di database.");
        
        if (!global.db.stores || !global.db.stores.active || global.db.stores.active.length === 0) {
            return m.reply(`*STORE MART*\n\n` +
                `Belum ada store yang tersedia!\n\n` +
                `Ingin buka store sendiri? Kirim perintah :\n` +
                `- ${usedPrefix}store [deskripsi] - Daftar store\n\n` +
                `Butuh Card? Silakan buat di Craft :\n` +
                `- ${usedPrefix}craft Card`);
        }

        const subCommand = args[0]?.toLowerCase();
        
        if (command === 'mart' || !subCommand) {
            return showAllStores(m, usedPrefix);
        } else if (subCommand === 'buy') {
            return buyFromStore(m, args, user, usedPrefix, command);
        }
    }
};

function showAllStores(m, usedPrefix) {
    const activeStores = global.db.stores.active;
    
    if (!activeStores || activeStores.length === 0) {
        return m.reply("Belum ada store yang aktif!");
    }
    
    let storesList = `*STORE MART*\n\n`;
    storesList += `*Total Toko Aktif* : ${activeStores.length}\n\n`;
    
    activeStores.forEach((store, index) => {
        const rating = store.rating || 0;
        const productCount = store.products ? store.products.length : 0;
        const customerCount = store.customerCount || 0;
        const storeId = store.storeId ? store.storeId.toString().padStart(5, '0') : '00000';
        
        storesList += `━━━━ *${store.storeName || 'Tidak ada nama'}* ━━━━\n\n`;
        storesList += `[${index + 1}]\n`;
        storesList += `- *Pemilik* : ${store.ownerName || m.sender.split('@')[0]}\n`;
        storesList += `- *Deskripsi* : ${store.description || 'Tidak ada deskripsi'}\n`;
        storesList += `- *Rating* : ${rating.toFixed(1)}\n\n`;
        
        storesList += `*Produk Yang Dijual*\n`;
        if (store.products && store.products.length > 0) {
            store.products.forEach((product, productIndex) => {
                const sold = product.sold || 0;
                storesList += `${productIndex + 1}. ${product.name} : ${formatNumber(product.price)} Money\n`;
                storesList += `(Stock : ${product.stock} | Terjual : ${sold})\n`;
            });
        } else {
            storesList += `_Belum ada produk yang dijual_\n`;
        }
        
        storesList += `\n- *Produk* : ${productCount} item\n`;
        storesList += `- *Pembeli* : ${customerCount} orang\n\n`;
    });
    
    storesList += `━━━━ *Cara Membeli* ━━━━\n\n`;
    storesList += `*Contoh* : ${usedPrefix}mart buy [nomor-toko] [nama-item] [jumlah-optional]\n`;
    storesList += `*Contoh penggunaan* : ${usedPrefix}mart buy 1 Karung 2`;
    
    return m.reply(storesList);
}

async function buyFromStore(m, args, buyer, usedPrefix, command) {
    let storeIndex, itemIdentifier, quantity;

    // Logika untuk mart buy
    storeIndex = parseInt(args[1]) - 1;
    itemIdentifier = args[2];
    quantity = parseInt(args[3]) || 1;
    
    if (isNaN(storeIndex) || storeIndex < 0 || !itemIdentifier) {
        return m.reply(`Format pembelian salah!\n\n` +
            `*Contoh* : ${usedPrefix}mart buy [nomor-toko] [nama/nomor-item] [nominal]\n` +
            `*Contoh penggunaan* :\n` +
            `- ${usedPrefix}mart buy 1 Karung 2`);
    }
    
    if (isNaN(quantity) || quantity <= 0) {
        quantity = 1;
    }
    
    const activeStores = global.db.stores.active;
    if (storeIndex >= activeStores.length) {
        return m.reply(`Toko nomor "${storeIndex + 1}" tidak ditemukan!`);
    }
    
    const store = activeStores[storeIndex];
    
    if (!store.products || store.products.length === 0) {
        return m.reply(`Toko "${store.storeName}" belum memiliki produk!`);
    }
    
    let product;
    
    if (!isNaN(parseInt(itemIdentifier))) {
        const productIndex = parseInt(itemIdentifier) - 1;
        if (productIndex >= 0 && productIndex < store.products.length) {
            product = store.products[productIndex];
        }
    } else {
        const itemName = itemIdentifier.charAt(0).toUpperCase() + itemIdentifier.slice(1).toLowerCase();
        product = store.products.find(p => p.name.toLowerCase() === itemName.toLowerCase());
    }
    
    if (!product) {
        let availableProducts = `Produk tidak ditemukan di toko "${store.storeName}".\n\n`;
        availableProducts += `*Produk yang tersedia*\n`;
        store.products.forEach((p, index) => {
            availableProducts += `${index + 1}. ${p.name} - ${formatNumber(p.price)} Money (*Stock* : ${p.stock})\n`;
        });
        return m.reply(availableProducts);
    }
    
    if (product.stock < quantity) {
        return m.reply(`Stock tidak mencukupi!\n\n` +
            `- *Produk* : ${product.name}\n` +
            `- *Stock tersedia* : ${product.stock}\n` +
            `- *Yang diminta* : ${quantity}`);
    }
    
    const totalPrice = product.price * quantity;
    
    if (buyer.money < totalPrice) {
        return m.reply(`Money tidak mencukupi!\n\n` +
            `- *Produk* : ${product.name}\n` +
            `- *Dibutuhkan* : ${formatNumber(totalPrice)} Money\n` +
            `- *Money Anda* : ${formatNumber(buyer.money)} Money`);
    }
    
    try {
        buyer.money -= totalPrice;
        
        const storeOwner = global.db.users[store.ownerId];
        if (storeOwner) {
            storeOwner.money = (storeOwner.money || 0) + totalPrice;
        }
        
        product.stock -= quantity;
        product.sold = (product.sold || 0) + quantity;
        
        store.totalSales = (store.totalSales || 0) + quantity;
        store.totalRevenue = (store.totalRevenue || 0) + totalPrice;
        
        if (!store.customers) store.customers = new Set();
        if (!store.customers.has(m.sender)) {
            store.customers.add(m.sender);
            store.customerCount = store.customers.size;
        }
        
        if (!buyer.inventory) buyer.inventory = {};
        buyer.inventory[product.name] = (buyer.inventory[product.name] || 0) + quantity;
        
        if (product.stock <= 0) {
            const productIndex = store.products.indexOf(product);
            if (productIndex > -1) {
                store.products.splice(productIndex, 1);
            }
        }
        
        await m.reply(
            `*STORE* (buy)\n\n` +
            `- *Toko* : ${store.storeName}\n` +
            `- *Produk* : ${product.name}\n` +
            `- *Jumlah* : ${quantity} item\n` +
            `- *Total Bayar* : ${formatNumber(totalPrice)} Money\n` +
            `- *Sisa Uang* : ${formatNumber(buyer.money)} Money\n\n` +
            `_Item telah ditambahkan ke inventory Anda!_`
        );
        
        try {
            const storeOwnerMessage = `*STORE* (penjualan baru)\n\n` +
                `- *Produk* : ${product.name}\n` +
                `- *Jumlah* : ${quantity} item\n` +
                `- *Pendapatan* : ${formatNumber(totalPrice)} Money\n` +
                `- *Pembeli* : ${m.sender.split('@')[0]}\n\n` +
                `- *Stock* : ${product.stock}`;
            
            await m.conn.sendMessage(store.ownerId, { text: storeOwnerMessage });
        } catch (e) {
            console.log('Pemilik store tidak bisa dikirimi notifikasi');
        }
        
    } catch (error) {
        console.error(error);
        return m.reply(`Terjadi kesalahan saat proses pembelian!`);
    }
}