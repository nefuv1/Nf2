const moment = require('moment-timezone')
const { Function: Func } = new (require('@znan/wabot'))
const formatNumber = require('../../lib/formatNumber');

module.exports = {
    help: ['bank'],
    tags: 'rpg',
    group: true,
    rpg: true,
    register: true,
    run: async (m, { usedPrefix, command, args }) => {
        try {
            const user = global.db.users[m.sender]
            if (!user) return m.reply('Data pengguna tidak ada di database.')

            if (!user.inventory || !user.inventory.atm)
                return m.reply(`Kamu membutuhkan *ATM*.\n\nSilakan buat dengan perintah : ${usedPrefix}craft atm`)

            if (!user.bank) user.bank = { money: 0, exp: 0, limit: 0, totalTransactions: 0 }

            const roleData = Func.role(user.level)
            const roleName = roleData?.name || 'Unranked'

            const now = moment().tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm')

            if (!args[0]) {
                let msg = `*BANK*\n\n`
                msg += `- *Username* : ${user.username || m.pushName}\n`
                msg += `- *Role* : ${roleName}\n`
                msg += `- *Level* : ${user.level || 1}\n\n`

                msg += `*BALANCE*\n\n`
                msg += `- *ATM Money* : ${formatNumber(user.bank.money)}\n`
                msg += `- *ATM EXP* : ${formatNumber(user.bank.exp)}\n`
                msg += `- *ATM Limit* : ${formatNumber(user.bank.limit)}\n\n`

                msg += `*STATISTIK*\n\n`
                msg += `- *Total Transaksi* : ${formatNumber(user.bank.totalTransactions)}\n`
                msg += `- *Total Simpanan* : ${formatNumber(user.bank.money + user.bank.exp + user.bank.limit)}\n`
                msg += `- *Terakhir Update* : ${now}\n`
                msg += `\n*Contoh penggunaan* :\n`
                msg += `1. ${usedPrefix}bank atm money 10000\n`
                msg += `2. ${usedPrefix}bank tarik exp all`

                return m.reply(msg)
            }

            const action = args[0].toLowerCase()
            const validActions = ['atm', 'tarik']
            if (!validActions.includes(action))
                return m.reply(`Perintah tidak dikenali.\nSilakan kirim perintah : ${usedPrefix}bank atm atau ${usedPrefix}bank tarik`)

            const type = (args[1] || '').toLowerCase()
            const validTypes = ['money', 'exp', 'limit']
            if (!validTypes.includes(type))
                return m.reply(`Item tidak dikenal.\n\nPilih salah satu : Money, EXP, Limit.`)

            let amount = args[2]
            
            let source = user[type]
            let banked = user.bank[type]

            // TAMBAH LOGIC FORMAT NUMBER DI SINI
            if (amount === 'all') {
                if (action === 'atm') {
                    amount = source
                } else if (action === 'tarik') {
                    amount = banked
                }
            } else {
                // Support format number (1.000, 1,000, dll)
                amount = parseInt(amount.replace(/[.,]/g, '')) || 1
            }

            if (amount <= 0)
                return m.reply('Nominal tidak valid.')

            if (amount > 9999999999)
                return m.reply('Nominal terlalu besar. Maksimal 10.000.000.000')

            if (action === 'atm') {
                if (source < amount)
                    return m.reply(`Saldo "${type}" kamu tidak mencukupi untuk menyetor ${formatNumber(amount)}.`)

                user[type] -= amount
                user.bank[type] += amount
                user.bank.totalTransactions++

                return m.reply(
                    `*BANK* (transaksi)\n\n` +
                    `Transaksi berhasil.\n` +
                    `- *Item* : SETOR (${type.toUpperCase()})\n` +
                    `- *Jumlah* : ${formatNumber(amount)}\n` +
                    `- *Status* : Sukses. 👍\n` +
                    `- *Waktu* : ${now}\n\n` +
                    `Saldo bank kamu sekarang :\n` +
                    `- *ATM Money* : ${formatNumber(user.bank.money)}\n` +
                    `- *ATM EXP* : ${formatNumber(user.bank.exp)}\n` +
                    `- *ATM Limit* : ${formatNumber(user.bank.limit)}`
                )
            }

            if (action === 'tarik') {
                if (banked < amount)
                    return m.reply(`Saldo bank "${type}" kamu tidak mencukupi untuk menarik ${formatNumber(amount)}.`)

                user.bank[type] -= amount
                user[type] += amount
                user.bank.totalTransactions++

                return m.reply(
                    `*BANK* (transaksi)\n\n` +
                    `Transaksi berhasil.\n` +
                    `- *Item* : TARIK (${type.toUpperCase()})\n` +
                    `- *Jumlah* : ${formatNumber(amount)}\n` +
                    `- *Status* : Sukses. 👍\n` +
                    `- *Waktu* : ${now}\n\n` +
                    `Saldo bank kamu sekarang :\n` +
                    `- *ATM Money* : ${formatNumber(user.bank.money)}\n` +
                    `- *ATM EXP* : ${formatNumber(user.bank.exp)}\n` +
                    `- *ATM Limit* : ${formatNumber(user.bank.limit)}`
                )
            }

        } catch (e) {
            console.error(e)
            throw Func.jsonFormat(e)
        }
    }
}