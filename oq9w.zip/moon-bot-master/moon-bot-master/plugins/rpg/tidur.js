const formatNumber = require('../../lib/formatNumber');
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

// Data makanan
const buahList = [
    { name: 'semangka', emoji: '🍉' }, { name: 'apel', emoji: '🍎' }, { name: 'pisang', emoji: '🍌' },
    { name: 'anggur', emoji: '🍇' }, { name: 'mangga', emoji: '🥭' }, { name: 'jeruk', emoji: '🍊' },
    { name: 'stroberi', emoji: '🍓' }, { name: 'persik', emoji: '🍑' }, { name: 'pir', emoji: '🍐' },
    { name: 'lemon', emoji: '🍋' }, { name: 'kiwi', emoji: '🥝' }, { name: 'cherry', emoji: '🍒' }
];

const ikanList = [
    { name: 'ikan', emoji: '🐟' }, { name: 'udang', emoji: '🦐' }, { name: 'lobster', emoji: '🦞' },
    { name: 'cumicumi', emoji: '🦑' }, { name: 'ikanbuntal', emoji: '🐡' }, { name: 'ikantropis', emoji: '🐠' },
    { name: 'hiu', emoji: '🦈' }, { name: 'paus', emoji: '🐋' }, { name: 'lumbalumba', emoji: '🐬' }
];

const hewanList = [
    { name: 'ayam', emoji: '🐓' }, { name: 'sapi', emoji: '🐄' }, { name: 'kambing', emoji: '🐐' },
    { name: 'babi', emoji: '🐖' }, { name: 'bebek', emoji: '🦆' }, { name: 'kelinci', emoji: '🐇' }
];

module.exports = {
    help: ['masak', 'makan', 'tidur'],
    aliases: ['cook', 'eat', 'sleep'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,
    run: async (m, { usedPrefix, command, text }) => {
        const user = global.db.users[m.sender];
        if (!user) return m.reply("Data pengguna tidak ada di database.");

        // Inisialisasi data user
        if (!user.inventory) user.inventory = {};
        if (!user.masakan) user.masakan = {};
        if (typeof user.stamina !== 'number') user.stamina = 100;
        if (typeof user.health !== 'number') user.health = 100;
        if (typeof user.isSleeping !== 'boolean') user.isSleeping = false;

        const args = text ? text.split('|').map(arg => arg.trim()) : [];
        
        // ===== COMMAND MASAK =====
        if (['masak', 'cook'].includes(command)) {
            if (!args[0]) {
                const semuaBahan = [...ikanList, ...hewanList];
                let daftar = [`*COOK*\n\n*Format* : ${usedPrefix + command} [nama-ikan/hewan] | [jumlah]\n\n*Contoh* :\n- ${usedPrefix + command} udang 1\n- ${usedPrefix + command} ikan\n\n*Daftar Bahan*`];
                
                semuaBahan.forEach((item, i) => {
                    const jumlah = user.inventory[item.name] || 0;
                    daftar.push(`${i+1}. ${item.emoji} ${item.name} : ${jumlah} (dimiliki)`);
                });

                return m.reply(daftar.join('\n'));
            }

            const itemName = args[0].toLowerCase();
            const jumlah = parseInt(args[1]) || 1;

            if (jumlah < 1 || jumlah > 100) return m.reply('Jumlah harus 1-100!');

            const item = [...ikanList, ...hewanList].find(item => item.name === itemName);
            if (!item) return m.reply(`Item "${args[0]}" tidak ditemukan!`);

            if (!user.inventory[item.name] || user.inventory[item.name] < jumlah) {
                return m.reply(`Kamu hanya mempunyai ${user.inventory[item.name] || 0} ${item.name}, butuh ${jumlah}!`);
            }

            // Proses masak
            user.inventory[item.name] -= jumlah;
            if (user.inventory[item.name] <= 0) delete user.inventory[item.name];

            const namaMasakan = `masakan_${item.name}`;
            user.masakan[namaMasakan] = (user.masakan[namaMasakan] || 0) + jumlah;

            return m.reply(
                `*COOK*\n\n${item.emoji} Berhasil memasak ${jumlah} ${item.name}!\n\n` +
                `*Inventory Masakan*\n- ${item.emoji} ${namaMasakan} : ${user.masakan[namaMasakan]} porsi\n\n` +
                `Untuk makan kirim perintah : ${usedPrefix}eat ${item.name} | [jumlah]`
            );
        }

        // ===== COMMAND MAKAN =====
        if (['makan', 'eat'].includes(command)) {
            if (!args[0]) {
                // Cek makanan yang dimiliki
                const buah = buahList.filter(b => user.inventory[b.name] > 0);
                const masakan = [...ikanList, ...hewanList].filter(item => user.masakan[`masakan_${item.name}`] > 0);
                const mentah = [...ikanList, ...hewanList].filter(item => user.inventory[item.name] > 0);

                if (!buah.length && !masakan.length && !mentah.length) {
                    return m.reply(
                        `Kamu tidak mempunyai makanan!\n\n*Cara mendapatkan* :\n` +
                        `1. Buah : ${usedPrefix}menebang / ${usedPrefix}berkebun\n` +
                        `2. Ikan : ${usedPrefix}memancing\n` +
                        `3. Hewan : ${usedPrefix}berburu\n` +
                        `4. Beli : ${usedPrefix}shop`
                    );
                }

                let daftar = [`*EAT*\n\n🍽️ Makanan yang kamu miliki :\n`];
                let nomor = 1;

                if (buah.length) {
                    daftar.push(`\n*Buah*`);
                    buah.forEach(b => daftar.push(`${nomor++}. ${b.emoji} ${b.name} : ${user.inventory[b.name]} buah`));
                }

                if (masakan.length) {
                    daftar.push(`\n*Masakan*`);
                    masakan.forEach(m => daftar.push(`${nomor++}. ${m.emoji} ${m.name} : ${user.masakan[`masakan_${m.name}`]} porsi`));
                }

                if (mentah.length) {
                    daftar.push(`\n*Bahan Mentah*`);
                    mentah.forEach(m => daftar.push(`${nomor++}. ${m.emoji} ${m.name} : ${user.inventory[m.name]} (mentah)`));
                }

                daftar.push(
                    `\n*Contoh Penggunaan* :\n1. ${usedPrefix}masak [nama-ikan/hewan] | [jumlah] - (Masak ikan/buah)\n2. ${usedPrefix + command} [nama-ikan/hewan] | [jumlah] - (Makan ikan/buah)`,
                    `\n*Contoh* : makan apel | 2`
                );

                return m.reply(daftar.join('\n'));
            }

            // Makan spesifik
            const itemName = args[0].toLowerCase();
            const jumlah = parseInt(args[1]) || 1;

            if (jumlah < 1 || jumlah > 50) return m.reply('Jumlah harus 1-50!');

            // Cek buah
            const buah = buahList.find(b => b.name === itemName);
            if (buah) {
                if (!user.inventory[buah.name] || user.inventory[buah.name] < jumlah) {
                    return m.reply(`Kamu hanya mempunyai ${user.inventory[buah.name] || 0} ${buah.name}!`);
                }

                user.inventory[buah.name] -= jumlah;
                if (user.inventory[buah.name] <= 0) delete user.inventory[buah.name];

                const staminaGain = (Math.floor(Math.random() * 10) + 1) * jumlah;
                const healthGain = (Math.floor(Math.random() * 10) + 1) * jumlah;

                user.stamina = Math.min(100, user.stamina + staminaGain);
                user.health = Math.min(100, user.health + healthGain);

                return m.reply(
                    `*EAT* (buah)\n\n${buah.emoji} Memakan ${jumlah} ${buah.name}!\n\n` +
                    `Stamina : +${staminaGain}\nHealth : +${healthGain}`
                );
            }

            // Cek masakan
            const namaMasakan = `masakan_${itemName}`;
            const itemMasak = [...ikanList, ...hewanList].find(item => item.name === itemName);

            if (itemMasak && user.masakan[namaMasakan] >= jumlah) {
                user.masakan[namaMasakan] -= jumlah;
                if (user.masakan[namaMasakan] <= 0) delete user.masakan[namaMasakan];

                const staminaGain = (Math.floor(Math.random() * 16) + 5) * jumlah;
                const healthGain = (Math.floor(Math.random() * 16) + 5) * jumlah;

                user.stamina = Math.min(100, user.stamina + staminaGain);
                user.health = Math.min(100, user.health + healthGain);

                return m.reply(
                    `*EAT* (masakan)\n\n${itemMasak.emoji} Memakan ${jumlah} ${itemMasak.name}!\n\n` +
                    `Stamina : +${staminaGain}\nHealth : +${healthGain}`
                );
            }

            return m.reply(`Tidak ada makanan "${args[0]}"!\n\nSilakan kirim perintah : ${usedPrefix + command} - (Untuk lihat daftar)`);
        }

        // ===== COMMAND TIDUR =====
        if (['tidur', 'sleep'].includes(command)) {
            if (user.isSleeping) return m.reply(`Masih tidur, tunggu hingga bangun.`);
            if (user.stamina >= 100) return m.reply(`Stamina sudah penuh!`);

            user.isSleeping = true;
            await m.reply(`*SLEEP*\n\n💤 Tidur... +1 stamina setiap *10 detik...* (max 30).`);

            let gained = 0;
            for (let i = 0; i < 30; i++) {
                await sleep(10000);
                if (user.stamina < 100) {
                    user.stamina++;
                    gained++;
                } else break;
            }

            user.isSleeping = false;
            return m.reply(`*TIDUR*\n\n💤 Bangun!\n\nStamina : +${gained}\nTotal : ${user.stamina}`);
        }
    }
};