const formatNumber = require('../../lib/formatNumber');

module.exports = {
  help: ['pets'],
  aliases: ['pet', 'peliharaan'],
  tags: 'rpg',
  register: true,
  rpg: true,
  group: true,
  run: async (m, { conn, usedPrefix, command, Func }) => {
    const userId = m.sender;
    if (!global.db.users[userId]) return m.reply('Data pengguna tidak terdaftar di database.');
    
    const user = global.db.users[userId];
    if (!user.pets) user.pets = {};
    if (!user.inventory) user.inventory = {};
    
    const args = m.text.split(' ');
    const cmd = args[1]?.toLowerCase();

    // Pets data dengan shortcut
    const petsData = {
      normal: [
        { name: 'Kucing', emoji: '🐱', item: 'kucing', atk: 15, hp: 80, spd: 8 },
        { name: 'Anjing', emoji: '🐶', item: 'anjing', atk: 18, hp: 90, spd: 6 },
        { name: 'Ular', emoji: '🐍', item: 'ular', atk: 20, hp: 70, spd: 9 }
      ],
      rare: [
        { name: 'Serigala', emoji: '🐺', item: 'serigala', atk: 25, hp: 120, spd: 7 },
        { name: 'Rubah', emoji: '🦊', item: 'rubah', atk: 22, hp: 100, spd: 10 },
        { name: 'Banteng', emoji: '🐂', item: 'banteng', atk: 30, hp: 150, spd: 4 }
      ],
      epic: [
        { name: 'Harimau', emoji: '🐯', item: 'harimau', atk: 35, hp: 140, spd: 8 },
        { name: 'Singa', emoji: '🦁', item: 'singa', atk: 38, hp: 160, spd: 6 }
      ],
      legendary: [
        { name: 'Naga', emoji: '🐉', item: 'naga', atk: 50, hp: 200, spd: 5 }
      ]
    };

    // Helper functions
    const findPet = (name) => {
      for (const [rarity, pets] of Object.entries(petsData)) {
        const found = pets.find(p => p.name.toLowerCase() === name);
        if (found) return { ...found, rarity };
      }
      return null;
    };

    const getPetStatus = (pet) => {
      const hunger = pet.hunger > 70 ? '😊' : pet.hunger > 30 ? '😐' : '😵';
      const happy = pet.happiness > 70 ? '😍' : pet.happiness > 30 ? '🙂' : '😞';
      return { hunger, happy };
    };

    // Timeout helper (1 menit = 60 detik)
    const checkTimeout = (lastAction) => {
      const now = Date.now();
      const timeout = 60 * 1000; // 1 menit
      if (now - lastAction < timeout) {
        const remaining = timeout - (now - lastAction);
        const seconds = Math.floor(remaining / 1000);
        return `Tunggu ${seconds} detik lagi sebelum menggunakan perintah ini.`;
      }
      return null;
    };

    try {
      // MAIN LIST
      if (!cmd || cmd === 'list') {
        const owned = Object.values(user.pets);
        let msg = `*PETS* (sistem)\n\n`;
        msg += `*Cara Dapatkan Pet* :\nKumpulkan item hewan dari inventory!\n\n`;
        
        if (owned.length > 0) {
          msg += `Pets Yang Sudah Aktif :\n`;
          owned.forEach((pet, i) => {
            const status = getPetStatus(pet);
            msg += `${i+1}. ${pet.emoji} ${pet.name} Lv.${pet.level}\n`;
            msg += `   ⚡ ${pet.attack} || ❤️ ${pet.currentHp}/${pet.maxHp}\n`;
            msg += `   🍖 ${status.hunger} ${pet.hunger}% || 💖 ${status.happy} ${pet.happiness}%\n\n`;
          });
        }

        msg += `Pets Yang Bisa Diaktifkan :\n`;
        let available = false;
        
        Object.values(petsData).flat().forEach(pet => {
          const hasItem = user.inventory[pet.item] > 0;
          const hasPet = owned.find(p => p.name === pet.name);
          
          if (hasItem && !hasPet) {
            available = true;
            msg += `${pet.emoji} ${pet.name} - ✅ Ada di inventory\n`;
            msg += `   📝 ${usedPrefix + command} register ${pet.name.toLowerCase()}\n\n`;
          }
        });

        if (!available && owned.length === 0) {
          msg += `Kamu belum mempunyai item hewan di inventory!\n\n`;
          msg += `Cara mendapatkan hewan :\n`;
          msg += `- ${usedPrefix}berburu - Berburu\n`;
          msg += `- ${usedPrefix}shop - Membeli di shop\n`;
        }

        msg += `\n*Perintah Lain* :\n`;
        const cmds = [
          `1. ${usedPrefix + command} register [nama-pet] - Aktifkan pet`,
          `2. ${usedPrefix + command} info [nama-pet] - Detail pet`, 
          `3. ${usedPrefix + command} feed [nama-pet] - Kasih makan`,
          `4. ${usedPrefix + command} train [nama-pet] - Latih pet`,
          `5. ${usedPrefix + command} battle [nama-pet] - Battle arena`,
          `6. ${usedPrefix + command} battle [nama-pet] @tag - Battle member`
        ];
        cmds.forEach(c => msg += `${c}\n`);

        return m.reply(msg);
      }

      // REGISTER PET
      if (cmd === 'register') {
        const pName = args.slice(2).join(' ')?.toLowerCase();
        if (!pName) return m.reply(`Silakan berikan pet Anda.\n\n*Contoh* : ${usedPrefix + command} register naga`);

        const petData = findPet(pName);
        if (!petData) return m.reply(`Pet "${pName}" tidak dikenali!\n\n*Daftar Pet* :\n${Object.values(petsData).flat().map((p,i) => `${i+1}. ${p.name.toLowerCase()}`).join('\n')}`);

        if (Object.values(user.pets).find(p => p.name === petData.name)) {
          return m.reply(`Kamu sudah punya ${petData.emoji} ${petData.name}!`);
        }

        if (!user.inventory[petData.item] || user.inventory[petData.item] < 1) {
          return m.reply(`Kamu tidak mempunyai ${petData.item} di inventory! 👎\n\nButuh 1 ${petData.item} untuk mengaktifkan ${petData.emoji} ${petData.name}`);
        }

        // Kurangi inventory & buat pet
        user.inventory[petData.item]--;
        if (user.inventory[petData.item] <= 0) delete user.inventory[petData.item];

        const petId = petData.name.toLowerCase() + '_' + Date.now();
        user.pets[petId] = {
          name: petData.name,
          emoji: petData.emoji,
          level: 1,
          exp: 0,
          maxExp: 100,
          attack: petData.atk,
          maxHp: petData.hp,
          currentHp: petData.hp,
          speed: petData.spd,
          hunger: 100,
          happiness: 100,
          rarity: petData.rarity.charAt(0).toUpperCase() + petData.rarity.slice(1),
          skills: ['Basic Attack'],
          lastFeed: 0,
          lastTrain: 0,
          lastBattle: 0,
          lastBattlePvP: 0,
          wins: 0,
          losses: 0
        };

        return m.reply(`*PETS*\n\nBerhasil! Kamu mengaktifkan ${petData.emoji} *${petData.name}*\n` +
          `- ⚡ *Attack* : ${petData.atk}\n` +
          `- ❤️ *HP* : ${petData.hp}\n` +
          `- 🏃 *Speed* : ${petData.spd}\n` +
          `- 🎯 *Rarity* : ${petData.rarity.toUpperCase()}\n` +
          `- 📦 *${petData.item}* -1\n\n` +
          `Gunakan : ${usedPrefix + command} list - Untuk melihat pet kamu!`);
      }

      // PET INFO
      if (cmd === 'info') {
        const pName = args.slice(2).join(' ')?.toLowerCase();
        if (!pName) return m.reply(`Silakan berikan pet Anda.\n\n*Contoh* : ${usedPrefix + command} info naga`);

        const pet = Object.values(user.pets).find(p => p.name.toLowerCase().includes(pName));
        if (!pet) return m.reply('Pet tidak ditemukan!');

        const spd = pet.speed || 5;
        const wins = pet.wins || 0;
        const losses = pet.losses || 0;

        let msg = `*PETS* (info)\n\n`;
        msg += `${pet.emoji} *${pet.name}*\n`;
        const stats = [
          `🎯 Level : ${pet.level}`,
          `📊 EXP : ${pet.exp}/${pet.maxExp}`,
          `❤️ HP : ${pet.currentHp}/${pet.maxHp}`,
          `⚡ Attack : ${pet.attack}`,
          `🏃 Speed : ${spd}`,
          `🎖️ Rarity : ${pet.rarity}`,
          `🍖 Hunger : ${pet.hunger}%`,
          `💖 Happiness : ${pet.happiness}%`,
          `🏆 Record : ${wins} Menang / ${losses} Kalah`
        ];
        stats.forEach(s => msg += `- ${s}\n`);

        msg += `\n*Skills* :\n`;
        pet.skills.forEach((s, i) => msg += `${i+1}. ${s}\n`);

        msg += `\n*Perintah* :\n`;
        const actions = [
          `feed ${pet.name.toLowerCase()} - Kasih makan`,
          `train ${pet.name.toLowerCase()} - Latih`,
          `battle ${pet.name.toLowerCase()} - Battle arena`,
          `battle ${pet.name.toLowerCase()} @tag - Battle member`
        ];
        actions.forEach((a, i) => msg += `${i+1}. ${usedPrefix + command} ${a}\n`);

        return m.reply(msg);
      }

      // FEED PET - dengan timeout 1 menit
      if (cmd === 'feed') {
        const pName = args.slice(2).join(' ')?.toLowerCase();
        if (!pName) return m.reply(`Silakan berikan pet Anda.\n\n*Contoh* : ${usedPrefix + command} feed naga`);

        const pet = Object.values(user.pets).find(p => p.name.toLowerCase().includes(pName));
        if (!pet) return m.reply('Pet tidak ditemukan!');

        // Cek timeout 1 menit
        const timeoutMsg = checkTimeout(pet.lastFeed);
        if (timeoutMsg) return m.reply(timeoutMsg);

        const foods = ['ikan', 'ayam', 'daging', 'semangka', 'apel'];
        const food = foods.find(f => user.inventory?.[f] > 0);
        if (!food) return m.reply(`Kamu tidak mempunyai makanan! 👎\n\n*Dibutuhkan* :\n${foods.map((f,i) => `${i+1}. ${f}`).join('\n')}`);

        user.inventory[food]--;
        if (user.inventory[food] <= 0) delete user.inventory[food];

        pet.hunger = Math.min(100, pet.hunger + 30);
        pet.happiness = Math.min(100, pet.happiness + 15);
        pet.lastFeed = Date.now(); // Update timestamp

        return m.reply(`${pet.emoji} *${pet.name}* sudah diberi makan! 🍖\n\n` +
          `- *Hunger* : +30% (sekarang ${pet.hunger}%)\n` +
          `- *Happiness* : +15% (sekarang ${pet.happiness}%)\n` +
          `${food} -1\n\n` +
          `Pet siap untuk bertarung! ⚔️`);
      }

      // TRAIN PET - dengan timeout 1 menit
      if (cmd === 'train') {
        const pName = args.slice(2).join(' ')?.toLowerCase();
        if (!pName) return m.reply(`Silakan berikan pet Anda.\n\n*Contoh* : ${usedPrefix + command} train naga`);

        const pet = Object.values(user.pets).find(p => p.name.toLowerCase().includes(pName));
        if (!pet) return m.reply('Pet tidak ditemukan!');

        // Cek timeout 1 menit
        const timeoutMsg = checkTimeout(pet.lastTrain);
        if (timeoutMsg) return m.reply(timeoutMsg);

        if (pet.hunger < 30) return m.reply('Pet terlalu lapar! Beri makan terlebih dahulu.');
        if (pet.happiness < 30) return m.reply('Pet tidak bahagia! Ajak main terlebih dahulu.');

        const expGain = Math.floor(Math.random() * 30) + 20;
        pet.exp += expGain;
        pet.hunger -= 20;
        pet.happiness -= 10;
        pet.lastTrain = Date.now(); // Update timestamp

        let msg = `${pet.emoji} *${pet.name}* sedang berlatih! 🏋️\n\n`;
        msg += `- *EXP* : +${expGain} (${pet.exp}/${pet.maxExp})\n`;
        msg += `- *Hunger* : -20% (sekarang ${pet.hunger}%)\n`;
        msg += `- *Happiness* : -10% (sekarang ${pet.happiness}%)`;

        if (pet.exp >= pet.maxExp) {
          pet.level++;
          pet.exp = 0;
          pet.maxExp = pet.level * 100;
          pet.attack += 5;
          pet.maxHp += 20;
          pet.currentHp = pet.maxHp;
          pet.speed = (pet.speed || 5) + 1;
          
          const newSkills = {
            5: 'Power Strike',
            10: 'Critical Hit', 
            15: 'Ultimate Attack',
            20: 'Super Nova'
          };
          if (newSkills[pet.level]) {
            pet.skills.push(newSkills[pet.level]);
          }
          
          msg += `\n*LEVEL UP* Sekarang Level ${pet.level}!\n`;
          msg += `- ⚡ *Attack* : +5\n`;
          msg += `- ❤️ *Max HP* : +20\n`;
          msg += `- 🏃 *Speed* : +1\n`;
          if (pet.skills.length > 1) {
            msg += `- 🎯 *Skill baru* : ${pet.skills[pet.skills.length - 1]}\n`;
          }
        }

        return m.reply(msg);
      }

      // BATTLE SYSTEM - dengan timeout 1 menit
      if (cmd === 'battle') {
        const mention = m.mentionedJid[0];
        const pName = mention ? args.slice(2, -1).join(' ')?.toLowerCase() : args.slice(2).join(' ')?.toLowerCase();
        
        if (!pName) {
          return m.reply(`Berikan nama pet Anda.\n\n*Contoh* :\n1. ${usedPrefix + command} battle naga - Battle arena\n2. ${usedPrefix + command} battle naga @0 - Battle member`);
        }

        const pPet = Object.values(user.pets).find(p => p.name.toLowerCase().includes(pName));
        if (!pPet) return m.reply('Pet kamu tidak ditemukan!');

        if (pPet.currentHp <= 0) return m.reply(`${pPet.emoji} ${pPet.name} KO! Butuh healing.`);
        if (pPet.hunger < 20) return m.reply(`${pPet.emoji} ${pPet.name} terlalu lapar! Kasih makan terlebih dahulu.`);
        if (pPet.happiness < 20) return m.reply(`${pPet.emoji} ${pPet.name} tidak mood battle!`);

        // PVP BATTLE - dengan timeout 1 menit
        if (mention) {
          // Cek timeout 1 menit untuk PvP
          const timeoutMsg = checkTimeout(pPet.lastBattlePvP);
          if (timeoutMsg) return m.reply(timeoutMsg);
          
          if (mention === userId) return m.reply('Tidak bisa battle dengan diri sendiri!');
          
          const opp = global.db.users[mention];
          if (!opp || !opp.pets) return m.reply('Member tersebut belum terdaftar atau tidak punya pet!');

          const oppPets = Object.values(opp.pets).filter(p => p.currentHp > 0);
          if (oppPets.length === 0) return m.reply('Semua pet lawan sedang KO!');

          const oPet = oppPets[Math.floor(Math.random() * oppPets.length)];
          let msg = `*PETS* (battle)\n\n`;
          msg += `*${conn.getName(userId)}* vs *${conn.getName(mention)}*\n\n`;
          
          msg += `*Player Pets* :\n`;
          msg += `${pPet.emoji} ${pPet.name} Lv.${pPet.level}\n`;
          msg += `❤️ ${pPet.currentHp}/${pPet.maxHp} || ⚡ ${pPet.attack} || 🏃 ${pPet.speed || 5}\n`;
          msg += `🎯 ${pPet.rarity}\n\n`;
          
          msg += `*VS*\n\n`;
          
          msg += `*Opponent Pets* :\n`;
          msg += `${oPet.emoji} ${oPet.name} Lv.${oPet.level}\n`;
          msg += `❤️ ${oPet.currentHp}/${oPet.maxHp} || ⚡ ${oPet.attack} || 🏃 ${oPet.speed || 5}\n`;
          msg += `🎯 ${oPet.rarity}\n\n`;

          msg += `*Battle Start*\n`;

          // Battle simulation
          let round = 1;
          let pHp = pPet.currentHp;
          let oHp = oPet.currentHp;
          const maxRounds = 15;

          while (pHp > 0 && oHp > 0 && round <= maxRounds) {
            const pSpd = pPet.speed || 5;
            const oSpd = oPet.speed || 5;
            const first = pSpd >= oSpd ? 
              { pet: pPet, hp: pHp, isP: true } : { pet: oPet, hp: oHp, isP: false };
            const second = first.isP ? 
              { pet: oPet, hp: oHp, isP: false } : { pet: pPet, hp: pHp, isP: true };

            // First attack
            let dmg = Math.floor(Math.random() * first.pet.attack) + 10;
            if (Math.random() < 0.1) {
              dmg = Math.floor(dmg * 1.5);
              msg += `Round ${round}: 💥 CRITICAL! `;
            } else {
              msg += `Round ${round}: `;
            }
            msg += `${first.pet.emoji} ${first.pet.name} menyerang! -${dmg} HP\n`;
            second.hp -= dmg;
            if (second.hp <= 0) break;

            // Second attack  
            dmg = Math.floor(Math.random() * second.pet.attack) + 10;
            if (Math.random() < 0.1) {
              dmg = Math.floor(dmg * 1.5);
              msg += `Round ${round}: 💥 CRITICAL! `;
            }
            msg += `${second.pet.emoji} ${second.pet.name} menyerang! -${dmg} HP\n\n`;
            first.hp -= dmg;

            if (first.isP) pHp = first.hp;
            else oHp = first.hp;

            if (second.isP) pHp = second.hp;
            else oHp = second.hp;

            round++;
          }

          // Battle result
          if (pHp > 0 && oHp <= 0) {
            const exp = oPet.level * 25;
            const money = oPet.level * 100;
            
            pPet.exp += exp;
            user.money += money;
            pPet.currentHp = pHp;
            pPet.happiness += 25;
            pPet.hunger -= 20;
            pPet.wins = (pPet.wins || 0) + 1;

            oPet.currentHp = 0;
            oPet.losses = (oPet.losses || 0) + 1;

            msg += `*Victory* ${pPet.emoji} ${pPet.name} Menang!\n\n`;
            msg += `- *Money* : ${formatNumber(money)}\n`;
            msg += `- *EXP* : +${exp}\n`;
            msg += `- *Happiness* : +25%\n`;
            msg += `- *Hunger* : -20%\n`;
            msg += `- *Win* : ${pPet.wins || 0}\n`;

          } else if (oHp > 0 && pHp <= 0) {
            pPet.currentHp = 1;
            pPet.happiness -= 25;
            pPet.hunger -= 15;
            pPet.losses = (pPet.losses || 0) + 1;

            oPet.happiness += 15;
            oPet.wins = (oPet.wins || 0) + 1;

            msg += `*Defeat* ${pPet.emoji} ${pPet.name} Kalah!\n\n`;
            msg += `- *HP sisa* : 1\n`;
            msg += `- *Happiness* : -25%\n`;
            msg += `- *Hunger* : -15%\n`;
            msg += `- *Loss* : ${pPet.losses || 0}\n`;

          } else {
            pPet.currentHp = Math.max(1, pHp);
            oPet.currentHp = Math.max(1, oHp);
            pPet.happiness -= 10;
            oPet.happiness -= 10;

            msg += `*DRAW* Pertarungan seri!\n\n`;
            msg += `Kedua pet kelelahan dan berhenti bertarung.\n`;
          }

          if (pPet.exp >= pPet.maxExp) {
            pPet.level++;
            pPet.exp = 0;
            pPet.maxExp = pPet.level * 100;
            pPet.attack += 5;
            pPet.maxHp += 20;
            pPet.currentHp = pPet.maxHp;
            pPet.speed = (pPet.speed || 5) + 1;
            msg += `\n*LEVEL UP* ${pPet.name} sekarang Level ${pPet.level}!\n`;
          }

          // Update timestamp untuk PvP battle
          pPet.lastBattlePvP = Date.now();

          msg += `\nGunakan : ${usedPrefix + command} feed ${pPet.name.toLowerCase()} untuk recovery`;
          msg += `\n\n${conn.getName(mention)} cek pet kamu!`;

          return m.reply(msg, { mentions: [mention] });
          
        } else {
          // ARENA BATTLE - dengan timeout 1 menit
          // Cek timeout 1 menit untuk arena
          const timeoutMsg = checkTimeout(pPet.lastBattle);
          if (timeoutMsg) return m.reply(timeoutMsg);

          const enemies = [
            { name: 'Goblin', emoji: '👺', level: pPet.level, atk: pPet.attack - 3, hp: pPet.maxHp - 15, spd: 6 },
            { name: 'Slime', emoji: '🦠', level: pPet.level, atk: pPet.attack - 5, hp: pPet.maxHp - 10, spd: 3 },
            { name: 'Orc', emoji: '🧌', level: pPet.level + 1, atk: pPet.attack + 2, hp: pPet.maxHp + 10, spd: 5 },
            { name: 'Demon', emoji: '😈', level: pPet.level + 2, atk: pPet.attack + 5, hp: pPet.maxHp + 20, spd: 7 }
          ];

          const enemy = enemies[Math.floor(Math.random() * enemies.length)];
          enemy.currentHp = enemy.hp;

          let msg = `*PETS* (arena battle)\n\n`;
          msg += `*Player Pet* :\n`;
          msg += `${pPet.emoji} ${pPet.name} Lv.${pPet.level}\n`;
          msg += `❤️ ${pPet.currentHp}/${pPet.maxHp} || ⚡ ${pPet.attack} || 🏃 ${pPet.speed || 5}\n\n`;
          
          msg += `*VS*\n\n`;
          
          msg += `*Arena Enemy* :\n`;
          msg += `${enemy.emoji} ${enemy.name} Lv.${enemy.level}\n`;
          msg += `❤️ ${enemy.currentHp}/${enemy.hp} || ⚡ ${enemy.atk} || 🏃 ${enemy.spd}\n\n`;

          // Battle simulation
          let round = 1;
          let pHp = pPet.currentHp;
          let eHp = enemy.currentHp;

          while (pHp > 0 && eHp > 0 && round <= 10) {
            let dmg = Math.floor(Math.random() * pPet.attack) + 10;
            if (Math.random() < 0.15) {
              dmg = Math.floor(dmg * 1.5);
              msg += `Round ${round} : 💥 CRITICAL! `;
            } else {
              msg += `Round ${round} : `;
            }
            msg += `${pPet.emoji} ${pPet.name} menyerang! -${dmg} HP\n`;
            eHp -= dmg;
            if (eHp <= 0) break;

            dmg = Math.floor(Math.random() * enemy.atk) + 8;
            msg += `Round ${round} : ${enemy.emoji} ${enemy.name} menyerang! -${dmg} HP\n\n`;
            pHp -= dmg;

            round++;
          }

          if (pHp > 0) {
            const exp = enemy.level * 15;
            const money = enemy.level * 75;
            
            pPet.exp += exp;
            user.money += money;
            pPet.currentHp = pHp;
            pPet.happiness += 20;
            pPet.hunger -= 15;
            pPet.wins = (pPet.wins || 0) + 1;

            msg += `*Arena Victory*\n`;
            msg += `- *Money* : +${formatNumber(money)}\n`;
            msg += `- *EXP*: +${exp}\n`;
            msg += `- *Happiness* : +20%\n`;
            msg += `- *Hunger* : -15%\n`;
            msg += `- *Arena Win* : ${pPet.wins || 0}\n`;

          } else {
            pPet.currentHp = 1;
            pPet.happiness -= 20;
            pPet.hunger -= 10;
            pPet.losses = (pPet.losses || 0) + 1;

            msg += `*Arena Default*\n\n`;
            msg += `- *HP sisa* : 1\n`;
            msg += `- *Happiness* : -20%\n`;
            msg += `- *Hunger* : -10%\n`;
            msg += `- *Arena Loss* : ${pPet.losses || 0}\n`;
          }

          if (pPet.exp >= pPet.maxExp) {
            pPet.level++;
            pPet.exp = 0;
            pPet.maxExp = pPet.level * 100;
            pPet.attack += 5;
            pPet.maxHp += 20;
            pPet.currentHp = pPet.maxHp;
            pPet.speed = (pPet.speed || 5) + 1;
            msg += `\n*LEVEL UP* ${pPet.name} sekarang Level ${pPet.level}!\n`;
          }

          // Update timestamp untuk arena battle
          pPet.lastBattle = Date.now();

          return m.reply(msg);
        }
      }

      // DEFAULT HELP
      return m.reply(`*PETS* (sistem)
      
*Perintah Utama* :
1. ${usedPrefix + command} list - Lihat pets & yang bisa diaktifkan
2. ${usedPrefix + command} register [nama-pets] - Aktifkan pet dari inventory
3. ${usedPrefix + command} info [nama-pets] - Detail pet
4. ${usedPrefix + command} feed [nama-pets] - Kasih makan
5. ${usedPrefix + command} train [nama-pets] - Latih pet
6. ${usedPrefix + command} battle [nama-pets] - Battle arena
7. ${usedPrefix + command} battle [nama-pets] @tag - Battle dengan member

*Rarity System* :
📗 Normal - Kucing, Anjing, Ular
📘 Rare - Serigala, Rubah, Banteng  
📙 Epic - Harimau, Singa
📕 Legendary - Naga

*Cara Mendapatkan Pet* :
1. ${usedPrefix}berburu - Berburu
2. ${usedPrefix}shop - Membeli di shop

Ayo kumpulkan semua pets dan jadi Pet Battle Master! 🏆`);

    } catch (e) {
      console.error(e);
      throw Func.jsonFormat(e);
    }
  }
};