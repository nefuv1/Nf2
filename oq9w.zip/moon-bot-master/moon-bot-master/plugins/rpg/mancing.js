const formatNumber = require('../../lib/formatNumber');
const timeout = 60000; // 1 menit cooldown

function addToInventory(user, item, qty) {
    if (!user.inventory) user.inventory = {};
    user.inventory[item] = (user.inventory[item] || 0) + qty;
}

function msToTime(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor((ms % 3600000) / 60000);
    let s = Math.floor((ms % 60000) / 1000);
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

module.exports = {
    help: ['memancing'],
    aliases: ['fishing', 'mancing'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,
    run: async (m, { usedPrefix }) => {
        const user = global.db.users[m.sender];
        if (!user) return m.reply("Data pengguna tidak ada di database.");
        if (!user.inventory) user.inventory = {};
        if (!user.lastfishing) user.lastfishing = 0;
        if (typeof user.stamina !== 'number') user.stamina = 100;
        if (typeof user.healt !== 'number') user.healt = 100;

        // FIX: Semua durability disimpan di user.durability
        if (!user.durability) user.durability = {};
        
        // Durability untuk equipment memancing
        if (!user.durability.pancingan) user.durability.pancingan = '0/30';
        if (!user.durability.umpan) user.durability.umpan = '0/2';

        const now = Date.now();
        const remaining = timeout - (now - user.lastfishing);
        if (remaining > 0) return m.reply(`Tunggu ${msToTime(remaining)} sebelum memancing lagi.`);

        // Cek perlengkapan
        if (!user.inventory.pancingan || user.inventory.pancingan < 1)
            return m.reply(`Kamu membutuhkan *Pancingan*.\n\nSilakan beli kirim perintah : ${usedPrefix}shop buy pancingan 1`);
        if (!user.inventory.umpan || user.inventory.umpan < 1)
            return m.reply(`Kamu membutuhkan *Umpan*.\n\nSilakan beli kirim perintah : ${usedPrefix}shop buy umpan 1`);

        // FIX: Parse semua durability dari user.durability
        const [currentPancinganUses, maxPancinganUses] = user.durability.pancingan.split('/').map(Number);
        const [currentUmpanUses, maxUmpanUses] = user.durability.umpan.split('/').map(Number);

        // Kurangi stamina
        const staminaCost = Math.floor(Math.random() * 10) + 1;
        if (user.stamina < staminaCost)
            return m.reply(`Stamina kamu tidak cukup untuk memancing.\n\nSilakan kirim perintah : ${usedPrefix}sleep atau ${usedPrefix}eat`);

        user.stamina -= staminaCost;

        // FIX: Update durability di user.durability
        const newUmpanUses = currentUmpanUses + 1;
        user.durability.umpan = `${newUmpanUses}/${maxUmpanUses}`;
        
        const newPancinganUses = currentPancinganUses + 1;
        user.durability.pancingan = `${newPancinganUses}/${maxPancinganUses}`;

        // FIX: Cek jika equipment rusak (menggunakan user.durability)
        if (newUmpanUses >= maxUmpanUses) {
            user.inventory.umpan -= 1;
            if (user.inventory.umpan <= 0) delete user.inventory.umpan;
            user.durability.umpan = '0/2';
            m.reply(`Umpan kamu habis!\n\nSilakan beli lagi di : ${usedPrefix}shop`);
        }

        if (newPancinganUses >= maxPancinganUses) {
            user.inventory.pancingan -= 1;
            if (user.inventory.pancingan <= 0) delete user.inventory.pancingan;
            user.durability.pancingan = '0/30';
            m.reply(`Pancingan kamu rusak!\n\nSilakan beli baru di : ${usedPrefix}shop`);
        }

        user.lastfishing = now;
        m.reply(`*FISHING*\n\n🎣 Kamu mulai memancing di tepi danau... Tunggu hasilnya selama *1 menit...*`);

        // Delay 60 detik
        setTimeout(() => {
            const fishList = [
                { name: 'ikan', emoji: '🐟', rarity: 0.95, amount: [3, 8] },
                { name: 'ikantropis', emoji: '🐠', rarity: 0.9, amount: [2, 6] },
                { name: 'ikanbuntal', emoji: '🐡', rarity: 0.85, amount: [2, 5] },
                { name: 'udang', emoji: '🦐', rarity: 0.8, amount: [1, 4] },
                { name: 'cumicumi', emoji: '🦑', rarity: 0.75, amount: [1, 3] },
                { name: 'lobster', emoji: '🦞', rarity: 0.6, amount: [1, 2] },
                { name: 'uburubur', emoji: '🌊', rarity: 0.55, amount: [1, 2] },
                // FIX: PERSULIT BANGET ikan langka
                { name: 'lumbalumba', emoji: '🐬', rarity: 0.08, amount: [1, 1] }, // DULUNYA 0.25
                { name: 'hiu', emoji: '🦈', rarity: 0.05, amount: [1, 1] }, // DULUNYA 0.2
                { name: 'paus', emoji: '🐋', rarity: 0.03, amount: [1, 1] }, // DULUNYA 0.15
                { name: 'putriduyung', emoji: '🧜‍♀️', rarity: 0.01, amount: [1, 1] } // DULUNYA 0.1
            ];

            const success = Math.random() < 0.85; // 85% success rate

            if (!success) {
                // FIX: Tampilkan durability dari user.durability
                return m.reply(`*FISHING*\n\n🎣 Kamu tidak mendapatkan apapun kali ini...\nMungkin ikan sedang tidak lapar\n\nStamina : -${staminaCost}\nDurability Pancingan : ${newPancinganUses}/${maxPancinganUses}\nDurability Umpan : ${newUmpanUses}/${maxUmpanUses}`);
            }

            // Berhasil - dapat berbagai ikan random
            const results = [];
            const maxItems = Math.floor(Math.random() * 3) + 1; // 1-3 jenis ikan berbeda
            
            for (let i = 0; i < maxItems; i++) {
                const randomFish = fishList[Math.floor(Math.random() * fishList.length)];
                
                // Cek rarity ikan (lebih sulit untuk ikan langka)
                const rarityCheck = Math.random();
                if (rarityCheck < randomFish.rarity) {
                    const [minAmount, maxAmount] = randomFish.amount;
                    const amount = Math.floor(Math.random() * (maxAmount - minAmount + 1)) + minAmount;
                    
                    addToInventory(user, randomFish.name, amount);
                    results.push(`- ${randomFish.emoji} +${formatNumber(amount)} ${randomFish.name}`);
                }
            }

            // FIX: Tampilkan durability dari user.durability
            const msg = results.length > 0 
                ? `*FISHING*\n\n🎣 Kamu berhasil memancing dan mendapatkan :\n${results.join('\n')}\n\nStamina : -${staminaCost}\nDurability Pancingan : ${newPancinganUses}/${maxPancinganUses}\nDurability Umpan : ${newUmpanUses}/${maxUmpanUses}`
                : `*FISHING*\n\n🎣 Sayang sekali... Umpan nya habis tapi ikannya kabur!\n\nStamina : -${staminaCost}\nDurability Pancingan : ${newPancinganUses}/${maxPancinganUses}\nDurability Umpan : ${newUmpanUses}/${maxUmpanUses}`;

            return m.reply(msg);
        }, 60000);
    }
};