const formatNumber = require('../../lib/formatNumber');

// Inisialisasi shop data di global.db.groups
function initShopData(groupId) {
    if (!global.db.groups[groupId]) global.db.groups[groupId] = {};
    if (!global.db.groups[groupId].shop) {
        global.db.groups[groupId].shop = {
            lastReset: Date.now(),
            items: {}
        };
        
        // Generate items dari global.item
        for (const [itemName, itemData] of Object.entries(global.item)) {
            global.db.groups[groupId].shop.items[itemName] = {
                price: itemData.price,
                stock: itemData.maxStock,
                category: itemData.category,
                maxStock: itemData.maxStock
            };
        }
    }
    return global.db.groups[groupId].shop;
}

// Fungsi untuk menghitung harga jual (42% dari harga beli)
function getSellPrice(price) {
    return Math.floor(price * 0.42);
}

// Fungsi untuk menyimpan income shop ke owner
function saveShopIncome(amount) {
    const config = require('../../config.json');
    const ownerNumber = config.owner + '@s.whatsapp.net';
    
    if (ownerNumber && global.db.users[ownerNumber]) {
        if (!global.db.users[ownerNumber].income) {
            global.db.users[ownerNumber].income = {};
        }
        if (!global.db.users[ownerNumber].income.incomeShop) {
            global.db.users[ownerNumber].income.incomeShop = {
                money: 0,
                totalTransactions: 0
            };
        }
        
        global.db.users[ownerNumber].income.incomeShop.money += amount;
        global.db.users[ownerNumber].income.incomeShop.totalTransactions++;
    }
}

// Fungsi untuk cek dan reset stock setiap 3 hari
function checkAndResetStock(groupId) {
    const shop = initShopData(groupId);
    const now = Date.now();
    const threeDays = 3 * 24 * 60 * 60 * 1000;
    
    if (now - shop.lastReset >= threeDays) {
        // Reset semua stock ke maxStock
        for (const [itemName, item] of Object.entries(shop.items)) {
            item.stock = item.maxStock;
        }
        shop.lastReset = now;
        return true;
    }
    return false;
}

// Sistem trading antar user
if (!global.tradingSessions) global.tradingSessions = {};

// Fungsi untuk membuat menu shop
function buatMenuShop(usedPrefix, command, groupId) {
    const shop = initShopData(groupId);
    checkAndResetStock(groupId);
    
    let menu = `*SHOP*\n\n`;
    menu += `*Contoh* :\n`;
    menu += `1. ${usedPrefix + command} buy/sell [item] [jumlah]\n`;
    menu += `2. ${usedPrefix + command} buy potion 1\n\n`;
    menu += `*Menjual Ke Pengguna* :\n`;    
    menu += `1. ${usedPrefix + command} sell [item] [harga] [jumlah] @user\n`;
    menu += `2. ${usedPrefix + command} sell potion 500 1 @0\n`;    
    menu += `3. ${usedPrefix + command} acc @tagPenjual\n\n`;
    
    menu += `*STOK TERBATAS - HARGA BERVARIASI*\n\n`;
    menu += `HARGA_BELI  ||  HARGA_JUAL\n`;
    menu += `━━━━━━━━━━━━━━━━━━━━\n\n`;
    
    // Hitung waktu sampai reset berikutnya
    const nextReset = shop.lastReset + (3 * 24 * 60 * 60 * 1000);
    const timeLeft = nextReset - Date.now();
    const daysLeft = Math.floor(timeLeft / (24 * 60 * 60 * 1000));
    const hoursLeft = Math.floor((timeLeft % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
    
    // Tampilkan per kategori dari global.itemCategories
    for (const [categoryName, items] of Object.entries(global.itemCategories)) {
        const emoji = {
            bibit: '', barang: '', buah: '', ikan: '', perhiasan: '', hewan: ''
        }[categoryName] || '';
        
        menu += `${emoji} *${categoryName.toUpperCase()}*\n`;
        menu += `━━━━━━━━━━━━━━━━━━━━\n`;
        
        items.forEach(itemName => {
            const item = shop.items[itemName];
            if (item) {
                const sellPrice = getSellPrice(item.price);
                const stockStatus = item.stock <= 5 ? '🔴' : item.stock <= 15 ? '🟡' : '🟢';
                menu += `${stockStatus} ${itemName} : ${formatNumber(item.price)}  ||  ${formatNumber(sellPrice)} (Stock: ${item.stock})\n`;
            }
        });
        
        menu += `\n`;
    }
    
    menu += `*KETERANGAN*\n`;
    menu += `🔴 Stok Sedikit (≤5) | 🟡 Stok Sedang (6-15) | 🟢 Stok Banyak (≥16)\n\n`;
    menu += `*INFORMASI*\n`;
    menu += `1. Harga jual = 42% dari harga beli\n`;
    menu += `2. Stock reset otomatis setiap 3 hari\n`;
    menu += `3. Reset stock berikutnya : *${daysLeft} hari ${hoursLeft} jam* lagi\n`;
    menu += `4. Stock tersimpan di database grup\n`;
    menu += `5. Bisa jual ke user lain dengan harga custom`;
    
    return menu;
}

// ==================== MODULE EXPORTS ====================
module.exports = {
    help: ['shop'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,
    run: async (m, { 
        conn, 
        text, 
        usedPrefix, 
        command,
        args,
        users,
        Func,
        groupSet
    }) => {
        const user = users;
        if (!user) return m.reply("Data pengguna tidak ada di database.");
        
        const groupId = m.chat;
        const shop = initShopData(groupId);
        checkAndResetStock(groupId);
        
        // Inisialisasi inventory user jika belum ada
        if (!user.inventory) user.inventory = {};
        
        const aksi = args[0]?.toLowerCase();
        const itemArg = args[1];
        
        const menu = buatMenuShop(usedPrefix, command, groupId);
        
        try {
            if (!aksi) return m.reply(menu);
            
            if (aksi === 'jual' || aksi === 'sell') {
                if (!itemArg) return m.reply(`*Format* : ${usedPrefix + command} ${aksi} [item] [harga] [jumlah] @tag\n*Contoh penggunaan* : ${usedPrefix + command} ${aksi} potion 500 1 @tag`);
                
                const mentioned = m.mentionedJid && m.mentionedJid[0];
                const isSellToBot = !mentioned;
                
                let itemName, customPrice, jumlah, targetUser;
                
                if (isSellToBot) {
                    // JUAL KE BOT
                    itemName = itemArg;
                    jumlah = Math.max(1, parseInt(args[2]) || 1);
                } else {
                    // JUAL KE USER
                    targetUser = mentioned;
                    itemName = itemArg;
                    customPrice = !isNaN(parseInt(args[2])) ? parseInt(args[2]) : null;
                    jumlah = !isNaN(parseInt(args[3])) ? Math.max(1, parseInt(args[3])) : 1;
                }
                
                const itemKey = Object.keys(global.item).find(key => 
                    key.toLowerCase() === itemName.toLowerCase()
                );
                
                if (!itemKey) return m.reply(`Item "${itemName}" tidak ditemukan!`);
                
                // Validasi inventory
                if (!user.inventory[itemKey] || user.inventory[itemKey] < jumlah) {
                    return m.reply(`Kamu tidak memiliki ${jumlah} ${itemKey}! 👎\n\nKamu hanya mempunyai ${user.inventory[itemKey] || 0} ${itemKey}`);
                }
                
                if (isSellToBot) {
                    // JUAL KE BOT
                    const item = shop.items[itemKey];
                    const sellPrice = getSellPrice(item.price);
                    const totalDapat = sellPrice * jumlah;
                    
                    user.inventory[itemKey] -= jumlah;
                    user.money += totalDapat;
                    
                    if (user.inventory[itemKey] <= 0) {
                        delete user.inventory[itemKey];
                    }
                    
                    return m.reply(`*SHOP* (sell)\n\nBerhasil menjual :\n- *Status* : Sukses. 👍\n- *Item* : ${itemKey}\n- *Jumlah* : ${jumlah}\n- *Harga* : +${formatNumber(totalDapat)} Money`);
                    
                } else {
                    // JUAL KE USER LAIN
                    const targetUserData = global.db.users[targetUser];
                    if (!targetUserData) return m.reply("Data pengguna tidak ada di database.");
                    
                    const shopItem = shop.items[itemKey];
                    const finalPrice = customPrice || (shopItem ? getSellPrice(shopItem.price) : 1000);
                    const totalPrice = finalPrice * jumlah;
                    
                    // Buat session trading
                    const sessionId = `${m.sender}_${targetUser}_${Date.now()}`;
                    global.tradingSessions[sessionId] = {
                        seller: m.sender,
                        buyer: targetUser,
                        item: itemKey,
                        price: finalPrice,
                        jumlah: jumlah,
                        totalPrice: totalPrice,
                        groupId: groupId,
                        createdAt: Date.now(),
                        expiredAt: Date.now() + (5 * 60 * 1000) // 5 menit
                    };
                    
                    return m.reply(
                        `*STORE* (penawaran)\n\n` +
                        `- *Status* : Tertunda. 👎\n` +         
                        `- *Penjual* : @${m.sender.split('@')[0]}\n` +
                        `- *Pembeli* : @${targetUser.split('@')[0]}\n` +
                        `- *Item* : ${itemKey}\n` +
                        `- *Jumlah* : ${jumlah}\n` +
                        `- *Harga Satuan* : ${formatNumber(finalPrice)} Money\n` +
                        `- *Total Harga* : ${formatNumber(totalPrice)} Money\n\n` +
                        `Pembeli bisa menerima dengan : ${usedPrefix + command} acc @${m.sender.split('@')[0]}\n\n` +
                        `_Penawaran berlaku *5 menit*_`,
                        null,
                        { mentions: [targetUser, m.sender] }
                    );
                }
                
            } else if (aksi === 'acc') {
                // Accept penawaran
                const mentioned = m.mentionedJid && m.mentionedJid[0];
                if (!mentioned) return m.reply(`Tag penjual!\n\n*Format* : ${usedPrefix + command} acc @tagPenjual`);
                
                // Cari session trading
                let activeSession = null;
                let sessionId = null;
                
                for (const [id, session] of Object.entries(global.tradingSessions)) {
                    if (session.buyer === m.sender && session.seller === mentioned && session.expiredAt > Date.now()) {
                        activeSession = session;
                        sessionId = id;
                        break;
                    }
                }
                
                if (!activeSession) return m.reply("Tidak ada penawaran aktif dari pengguna tersebut!");
                
                const { seller, buyer, item, price, jumlah, totalPrice } = activeSession;
                const sellerData = global.db.users[seller];
                const buyerData = global.db.users[buyer];
                
                if (!sellerData || !buyerData) {
                    delete global.tradingSessions[sessionId];
                    return m.reply("Data tidak valid!");
                }
                
                // Validasi
                if (!sellerData.inventory[item] || sellerData.inventory[item] < jumlah) {
                    delete global.tradingSessions[sessionId];
                    return m.reply(`Penjual tidak memiliki ${jumlah} ${item} lagi!`);
                }
                
                if (!buyerData.money || buyerData.money < totalPrice) {
                    return m.reply(`Money tidak mencukupi! 👎\n\nDibutuhkan : ${formatNumber(totalPrice)} Money`);
                }
                
                // Proses transaksi
                sellerData.inventory[item] -= jumlah;
                buyerData.inventory[item] = (buyerData.inventory[item] || 0) + jumlah;
                sellerData.money += totalPrice;
                buyerData.money -= totalPrice;
                
                delete global.tradingSessions[sessionId];
                
                return m.reply(
                    `*SHOP* (transaksi)\n\n` +
                    `- *Status* : Sukses. 👍\n` +     
                    `- *Item* : ${item}\n` +
                    `- *Jumlah* : ${jumlah}\n` +
                    `- *Harga Satuan* : ${formatNumber(price)} Money\n` +
                    `- *Total Harga* : ${formatNumber(totalPrice)} Money\n` +
                    `- *Penjual* : @${seller.split('@')[0]}\n` +
                    `- *Pembeli* : @${buyer.split('@')[0]}\n\n` +
                    `_Transaksi berhasil!_`,
                    null,
                    { mentions: [seller, buyer] }
                );
                
            } else if (aksi === 'buy') {
                const jumlah = Math.max(1, parseInt(args[2]) || 1);
                const itemKey = Object.keys(global.item).find(key => 
                    key.toLowerCase() === itemArg.toLowerCase()
                );
                
                if (!itemKey) return m.reply(`Item "${itemArg}" tidak ditemukan!`);
                
                const item = shop.items[itemKey];
                if (!item) return m.reply(`Item "${itemKey}" tidak tersedia di shop!`);
                
                if (item.stock < jumlah) {
                    return m.reply(`Stock tidak cukup! Hanya tersedia ${item.stock} ${itemKey}`);
                }
                
                const totalHarga = item.price * jumlah;
                if (user.money < totalHarga) {
                    return m.reply(`Money tidak mencukupi! 👎\n\nDibutuhkan : ${formatNumber(totalHarga)} Money`);
                }
                
                // Proses pembelian
                item.stock -= jumlah;
                user.money -= totalHarga;
                user.inventory[itemKey] = (user.inventory[itemKey] || 0) + jumlah;
                
                // Simpan income ke owner
                saveShopIncome(totalHarga);
                
                return m.reply(`*SHOP* (buy)\n\nBerhasil membeli :\n- *Status* : Sukses. 👍\n- *Item* : ${itemKey}\n- *Jumlah* : ${jumlah}\n- *Harga* : -${formatNumber(totalHarga)} Money\n\nStock : ${item.stock}/${item.maxStock}`);
                
            } else {
                return m.reply(`*Gunakan* :\n1. ${usedPrefix + command} buy [item] [jumlah]\n2. ${usedPrefix + command} sell [item] [jumlah]\n3. ${usedPrefix + command} sell [item] [harga] [jumlah] @tag\n4. ${usedPrefix + command} acc @penjual`);
            }
        } catch (e) {
            return m.reply(`Error : ${e.message}`);
        }
    }
};

// Cleanup expired sessions
setInterval(() => {
    const now = Date.now();
    for (const [sessionId, session] of Object.entries(global.tradingSessions)) {
        if (session.expiredAt < now) {
            delete global.tradingSessions[sessionId];
        }
    }
}, 60000);