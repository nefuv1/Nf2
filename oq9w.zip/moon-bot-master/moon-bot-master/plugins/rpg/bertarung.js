const formatNumber = require('../../lib/formatNumber');
const delay = ms => new Promise(res => setTimeout(res, ms));
const fightTimeout = 60000; // cooldown 1 menit
const fightDelay = 60000;   // battle delay 1 menit

function getRandom(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function msToTime(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor((ms % 3600000) / 60000);
    let s = Math.floor((ms % 60000) / 1000);
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

module.exports = {
    help: ['bertarung'],
    aliases: ['fight', 'fighting'],
    tags: 'rpg',
    group: true,
    rpg: true,
    register: true,    
    run: async (m, { conn, usedPrefix }) => {
        conn.fight = conn.fight || {};

        const user = global.db.users[m.sender];
        if (!user) return m.reply("Data pengguna tidak ada di database.");
        if (!user.inventory) user.inventory = {};
        if (typeof user.stamina !== 'number') user.stamina = 100;
        if (typeof user.healt !== 'number') user.healt = 100;
        if (typeof user.money !== 'number') user.money = 0;
        if (typeof user.limit !== 'number') user.limit = 0;

        // Set durability default
        if (!user.durability) user.durability = {};
        if (!user.durability.pedang) user.durability.pedang = '0/30';
        if (!user.durability.topeng) user.durability.topeng = '0/2';
        if (!user.durability.senjata) user.durability.senjata = '0/30';
        
        // Armor durability & level
        if (!user.itemLevel) user.itemLevel = {};
        if (!user.itemLevel.armor) user.itemLevel.armor = 1;
        
        if (!user.durability.armor || !user.durability.armor.includes('/')) {
            const maxUses = user.itemLevel.armor === 10 ? 9999 : user.itemLevel.armor * 3;
            user.durability.armor = `0/${maxUses}`;
        }

        // Cek cooldown
        if (user.lastFight && Date.now() - user.lastFight < fightTimeout) {
            const sisa = fightTimeout - (Date.now() - user.lastFight);
            return m.reply(`Tunggu ${msToTime(sisa)} sebelum bertarung lagi.`);
        }

        // Cek requirement items
        const requiredItems = ['pedang', 'topeng', 'senjata', 'armor'];
        for (const it of requiredItems) {
            if (!user.inventory[it] || user.inventory[it] < 1) {
                return m.reply(`Kamu membutuhkan *${it}*.\n\nSilakan ${it === 'armor' ? 'buat' : 'beli'} kirim perintah : ${usedPrefix}${it === 'armor' ? 'craft' : 'shop buy'} ${it}`);
            }
        }

        // Parse durability
        const [currentArmorUses, maxArmorUses] = user.durability.armor.split('/').map(Number);
        const [currentPedangUses, maxPedangUses] = user.durability.pedang.split('/').map(Number);
        const [currentTopengUses, maxTopengUses] = user.durability.topeng.split('/').map(Number);
        const [currentSenjataUses, maxSenjataUses] = user.durability.senjata.split('/').map(Number);

        if (isNaN(currentArmorUses) || isNaN(maxArmorUses)) {
            const maxUses = user.itemLevel.armor === 10 ? 9999 : user.itemLevel.armor * 3;
            user.durability.armor = `0/${maxUses}`;
            return m.reply(`Data armor corrupt! Silakan coba bertarung lagi.`);
        }

        if (user.itemLevel.armor < 10 && currentArmorUses >= maxArmorUses) {
            return m.reply(`Armor kamu rusak!\n\nMax (${maxArmorUses}x)\n\nSilakan upgrade kirim perintah : ${usedPrefix}upgrade armor`);
        }

        // 🔹 REVISI: Ambil lawan dari member grup saja
        let lawan, lawanId;
        const mentioned = m.mentionedJid && m.mentionedJid[0];
        
        if (mentioned && mentioned !== m.sender) {
            lawanId = mentioned;
            lawan = global.db.users[lawanId];
            if (!lawan) return m.reply("Target tidak ditemukan di database.");
        } else {
            // Ambil dari member grup
            const groupData = global.db.groups[m.chat];
            if (!groupData || !groupData.member) {
                return m.reply("Tidak ada data member grup yang tersedia.");
            }
            
            const groupMembers = Object.keys(groupData.member).filter(memberId => 
                memberId !== m.sender && global.db.users[memberId]
            );
            
            if (groupMembers.length === 0) {
                return m.reply("Tidak ada member lain di grup ini yang bisa dijadikan lawan.");
            }
            
            lawanId = groupMembers[getRandom(0, groupMembers.length - 1)];
            lawan = global.db.users[lawanId];
        }

        if (conn.fight[m.sender]) return m.reply(`Kamu masih dalam pertarungan yang belum selesai.`);

        conn.fight[m.sender] = true;
        user.lastFight = Date.now();

        const staminaCost = getRandom(5, 15);
        if (user.stamina < staminaCost) return m.reply(`Stamina kamu tidak cukup untuk bertarung.\n\nSilakan kirim perintah : ${usedPrefix}sleep atau ${usedPrefix}eat`);
        user.stamina -= staminaCost;

        // Update durability armor
        let newArmorUses = currentArmorUses;
        if (user.itemLevel.armor < 10) {
            newArmorUses = currentArmorUses + 1;
            user.durability.armor = `${newArmorUses}/${maxArmorUses}`;
        }

        // Update durability items
        const newPedangUses = currentPedangUses + 1;
        user.durability.pedang = `${newPedangUses}/${maxPedangUses}`;
        
        const newTopengUses = currentTopengUses + 1;
        user.durability.topeng = `${newTopengUses}/${maxTopengUses}`;
        
        const newSenjataUses = currentSenjataUses + 1;
        user.durability.senjata = `${newSenjataUses}/${maxSenjataUses}`;

        // Cek jika items rusak
        if (newPedangUses >= maxPedangUses) {
            user.inventory.pedang -= 1;
            if (user.inventory.pedang <= 0) delete user.inventory.pedang;
            user.durability.pedang = '0/30';
            m.reply(`Pedang kamu rusak!\n\nSilakan beli lagi di : ${usedPrefix}shop`);
        }

        if (newTopengUses >= maxTopengUses) {
            user.inventory.topeng -= 1;
            if (user.inventory.topeng <= 0) delete user.inventory.topeng;
            user.durability.topeng = '0/2';
            m.reply(`Topeng kamu rusak!\n\nSilakan beli lagi di : ${usedPrefix}shop`);
        }

        if (newSenjataUses >= maxSenjataUses) {
            user.inventory.senjata -= 1;
            if (user.inventory.senjata <= 0) delete user.inventory.senjata;
            user.durability.senjata = '0/30';
            m.reply(`Senjata kamu rusak!\n\nSilakan beli lagi di : ${usedPrefix}shop`);
        }

        m.reply(`*FIGHT*\n\n⚔️ Pertarungan dengan @${lawanId.split('@')[0]} dimulai! Tunggu *1 menit...*`, null, { mentions: [lawanId] });
        await delay(fightDelay);

        // Hitung skor battle
        const baseUserScore = getRandom(1, 100) + (user.stamina/2);
        const baseEnemyScore = getRandom(1, 100) + (lawan.stamina/2);
        
        const armorBonus = user.itemLevel.armor * 0.1;
        const userScore = baseUserScore * (1 + armorBonus);
        const enemyScore = baseEnemyScore;

        // Kurangi stamina & health
        const userStaminaLoss = getRandom(5, 15);
        const lawanStaminaLoss = getRandom(5, 15);
        
        const baseUserHealthLoss = getRandom(5, 20);
        const baseLawanHealthLoss = getRandom(5, 20);
        
        const armorReduction = user.itemLevel.armor * 0.1;
        const userHealthLoss = Math.max(1, Math.floor(baseUserHealthLoss * (1 - armorReduction)));
        const lawanHealthLoss = baseLawanHealthLoss;
        
        user.stamina = Math.max(0, user.stamina - userStaminaLoss);
        lawan.stamina = Math.max(0, lawan.stamina - lawanStaminaLoss);
        user.healt = Math.max(0, user.healt - userHealthLoss);
        lawan.healt = Math.max(0, lawan.healt - lawanHealthLoss);

        let msg = '';
        if (userScore > enemyScore) {
            // **PERBAIKAN: Money gain dengan chance 80%**
            const rewards = [];
            
            // Money gain (80% chance)
            if (Math.random() < 0.8) {
                const moneyGain = Math.min(getRandom(100000, 1000000), lawan.money);
                if (moneyGain > 0) {
                    lawan.money -= moneyGain;
                    user.money += moneyGain;
                    rewards.push(`- +${formatNumber(moneyGain)} Money`);
                }
            }
            
            // Limit gain (selalu dapat)
            const limitGain = Math.min(getRandom(1, 5), lawan.limit);
            if (limitGain > 0) {
                lawan.limit -= limitGain;
                user.limit += limitGain;
                rewards.push(`- +${limitGain} Limit`);
            }

            const armorDurabilityInfo = user.itemLevel.armor === 10 ? 
                'Durability Armor : ∞' : 
                `Durability Armor : ${newArmorUses}/${maxArmorUses}`;

            msg = `*FIGHT*\n\n⚔️ Kamu MENANG melawan @${lawanId.split('@')[0]}! Telah meretas :\n${rewards.join('\n')}\n\n*Kamu*\nStamina : -${userStaminaLoss}\nHealth : -${userHealthLoss} (Armor mengurangi ${Math.floor(armorReduction * 100)}% damage)\n${armorDurabilityInfo}\nDurability Pedang : ${newPedangUses}/${maxPedangUses}\nDurability Topeng : ${newTopengUses}/${maxTopengUses}\nDurability Senjata : ${newSenjataUses}/${maxSenjataUses}\n\n*Target*\nStamina : -${lawanStaminaLoss}\nHealth : -${lawanHealthLoss}`;
        } else if (userScore < enemyScore) {
            const moneyLoss = Math.min(getRandom(100000, 1000000), user.money);
            const limitLoss = Math.min(getRandom(1, 5), user.limit);

            user.money -= moneyLoss;
            user.limit -= limitLoss;
            lawan.money += moneyLoss;
            lawan.limit += limitLoss;

            const armorDurabilityInfo = user.itemLevel.armor === 10 ? 
                'Durability Armor : ∞' : 
                `Durability Armor : ${newArmorUses}/${maxArmorUses}`;

            msg = `*FIGHT*\n\n⚔️ Kamu KALAH melawan @${lawanId.split('@')[0]}. Kehilangan :\n- -${formatNumber(moneyLoss)} Money\n- -${limitLoss} Limit\n\n*Kamu*\nStamina : -${userStaminaLoss}\nHealth : -${userHealthLoss} (Armor mengurangi ${Math.floor(armorReduction * 100)}% damage)\n${armorDurabilityInfo}\nDurability Pedang : ${newPedangUses}/${maxPedangUses}\nDurability Topeng : ${newTopengUses}/${maxTopengUses}\nDurability Senjata : ${newSenjataUses}/${maxSenjataUses}\n\n*Target*\nStamina : -${lawanStaminaLoss}\nHealth : -${lawanHealthLoss}`;
        } else {
            const armorDurabilityInfo = user.itemLevel.armor === 10 ? 
                'Durability Armor : ∞' : 
                `Durability Armor : ${newArmorUses}/${maxArmorUses}`;

            msg = `*FIGHT*\n\n⚔️ Pertarungan dengan @${lawanId.split('@')[0]} seri. Tidak ada yang menang.\n\n*Kamu*\nStamina : -${userStaminaLoss}\nHealth : -${userHealthLoss} (Armor mengurangi ${Math.floor(armorReduction * 100)}% damage)\n${armorDurabilityInfo}\nDurability Pedang : ${newPedangUses}/${maxPedangUses}\nDurability Topeng : ${newTopengUses}/${maxTopengUses}\nDurability Senjata : ${newSenjataUses}/${maxSenjataUses}\n\n*Target*\nStamina : -${lawanStaminaLoss}\nHealth : -${lawanHealthLoss}`;
        }

        delete conn.fight[m.sender];
        return m.reply(msg, null, { mentions: [lawanId] });
    }
};