const formatNumber = require('../../lib/formatNumber');
const timeout = 60000; // 1 menit cooldown

function msToTime(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor((ms % 3600000) / 60000);
    let s = Math.floor((ms % 60000) / 1000);
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

module.exports = {
    help: ['koboy'],
    aliases: ['cowboy', 'kb'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,
    run: async (m, { command, usedPrefix }) => {
        const user = global.db.users[m.sender];
        if (!user) return m.reply("Data pengguna tidak ada di database.");
        if (!user.inventory) user.inventory = {};
        if (!user.lastkoboy) user.lastkoboy = 0;
        if (typeof user.stamina !== 'number') user.stamina = 100;
        if (typeof user.healt !== 'number') user.healt = 100;

        // FIX: Semua durability disimpan di user.durability
        if (!user.durability) user.durability = {};
        
        // FIX: Armor durability & level system
        if (!user.itemLevel) user.itemLevel = {};
        if (!user.itemLevel.armor) user.itemLevel.armor = 1;
        
        // Set durability armor default jika belum ada
        if (!user.durability.armor || !user.durability.armor.includes('/')) {
            const maxUses = user.itemLevel.armor === 10 ? 9999 : user.itemLevel.armor * 3;
            user.durability.armor = `0/${maxUses}`;
        }

        // FIX: Durability equipment koboy disimpan di user.durability
        if (!user.durability.kuda) user.durability.kuda = '0/30';
        if (!user.durability.topi) user.durability.topi = '0/2';
        if (!user.durability.tali) user.durability.tali = '0/2';
        if (!user.durability.masker) user.durability.masker = '0/2';

        const now = Date.now();
        const remaining = timeout - (now - user.lastkoboy);
        if (remaining > 0) return m.reply(`Tunggu ${msToTime(remaining)} sebelum koboy lagi.`);

        // Cek armor requirement
        if (!user.inventory.armor || user.inventory.armor < 1) {
            return m.reply(`Kamu membutuhkan *Armor*.\n\nSilakan buat kirim perintah : ${usedPrefix}craft armor`);
        }

        // Cek perlengkapan koboy
        if (!user.inventory.kuda || user.inventory.kuda < 1) {
            return m.reply(`Kamu membutuhkan *Kuda*.\n\nSilakan beli kirim perintah : ${usedPrefix}shop buy Kuda 1`);
        }
        if (!user.inventory.topi || user.inventory.topi < 1) {
            return m.reply(`Kamu membutuhkan *Topi*.\n\nSilakan beli kirim perintah : ${usedPrefix}shop buy Topi 1`);
        }
        if (!user.inventory.tali || user.inventory.tali < 1) {
            return m.reply(`Kamu membutuhkan *Tali*.\n\nSilakan beli kirim perintah : ${usedPrefix}shop buy Tali 1`);
        }
        if (!user.inventory.masker || user.inventory.masker < 1) {
            return m.reply(`Kamu membutuhkan *Masker*.\n\nSilakan beli kirim perintah : ${usedPrefix}shop buy Masker 1`);
        }

        // FIX: Parse semua durability dari user.durability
        const [currentArmorUses, maxArmorUses] = user.durability.armor.split('/').map(Number);
        const [currentKudaUses, maxKudaUses] = user.durability.kuda.split('/').map(Number);
        const [currentTopiUses, maxTopiUses] = user.durability.topi.split('/').map(Number);
        const [currentTaliUses, maxTaliUses] = user.durability.tali.split('/').map(Number);
        const [currentMaskerUses, maxMaskerUses] = user.durability.masker.split('/').map(Number);

        // Validasi parsing number
        if (isNaN(currentArmorUses) || isNaN(maxArmorUses)) {
            const maxUses = user.itemLevel.armor === 10 ? 9999 : user.itemLevel.armor * 3;
            user.durability.armor = `0/${maxUses}`;
            return m.reply(`Data armor corrupt! Silakan coba koboy lagi.`);
        }

        // Cek durability armor (kecuali level 10 = unlimited)
        if (user.itemLevel.armor < 10 && currentArmorUses >= maxArmorUses) {
            return m.reply(`Armor kamu rusak!\n\nMax (${maxArmorUses}x)\n\nSilakan upgrade kirim perintah : ${usedPrefix}upgrade armor`);
        }

        // FIX: Update durability armor (hanya jika bukan level 10)
        let newArmorUses = currentArmorUses;
        if (user.itemLevel.armor < 10) {
            newArmorUses = currentArmorUses + 1;
            user.durability.armor = `${newArmorUses}/${maxArmorUses}`;
        }

        // FIX: Update durability equipment koboy di user.durability
        const newKudaUses = currentKudaUses + 1;
        user.durability.kuda = `${newKudaUses}/${maxKudaUses}`;
        
        const newTopiUses = currentTopiUses + 1;
        user.durability.topi = `${newTopiUses}/${maxTopiUses}`;
        
        const newTaliUses = currentTaliUses + 1;
        user.durability.tali = `${newTaliUses}/${maxTaliUses}`;
        
        const newMaskerUses = currentMaskerUses + 1;
        user.durability.masker = `${newMaskerUses}/${maxMaskerUses}`;

        // FIX: Cek jika equipment rusak (menggunakan user.durability)
        if (newKudaUses >= maxKudaUses) {
            user.inventory.kuda -= 1;
            if (user.inventory.kuda <= 0) delete user.inventory.kuda;
            user.durability.kuda = '0/30';
            m.reply(`Kuda kamu lelah, perlu istirahat!\n\nSilakan beli baru di : ${usedPrefix}shop`);
        }
        if (newTopiUses >= maxTopiUses) {
            user.inventory.topi -= 1;
            if (user.inventory.topi <= 0) delete user.inventory.topi;
            user.durability.topi = '0/2';
            m.reply(`Topi kamu rusak!\n\nSilakan beli baru di : ${usedPrefix}shop`);
        }
        if (newTaliUses >= maxTaliUses) {
            user.inventory.tali -= 1;
            if (user.inventory.tali <= 0) delete user.inventory.tali;
            user.durability.tali = '0/2';
            m.reply(`Tali kamu habis!\n\nSilakan beli lagi di : ${usedPrefix}shop`);
        }
        if (newMaskerUses >= maxMaskerUses) {
            user.inventory.masker -= 1;
            if (user.inventory.masker <= 0) delete user.inventory.masker;
            user.durability.masker = '0/2';
            m.reply(`Masker kamu sobek!\n\nSilakan beli baru di : ${usedPrefix}shop`);
        }

        // Kurangi stamina
        const staminaCost = Math.floor(Math.random() * 10) + 5;
        if (user.stamina < staminaCost) {
            return m.reply(`Stamina kamu tidak cukup untuk koboy.\n\nSilakan kirim perintah : ${usedPrefix}sleep atau ${usedPrefix}eat`);
        }

        user.stamina -= staminaCost;
        user.lastkoboy = now;

        // Kirim pesan memulai
        m.reply(`*KOBOY*\n\n🤠 Kamu mulai berpetualang sebagai koboy... Tunggu hasilnya selama *1 menit...*\n\nStamina : -${staminaCost}`);

        // Delay 1 menit (60000 ms)
        setTimeout(() => {
            const successRate = 0.7;
            const isSuccess = Math.random() < successRate;

            if (!isSuccess) {
                const failScenarios = [
                    {
                        title: "Kuda Kabur!",
                        message: "Kudamu kabur saat mengejar sapi liar! Kamu harus berjalan pulang dengan lelah.",
                        healthLoss: Math.floor(Math.random() * 10) + 5,
                        staminaLoss: Math.floor(Math.random() * 10) + 10
                    },
                    {
                        title: "Diserang Bandit!",
                        message: "Sekelompok bandit menyerangmu di padang rumput! Mereka mengambil sebagian hasil buruanmu.",
                        healthLoss: Math.floor(Math.random() * 10) + 5,
                        staminaLoss: Math.floor(Math.random() * 10) + 3
                    },
                    {
                        title: "Terjebak Badai Pasir!",
                        message: "Badai pasir tiba-tiba datang! Kamu tersesat dan kehilangan arah.",
                        healthLoss: Math.floor(Math.random() * 8) + 3,
                        staminaLoss: Math.floor(Math.random() * 10) + 10
                    },
                    {
                        title: "Jebakan Kaktus!",
                        message: "Kudamu menginjak kaktus dan terluka! Harus beristirahat dulu.",
                        healthLoss: Math.floor(Math.random() * 10) + 7,
                        staminaLoss: Math.floor(Math.random() * 10) + 7
                    },
                    {
                        title: "Sapi Liar Menyerang!",
                        message: "Kawanan sapi liar menyerangmu! Kamu harus kabur dengan cepat.",
                        healthLoss: Math.floor(Math.random() * 10) + 5,
                        staminaLoss: Math.floor(Math.random() * 10) + 3
                    }
                ];

                const randomFail = failScenarios[Math.floor(Math.random() * failScenarios.length)];
                
                // Armor damage reduction
                const baseHealthLoss = randomFail.healthLoss;
                const armorReduction = user.itemLevel.armor * 0.1; // 10% reduction per level
                const actualHealthLoss = Math.max(1, Math.floor(baseHealthLoss * (1 - armorReduction)));
                
                user.healt -= actualHealthLoss;
                user.stamina -= randomFail.staminaLoss;
                
                if (user.healt < 0) user.healt = 0;
                if (user.stamina < 0) user.stamina = 0;

                // FIX: Tampilkan semua durability dari user.durability
                const armorDurabilityInfo = user.itemLevel.armor === 10 ? 
                    'Durability Armor : ∞' : 
                    `Durability Armor : ${newArmorUses}/${maxArmorUses}`;

                return m.reply(`*KOBOY*\n\n${randomFail.title}\n\n🤠 ${randomFail.message}\n\nHealth : -${actualHealthLoss} (Armor mengurangi ${Math.floor(armorReduction * 100)}% damage)\nStamina : -${randomFail.staminaLoss}\n${armorDurabilityInfo}\nDurability Kuda : ${newKudaUses}/${maxKudaUses}\nDurability Topi : ${newTopiUses}/${maxTopiUses}\nDurability Tali : ${newTaliUses}/${maxTaliUses}\nDurability Masker : ${newMaskerUses}/${maxMaskerUses}`);
            }

            // Event berhasil - REWARD RANDOM YANG LEBIH VARIATIF
            const results = [];
            
            // Random jumlah jenis reward (1-4 jenis berbeda)
            const rewardTypes = Math.floor(Math.random() * 4) + 1;
            
            // Daftar kemungkinan reward
            const possibleRewards = [
                { type: 'exp', min: 100, max: 50000, chance: 0.8 },
                { type: 'money', min: 100, max: 50000, chance: 0.8 },
                { type: 'limit', min: 0, max: 1, chance: 0.3 }, // Sulit dapat limit
                { type: 'sapi', min: 1, max: 5, chance: 0.4 }, // Dapat sapi
                { type: 'kuda', min: 0, max: 1, chance: 0.2 } // Sangat sulit dapat kuda
            ];

            // Pilih reward secara random
            for (let i = 0; i < rewardTypes; i++) {
                const reward = possibleRewards[Math.floor(Math.random() * possibleRewards.length)];
                
                // Cek chance
                if (Math.random() < reward.chance) {
                    let amount = 0;
                    
                    if (reward.type === 'limit' || reward.type === 'kuda') {
                        // Untuk limit dan kuda, hanya 0 atau 1
                        amount = Math.random() < 0.5 ? 0 : 1;
                    } else {
                        // Untuk lainnya, random amount
                        amount = Math.floor(Math.random() * (reward.max - reward.min + 1)) + reward.min;
                    }
                    
                    if (amount > 0) {
                        // Tambahkan ke user
                        if (reward.type === 'exp') {
                            user.exp += amount;
                            results.push(`- +${formatNumber(amount)} EXP`);
                        } else if (reward.type === 'money') {
                            user.money += amount;
                            results.push(`- +${formatNumber(amount)} Money`);
                        } else if (reward.type === 'limit') {
                            user.limit += amount;
                            results.push(`- +${amount} Limit`);
                        } else if (reward.type === 'sapi') {
                            user.inventory.sapi = (user.inventory.sapi || 0) + amount;
                            results.push(`- +${amount} Sapi`);
                        } else if (reward.type === 'kuda') {
                            user.inventory.kuda = (user.inventory.kuda || 0) + amount;
                            results.push(`- +${amount} Kuda`);
                        }
                    }
                }
            }

            // Jika tidak dapat apa-apa, berikan minimal reward
            if (results.length === 0) {
                const minExp = Math.floor(Math.random() * 1000) + 100;
                user.exp += minExp;
                results.push(`- +${formatNumber(minExp)} EXP`);
            }

            const successScenarios = [
                `Berhasil menangkap kawanan sapi liar! 🐄`,
                `Memenangkan kontes rodeo! 🏆`,
                `Menemukan harta karun koboy tersembunyi! 💰`,
                `Berhasil menjinakkan kuda liar! 🐎`,
                `Menyelamatkan kota dari bandit! 👮‍♂️`
            ];

            const randomSuccess = successScenarios[Math.floor(Math.random() * successScenarios.length)];

            // FIX: Tampilkan semua durability dari user.durability
            const armorDurabilityInfo = user.itemLevel.armor === 10 ? 
                'Durability Armor : ∞' : 
                `Durability Armor : ${newArmorUses}/${maxArmorUses}`;

            const msg = `*KOBOY*\n\n${randomSuccess}\n\n🤠 Dari Koboy kamu mendapatkan :\n${results.join('\n')}\n\nStamina : -${staminaCost}\n${armorDurabilityInfo}\nDurability Kuda : ${newKudaUses}/${maxKudaUses}\nDurability Topi : ${newTopiUses}/${maxTopiUses}\nDurability Tali : ${newTaliUses}/${maxTaliUses}\nDurability Masker : ${newMaskerUses}/${maxMaskerUses}`;

            return m.reply(msg);

        }, 60000);
    }
};