const formatNumber = require('../../lib/formatNumber');
const timeout = 60000;

function addToInventory(user, item, qty) {
    if (!user.inventory) user.inventory = {};
    user.inventory[item] = (user.inventory[item] || 0) + qty;
}

function msToTime(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor((ms % 3600000) / 60000);
    let s = Math.floor((ms % 60000) / 1000);
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

module.exports = {
    help: ['menebang'],
    aliases: ['nebang', 'tebang', 'woodcut'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,    
    run: async (m, { command, Func, text, usedPrefix, users }) => {
        const user = users;
        if (!user) return m.reply("Data pengguna tidak ada di database.");
        if (!user.inventory) user.inventory = {};
        if (!user.lastnebang) user.lastnebang = 0;
        if (typeof user.stamina !== 'number') user.stamina = 100; // default stamina

        const now = Date.now();
        const remaining = timeout - (now - user.lastnebang);

        if (remaining > 0) return m.reply(`Tunggu ${msToTime(remaining)} sebelum menebang lagi.`);
        if (!user.inventory.kapak || user.inventory.kapak < 1)
            return m.reply(`Kamu membutuhkan *Kapak*.\n\nSilakan kirim perintah : ${usedPrefix}shop buy kapak 1`);
            
        if (!user.inventory.gergaji || user.inventory.gergaji < 1)
            return m.reply(`Kamu membutuhkan *Gergaji*.\n\nSilakan kirim perintah : ${usedPrefix}shop buy gergaji 1`);            

        // Acak pengurangan stamina (1–10)
        const staminaCost = Math.floor(Math.random() * 10) + 1;

        if (user.stamina < staminaCost)
            return m.reply(`Stamina kamu tidak cukup untuk menebang.\n\nSilakan kirim perintah : ${usedPrefix}sleep atau ${usedPrefix}eat`);

        user.stamina -= staminaCost;

        // Kurangi kapak
        user.inventory.kapak -= 1;
        if (user.inventory.kapak <= 0) delete user.inventory.kapak;
        
        // Kurangi gergaji
        user.inventory.gergaji -= 1;
        if (user.inventory.gergaji <= 0) delete user.inventory.gergaji;        

        // Daftar hasil tebangan & rarity
        const items = [
            { name: 'kayu', rarity: 0.9 },
            { name: 'burung', rarity: 0.75 },
            { name: 'mangga', rarity: 0.3 },
            { name: 'jeruk', rarity: 0.25 },
            { name: 'lemon', rarity: 0.2 },
            { name: 'ular', rarity: 0.6 },   
            { name: 'pisang', rarity: 0.3 },       
            { name: 'pir', rarity: 0.1 },
            { name: 'bibitpisang', rarity: 0.9 },
            { name: 'lemon', rarity: 0.4 },
            { name: 'bibitmangga', rarity: 0.29 },
            { name: 'bibitkiwi', rarity: 0.3 },
            { name: 'cherry', rarity: 0.1 },
        ];

        const finds = Math.floor(Math.random() * 3) + 2; // 2–4 hasil tebang
        let results = [];

        for (let i = 0; i < finds; i++) {
            const luck = Math.random();
            const available = items.filter(it => luck <= it.rarity);
            if (available.length === 0) continue;

            const item = available[Math.floor(Math.random() * available.length)];
            const value = Math.floor(Math.random() * 11); // 0–10 acak

            if (value > 0) {
                addToInventory(user, item.name, value);
                results.push(`- +${formatNumber(value)} ${item.name}`);
            }
        }

        user.lastnebang = now;

        const msg = results.length > 0
            ? `*WOODCUTTER*\n\n🪓 Dari menebang kamu mendapatkan :\n${results.join('\n')}\n\nStamina : -${staminaCost}`
            : `*WOODCUTTER*\n\n🪓 Kamu tidak mendapatkan apapun kali ini!\n\nStamina : -${staminaCost}`;

        return m.reply(msg);
    }
};