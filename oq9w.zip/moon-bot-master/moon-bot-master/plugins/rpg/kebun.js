module.exports = {
    help: ['kebun'],
    aliases: ['garden', 'buah'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,
    run: async (m, { users }) => {
        const user = users;
        if (!user || !user.inventory) return m.reply("Data pengguna tidak ada di database.");

        // Daftar buah
        const buahList = [
            { name: 'semangka', emoji: '🍉' },
            { name: 'apel', emoji: '🍎' },
            { name: 'pisang', emoji: '🍌' },
            { name: 'anggur', emoji: '🍇' },
            { name: 'mangga', emoji: '🥭' },
            { name: 'jeruk', emoji: '🍊' },
            { name: 'stroberi', emoji: '🍓' },
            { name: 'persik', emoji: '🍑' },
            { name: 'pir', emoji: '🍐' },
            { name: 'lemon', emoji: '🍋' },
            { name: 'kiwi', emoji: '🥝' },
            { name: 'cherry', emoji: '🍒' }
        ];

        // Daftar bibit
        const bibitList = [
            { name: 'bibitsemangka', emoji: '🌱🍉' },
            { name: 'bibitapel', emoji: '🌱🍎' },
            { name: 'bibitpisang', emoji: '🌱🍌' },
            { name: 'bibitanggur', emoji: '🌱🍇' },
            { name: 'bibitmangga', emoji: '🌱🥭' },
            { name: 'bibitjeruk', emoji: '🌱🍊' },
            { name: 'bibitstroberi', emoji: '🌱🍓' },
            { name: 'bibitpersik', emoji: '🌱🍑' },
            { name: 'bibitpir', emoji: '🌱🍐' },
            { name: 'bibitlemon', emoji: '🌱🍋' },
            { name: 'bibitkiwi', emoji: '🌱🥝' },
            { name: 'bibitcherry', emoji: '🌱🍒' }
        ];

        let ownedBuah = [];
        let ownedBibit = [];
        let countBuah = 1;
        let countBibit = 1;

        // Cek buah yang dimiliki
        for (let b of buahList) {
            const qty = user.inventory[b.name] || 0;
            if (qty > 0) {
                ownedBuah.push(`${countBuah++}. ${b.emoji} *${b.name}* : ${qty}`);
            }
        }

        // Cek bibit yang dimiliki
        for (let s of bibitList) {
            const qty = user.inventory[s.name] || 0;
            if (qty > 0) {
                ownedBibit.push(`${countBibit++}. ${s.emoji} *${s.name}* : ${qty}`);
            }
        }

        // Gabungkan pesan
        const buahText = ownedBuah.length > 0 ? ownedBuah.join('\n') : '_Kamu belum punya buah 🌳_';
        const bibitText = ownedBibit.length > 0 ? ownedBibit.join('\n') : '_Kamu belum punya bibit 🌱_';

        const msg = `*GARDEN* (buah & bibit)\n\n` +
                    `*Buah*\n${buahText}\n\n` +
                    `*Bibit*\n${bibitText}`;

        return m.reply(msg);
    }
};