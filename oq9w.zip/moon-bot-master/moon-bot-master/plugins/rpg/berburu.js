const formatNumber = require('../../lib/formatNumber');
const timeout = 60000;

function addToInventory(user, item, qty) {
    if (!user.inventory) user.inventory = {};
    user.inventory[item] = (user.inventory[item] || 0) + qty;
}

function msToTime(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor((ms % 3600000) / 60000);
    let s = Math.floor((ms % 60000) / 1000);
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

module.exports = {
    help: ['berburu'],
    aliases: ['hunting', 'hunt', 'hunter'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,
    run: async (m, { command, text, usedPrefix }) => {
        const user = global.db.users[m.sender];
        if (!user) return m.reply("Data pengguna tidak ada di database.");
        if (!user.inventory) user.inventory = {};
        if (!user.lasterburu) user.lasterburu = 0;
        if (typeof user.stamina !== 'number') user.stamina = 100;
        if (typeof user.healt !== 'number') user.healt = 100;

        // Set durability default SEMUA di user.durability
        if (!user.durability) user.durability = {};
        
        // Busur durability (hanya set jika belum ada)
        if (!user.durability.busur) user.durability.busur = '0/30';
        
        // Panah durability (hanya set jika belum ada)  
        if (!user.durability.panah) user.durability.panah = '0/5';
        
        // Armor durability & level
        if (!user.itemLevel) user.itemLevel = {};
        if (!user.itemLevel.armor) user.itemLevel.armor = 1;
        
        // Set durability armor default jika belum ada
        if (!user.durability.armor || !user.durability.armor.includes('/')) {
            const maxUses = user.itemLevel.armor === 10 ? 9999 : user.itemLevel.armor * 3;
            user.durability.armor = `0/${maxUses}`;
        }

        const now = Date.now();
        const remaining = timeout - (now - user.lasterburu);
        if (remaining > 0) return m.reply(`Tunggu ${msToTime(remaining)} sebelum berburu lagi.`);

        // Cek requirement items
        if (!user.inventory.busur || user.inventory.busur < 1) {
            return m.reply(`Kamu membutuhkan *Busur*.\n\nSilakan beli kirim perintah : ${usedPrefix}shop buy busur`);
        }

        if (!user.inventory.panah || user.inventory.panah < 1) {
            return m.reply(`Kamu membutuhkan *Panah*.\n\nSilakan beli kirim perintah : ${usedPrefix}shop buy panah`);
        }

        if (!user.inventory.armor || user.inventory.armor < 1) {
            return m.reply(`Kamu membutuhkan *Armor*.\n\nSilakan buat kirim perintah : ${usedPrefix}craft armor`);
        }

        // Parse semua durability dari user.durability
        const [currentArmorUses, maxArmorUses] = user.durability.armor.split('/').map(Number);
        const [currentBusurUses, maxBusurUses] = user.durability.busur.split('/').map(Number);
        const [currentPanahUses, maxPanahUses] = user.durability.panah.split('/').map(Number);

        // Validasi parsing number
        if (isNaN(currentArmorUses) || isNaN(maxArmorUses)) {
            const maxUses = user.itemLevel.armor === 10 ? 9999 : user.itemLevel.armor * 3;
            user.durability.armor = `0/${maxUses}`;
            return m.reply(`Data armor corrupt! Silakan coba berburu lagi.`);
        }

        if (user.itemLevel.armor < 10 && currentArmorUses >= maxArmorUses) {
            return m.reply(`Armor kamu rusak!\n\nMax (${maxArmorUses}x)\n\nSilakan upgrade kirim perintah : ${usedPrefix}upgrade armor`);
        }

        const staminaCost = Math.floor(Math.random() * 10) + 1;
        if (user.stamina < staminaCost) {
            return m.reply(`Stamina kamu tidak cukup untuk berburu.\n\nSilakan kirim perintah : ${usedPrefix}sleep atau ${usedPrefix}eat`);
        }

        user.stamina -= staminaCost;

        let newArmorUses = currentArmorUses;
        if (user.itemLevel.armor < 10) {
            newArmorUses = currentArmorUses + 1;
            user.durability.armor = `${newArmorUses}/${maxArmorUses}`;
        }

        // Kurangi durability panah
        const newPanahUses = currentPanahUses + 1;
        user.durability.panah = `${newPanahUses}/${maxPanahUses}`;
        
        if (newPanahUses >= maxPanahUses) {
            user.inventory.panah -= 1;
            if (user.inventory.panah <= 0) delete user.inventory.panah;
            user.durability.panah = '0/5';
            m.reply(`Panah kamu habis!\n\nSilakan beli lagi di : ${usedPrefix}shop`);
        }

        // Kurangi durability busur
        const newBusurUses = currentBusurUses + 1;
        user.durability.busur = `${newBusurUses}/${maxBusurUses}`;
        
        if (newBusurUses >= maxBusurUses) {
            user.inventory.busur -= 1;
            if (user.inventory.busur <= 0) delete user.inventory.busur;
            user.durability.busur = '0/30';
            m.reply(`Busur kamu rusak!\n\nSilakan beli baru di : ${usedPrefix}shop`);
        }

        user.lasterburu = now;
        
        // Kirim pesan menunggu
        m.reply(`*HUNTER*\n\n🏹 Kamu mulai berburu di hutan... Tunggu hasilnya selama *1 menit...*`);

        // Delay 60 detik
        setTimeout(() => {
            const animals = [
                { name: 'burung', emoji: '🐦', rarity: 0.9 },
                { name: 'ular', emoji: '🐍', rarity: 0.65 },
                { name: 'kuda', emoji: '🐴', rarity: 0.6 },
                { name: 'banteng', emoji: '🐃', rarity: 0.35 },
                { name: 'gajah', emoji: '🐘', rarity: 0.15 },
                { name: 'harimau', emoji: '🐅', rarity: 0.2 },
                { name: 'kambing', emoji: '🐐', rarity: 0.9 },
                { name: 'panda', emoji: '🐼', rarity: 0.4 },
                { name: 'buaya', emoji: '🐊', rarity: 0.45 },
                { name: 'kerbau', emoji: '🐃', rarity: 0.55 },
                { name: 'sapi', emoji: '🐄', rarity: 0.85 },
                { name: 'monyet', emoji: '🐒', rarity: 0.7 },
                { name: 'babi', emoji: '🐖', rarity: 0.85 },
                { name: 'ayam', emoji: '🐓', rarity: 0.95 },
                { name: 'bebek', emoji: '🦆', rarity: 0.65 },
                { name: 'kelinci', emoji: '🐇', rarity: 0.75 }, 
                { name: 'kucing', emoji: '🐈', rarity: 0.65 },
                { name: 'singa', emoji: '🦁', rarity: 0.26 },  
                { name: 'serigala', emoji: '🐺', rarity: 0.35 },
                { name: 'rubah', emoji: '🦊', rarity: 0.88 }
            ];

            const success = Math.random() < 0.8;

            // Gagal - kehilangan health
            if (!success) {
                const baseDamage = Math.floor(Math.random() * 11) + 5;
                const armorReduction = user.itemLevel.armor * 0.1;
                const actualDamage = Math.max(1, Math.floor(baseDamage * (1 - armorReduction)));
                
                user.healt -= actualDamage;
                if (user.healt < 0) user.healt = 0;
                
                const randomAnimal = animals[Math.floor(Math.random() * animals.length)];
                
                // Tampilkan info durability
                const armorDurabilityInfo = user.itemLevel.armor === 10 ? 
                    'Durability Armor : ∞' : 
                    `Durability Armor : ${newArmorUses}/${maxArmorUses}`;
                
                return m.reply(`*HUNTER*\n\n🏹 Kamu *diserang* oleh ${randomAnimal.emoji} ${randomAnimal.name} saat berburu!\n\nHealth -${actualDamage} (Armor mengurangi ${Math.floor(armorReduction * 100)}% damage)\n\nStamina : -${staminaCost}\n${armorDurabilityInfo}\nDurability Busur : ${newBusurUses}/${maxBusurUses}\nDurability Panah : ${newPanahUses}/${maxPanahUses}`);
            }

            // Berhasil - dapat berbagai hewan random
            const results = [];
            const maxItems = Math.floor(Math.random() * 4) + 1;
            
            for (let i = 0; i < maxItems; i++) {
                const randomAnimal = animals[Math.floor(Math.random() * animals.length)];
                const amount = Math.floor(Math.random() * 6) + 1;
                
                const rarityCheck = Math.random();
                if (rarityCheck < randomAnimal.rarity) {
                    addToInventory(user, randomAnimal.name, amount);
                    results.push(`- ${randomAnimal.emoji} +${formatNumber(amount)} ${randomAnimal.name}`);
                }
            }

            // Tampilkan info durability
            const armorDurabilityInfo = user.itemLevel.armor === 10 ? 
                'Durability Armor : ∞' : 
                `Durability Armor : ${newArmorUses}/${maxArmorUses}`;

            const msg = results.length > 0 
                ? `*HUNTER*\n\n🏹 Dari berburu kamu mendapatkan :\n${results.join('\n')}\n\nStamina : -${staminaCost}\n${armorDurabilityInfo}\nDurability Busur : ${newBusurUses}/${maxBusurUses}\nDurability Panah : ${newPanahUses}/${maxPanahUses}`
                : `*HUNTER*\n\n🏹 Kamu tidak mendapatkan apa-apa dari buruan kali ini.\n\nStamina : -${staminaCost}\n${armorDurabilityInfo}\nDurability Busur : ${newBusurUses}/${maxBusurUses}\nDurability Panah : ${newPanahUses}/${maxPanahUses}`;

            return m.reply(msg);
        }, 60000);
    }
};