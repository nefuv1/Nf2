const formatNumber = require('../../lib/formatNumber');
const timeout = 60000;

function addToInventory(user, item, qty) {
    if (!user.inventory) user.inventory = {};
    user.inventory[item] = (user.inventory[item] || 0) + qty;
}

function msToTime(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor((ms % 3600000) / 60000);
    let s = Math.floor((ms % 60000) / 1000);
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

module.exports = {
    help: ['menambang'],
    aliases: ['nambang', 'tambang', 'mining'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,    
    run: async (m, { command, Func, text, usedPrefix, users }) => {
        const user = users;
        if (!user) return m.reply("Data pengguna tidak ada di database.");
        if (!user.inventory) user.inventory = {};
        if (!user.lastnambang) user.lastnambang = 0;
        if (typeof user.stamina !== 'number') user.stamina = 100; // default stamina

        const now = Date.now();
        const remaining = timeout - (now - user.lastnambang);

        if (remaining > 0) return m.reply(`Tunggu ${msToTime(remaining)} sebelum menambang lagi.`);
        if (!user.inventory.pickaxe || user.inventory.pickaxe < 1)
            return m.reply(`Kamu membutuhkan *Pickaxe*.\n\nSilakan beli kirim perintah : ${usedPrefix}shop buy pickaxe 1`);

        // Acak pengurangan stamina (1–10)
        const staminaCost = Math.floor(Math.random() * 10) + 1;

        if (user.stamina < staminaCost)
            return m.reply(`Stamina kamu tidak cukup untuk menambang.\n\nSilakan kirim perintah : ${usedPrefix}sleep atau ${usedPrefix}eat`);

        user.stamina -= staminaCost;

        // Kurangi pickaxe
        user.inventory.pickaxe -= 1;
        if (user.inventory.pickaxe <= 0) delete user.inventory.pickaxe;

        // Daftar barang tambang & rarity
        const items = [
            { name: 'garam', rarity: 0.95 },
            { name: 'gas', rarity: 0.85 },
            { name: 'tembaga', rarity: 0.7 },
            { name: 'besi', rarity: 0.6 },
            { name: 'aluminium', rarity: 0.5 },
            { name: 'zamrud', rarity: 0.25 },
            { name: 'rubi', rarity: 0.2 },
            { name: 'safir', rarity: 0.15 }
        ];

        const finds = Math.floor(Math.random() * 3) + 2; // 2–4 hasil tambang
        let results = [];

        for (let i = 0; i < finds; i++) {
            const luck = Math.random();
            const available = items.filter(it => luck <= it.rarity);
            if (available.length === 0) continue;

            const item = available[Math.floor(Math.random() * available.length)];
            const value = Math.floor(Math.random() * 11); // 0–10 acak

            if (value > 0) {
                addToInventory(user, item.name, value);
                results.push(`- +${formatNumber(value)} ${item.name}`);
            }
        }

        user.lastnambang = now;

        const msg = results.length > 0
            ? `*MINER*\n\n⛏️ Dari menambang kamu mendapatkan :\n${results.join('\n')}\n\nStamina : -${staminaCost}`
            : `*MINER*\n\n⛏️ Kamu tidak menemukan apapun kali ini!\n\nStamina : -${staminaCost}`;

        return m.reply(msg);
    }
};