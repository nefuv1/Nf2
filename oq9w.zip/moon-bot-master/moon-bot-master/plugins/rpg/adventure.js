const formatNumber = require('../../lib/formatNumber');

function msToTime(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor((ms % 3600000) / 60000);
    let s = Math.floor((ms % 60000) / 1000);
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

module.exports = {
    help: ['adventure'],
    aliases: ['adv', 'petualang'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,
    run: async (m, { conn, text, usedPrefix, command, users, Func }) => {
        try {
            m.react(global.react);
            
            const user = global.db.users[m.sender];
            if (!user) return m.reply('Data pengguna tidak ada di database.');
            if (!user.inventory) user.inventory = {};
            if (!user.lastAdventure) user.lastAdventure = 0;
            if (typeof user.stamina !== 'number') user.stamina = 100;
            if (typeof user.healt !== 'number') user.healt = 100;

            // **PERBAIKAN: Cooldown diubah menjadi 1 jam (3600000 ms)**
            const timeout = 3600000; // 1 jam
            const now = Date.now();
            const remaining = timeout - (now - user.lastAdventure);
            
            if (remaining > 0) {
                return m.reply(`Tunggu ${msToTime(remaining)} sebelum adventure lagi.`);
            }

            // Durability setup dan pengecekan items tetap sama...
            if (!user.durability) user.durability = {};
            if (!user.durability.pedang) user.durability.pedang = '0/30';
            if (!user.durability.busur) user.durability.busur = '0/30';
            if (!user.durability.panah) user.durability.panah = '0/5';
            
            if (!user.itemLevel) user.itemLevel = {};
            if (!user.itemLevel.armor) user.itemLevel.armor = 1;
            
            if (!user.durability.armor || !user.durability.armor.includes('/')) {
                const maxUses = user.itemLevel.armor === 10 ? 9999 : user.itemLevel.armor * 3;
                user.durability.armor = `0/${maxUses}`;
            }

            // Cek perlengkapan dengan armor
            const requiredItems = ['pedang', 'busur', 'panah', 'armor'];
            for (const it of requiredItems) {
                if (!user.inventory[it] || user.inventory[it] < 1) {
                    return m.reply(`Kamu membutuhkan *${it}*.\n\nSilakan ${it === 'armor' ? 'buat' : 'beli'} kirim perintah : ${usedPrefix}${it === 'armor' ? 'craft' : 'shop buy'} ${it}`);
                }
            }

            // Parse durability
            const [currentArmorUses, maxArmorUses] = user.durability.armor.split('/').map(Number);
            const [currentPedangUses, maxPedangUses] = user.durability.pedang.split('/').map(Number);
            const [currentBusurUses, maxBusurUses] = user.durability.busur.split('/').map(Number);
            const [currentPanahUses, maxPanahUses] = user.durability.panah.split('/').map(Number);

            if (isNaN(currentArmorUses) || isNaN(maxArmorUses)) {
                const maxUses = user.itemLevel.armor === 10 ? 9999 : user.itemLevel.armor * 3;
                user.durability.armor = `0/${maxUses}`;
                return m.reply(`Data armor corrupt! Silakan coba adventure lagi.`);
            }

            // Cek durability armor
            if (user.itemLevel.armor < 10 && currentArmorUses >= maxArmorUses) {
                return m.reply(`Armor kamu rusak!\n\nMax (${maxArmorUses}x)\n\nSilakan upgrade kirim perintah : ${usedPrefix}upgrade armor`);
            }

            // Kurangi stamina
            const staminaCost = Math.floor(Math.random() * 5) + 1;
            if (user.stamina < staminaCost) {
                return m.reply(`Stamina kamu tidak cukup untuk adventure.\n\nSilakan kirim perintah : ${usedPrefix}sleep atau ${usedPrefix}eat`);
            }

            user.stamina -= staminaCost;
            user.lastAdventure = now;

            // Update durability armor
            let newArmorUses = currentArmorUses;
            if (user.itemLevel.armor < 10) {
                newArmorUses = currentArmorUses + 1;
                user.durability.armor = `${newArmorUses}/${maxArmorUses}`;
            }

            // Update durability items adventure
            const newPedangUses = currentPedangUses + 1;
            user.durability.pedang = `${newPedangUses}/${maxPedangUses}`;
            
            const newBusurUses = currentBusurUses + 1;
            user.durability.busur = `${newBusurUses}/${maxBusurUses}`;
            
            const newPanahUses = currentPanahUses + 1;
            user.durability.panah = `${newPanahUses}/${maxPanahUses}`;

            // Cek jika items rusak
            if (newPedangUses >= maxPedangUses) {
                user.inventory.pedang -= 1;
                if (user.inventory.pedang <= 0) delete user.inventory.pedang;
                user.durability.pedang = '0/30';
                m.reply(`Pedang kamu rusak!\n\nSilakan beli lagi di : ${usedPrefix}shop`);
            }

            if (newBusurUses >= maxBusurUses) {
                user.inventory.busur -= 1;
                if (user.inventory.busur <= 0) delete user.inventory.busur;
                user.durability.busur = '0/30';
                m.reply(`Busur kamu rusak!\n\nSilakan beli lagi di : ${usedPrefix}shop`);
            }

            if (newPanahUses >= maxPanahUses) {
                user.inventory.panah -= 1;
                if (user.inventory.panah <= 0) delete user.inventory.panah;
                user.durability.panah = '0/5';
                m.reply(`Panah kamu rusak!\n\nSilakan beli lagi di : ${usedPrefix}shop`);
            }

            // **PERBAIKAN: Pesan timeout menunjukkan 1 jam**
            m.reply(`*ADVENTURE*\n\n🧭 Memulai perjalanan... Tunggu hasilnya selama *1 menit*.\n\nCooldown berikutnya: *1 jam*\nStamina : -${staminaCost}`);

            // **PERBAIKAN: Delay simulasi adventure tetap 1 menit (60000 ms)**
            setTimeout(() => {
                // [Kode adventure logic tetap sama...]
                const adventureLocations = [
                    // ... lokasi adventure tetap sama
                ];

                const location = adventureLocations[Math.floor(Math.random() * adventureLocations.length)];
                const event = location.events[Math.floor(Math.random() * location.events.length)];
                
                const baseSuccessRate = 0.7;
                const levelBonus = (user.level || 1) * 0.02;
                const armorBonus = user.itemLevel.armor * 0.05;
                const successRate = Math.min(0.95, baseSuccessRate + levelBonus + armorBonus);
                
                const isSuccess = Math.random() < successRate;

                if (!isSuccess) {
                    const baseDamage = Math.floor(Math.random() * 20) + 10;
                    const armorReduction = user.itemLevel.armor * 0.1;
                    const actualDamage = Math.max(1, Math.floor(baseDamage * (1 - armorReduction)));
                    
                    user.healt -= actualDamage;
                    if (user.healt < 0) user.healt = 0;

                    const failMessages = [
                        `Kamu tersesat di ${location.name} dan kehilangan banyak stamina.`,
                        `Serangan tak terduga di ${location.name} membuatmu terluka.`,
                        `Jebakan mematikan di ${location.name} hampir merenggut nyawamu.`,
                        `Monster kuat di ${location.name} memaksamu mundur.`
                    ];

                    const failMessage = failMessages[Math.floor(Math.random() * failMessages.length)];

                    const armorDurabilityInfo = user.itemLevel.armor === 10 ? 
                        'Durability Armor : ∞' : 
                        `Durability Armor : ${newArmorUses}/${maxArmorUses}`;

                    return m.reply(
                        `*ADVENTURE*\n\n` +
                        `- *Lokasi* : ${location.name}\n` +
                        `- *Kesulitan* : ${location.difficulty.toUpperCase()}\n\n` +
                        `${failMessage}\n\n` +
                        `Health : -${actualDamage} (Armor mengurangi ${Math.floor(armorReduction * 100)}% damage)\n` +
                        `Stamina : -${staminaCost}\n` +
                        `${armorDurabilityInfo}\n` +
                        `Durability Pedang : ${newPedangUses}/${maxPedangUses}\n` +
                        `Durability Busur : ${newBusurUses}/${maxBusurUses}\n` +
                        `Durability Panah : ${newPanahUses}/${maxPanahUses}\n\n` +
                        `_Tingkatkan level dan equipment untuk kesuksesan lebih tinggi._`
                    );
                }

                // Adventure berhasil - logic rewards tetap sama
                const expReward = Math.floor(Math.random() * (location.rewards.exp[1] - location.rewards.exp[0] + 1)) + location.rewards.exp[0];
                const moneyReward = Math.floor(Math.random() * (location.rewards.money[1] - location.rewards.money[0] + 1)) + location.rewards.money[0];

                user.exp += expReward;
                user.money += moneyReward;

                const rewards = [];
                rewards.push(`- +${formatNumber(expReward)} EXP`);
                rewards.push(`- +${formatNumber(moneyReward)} Money`);

                // [Kode rewards tetap sama...]

                const armorDurabilityInfo = user.itemLevel.armor === 10 ? 
                    'Durability Armor : ∞' : 
                    `Durability Armor : ${newArmorUses}/${maxArmorUses}`;

                return m.reply(
                    `*ADVENTURE*\n\n` +
                    `🧭 ${event}\n` +
                    `- *Lokasi* : ${location.name}\n` +
                    `- *Kesulitan* : ${location.difficulty.toUpperCase()}\n\n` +
                    `- *Status* : Berhasil. 👍\n\n` +
                    `*Reward*\n` +
                    `${rewards.join('\n')}\n\n` +
                    `Stamina : -${staminaCost}\n` +
                    `${armorDurabilityInfo}\n` +
                    `Durability Pedang : ${newPedangUses}/${maxPedangUses}\n` +
                    `Durability Busur : ${newBusurUses}/${maxBusurUses}\n` +
                    `Durability Panah : ${newPanahUses}/${maxPanahUses}\n\n` +
                    `🏆 *Level Progress* : ${user.level || 1}`
                );

            }, 60000); // **Delay simulasi tetap 1 menit**

        } catch (e) {
            console.error(e);
            return m.reply(Func.jsonFormat(e));
        }
    }
};