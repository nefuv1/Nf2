const formatNumber = require('../../lib/formatNumber');

module.exports = {
    help: ['transfer'],
    aliases: ['tf'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,
    run: async (m, { 
        conn, 
        text, 
        usedPrefix, 
        command,
        args,
        users,
        env
    }) => {
        const user = users;
        if (!user) return m.reply("Data pengguna tidak ada di database.");
        if (!user.inventory) user.inventory = {};
        if (typeof user.money !== 'number') user.money = 0;
        if (typeof user.exp !== 'number') user.exp = 0;
        if (typeof user.limit !== 'number') user.limit = 0;

        // Ambil nomor owner dari config.json
        const config = require('../../config.json');
        const ownerNumber = config.owner + '@s.whatsapp.net';

        const mentioned = m.mentionedJid && m.mentionedJid[0];
        if (!mentioned || !text) {
            // Format inventory untuk ditampilkan
            const inventoryList = Object.entries(user.inventory)
                .map(([item, quantity]) => `- ${item} : ${quantity}`)
                .join('\n') || '- Tidak ada item';

            return m.reply(`*TRANSFER* (sistem)\n\n` +
                `*Contoh* :\n` +
                `1. ${usedPrefix + command} [jenis] [nominal] [@tag]\n` +
                `2. ${usedPrefix + command} [jenis] [nominal] | [jenis] [nominal] [@tag]\n\n` +
                `*Cara Penggunaan* :\n` +
                `1. ${usedPrefix + command} money 1000 @0 - Transfer Money\n` +
                `2. ${usedPrefix + command} money | limit @0 - Transfer 1 Money & 1 Limit\n` +
                `3. ${usedPrefix + command} kayu 3 | limit 1 @0 - Transfer Multiple\n\n` +
                `*Biaya Transfer* :\n` +
                `- Sistem fee otomatis (semakin besar nominal, semakin besar fee)\n` +
                `- Nominal opsional (default: 1)\n\n` +
                `*Saldo Anda*\n` +
                `- Money : ${formatNumber(user.money)}\n` +
                `- EXP : ${formatNumber(user.exp)}\n` +
                `- Limit : ${user.limit}\n\n` +
                `*Inventory Anda*\n` +
                `${inventoryList}\n\n` +
                `Inventory : ${Object.keys(user.inventory).length} item`);
        }

        const targetId = mentioned;
        if (targetId === m.sender) {
            return m.reply(`Tidak bisa transfer ke diri sendiri!`);
        }

        const targetUser = global.db.users[targetId];
        if (!targetUser) {
            return m.reply(`Data pengguna tidak ditemukan di database.`);
        }

        if (!targetUser.inventory) targetUser.inventory = {};
        if (typeof targetUser.money !== 'number') targetUser.money = 0;
        if (typeof targetUser.exp !== 'number') targetUser.exp = 0;
        if (typeof targetUser.limit !== 'number') targetUser.limit = 0;

        const transferType = args[0]?.toLowerCase();
        const amountArg = args[1];

        // Fungsi untuk menghitung fee otomatis berdasarkan nominal
        const calculateFee = (amount) => {
            if (amount <= 1000) return Math.ceil(amount * 0.05);
            if (amount <= 10000) return Math.ceil(amount * 0.08);
            if (amount <= 100000) return Math.ceil(amount * 0.12);
            return Math.ceil(amount * 0.15);
        };

        // Fungsi untuk mendapatkan persentase fee
        const getFeePercentage = (amount) => {
            if (amount <= 1000) return 5;
            if (amount <= 10000) return 8;
            if (amount <= 100000) return 12;
            return 15;
        };

        // Fungsi untuk menyimpan income ke owner di db.users
        const saveOwnerIncome = (type, fee) => {
            if (ownerNumber && global.db.users[ownerNumber]) {
                if (!global.db.users[ownerNumber].income) {
                    global.db.users[ownerNumber].income = {};
                }
                if (!global.db.users[ownerNumber].income.incomeTransfer) {
                    global.db.users[ownerNumber].income.incomeTransfer = {
                        money: 0,
                        exp: 0,
                        limit: 0,
                        totalTransactions: 0
                    };
                }
                
                global.db.users[ownerNumber].income.incomeTransfer[type] += fee;
                global.db.users[ownerNumber].income.incomeTransfer.totalTransactions++;
            }
        };

        // Cek jika format multiple (menggunakan |)
        if (text.includes('|')) {
            // TRANSFER MULTIPLE
            const parts = text.split('|');
            const transferResults = [];
            
            for (const part of parts) {
                const transferArgs = part.trim().split(' ').filter(arg => arg);
                const type = transferArgs[0]?.toLowerCase();
                
                // Cek jika ada nominal (arg kedua adalah angka) atau tidak
                let amount = 1; // Default 1
                if (transferArgs[1] && !isNaN(parseInt(transferArgs[1]))) {
                    amount = parseInt(transferArgs[1]);
                }
                
                if (!type) {
                    return m.reply(`Format transfer multiple tidak valid!\n\n*Contoh* : ${usedPrefix + command} money 100 | limit 5 @0`);
                }
                
                if (type === 'money') {
                    if (user.money < amount) {
                        return m.reply(`Money tidak mencukupi!`);
                    }
                    
                    const fee = calculateFee(amount);
                    const receivedAmount = amount - fee;
                    
                    user.money -= amount;
                    targetUser.money += receivedAmount;
                    saveOwnerIncome('money', fee);
                    
                    transferResults.push({
                        type: 'money',
                        amount: amount,
                        fee: fee,
                        received: receivedAmount,
                        feePercentage: getFeePercentage(amount)
                    });
                    
                } else if (type === 'exp') {
                    if (user.exp < amount) {
                        return m.reply(`EXP tidak mencukupi!`);
                    }
                    
                    const fee = calculateFee(amount);
                    const receivedAmount = amount - fee;
                    
                    user.exp -= amount;
                    targetUser.exp += receivedAmount;
                    saveOwnerIncome('exp', fee);
                    
                    transferResults.push({
                        type: 'exp',
                        amount: amount,
                        fee: fee,
                        received: receivedAmount,
                        feePercentage: getFeePercentage(amount)
                    });
                    
                } else if (type === 'limit') {
                    if (user.limit < amount) {
                        return m.reply(`Limit tidak mencukupi!`);
                    }
                    
                    const fee = Math.max(1, Math.ceil(amount * 0.1));
                    const receivedAmount = amount - fee;
                    
                    user.limit -= amount;
                    targetUser.limit += receivedAmount;
                    saveOwnerIncome('limit', fee);
                    
                    transferResults.push({
                        type: 'limit',
                        amount: amount,
                        fee: fee,
                        received: receivedAmount,
                        feePercentage: 10
                    });
                    
                } else {
                    // Transfer item
                    const itemName = type.charAt(0).toUpperCase() + type.slice(1).toLowerCase();
                    
                    if (!user.inventory[itemName] || user.inventory[itemName] < amount) {
                        return m.reply(`Item "${itemName}" tidak mencukupi!\n\n*Dibutuhkan* : ${amount}\n*Anda mempunyai* : ${user.inventory[itemName] || 0}`);
                    }
                    
                    user.inventory[itemName] -= amount;
                    if (user.inventory[itemName] <= 0) {
                        delete user.inventory[itemName];
                    }
                    targetUser.inventory[itemName] = (targetUser.inventory[itemName] || 0) + amount;
                    
                    transferResults.push({
                        type: 'item',
                        itemName: itemName,
                        amount: amount
                    });
                }
            }
            
            // Format hasil transfer multiple dengan nomor urutan
            const transferDetails = transferResults.map((transfer, index) => {
                if (transfer.type === 'item') {
                    return `${index + 1}. ${transfer.itemName} : ${transfer.amount} item`;
                } else {
                    const typeName = transfer.type.charAt(0).toUpperCase() + transfer.type.slice(1);
                    const unit = transfer.type === 'limit' ? '' : ' ' + transfer.type;
                    return `${index + 1}. ${typeName} : ${formatNumber(transfer.amount)}${unit} (Fee : ${formatNumber(transfer.fee)}${unit} - ${transfer.feePercentage}%) Diterima : ${formatNumber(transfer.received)}${unit}`;
                }
            }).join('\n');
            
            return m.reply(`*TRANSFER* (multiple)\n\n` +
                `- *Status* : Berhasil. 👍\n` +
                `- *Dari* : @${m.sender.split('@')[0]}\n` +
                `- *Kepada* : @${targetId.split('@')[0]}\n\n` +
                `- *Detail Transfer* :\n` +
                `${transferDetails}\n\n` +
                `*Saldo Sekarang*\n` +
                `- Money : ${formatNumber(user.money)}\n` +
                `- EXP : ${formatNumber(user.exp)}\n` +
                `- Limit : ${user.limit}`, 
                null, { mentions: [m.sender, targetId] });
                
        } else if (transferType === 'money') {
            // TRANSFER MONEY SINGLE - Nominal opsional
            let amount = 1; // Default 1
            if (amountArg && !isNaN(parseInt(amountArg))) {
                amount = parseInt(amountArg);
            }

            if (amount <= 0) {
                return m.reply(`Nominal money tidak valid!\n\n*Contoh* : ${usedPrefix + command} money 1000 @0`);
            }

            const fee = calculateFee(amount);
            const receivedAmount = amount - fee;
            const feePercentage = getFeePercentage(amount);

            if (user.money < amount) {
                return m.reply(`Money tidak mencukupi!\n\n*Dibutuhkan* : ${formatNumber(amount)} Money\n*Anda mempunyai* : ${formatNumber(user.money)} Money`);
            }

            if (receivedAmount <= 0) {
                return m.reply(`Nominal transfer terlalu kecil!\n\nSetelah fee, penerima tidak mendapatkan apa-apa.`);
            }

            user.money -= amount;
            targetUser.money += receivedAmount;
            saveOwnerIncome('money', fee);

            return m.reply(`*TRANSFER*\n\n` + 
                `- *Status* : Berhasil. 👍\n` +
                `- *Dari* : @${m.sender.split('@')[0]}\n` +
                `- *Kepada* : @${targetId.split('@')[0]}\n` +
                `- *Nominal Transfer* : ${formatNumber(amount)} Money\n` +
                `- *Biaya Admin* : ${formatNumber(fee)} Money (${feePercentage}%)\n` +
                `- *Diterima* : ${formatNumber(receivedAmount)} Money\n\n` +
                `*Saldo Sekarang*\n` +
                `- Anda : ${formatNumber(user.money)} Money\n` +
                `- Target : ${formatNumber(targetUser.money)} Money`, 
                null, { mentions: [m.sender, targetId] });

        } else if (transferType === 'exp') {
            // TRANSFER EXP SINGLE - Nominal opsional
            let amount = 1; // Default 1
            if (amountArg && !isNaN(parseInt(amountArg))) {
                amount = parseInt(amountArg);
            }

            if (amount <= 0) {
                return m.reply(`Nominal EXP tidak valid!\n\n*Contoh* : ${usedPrefix + command} exp 500 @0`);
            }

            const fee = calculateFee(amount);
            const receivedAmount = amount - fee;
            const feePercentage = getFeePercentage(amount);

            if (user.exp < amount) {
                return m.reply(`EXP tidak mencukupi!\n\n*Dibutuhkan* : ${formatNumber(amount)} EXP\n*Anda mempunyai* : ${formatNumber(user.exp)} EXP`);
            }

            user.exp -= amount;
            targetUser.exp += receivedAmount;
            saveOwnerIncome('exp', fee);

            return m.reply(`*TRANSFER*\n\n` +
                `- *Status* : Berhasil. 👍\n` +
                `- *Dari* : @${m.sender.split('@')[0]}\n` +
                `- *Kepada* : @${targetId.split('@')[0]}\n` +
                `- *Nominal Transfer* : ${formatNumber(amount)} EXP\n` +
                `- *Biaya Admin* : ${formatNumber(fee)} EXP (${feePercentage}%)\n` +
                `- *Diterima* : ${formatNumber(receivedAmount)} EXP\n\n` +
                `*EXP Sekarang*\n` +
                `- Anda : ${formatNumber(user.exp)} EXP\n` +
                `- Target : ${formatNumber(targetUser.exp)} EXP`, 
                null, { mentions: [m.sender, targetId] });

        } else if (transferType === 'limit') {
            // TRANSFER LIMIT SINGLE - Nominal opsional
            let amount = 1; // Default 1
            if (amountArg && !isNaN(parseInt(amountArg))) {
                amount = parseInt(amountArg);
            }

            if (amount <= 0) {
                return m.reply(`Nominal Limit tidak valid!\n\n*Contoh* : ${usedPrefix + command} limit 2 @0`);
            }

            const fee = Math.max(1, Math.ceil(amount * 0.1));
            const receivedAmount = amount - fee;
            const feePercentage = 10;

            if (user.limit < amount) {
                return m.reply(`Limit tidak mencukupi!\n\n*Dibutuhkan* : ${amount} Limit\n*Anda mempunyai* : ${user.limit} Limit`);
            }

            user.limit -= amount;
            targetUser.limit += receivedAmount;
            saveOwnerIncome('limit', fee);

            return m.reply(`*TRANSFER*\n\n` +
                `- *Status* : Berhasil. 👍\n` +
                `- *Dari* : @${m.sender.split('@')[0]}\n` +
                `- *Kepada* : @${targetId.split('@')[0]}\n` +
                `- *Nominal Transfer* : ${amount} Limit\n` +
                `- *Biaya Admin* : ${fee} Limit (${feePercentage}%)\n` +
                `- *Diterima* : ${receivedAmount} Limit\n\n` +
                `*Limit Sekarang*\n` +
                `- Anda : ${user.limit} Limit\n` +
                `- Target : ${targetUser.limit} Limit`, 
                null, { mentions: [m.sender, targetId] });

        } else {
            // TRANSFER ITEM SINGLE - Nominal opsional
            const itemName = args[0]?.charAt(0).toUpperCase() + args[0]?.slice(1).toLowerCase();
            let quantity = 1; // Default 1
            if (args[1] && !isNaN(parseInt(args[1]))) {
                quantity = parseInt(args[1]);
            }

            if (!itemName) {
                return m.reply(`Format transfer item tidak valid!\n\n*Contoh* : ${usedPrefix + command} kayu 5 @0`);
            }

            if (!user.inventory[itemName] || user.inventory[itemName] < quantity) {
                return m.reply(`Item "${itemName}" tidak mencukupi!\n\n*Dibutuhkan* : ${quantity}\n*Anda mempunyai* : ${user.inventory[itemName] || 0}`);
            }

            user.inventory[itemName] -= quantity;
            if (user.inventory[itemName] <= 0) {
                delete user.inventory[itemName];
            }
            targetUser.inventory[itemName] = (targetUser.inventory[itemName] || 0) + quantity;

            return m.reply(`*TRANSFER*\n\n` +
                `- *Status* : Berhasil. 👍\n` +
                `- *Dari* : @${m.sender.split('@')[0]}\n` +
                `- *Kepada* : @${targetId.split('@')[0]}\n` +
                `- *Item* : ${itemName}\n` +
                `- *Nominal* : ${quantity} item\n\n` +
                `_Inventory telah diperbarui!_`, 
                null, { mentions: [m.sender, targetId] });
        }
    }
};