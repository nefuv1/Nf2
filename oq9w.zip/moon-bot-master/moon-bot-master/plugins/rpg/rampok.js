const formatNumber = require('../../lib/formatNumber');
const timeout = 60000;

function msToTime(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor((ms % 3600000) / 60000);
    let s = Math.floor((ms % 60000) / 1000);
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

const protectedJobs = [
    'agent', 'dpr', 'polisi', 'tni', 'hakim', 'jaksa', 'pejabat', 'satpam', 'intel'
];

function isProtectedUser(userId) {
    if (!global.db.business || !global.db.business.jobListings) return false;
    for (const [jobId, job] of Object.entries(global.db.business.jobListings)) {
        if (!job.jobName) continue;
        const jobNameLower = job.jobName.toLowerCase();
        const isProtectedJob = protectedJobs.some(protectedJob => jobNameLower.includes(protectedJob));
        if (isProtectedJob && job.workers.includes(userId)) {
            return {
                protected: true,
                jobName: job.jobName,
                jobType: protectedJobs.find(pj => jobNameLower.includes(pj)) || 'Protected Job'
            };
        }
    }
    return { protected: false };
}

module.exports = {
    help: ['merampok'],
    aliases: ['rob', 'rampok'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,
    run: async (m, { command, text, usedPrefix }) => {
        const user = global.db.users[m.sender];
        if (!user) return m.reply("Data pengguna tidak ada di database.");
        if (!user.inventory) user.inventory = {};
        if (!user.lastrampok) user.lastrampok = 0;
        if (typeof user.stamina !== 'number') user.stamina = 100;
        if (typeof user.healt !== 'number') user.healt = 100;
        if (typeof user.money !== 'number') user.money = 0;
        if (typeof user.exp !== 'number') user.exp = 0;

        // TAMBAHKAN: Armor durability & level system
        if (!user.itemLevel) user.itemLevel = {};
        if (!user.itemLevel.armor) user.itemLevel.armor = 1;
        if (!user.durability) user.durability = {};
        
        // Set durability armor default jika belum ada
        if (!user.durability.armor || !user.durability.armor.includes('/')) {
            const maxUses = user.itemLevel.armor === 10 ? 9999 : user.itemLevel.armor * 3;
            user.durability.armor = `0/${maxUses}`;
        }

        // TAMBAHKAN: Durability masker disimpan di user.durability
        if (!user.durability.masker) user.durability.masker = '0/2';

        // TAMBAHKAN: Cek armor requirement
        if (!user.inventory.armor || user.inventory.armor < 1) {
            return m.reply(`Kamu membutuhkan *Armor*.\n\nSilakan buat kirim perintah : ${usedPrefix}craft armor`);
        }

        // UBAH: Cek masker menggunakan durability system
        if (!user.inventory.masker || user.inventory.masker < 1)
            return m.reply(`Kamu membutuhkan *Masker*.\n\nSilakan beli kirim perintah : ${usedPrefix}shop buy masker 1`);

        const targetId = (m.mentionedJid && m.mentionedJid[0]) || null;
        if (!targetId) return m.reply(`Silakan @tag target.\n\n*Example* : ${usedPrefix + command} @0`);
        if (targetId === m.sender) return m.reply(`Kamu tidak bisa merampok diri sendiri!`);

        const target = global.db.users[targetId];
        if (!target) return m.reply(`Target tidak ditemukan di database.`);
        if (typeof target.stamina !== 'number') target.stamina = 100;
        if (typeof target.healt !== 'number') target.healt = 100;
        if (typeof target.money !== 'number') target.money = 0;
        if (typeof target.exp !== 'number') target.exp = 0;

        // TAMBAHKAN: Parse durability dari user.durability
        const [currentArmorUses, maxArmorUses] = user.durability.armor.split('/').map(Number);
        const [currentMaskerUses, maxMaskerUses] = user.durability.masker.split('/').map(Number);

        // TAMBAHKAN: Cek durability armor (kecuali level 10 = unlimited)
        if (user.itemLevel.armor < 10 && currentArmorUses >= maxArmorUses) {
            return m.reply(`Armor kamu rusak!\n\nMax (${maxArmorUses}x)\n\nSilakan upgrade kirim perintah : ${usedPrefix}upgrade armor`);
        }

        // TAMBAHKAN: Cek durability masker
        if (currentMaskerUses >= maxMaskerUses) {
            user.inventory.masker -= 1;
            if (user.inventory.masker <= 0) delete user.inventory.masker;
            user.durability.masker = '0/2';
            return m.reply(`Masker kamu sobek!\n\nSilakan beli baru di : ${usedPrefix}shop`);
        }

        const targetProtection = isProtectedUser(targetId);
        if (targetProtection.protected) {
            const staminaPenalty = 10;
            const healtPenalty = 5;
            const fineAmount = Math.floor(user.money * 0.1);
            const stolenAmount = Math.min(fineAmount, user.money);
            user.stamina = Math.max(0, user.stamina - staminaPenalty);
            user.healt = Math.max(0, user.healt - healtPenalty);

            // UBAH: Update durability armor (hanya jika bukan level 10)
            if (user.itemLevel.armor < 10) {
                const newArmorUses = currentArmorUses + 1;
                user.durability.armor = `${newArmorUses}/${maxArmorUses}`;
            }

            // UBAH: Update durability masker
            const newMaskerUses = currentMaskerUses + 1;
            user.durability.masker = `${newMaskerUses}/${maxMaskerUses}`;

            // UBAH: Kurangi masker menggunakan durability system
            if (newMaskerUses >= maxMaskerUses) {
                user.inventory.masker -= 1;
                if (user.inventory.masker <= 0) delete user.inventory.masker;
                user.durability.masker = '0/2';
            }

            if (stolenAmount > 0) {
                user.money -= stolenAmount;
                target.money += stolenAmount;
                return m.reply(
                    `*ROB*\n\nKamu mencoba merampok @${targetId.split('@')[0]} (${targetProtection.jobType}).\n\n` +
                    `*HUKUMAN*\n- Stamina : -${staminaPenalty}\n- Health : -${healtPenalty}\n- Denda : ${formatNumber(stolenAmount)} Money\n- Money dikembalikan ke target\n\n_Pengguna ini tidak bisa dirampok!_`,
                    null,
                    { mentions: [targetId] }
                );
            } else {
                return m.reply(
                    `*ROB*\n\nKamu mencoba merampok @${targetId.split('@')[0]} (${targetProtection.jobType}).\n\n` +
                    `*HUKUMAN*\n- Stamina : -${staminaPenalty}\n- Health : -${healtPenalty}\n\n_Pengguna ini tidak bisa dirampok!_`,
                    null,
                    { mentions: [targetId] }
                );
            }
        }

        const now = Date.now();
        const remaining = timeout - (now - user.lastrampok);
        if (remaining > 0) return m.reply(`Tunggu ${msToTime(remaining)} sebelum merampok lagi.`);

        const staminaCost = Math.floor(Math.random() * 10) + 1;
        const healtCost = Math.floor(Math.random() * 10) + 1;
        if (user.stamina < staminaCost)
            return m.reply(`Stamina kamu tidak cukup untuk merampok.\n\nSilakan kirim perintah : ${usedPrefix}sleep atau ${usedPrefix}eat`);
        
        user.stamina -= staminaCost;
        
        // TAMBAHKAN: Armor damage reduction untuk health loss
        const baseHealtCost = healtCost;
        const armorReduction = user.itemLevel.armor * 0.1; // 10% reduction per level
        const actualHealtCost = Math.max(1, Math.floor(baseHealtCost * (1 - armorReduction)));
        user.healt = Math.max(0, user.healt - actualHealtCost);

        const staminaLossTarget = Math.floor(Math.random() * 5) + 1;
        const healtLossTarget = Math.floor(Math.random() * 5) + 1;
        target.stamina = Math.max(0, target.stamina - staminaLossTarget);
        target.healt = Math.max(0, target.healt - healtLossTarget);

        // TAMBAHKAN: Update durability armor (hanya jika bukan level 10)
        let newArmorUses = currentArmorUses;
        if (user.itemLevel.armor < 10) {
            newArmorUses = currentArmorUses + 1;
            user.durability.armor = `${newArmorUses}/${maxArmorUses}`;
        }

        // TAMBAHKAN: Update durability masker
        const newMaskerUses = currentMaskerUses + 1;
        user.durability.masker = `${newMaskerUses}/${maxMaskerUses}`;

        // UBAH: Cek jika masker rusak
        if (newMaskerUses >= maxMaskerUses) {
            user.inventory.masker -= 1;
            if (user.inventory.masker <= 0) delete user.inventory.masker;
            user.durability.masker = '0/2';
        }

        const successChance = 0.7;
        const success = Math.random() < successChance;
        user.lastrampok = now;

        if (!success) {
            // TAMBAHKAN: Info durability di pesan gagal
            const armorDurabilityInfo = user.itemLevel.armor === 10 ? 
                'Durability Armor : ∞' : 
                `Durability Armor : ${newArmorUses}/${maxArmorUses}`;

            return m.reply(`*ROB*\n\n💰 Rampokan gagal. Kamu tidak mendapatkan apa-apa.\n\n*Kamu*\nStamina : -${staminaCost}\nHealth : -${actualHealtCost} (Armor mengurangi ${Math.floor(armorReduction * 100)}% damage)\n${armorDurabilityInfo}\nDurability Masker : ${newMaskerUses}/${maxMaskerUses}\n\n*Target* \nStamina : -${staminaLossTarget}\nHealth : -${healtLossTarget}`);
        }

        const rewardType = ['money', 'exp', 'both'][Math.floor(Math.random() * 3)];
        let moneyGain = 0, expGain = 0;

        if (rewardType === 'money' || rewardType === 'both') {
            const p = Math.random();
            const stealableMoney = Math.min(target.money, 100000);
            moneyGain = Math.floor(Math.pow(p, 2.2) * stealableMoney);
        }
        if (rewardType === 'exp' || rewardType === 'both') {
            const p = Math.random();
            const stealableExp = Math.min(target.exp, 50000);
            expGain = Math.floor(Math.pow(p, 2) * stealableExp);
        }

        user.money += moneyGain;
        user.exp += expGain;
        target.money = Math.max(0, target.money - moneyGain);
        target.exp = Math.max(0, target.exp - expGain);

        const results = [];
        if (moneyGain > 0) results.push(`- +${formatNumber(moneyGain)} Money`);
        if (expGain > 0) results.push(`- +${formatNumber(expGain)} EXP`);

        // TAMBAHKAN: Info durability di pesan sukses
        const armorDurabilityInfo = user.itemLevel.armor === 10 ? 
            'Durability Armor : ∞' : 
            `Durability Armor : ${newArmorUses}/${maxArmorUses}`;

        const msg = results.length > 0
            ? `*ROB*\n\n💰 Kamu berhasil merampok @${targetId.split('@')[0]} dan mendapatkan :\n${results.join('\n')}\n\n*Kamu*\nStamina : -${staminaCost}\nHealth : -${actualHealtCost} (Armor mengurangi ${Math.floor(armorReduction * 100)}% damage)\n${armorDurabilityInfo}\nDurability Masker : ${newMaskerUses}/${maxMaskerUses}\n\n*Target*\nStamina : -${staminaLossTarget}\nHealth : -${healtLossTarget}`
            : `*ROB*\n\n💰 Kamu berhasil merampok tapi tidak mendapat hasil berharga.\n\n*Kamu*\nStamina : -${staminaCost}\nHealth : -${actualHealtCost} (Armor mengurangi ${Math.floor(armorReduction * 100)}% damage)\n${armorDurabilityInfo}\nDurability Masker : ${newMaskerUses}/${maxMaskerUses}\n\n*Target* \nStamina : -${staminaLossTarget}\nHealth : -${healtLossTarget}`;

        return m.reply(msg, null, { mentions: [targetId] });
    }
};