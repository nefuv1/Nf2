const moment = require('moment-timezone');

module.exports = {
    help: ['partner'],
    aliases: ['pasangan'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,
    run: async (m, { conn, text, usedPrefix, command, users, Func }) => {
        try {
            m.react(global.react);
            
            const user = global.db.users[m.sender];
            if (!user) return m.reply('Data pengguna tidak ada di database.');
            
            // Deteksi target
            let target;
            if (m.mentionedJid.length > 0) {
                target = m.mentionedJid[0];
            } else if (text) {
                let match = text.match(/@(\d+)/);
                if (match) target = match[1] + '@s.whatsapp.net';
            }
            
            const args = text ? text.trim().split(' ').filter(arg => !arg.includes('@')) : [];
            const subCommand = args[0]?.toLowerCase();
            
            // Inisialisasi partner requests di database jika belum ada
            if (!global.db.partnerRequests) global.db.partnerRequests = {};
            
            // **AJAK PARTNER** - !partner @tag
            if (target && (!subCommand || subCommand === 'partner')) {
                // Cek apakah user sudah punya partner
                if (user.partner) {
                    return m.reply(`Kamu sudah memiliki partner. Mau hapus?\n\nSilakan kirim perintah : ${usedPrefix + command} delete`);
                }
                
                // Cek apakah mengajak diri sendiri
                if (target === m.sender) {
                    return m.reply('Tidak bisa mengajak diri sendiri jadi partner!');
                }
                
                const targetUser = global.db.users[target];
                if (!targetUser) {
                    return m.reply('Pengguna yang di @tag tidak terdaftar di database.');
                }
                
                // Cek apakah target sudah punya partner
                if (targetUser.partner) {
                    return m.reply('Pengguna yang di @tag sudah memiliki partner!');
                }
                
                // Cek apakah sudah ada request yang aktif
                const existingRequest = Object.values(global.db.partnerRequests).find(
                    req => req.from === m.sender && req.to === target && req.status === 'pending'
                );
                
                if (existingRequest) {
                    return m.reply('Kamu sudah mengajak pengguna ini sebelumnya! Tunggu responnya...');
                }
                
                // Buat request partner baru
                const requestId = Date.now().toString();
                global.db.partnerRequests[requestId] = {
                    from: m.sender,
                    to: target,
                    status: 'pending',
                    createdAt: Date.now(),
                    expiresAt: Date.now() + (5 * 60 * 1000) // 5 menit
                };
                
                const fromTag = `@${m.sender.split('@')[0]}`;
                const toTag = `@${target.split('@')[0]}`;
                
                // Kirim pesan ke pengaju
                conn.reply(m.chat, 
                    `*PARTNER* (request)\n\n` +
                    `Kamu telah mengajak ${toTag} menjadi partner!\n` +
                    `Ajakan akan kadaluarsa dalam *5 menit*.\n\n` +
                    `_Menunggu respon..._`,
                    m
                );
                
                // Kirim pesan ke yang diajak
                const requestMessage = 
                    `*PARTNER* (request)\n\n` +
                    `${fromTag} mengajak kamu menjadi partner!\n\n` +
                    `- *Kadaluarsa* : 5 menit\n\n` +
                    `*Untuk menerima* :\n` +
                    `- ${usedPrefix + command} yes ${fromTag}\n\n` +
                    `*Untuk menolak* :\n` +
                    `- ${usedPrefix + command} no ${fromTag}`;
                
                return conn.reply(m.chat, requestMessage, { mentions: [target] });
            }
            
            // **TERIMA AJAKAN** - !partner yes @tag
            if (subCommand === 'yes' && target) {
                // Cek apakah user sudah punya partner
                if (user.partner) {
                    return m.reply('Kamu sudah memiliki partner!');
                }
                
                // Cari request yang sesuai
                const request = Object.values(global.db.partnerRequests).find(
                    req => req.to === m.sender && req.from === target && req.status === 'pending'
                );
                
                if (!request) {
                    return m.reply('Tidak ada ajakan partner yang ditemukan dari pengguna tersebut!');
                }
                
                // Cek apakah request sudah expired
                if (Date.now() > request.expiresAt) {
                    delete global.db.partnerRequests[Object.keys(global.db.partnerRequests).find(key => global.db.partnerRequests[key] === request)];
                    return m.reply('Ajakan partner sudah kadaluarsa!');
                }
                
                const fromUser = global.db.users[request.from];
                if (!fromUser) {
                    return m.reply('Pengguna pengaju tidak ditemukan!');
                }
                
                // Set partner untuk kedua user
                user.partner = request.from;
                fromUser.partner = m.sender;
                
                // Hapus request
                delete global.db.partnerRequests[Object.keys(global.db.partnerRequests).find(key => global.db.partnerRequests[key] === request)];
                
                const fromTag = `@${request.from.split('@')[0]}`;
                const toTag = `@${m.sender.split('@')[0]}`;
                
                // Kirim pesan ke yang menerima
                conn.reply(m.chat,
                    `*PARTNER* (accepted)\n\n` +
                    `Kamu sekarang menjadi partner dengan ${fromTag}\n\n` +
                    `🎉 Selamat berpetualang bersama!`,
                    m
                );
                
                // Kirim pesan ke pengaju
                const successMessage = 
                    `*PARTNER* (accepted)\n\n` +
                    `${toTag} telah menerima ajakan partner kamu!\n\n` +
                    `🎉 Sekarang kalian adalah partner!`;
                
                return conn.reply(m.chat, successMessage, { mentions: [request.from] });
            }
            
            // **TOLAK AJAKAN** - !partner no @tag
            if (subCommand === 'no' && target) {
                // Cari request yang sesuai
                const request = Object.values(global.db.partnerRequests).find(
                    req => req.to === m.sender && req.from === target && req.status === 'pending'
                );
                
                if (!request) {
                    return m.reply('Tidak ada ajakan partner yang ditemukan dari pengguna tersebut!');
                }
                
                // Hapus request
                delete global.db.partnerRequests[Object.keys(global.db.partnerRequests).find(key => global.db.partnerRequests[key] === request)];
                
                const fromTag = `@${request.from.split('@')[0]}`;
                
                // Kirim pesan ke yang menolak
                conn.reply(m.chat,
                    `*PARTNER* (rejected)\n\n` +
                    `Kamu telah menolak ajakan partner dari ${fromTag}.\n\n` +
                    `_Tidak ada partner yang terbentuk._`,
                    m
                );
                
                // Kirim pesan ke pengaju
                const rejectMessage = 
                    `*PARTNER* (rejected)\n\n` +
                    `Ajakan partner kamu telah ditolak.\n\n` +
                    `_Coba ajak pengguna lain atau tunggu waktu yang tepat._`;
                
                return conn.reply(m.chat, rejectMessage, { mentions: [request.from] });
            }
            
            // **HAPUS PARTNER** - !partner delete
            if (subCommand === 'delete') {
                if (!user.partner) {
                    return m.reply('Kamu tidak memiliki partner!');
                }
                
                const partnerUser = global.db.users[user.partner];
                if (partnerUser) {
                    // Hapus partner dari kedua user
                    delete partnerUser.partner;
                }
                delete user.partner;
                
                return m.reply(
                    `*PARTNER* (delete)\n\n` +
                    `Partner telah dihapus.\n\n` +
                    `_Kamu sekarang tidak memiliki partner._`
                );
            }
            
            // **INFO PARTNER** - !partner info
            if (subCommand === 'info' || !subCommand) {
                if (user.partner) {
                    const partnerTag = `@${user.partner.split('@')[0]}`;
                    
                    return m.reply(
                        `*PARTNER* (info)\n\n` +
                        `- *Partner* : ${partnerTag}\n` +
                        `- *Status* : Active\n\n` +
                        `_Untuk hapus! Gunakan : ${usedPrefix + command} delete_`
                    );
                } else {
                    return m.reply(
                        `*PARTNER* (sistem)\n\n` +
                        `Kamu belum memiliki partner.\n\n` +
                        `*Cara menggunakan* :\n` +
                        `1. ${usedPrefix + command} @tag - Ajak user jadi partner\n` +
                        `2. ${usedPrefix + command} yes @tag - Terima ajakan partner\n` +
                        `3. ${usedPrefix + command} no @tag - Tolak ajakan partner\n` +
                        `4. ${usedPrefix + command} delete - Hapus partner\n` +
                        `5. ${usedPrefix + command} info - Info partner\n\n` +
                        `_Ajakan partner kadaluarsa dalam *5 menit*._`
                    );
                }
            }
            
            // Clean up expired requests
            const now = Date.now();
            Object.keys(global.db.partnerRequests).forEach(requestId => {
                if (global.db.partnerRequests[requestId].expiresAt < now) {
                    delete global.db.partnerRequests[requestId];
                }
            });
            
            return m.reply(
                `Format command partner tidak valid!\n\n` +
                `*Contoh penggunaan* :\n` +
                `1. ${usedPrefix + command} @tag - Ajak user jadi partner\n` +
                `2. ${usedPrefix + command} yes @tag - Terima ajakan\n` +
                `3. ${usedPrefix + command} no @tag - Tolak ajakan\n` +
                `4. ${usedPrefix + command} delete - Hapus partner\n` +
                `5. ${usedPrefix + command} info - Info partner`
            );
            
        } catch (e) {
            console.error(e);
            return m.reply(Func.jsonFormat(e));
        }
    }
};