const formatNumber = require('../../lib/formatNumber');

module.exports = {
    help: ['upgrade'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,
    run: async (m, { text, usedPrefix, command, conn }) => {
        const user = global.db.users[m.sender];
        if (!user) return m.reply("Data pengguna tidak ada di database.");
        
        // Initialize user data jika belum ada
        if (!user.itemLevel) user.itemLevel = {};
        if (!user.durability) user.durability = {};
        if (!user.inventory) user.inventory = {};

        const args = text ? text.toLowerCase().split(' ') : [];
        if (args.length < 1) {
            return m.reply(`*Item* :\n\n1. Armor (Level ${user.itemLevel.armor || 1}/10)\n\n*Contoh* :\n- ${usedPrefix + command} [item]\n- ${usedPrefix + command} armor`);
        }

        const item = args[0];
        
        // Upgrade Armor
        if (item === 'armor') {
            // Cek apakah punya armor
            if (!user.inventory.armor || user.inventory.armor < 1) {
                return m.reply(`Kamu tidak memiliki Armor!\n\nSilakan buat kirim perintah : ${usedPrefix}craft armor`);
            }

            const currentLevel = user.itemLevel.armor || 1;
            
            // Cek max level
            if (currentLevel >= 10) {
                return m.reply(`Armor sudah mencapai level maksimal (10/10)`);
            }

            const upgradeCosts = {
              1: 50000, // Level 1 -> 2: 50,000 exp
              2: 100000, // Level 2 -> 3: 100,000 exp
              3: 200000, // Level 3 -> 4: 200,000 exp
              4: 400000, // Level 4 -> 5: 400,000 exp
              5: 800000, // Level 5 -> 6: 800,000 exp
              6: 1600000, // Level 6 -> 7: 1,600,000 exp
              7: 3200000, // Level 7 -> 8: 3,200,000 exp
              8: 6400000, // Level 8 -> 9: 6,400,000 exp
              9: 12800000 // Level 9 -> 10: 12,800,000 exp
            };

            const requiredExp = upgradeCosts[currentLevel];
            const nextLevel = currentLevel + 1;
            
            // Tentukan max uses berdasarkan level (level 10 = unlimited)
            const newMaxUses = nextLevel === 10 ? 9999 : nextLevel * 3;

            // Cek apakah exp cukup
            if (user.exp < requiredExp) {
                return m.reply(`EXP tidak mencukupi! 👎\n\nDibutuhkan : ${formatNumber(requiredExp)} EXP\nEXP Kamu : ${formatNumber(user.exp)}\n\nKekurangan : ${formatNumber(requiredExp - user.exp)} EXP`);
            }

            // Langsung upgrade tanpa konfirmasi
            user.exp -= requiredExp;
            user.itemLevel.armor = nextLevel;
            user.durability.armor = `0/${newMaxUses}`;
            
            // Bonus message
            let bonusMsg = '';
            if (nextLevel >= 5) {
                bonusMsg += `\n- Damage reduction : ${nextLevel * 10}%`;
            }
            if (nextLevel === 10) {
                bonusMsg += `\n- Max pemakaian : ∞ (Unlimited)`;
                bonusMsg += `\n- Status : LEGENDARY ARMOR! 🛡️`;
            }
            
            await m.reply(`*UPGRADE*\n\n- *Status* : Sukses. 👍\n- *Item* : Armor\n- *Level* : ${nextLevel}\n- *Max Pemakaian* : ${newMaxUses === 9999 ? '∞' : newMaxUses + '×'}${bonusMsg ? '\n\n*Bonus* :' + bonusMsg : ''}\n- *EXP Terpakai* : ${formatNumber(requiredExp)}`);
            
            return;
        }

        // Jika item tidak dikenali
        m.reply(`Item "${item}" tidak dikenali!.\n\n*Gunakan* : ${usedPrefix + command} armor`);
    }
};