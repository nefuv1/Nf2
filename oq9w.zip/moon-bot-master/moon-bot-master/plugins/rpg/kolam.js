module.exports = {
    help: ['kolam'],
    aliases: ['pool', 'ikan'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,    
    run: async (m, { users }) => {
        const user = users;
        if (!user || !user.inventory) return m.reply("Data pengguna tidak ada di database.");

        const ikanList = [
            { name: 'ikan', emoji: '🐟' },
            { name: 'ikantropis', emoji: '🐠' },
            { name: 'ikanbuntal', emoji: '🐡' },
            { name: 'lumbalumba', emoji: '🐬' },
            { name: 'paus', emoji: '🐋' },
            { name: 'hiu', emoji: '🦈' },
            { name: 'cumicumi', emoji: '🦑' },
            { name: 'udang', emoji: '🦐' },
            { name: 'lobster', emoji: '🦞' },
            { name: 'uburubur', emoji: '🌊' },
            { name: 'putriduyung', emoji: '🧜‍♀️' }
        ];

        let owned = [];
        let count = 1;

        for (let i of ikanList) {
            const qty = user.inventory[i.name] || 0;
            if (qty > 0) {
                owned.push(`${count++}. ${i.emoji} *${i.name}* : ${qty}`);
            }
        }

        const msg = owned.length > 0
            ? `*POOL* (ikan)\n\n${owned.join('\n')}`
            : `*POOL* (ikan)\n\nKamu belum memiliki ikan di kolam.`;

        return m.reply(msg);
    }
};