const moment = require('moment-timezone');
const formatNumber = require('../../lib/formatNumber');

module.exports = {
    help: ['store'],
    aliases: ['myshop'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,
    run: async (m, { 
        conn, 
        text, 
        usedPrefix, 
        command,
        args,
        users
    }) => {
        const user = users;
        if (!user) return m.reply("Data pengguna tidak ada di database.");
        
        // Inisialisasi database store jika belum ada
        if (!global.db.stores) global.db.stores = {
            pending: [],
            active: [],
            nextStoreId: 1
        };

        const subCommand = args[0]?.toLowerCase();
        
        // Cek jika user sudah memiliki store yang aktif
        const userStore = global.db.stores.active.find(store => store.ownerId === m.sender);
        
        if (!subCommand) {
            if (userStore) {
                // Tampilkan store user yang sudah aktif
                return showUserStore(m, conn, userStore, user, usedPrefix, command);
            } else {
                // Cek pending store
                const pendingStore = global.db.stores.pending.find(store => store.ownerId === m.sender);
                if (pendingStore) {
                    return showPendingStore(m, pendingStore, usedPrefix, command);
                } else {
                    return showStoreRegistration(m, usedPrefix, command, user);
                }
            }
        }

        switch (subCommand) {
            case 'add':
                if (!userStore) return m.reply("Anda belum memiliki store yang aktif!");
                return addProductToStore(m, args, userStore, user, usedPrefix, command);
                
            case 'remove':
                if (!userStore) return m.reply("Anda belum memiliki store yang aktif!");
                return removeProductFromStore(m, args, userStore, usedPrefix, command);
                
            case 'change':
                if (!userStore) return m.reply("Anda belum memiliki store yang aktif!");
                return changeProductPrice(m, args, userStore, user, usedPrefix, command);
                
            case 'stats':
            case 'statistics':
                if (!userStore) return m.reply("Anda belum memiliki store yang aktif!");
                return showStoreStatistics(m, userStore, usedPrefix, command);
                
            default:
                // Jika user mengirim deskripsi untuk pendaftaran
                if (!userStore) {
                    return registerStore(m, text, user, usedPrefix, command);
                } else {
                    return m.reply(`Perintah store tidak dikenali! Gunakan :\n\n` +
                        `1. ${usedPrefix + command} add [item] [stock] [harga]\n` +
                        `2. ${usedPrefix + command} remove [nomor-produk]\n` +
                        `3. ${usedPrefix + command} change [nomor-produk] [stock-baru] [harga-baru]\n` +
                        `4. ${usedPrefix + command} stats`);
                }
        }
    }
};

// Fungsi untuk menampilkan pendaftaran store
function showStoreRegistration(m, usedPrefix, command, user) {
    if (!user.inventory || !user.inventory.card) {
        return m.reply(`Kamu membutuhkan *Card*.\n\nSilakan buat kirim perintah : ${usedPrefix}craft Card`);
    }
    
    return m.reply(`*STORE* (pendaftaran)\n\n` +
        `Anda memiliki Card! 👍\n\n` +
        `Untuk mendaftar store, gunakan perintah :\n` +
        `- ${usedPrefix + command} [deskripsi-toko]\n` +
        `- ${usedPrefix + command} Toko terpercaya, menjual berbagai item rpg\n\n` +
        `*Proses Pendaftaran* :\n` +
        `1. Daftar dengan deskripsi toko\n` +
        `2. Tunggu approval 3 hari\n` +
        `3. Atau hubungi developer untuk akses cepat\n` +
        `4. Setelah di-approve, Anda bisa menambah produk`);
}

function registerStore(m, description, user, usedPrefix, command) {
    if (!description) {
        return m.reply(`Silakan berikan deskripsi untuk store Anda!\n\n*Contoh* : ${usedPrefix + command} Toko terpercaya, menjual berbagai item rpg`);
    }
    
    if (!user.inventory?.card) {
        return m.reply("Anda membutuhkan Card untuk membuat store!");
    }
    
    // Cek apakah sudah pending
    const existingPending = global.db.stores.pending.find(store => store.ownerId === m.sender);
    if (existingPending) {
        return m.reply("Anda sudah memiliki pendaftaran store yang sedang menunggu approval!");
    }
    
    const storeData = {
        ownerId: m.sender,
        ownerName: user.username || m.sender.split('@')[0],
        storeName: `${user.username || m.sender.split('@')[0]} Store`,
        description: description,
        registrationDate: moment().tz('Asia/Jakarta').format(),
        approvalDate: moment().tz('Asia/Jakarta').add(3, 'days').format(),
        status: 'pending',
        products: [],
        totalSales: 0,
        totalRevenue: 0,
        rating: 0,
        totalRatings: 0,
        customerCount: 0
    };
    
    global.db.stores.pending.push(storeData);    

    return m.reply(`*STORE* (sedang ditinjau)\n\n` +
        `*Data Pendaftaran*\n` +
        `- *Nama Toko* : ${storeData.storeName}\n` +
        `- *Deskripsi* : ${storeData.description}\n` +
        `- *Tanggal Daftar* : ${moment().tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm')}\n` +
        `- *Estimasi Selesai* : ${moment().tz('Asia/Jakarta').add(3, 'days').format('DD/MM/YYYY HH:mm')}\n\n` +
        `_Menunggu approval selama (3 hari)!_`);
}

function showPendingStore(m, pendingStore, usedPrefix, command) {
    const now = moment().tz('Asia/Jakarta');
    const approvalDate = moment(pendingStore.approvalDate);
    const daysLeft = approvalDate.diff(now, 'days');
    const hoursLeft = approvalDate.diff(now, 'hours') % 24;
    
    return m.reply(`*STORE* (sedang ditinjau)\n\n` +
        `*Data Pendaftaran*\n` +
        `- *Nama Toko* : ${pendingStore.storeName}\n` +
        `- *Deskripsi* : ${pendingStore.description}\n` +
        `- *Tanggal Daftar* : ${moment(pendingStore.registrationDate).format('DD/MM/YYYY HH:mm')}\n\n` +
        `- *Waktu Tersisa* : ${daysLeft} hari ${hoursLeft} jam\n` +
        `- *Estimasi Selesai* : ${moment(pendingStore.approvalDate).format('DD/MM/YYYY HH:mm')}\n\n` +
        `_Untuk akses cepat, hubungi developer bot!_`);
}

function showUserStore(m, conn, userStore, user, usedPrefix, command) {
    let productsList = '*Produk Yang Dijual*\n';
    
    if (!userStore.products || userStore.products.length === 0) {
        productsList += 'Belum ada produk yang ditambahkan\n\n';
    } else {
        userStore.products.forEach((product, index) => {
            productsList += `${index + 1}. ${product.name} : ${formatNumber(product.price)} Money\n`;
            productsList += `- *Stock* : ${product.stock} | *Terjual* : ${product.sold || 0}\n\n`;
        });
    }
    
    const ratingStars = '⭐'.repeat(Math.floor(userStore.rating)) + (userStore.rating % 1 >= 0.5 ? '½' : '');
    
    return m.reply(`*STORE*\n\n` +
        `*${userStore.storeName.toUpperCase()}*\n\n` +
        `*Info Toko*\n` +
        `- *ID Toko*: ${userStore.storeId?.toString().padStart(5, '0') || '00000'}\n` +
        `- *Pemilik* : ${userStore.ownerName}\n` +
        `- *Deskripsi* : ${userStore.description}\n` +
        `- *Rating* : ${ratingStars} (${userStore.rating?.toFixed(1) || '0.0'}) dari ${userStore.totalRatings || 0} ulasan\n` +
        `- *Total Penjualan* : ${userStore.totalSales || 0} item\n` +
        `- *Total Pendapatan* : ${formatNumber(userStore.totalRevenue || 0)} Money\n` +
        `- *Jumlah Pembeli* : ${userStore.customerCount || 0} orang\n\n` +
        `${productsList}` +
        `*Perintah Toko* :\n` +
        `1. ${usedPrefix + command} add [item] [stock] [harga] - Tambah produk\n` +
        `2. ${usedPrefix + command} remove [nomor] - Hapus produk\n` +
        `3. ${usedPrefix + command} change [nomor/nama] [stock-baru] [harga-baru] - Ubah stock & harga\n` +
        `4. ${usedPrefix + command} stats - Lihat statistik`);
}

// Fungsi untuk menambah produk ke store - PARAMETER DIPERBAIKI
function addProductToStore(m, args, userStore, user, usedPrefix, command) {
    const itemName = args[1]?.charAt(0).toUpperCase() + args[1]?.slice(1).toLowerCase();
    const stock = parseInt(args[2]);
    const price = parseInt(args[3]);
    
    if (!itemName || isNaN(stock) || isNaN(price)) {
        return m.reply(`Format salah!\n\n*Contoh* : ${usedPrefix + command} add [item] [stock] [harga]\n\n*Contoh penggunaan* : ${usedPrefix + command} add Karung 10 1000`);
    }
    
    if (stock <= 0 || price <= 0) {
        return m.reply("Stock dan harga harus lebih dari 0!");
    }
    
    if (!user.inventory || !user.inventory[itemName] || user.inventory[itemName] < stock) {
        return m.reply(`Item "${itemName}" tidak mencukupi di inventory!\n\nAnda memiliki : ${user.inventory[itemName] || 0}\nMembutuhkan : ${stock}`);
    }
    
    if (!userStore.products) {
        userStore.products = [];
    }
    
    if (userStore.products.length >= 10) {
        return m.reply("Maksimal 10 produk per store!");
    }
    
    // Cek apakah produk sudah ada
    const existingProduct = userStore.products.find(p => p.name === itemName);
    if (existingProduct) {
        return m.reply(`Produk "${itemName}" sudah ada di store!\n\nSilakan kirim perintah : ${usedPrefix + command} change [item] [stock] [harga] - Untuk mengubah stock/harga.`);
    }
    
    // Kurangi inventory user
    user.inventory[itemName] -= stock;
    if (user.inventory[itemName] <= 0) {
        delete user.inventory[itemName];
    }
    
    // Tambahkan produk ke store
    userStore.products.push({
        name: itemName,
        stock: stock,
        price: price,
        sold: 0
    });
    
    return m.reply(`*STORE* (produk ditambahkan)\n\n` +
        `*Detail Produk*\n` +
        `- *Nama* : ${itemName}\n` +
        `- *Stock* : ${stock} item\n` +
        `- *Harga* : ${formatNumber(price)} Money per item\n\n` +
        `_Item telah dipindahkan dari inventory ke store!_`);
}

function removeProductFromStore(m, args, userStore, usedPrefix, command) {
    const productIndex = parseInt(args[1]) - 1;
    
    if (!userStore.products || userStore.products.length === 0) {
        return m.reply("Tidak ada produk di store!");
    }
    
    if (isNaN(productIndex) || productIndex < 0 || productIndex >= userStore.products.length) {
        return m.reply(`Nomor produk tidak valid!`);
    }
    
    const removedProduct = userStore.products[productIndex];
    
    const owner = global.db.users[userStore.ownerId];
    if (owner && owner.inventory) {
        owner.inventory[removedProduct.name] = (owner.inventory[removedProduct.name] || 0) + removedProduct.stock;
    }
    
    userStore.products.splice(productIndex, 1);
    
    return m.reply(`*STORE* (produk dihapus)\n\n` +
        `*Produk yang dihapus*\n` +
        `- *Nama* : ${removedProduct.name}\n` +
        `- *Stock dikembalikan* : ${removedProduct.stock} item\n\n` +
        `_Stock telah dikembalikan ke inventory Anda!_`);
}

// FUNGSI changeProductPrice DIPERBAIKI - BISA UBAH STOCK DAN HARGA
function changeProductPrice(m, args, userStore, user, usedPrefix, command) {
    if (!userStore.products || userStore.products.length === 0) {
        return m.reply("Tidak ada produk di store!");
    }
    
    let productIdentifier = args[1];
    let newStock = parseInt(args[2]);
    let newPrice = parseInt(args[3]);
    
    if (!productIdentifier) {
        return m.reply(`Format salah!\n\n*Contoh* : ${usedPrefix + command} change [nomor/nama] [stock-baru] [harga-baru]\n*Contoh penggunaan* : ${usedPrefix + command} change 1 20 1500\n*Contoh penggunaan* : ${usedPrefix + command} change Karung 15 1200`);
    }
    
    let product;
    
    // Cari produk berdasarkan nomor atau nama
    if (!isNaN(parseInt(productIdentifier))) {
        // Jika input adalah nomor
        const productIndex = parseInt(productIdentifier) - 1;
        if (productIndex < 0 || productIndex >= userStore.products.length) {
            return m.reply(`Nomor produk tidak valid!`);
        }
        product = userStore.products[productIndex];
    } else {
        // Jika input adalah nama produk
        const itemName = productIdentifier.charAt(0).toUpperCase() + productIdentifier.slice(1).toLowerCase();
        product = userStore.products.find(p => p.name.toLowerCase() === itemName.toLowerCase());
        if (!product) {
            return m.reply(`Produk "${itemName}" tidak ditemukan di store!`);
        }
    }
    
    // Validasi stock baru
    if (isNaN(newStock) || newStock < 0) {
        return m.reply("Stock baru harus berupa angka dan tidak boleh negatif!");
    }
    
    // Validasi harga baru
    if (isNaN(newPrice) || newPrice <= 0) {
        return m.reply("Harga baru harus berupa angka dan lebih dari 0!");
    }
    
    // Hitung selisih stock untuk penyesuaian inventory
    const stockDifference = newStock - product.stock;
    const oldStock = product.stock;
    const oldPrice = product.price;
    
    // Jika stock bertambah, kurangi dari inventory user
    if (stockDifference > 0) {
        if (!user.inventory || !user.inventory[product.name] || user.inventory[product.name] < stockDifference) {
            return m.reply(`Tidak cukup ${product.name} di inventory untuk menambah stock!\n\nAnda memiliki: ${user.inventory[product.name] || 0}, butuh: ${stockDifference}`);
        }
        user.inventory[product.name] -= stockDifference;
        if (user.inventory[product.name] <= 0) {
            delete user.inventory[product.name];
        }
    }
    // Jika stock berkurang, kembalikan ke inventory user
    else if (stockDifference < 0) {
        if (!user.inventory) user.inventory = {};
        user.inventory[product.name] = (user.inventory[product.name] || 0) + Math.abs(stockDifference);
    }
    
    // Update produk
    product.stock = newStock;
    product.price = newPrice;
    
    return m.reply(`*STORE* (diperbarui)\n\n` +
        `*Detail Perubahan*\n` +
        `- *Produk* : ${product.name}\n` +
        `- *Stock Lama* : ${oldStock} → *Stock Baru* : ${newStock}\n` +
        `- *Harga Lama* : ${formatNumber(oldPrice)} → *Harga Baru* : ${formatNumber(newPrice)} Money\n\n` +
        `_Produk berhasil diperbarui!_`);
}

function showStoreStatistics(m, userStore, usedPrefix, command) {
    if (!userStore.products) {
        userStore.products = [];
    }
    
    const topProducts = [...userStore.products]
        .sort((a, b) => (b.sold || 0) - (a.sold || 0))
        .slice(0, 5);
    
    let topProductsText = '';
    topProducts.forEach((product, index) => {
        topProductsText += `${index + 1}. ${product.name} - *Terjual* : ${product.sold || 0} - *Pendapatan* : ${formatNumber((product.sold || 0) * product.price)} Money\n`;
    });
    
    if (topProducts.length === 0) {
        topProductsText = 'Belum ada produk yang terjual.\n';
    }
    
    const ratingPercentage = userStore.totalRatings > 0 ? (userStore.rating / 5 * 100).toFixed(1) : 0;
    
    return m.reply(`*STORE* (statistik)\n\n` +
        `${userStore.storeName.toUpperCase()}\n\n` +
        `*Performance Toko*\n` +
        `- *Total Pendapatan* : ${formatNumber(userStore.totalRevenue || 0)} Money\n` +
        `- *Total Penjualan* : ${userStore.totalSales || 0} item\n` +
        `- *Jumlah Pembeli* : ${userStore.customerCount || 0} orang\n` +
        `- *Rating* : ${(userStore.rating || 0).toFixed(1)}/5 (${ratingPercentage}%)\n` +
        `- Jumlah Ulasan* : ${userStore.totalRatings || 0}\n\n` +
        `*Produk Terlaris*\n${topProductsText}\n\n` +
        `- *Total Produk* : ${userStore.products.length}/10`);
}