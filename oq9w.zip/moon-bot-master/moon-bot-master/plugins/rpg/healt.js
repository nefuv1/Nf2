module.exports = {
    help: ['healt'],
    aliases: ['heal', 'health'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,
    run: async (m, { usedPrefix }) => {
        const user = global.db.users[m.sender];
        if (!user) return m.reply("Data pengguna tidak ada di database.");
        if (!user.inventory) user.inventory = {};
        if (typeof user.healt !== 'number') user.healt = 100;

        // CEK HEALTH SUDAH PENUH
        if (user.healt >= 100) {
            return m.reply(`❤️ Health kamu sudah penuh! 👍\n\nHealt : ${user.healt} / 100`);
        }

        const potion = user.inventory.potion || 0;
        if (potion < 1)
            return m.reply(`Kamu tidak memiliki *Potion*.\n\nSilakan beli kirim perintah : ${usedPrefix}shop buy potion 1`);

        // Gunakan potion
        user.inventory.potion -= 1;

        // Hitung heal berdasarkan sisa kekurangan health
        const healAmount = Math.min(5, 100 - user.healt);
        user.healt += healAmount;

        // Batasi maksimal 100
        if (user.healt > 100) user.healt = 100;

        return m.reply(
            `🧪 Kamu menggunakan -1 Potion!\n❤️ Health kamu pulih +${healAmount}\n\nPotion tersisa : ${user.inventory.potion}\nHealt : ${user.healt} / 100`
        );
    }
};