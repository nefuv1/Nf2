const formatNumber = require('../../lib/formatNumber')

const timeout = 60000;

function addToInventory(user, item, qty) {
    if (!user.inventory) user.inventory = {};
    user.inventory[item] = (user.inventory[item] || 0) + qty;
}

function msToTime(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor((ms % 3600000) / 60000);
    let s = Math.floor((ms % 60000) / 1000);
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

module.exports = {
    help: ['memulung'],
    aliases: ['mulung', 'pemulung', 'scavenger'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,    
    run: async (m, { command, Func, text, usedPrefix, users }) => {
        const user = users;
        if (!user) return m.reply("Data pengguna tidak ada di database.");
        if (!user.inventory) user.inventory = {};
        if (!user.lastmulung) user.lastmulung = 0;
        if (typeof user.stamina !== 'number') user.stamina = 100; // default stamina

        const now = Date.now();
        const remaining = timeout - (now - user.lastmulung);

        if (remaining > 0) return m.reply(`Tunggu ${msToTime(remaining)} sebelum mulung lagi.`);
        if (!user.inventory.karung || user.inventory.karung < 1)
            return m.reply(`Kamu membutuhkan *Karung*.\n\nSilakan beli kirim perintah : ${usedPrefix}shop buy karung 1`);

        // Acak pengurangan stamina (1–10)
        const staminaCost = Math.floor(Math.random() * 10) + 1;

        if (user.stamina < staminaCost)
            return m.reply(`Stamina kamu tidak cukup untuk mulung.\n\nSilakan kirim perintah : ${usedPrefix}sleep atau ${usedPrefix}eat`);

        user.stamina -= staminaCost;

        // Kurangi karung
        user.inventory.karung -= 1;
        if (user.inventory.karung <= 0) delete user.inventory.karung;

        // Daftar barang & rarity
        const items = [
            { name: 'pisau', rarity: 0.7 },
            { name: 'botol', rarity: 0.7 },            
            { name: 'kaleng', rarity: 0.9 },
            { name: 'karung', rarity: 0.85 },
            { name: 'kayu', rarity: 0.9 },
            { name: 'kardus', rarity: 0.9 },
            { name: 'paku', rarity: 0.9 },
            { name: 'pancingan', rarity: 0.25 },
            { name: 'armor', rarity: 0.25 },
            { name: 'mangga', rarity: 0.3 }
        ];

        const finds = Math.floor(Math.random() * 3) + 2;
        let results = [];

        for (let i = 0; i < finds; i++) {
            const luck = Math.random();
            const available = items.filter(it => luck <= it.rarity);
            if (available.length === 0) continue;

            const item = available[Math.floor(Math.random() * available.length)];
            const value = Math.floor(Math.random() * 11); // 0–10 acak

            // Hanya tampilkan kalau value > 0
            if (value > 0) {
                addToInventory(user, item.name, value);
                results.push(`- +${formatNumber(value)} ${item.name}`);
            }
        }

        // Kadang dapat karung tambahan (peluang 30%)
        if (Math.random() < 0.3) {
            addToInventory(user, 'Karung', 1);
            results.push(`- +1 Karung`);
        }

        user.lastmulung = now;

        const msg = results.length > 0
            ? `*SCAVENGER*\n\n🗑️ Dari mulung kamu mendapatkan :\n${results.join('\n')}\n\nStamina : -${staminaCost}`
            : `*SCAVENGER*\n\n🗑️ Kamu tidak menemukan apapun kali ini!\n\nStamina : -${staminaCost}`;

        return m.reply(msg);
    }
};