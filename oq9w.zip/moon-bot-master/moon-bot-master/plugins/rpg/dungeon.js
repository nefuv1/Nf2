const formatNumber = require('../../lib/formatNumber');

function msToTime(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor((ms % 3600000) / 60000);
    let s = Math.floor((ms % 60000) / 1000);
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}

function getRandom(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

module.exports = {
    help: ['dungeon'],
    aliases: ['dg'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,
    run: async (m, { conn, text, usedPrefix, command, users, Func }) => {
        try {
            m.react(global.react);
            
            const user = global.db.users[m.sender];
            if (!user) return m.reply('Data pengguna tidak ada di database.');
            if (!user.inventory) user.inventory = {};
            if (!user.lastDungeon) user.lastDungeon = 0;
            if (typeof user.stamina !== 'number') user.stamina = 100;
            if (typeof user.healt !== 'number') user.healt = 100;

            const timeout = 3600000; // 1 jam
            const now = Date.now();
            const remaining = timeout - (now - user.lastDungeon);
            
            if (remaining > 0) {
                return m.reply(`Tunggu ${msToTime(remaining)} sebelum dungeon lagi.`);
            }

            if (!user.durability) user.durability = {};
            if (!user.durability.pedang) user.durability.pedang = '0/30';
            if (!user.durability.busur) user.durability.busur = '0/30';
            if (!user.durability.panah) user.durability.panah = '0/5';
            if (!user.durability.armor) user.durability.armor = '0/15';
            
            if (!user.itemLevel) user.itemLevel = {};
            if (!user.itemLevel.armor) user.itemLevel.armor = 1;

            const requiredItems = ['pedang', 'busur', 'panah', 'armor', 'potion'];
            for (const it of requiredItems) {
                if (!user.inventory[it] || user.inventory[it] < 1) {
                    return m.reply(
                        `Kamu membutuhkan *${it}*.\n\n` +
                        `Silakan  ${it === 'armor' ? 'craft' : 'beli'} kirim perintah : ${usedPrefix}${it === 'armor' ? 'craft' : 'shop buy'} ${it}`
                    );
                }
            }

            const [currentArmorUses, maxArmorUses] = user.durability.armor.split('/').map(Number);
            const [currentPedangUses, maxPedangUses] = user.durability.pedang.split('/').map(Number);
            const [currentBusurUses, maxBusurUses] = user.durability.busur.split('/').map(Number);
            const [currentPanahUses, maxPanahUses] = user.durability.panah.split('/').map(Number);

            if (isNaN(currentArmorUses) || isNaN(maxArmorUses)) {
                const maxUses = user.itemLevel.armor === 10 ? 9999 : user.itemLevel.armor * 3;
                user.durability.armor = `0/${maxUses}`;
                return m.reply(`Data armor corrupt! Silakan coba dungeon lagi.`);
            }

            // **PERBAIKAN: Cek durability armor sebelum update**
            if (user.itemLevel.armor < 10 && currentArmorUses >= maxArmorUses) {
                return m.reply(`Armor kamu rusak!\n\nMax (${maxArmorUses}x)\n\nSilakan upgrade kirim perintah : ${usedPrefix}upgrade armor`);
            }

            const staminaCost = getRandom(10, 20);
            if (user.stamina < staminaCost) {
                return m.reply(`Stamina kamu tidak cukup untuk dungeon.\nMembutuhkan : ${staminaCost} Stamina \n\nSilakan kirim perintah : ${usedPrefix}sleep atau ${usedPrefix}eat`);
            }

            user.stamina -= staminaCost;
            user.lastDungeon = now;

            // **PERBAIKAN: Update durability dengan cek batas maksimal**
            let newArmorUses = currentArmorUses;
            if (user.itemLevel.armor < 10) {
                newArmorUses = Math.min(currentArmorUses + 2, maxArmorUses); // Tidak boleh melebihi max
                user.durability.armor = `${newArmorUses}/${maxArmorUses}`;
            }

            const newPedangUses = Math.min(currentPedangUses + 2, maxPedangUses);
            user.durability.pedang = `${newPedangUses}/${maxPedangUses}`;
            
            const newBusurUses = Math.min(currentBusurUses + 2, maxBusurUses);
            user.durability.busur = `${newBusurUses}/${maxBusurUses}`;
            
            const newPanahUses = Math.min(currentPanahUses + 2, maxPanahUses);
            user.durability.panah = `${newPanahUses}/${maxPanahUses}`;

            // Cek jika items rusak
            const brokenItems = [];
            if (newPedangUses >= maxPedangUses) {
                user.inventory.pedang -= 1;
                if (user.inventory.pedang <= 0) delete user.inventory.pedang;
                user.durability.pedang = '0/30';
                brokenItems.push('Pedang');
            }

            if (newBusurUses >= maxBusurUses) {
                user.inventory.busur -= 1;
                if (user.inventory.busur <= 0) delete user.inventory.busur;
                user.durability.busur = '0/30';
                brokenItems.push('Busur');
            }

            if (newPanahUses >= maxPanahUses) {
                user.inventory.panah -= 1;
                if (user.inventory.panah <= 0) delete user.inventory.panah;
                user.durability.panah = '0/5';
                brokenItems.push('Panah');
            }

            // Kurangi potion
            user.inventory.potion -= 1;
            if (user.inventory.potion <= 0) delete user.inventory.potion;

            if (brokenItems.length > 0) {
                m.reply(`${brokenItems.join(', ')} kamu rusak!\n\nSilakan beli lagi di : ${usedPrefix}shop`);
            }

            m.reply(`*DUNGEON*\n\n🏰 Memasuki dungeon berbahaya... Tunggu hasilnya selama *2 menit*.\n\nStamina : -${staminaCost}\nPotion : -1`);

            setTimeout(() => {
                const dungeons = [
                    {
                        name: 'Dungeon Api',
                        difficulty: 'extreme',
                        boss: 'Dragon Merah',
                        floors: 5,
                        rewards: { 
                            exp: [5000, 20000], 
                            money: [10000, 50000],
                            rareChance: 0.8,
                            bossChance: 0.6
                        },
                        events: [
                            'Mengalahkan Guardian Api',
                            'Memecahkan segel magis',
                            'Menemukan ruang harta',
                            'Melawan ular raksasa',
                            'MENGHADAPI BOSS FINAL'
                        ]
                    },
                    {
                        name: 'Dungeon Es', 
                        difficulty: 'extreme',
                        boss: 'Ice Lich',
                        floors: 6,
                        rewards: { 
                            exp: [6000, 25000], 
                            money: [12000, 60000],
                            rareChance: 0.85,
                            bossChance: 0.7
                        },
                        events: [
                            'Melewati jembatan es',
                            'Mengalahkan Yeti',
                            'Menemukan artifact kuno',
                            'Memecahkan puzzle es',
                            'Melarikan diri dari avalanche',
                            'MENGHADAPI BOSS FINAL'
                        ]
                    },
                    {
                        name: 'Dungeon Bayangan',
                        difficulty: 'nightmare',
                        boss: 'Shadow King',
                        floors: 7,
                        rewards: { 
                            exp: [8000, 30000], 
                            money: [15000, 75000],
                            rareChance: 0.9,
                            bossChance: 0.8
                        },
                        events: [
                            'Menghindari jebakan mematikan',
                            'Mengalahkan doppelganger',
                            'Menemukan ruang rahasia',
                            'Memecahkan kode bayangan',
                            'Melawan phantom army',
                            'Melewati labirin gelap',
                            'MENGHADAPI BOSS FINAL'
                        ]
                    },
                    {
                        name: 'Dungeon Kuno',
                        difficulty: 'legendary',
                        boss: 'Ancient Titan',
                        floors: 8,
                        rewards: { 
                            exp: [10000, 40000], 
                            money: [20000, 100000],
                            rareChance: 0.95,
                            bossChance: 0.9
                        },
                        events: [
                            'Aktivasi mekanisme kuno',
                            'Mengalahkan golem penjaga',
                            'Menemukan library terlarang',
                            'Memecahkan hieroglyph',
                            'Melawan elemental guardian',
                            'Melewati ruang waktu',
                            'Mengungkap misteri kuno',
                            'MENGHADAPI BOSS FINAL'
                        ]
                    }
                ];

                const dungeon = dungeons[Math.floor(Math.random() * dungeons.length)];
                
                const baseSuccessRate = 0.5;
                const levelBonus = (user.level || 1) * 0.01;
                const armorBonus = user.itemLevel.armor * 0.03;
                const successRate = Math.min(0.8, baseSuccessRate + levelBonus + armorBonus);
                
                const isSuccess = Math.random() < successRate;

                if (!isSuccess) {
                    const baseDamage = getRandom(30, 60);
                    const armorReduction = user.itemLevel.armor * 0.15;
                    const actualDamage = Math.max(10, Math.floor(baseDamage * (1 - armorReduction)));
                    
                    user.healt -= actualDamage;
                    if (user.healt < 0) user.healt = 0;

                    const failStories = [
                        `Kamu tersesat di ${dungeon.name} dan diserang oleh ${dungeon.boss}!`,
                        `Jebakan mematikan di lantai ${getRandom(2, dungeon.floors)} hampir merenggut nyawamu!`,
                        `${dungeon.boss} terlalu kuat! Kamu harus kabur dengan luka parah.`,
                        `Magis gelap di ${dungeon.name} menguras energimu!`
                    ];

                    const failStory = failStories[Math.floor(Math.random() * failStories.length)];

                    const armorDurabilityInfo = user.itemLevel.armor === 10 ? 
                        'Durability Armor : ∞' : 
                        `Durability Armor : ${newArmorUses}/${maxArmorUses}`;

                    return m.reply(
                        `*DUNGEON*\n\n` +
                        `- *Dungeon* : ${dungeon.name}\n` +
                        `- *Boss* : ${dungeon.boss}\n` +
                        `- *Kesulitan* : ${dungeon.difficulty.toUpperCase()}\n` +
                        `- *Floors* : ${dungeon.floors}\n\n` +
                        `*DUNGEON FAILED*\n\n` +
                        `${failStory}\n\n` +
                        `Health : -${actualDamage} (Armor mengurangi ${Math.floor(armorReduction * 100)}% damage)\n` +
                        `Stamina : -${staminaCost}\n` +
                        `Potion : -1\n` +
                        `${armorDurabilityInfo}\n` +
                        `Durability Pedang : ${newPedangUses}/${maxPedangUses}\n` +
                        `Durability Busur : ${newBusurUses}/${maxBusurUses}\n` +
                        `Durability Panah : ${newPanahUses}/${maxPanahUses}\n\n` +
                        `_Level up dan upgrade equipment untuk dungeon yang lebih sulit!_`
                    );
                }

                // **PERBAIKAN: Reward system yang lebih baik**
                const expReward = getRandom(dungeon.rewards.exp[0], dungeon.rewards.exp[1]);
                const moneyReward = getRandom(dungeon.rewards.money[0], dungeon.rewards.money[1]);

                user.exp += expReward;
                user.money += moneyReward;

                const rewards = [];
                rewards.push(`- +${formatNumber(expReward)} EXP`);
                rewards.push(`- +${formatNumber(moneyReward)} Money`);

                // Simulasi progress floors
                const completedFloors = [];
                for (let i = 1; i <= dungeon.floors; i++) {
                    if (Math.random() < 0.8) {
                        completedFloors.push(`✓ Floor ${i} : ${dungeon.events[i-1]}`);
                    } else {
                        completedFloors.push(`✗ Floor ${i} : Gagal`);
                        break;
                    }
                }

                const finalFloor = completedFloors.length;

                // **PERBAIKAN: Rare rewards dengan jumlah yang wajar (1-2)**
                if (Math.random() < dungeon.rewards.rareChance) {
                    const dungeonRares = [
                        { name: 'emas', amount: [1, 2], chance: 0.3 }, // 1-2 emas
                        { name: 'berlian', amount: [1, 1], chance: 0.1 }, // 1 berlian
                        { name: 'mythic', amount: [1, 3], chance: 0.4 }, // 1-3 mythic
                        { name: 'legendary', amount: [1, 2], chance: 0.2 } // 1-2 legendary
                    ];
                    
                    let selectedItem = null;
                    let roll = Math.random();
                    let cumulativeChance = 0;
                    
                    for (const item of dungeonRares) {
                        cumulativeChance += item.chance;
                        if (roll <= cumulativeChance) {
                            selectedItem = item;
                            break;
                        }
                    }
                    
                    if (selectedItem) {
                        // **PERBAIKAN: Pastikan amount adalah number, bukan NaN**
                        const itemAmount = Array.isArray(selectedItem.amount) ? 
                            getRandom(selectedItem.amount[0], selectedItem.amount[1]) : 
                            parseInt(selectedItem.amount) || 1; // Fallback ke 1 jika NaN
                        
                        user.inventory[selectedItem.name] = (user.inventory[selectedItem.name] || 0) + itemAmount;
                        rewards.push(`- +${itemAmount} ${selectedItem.name}`);
                    }
                }

                // Boss drop
                if (finalFloor === dungeon.floors && Math.random() < dungeon.rewards.bossChance) {
                    const bossDrops = [
                        { name: 'pedang', amount: 1, chance: 0.01 },
                        { name: 'busur', amount: 1, chance: 0.01 },
                        { name: 'armor', amount: 1, chance: 0.05 },
                        { name: 'potion', amount: [1, 5], chance: 0.3 },
                        { name: 'panah', amount: [1, 3], chance: 0.4 },
                        { name: 'perak', amount: [1, 5], chance: 0.14 },   
                        { name: 'uncommon', amount: [1, 3], chance: 0.15 }                                           
                    ];
                    
                    let bossDrop = null;
                    let roll = Math.random();
                    let cumulativeChance = 0;
                    
                    for (const drop of bossDrops) {
                        cumulativeChance += drop.chance;
                        if (roll <= cumulativeChance) {
                            bossDrop = drop;
                            break;
                        }
                    }
                    
                    if (bossDrop) {
                        const dropAmount = Array.isArray(bossDrop.amount) ? 
                            getRandom(bossDrop.amount[0], bossDrop.amount[1]) : 
                            parseInt(bossDrop.amount) || 1;
                        
                        user.inventory[bossDrop.name] = (user.inventory[bossDrop.name] || 0) + dropAmount;
                        rewards.push(`- +${dropAmount} ${bossDrop.name} (BOSS DROP!)`);
                    }
                }

                // Limit reward
                const limitReward = Math.min(10, Math.floor(finalFloor / 2) + getRandom(1, 3));
                user.limit += limitReward;
                rewards.push(`- +${limitReward} Limit`);

                // Floor bonus exp
                const floorBonusExp = finalFloor * 500;
                user.exp += floorBonusExp;
                if (floorBonusExp > 0) {
                    rewards.push(`- +${formatNumber(floorBonusExp)} EXP (Floor Bonus)`);
                }

                const armorDurabilityInfo = user.itemLevel.armor === 10 ? 
                    'Durability Armor : ∞' : 
                    `Durability Armor : ${newArmorUses}/${maxArmorUses}`;

                return m.reply(
                    `*DUNGEON*\n\n` +
                    `- *Dungeon* : ${dungeon.name}\n` +
                    `- *Boss* : ${dungeon.boss}\n` +
                    `- *Kesulitan* : ${dungeon.difficulty.toUpperCase()}\n` +
                    `- *Floors Completed* : ${finalFloor}/${dungeon.floors}\n\n` +
                    `*DUNGEON CLEARED*\n\n` +
                    `*Progress* :\n${completedFloors.slice(0, 5).join('\n')}${completedFloors.length > 5 ? '\n...' : ''}\n\n` +
                    `*Rewards* :\n` +
                    `${rewards.join('\n')}\n\n` +
                    `${armorDurabilityInfo}\n` +
                    `Durability Pedang : ${newPedangUses}/${maxPedangUses}\n` +
                    `Durability Busur : ${newBusurUses}/${maxBusurUses}\n` +
                    `Durability Panah : ${newPanahUses}/${maxPanahUses}\n\n` +
                    `🏆 *Dungeon Master Level* : ${user.level || 1}`
                );

            }, 120000); // 2 menit delay

        } catch (e) {
            console.error(e);
            return m.reply(Func.jsonFormat(e));
        }
    }
};