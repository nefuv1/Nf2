module.exports = {
    help: ['kandang'],
    aliases: ['pen', 'hewan'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,    
    run: async (m, { users }) => {
        const user = users;
        if (!user || !user.inventory) return m.reply("Data pengguna tidak ada di database.");

        const hewanList = [
            { name: 'burung', emoji: '🐦' },
            { name: 'ular', emoji: '🐍' },
            { name: 'kuda', emoji: '🐴' },
            { name: 'banteng', emoji: '🐃' },
            { name: 'gajah', emoji: '🐘' },
            { name: 'harimau', emoji: '🐅' },
            { name: 'kambing', emoji: '🐐' },
            { name: 'panda', emoji: '🐼' },
            { name: 'buaya', emoji: '🐊' },
            { name: 'kerbau', emoji: '🐃' },
            { name: 'sapi', emoji: '🐄' },
            { name: 'monyet', emoji: '🐒' },
            { name: 'babi', emoji: '🐖' },
            { name: 'ayam', emoji: '🐓' },
            { name: 'bebek', emoji: '🦆' },
            { name: 'kelinci', emoji: '🐇' }, 
            { name: 'kucing', emoji: '🐈' },
            { name: 'singa', emoji: '🦁' },  
            { name: 'serigala', emoji: '🐺' },
            { name: 'rubah', emoji: '🦊' },
            { name: 'naga', emoji: '🐉' }
        ];

        let owned = [];
        let count = 1;
        for (let h of hewanList) {
            const qty = user.inventory[h.name] || 0;
            if (qty > 0) {
                owned.push(`${count++}. ${h.emoji} *${h.name}* : ${qty}`);
            }
        }

        const msg = owned.length > 0
            ? `*PEN* (hewan)\n\n${owned.join('\n')}`
            : `*PEN* (hewan)\n\nKamu belum memiliki hewan di kandang.`;

        return m.reply(msg);
    }
};