const formatNumber = require('../../lib/formatNumber');

module.exports = {
    help: ['hacker'],
    aliases: ['hack', 'hck'],
    tags: 'rpg',
    register: true,
    rpg: true,
    private: true,
    group: false,
    run: async (m, { command, text, usedPrefix, users, conn }) => {
        const user = users;
        if (!user) return m.reply("Data pengguna tidak ada di database.");
        if (!user.inventory) user.inventory = {};

        if (!user.inventory.laptop || user.inventory.laptop < 1) {
            return m.reply(`Kamu membutuhkan *Laptop*.\n\nSilakan beli kirim perintah : ${usedPrefix}shop buy laptop`);
        }

        const args = text ? text.split(' ') : [];
        const subCommand = args[0]?.toLowerCase();

        function isValidSN(sn) {
            return sn && sn.length >= 5 && sn.match(/^[A-Z0-9]+$/);
        }

        const now = Date.now();
        if (!user.lastHack) user.lastHack = 0;
        const cooldown = 30000;
        const transferCooldown = 300000;

        function displayAllUserData(target, targetSN) {
            let message = `*HACKER* (path & database)\n\n`;
            message += `- *Target* : ${targetSN}\n`;
            message += `- *Username* : ${target.username || 'Unknown'}\n\n`;
            message += `db/users/\n`;
            
            const displayOrder = [
                'money', 'exp', 'level', 'healt', 'stamina', 'limit',
                'hit', 'spam', 'warning', 'premium', 'registered', 'banned',
                'ban_temporary', 'ban_times', 'lastclaim', 'lastrob', 'expired',
                'lastseen', 'usebot', 'regTime', 'age', 'lastReg', 'gender',
                'afk', 'afkReason'
            ];

            displayOrder.forEach((key, index) => {
                if (target[key] !== undefined && target[key] !== null && target[key] !== '') {
                    const isLast = index === displayOrder.length - 1 && !target.inventory;
                    
                    let value = target[key];
                    if (key === 'money') value = `${formatNumber(value)}`;
                    if (key === 'exp') value = `${formatNumber(value)}`;                    
                    if (key === 'premium' || key === 'registered' || key === 'banned') value = value ? 'Yes' : 'No';
                    if (key === 'lastseen' || key === 'regTime' || key === 'lastReg') {
                        value = new Date(value).toLocaleString();
                    }
                    
                    message += `${isLast ? ' └' : '├'} ${key} : ${value}\n`;
                }
            });

            if (target.inventory && Object.keys(target.inventory).length > 0) {
                message += `└ inventory\n`;
            }

            message += `\n*CMD*\n1. ${usedPrefix + command} ls ${targetSN} - Cek struktur path.\n`;
            message += `2. ${usedPrefix + command} ls ${targetSN} inventory - Masuk ke path tertentu.\n`;
            message += `3. ${usedPrefix + command} retas ${targetSN} money 1000 - Ambil nominal item.\n`;
            message += `4. ${usedPrefix + command} change ${targetSN} username ganti_baru - Ganti data target.\n`;

            return message;
        }

        function displaySpecificPath(target, targetSN, path) {
            let message = `*HACKER* (path & database)\n\n`;
            message += `- *Target* : ${targetSN}\n`;
            message += `- *Path* : ${path}\n\n`;

            if (path === 'inventory') {
                message += `db/users/inventory/\n`;
                const inventory = target.inventory || {};
                const items = Object.entries(inventory);
                
                if (items.length === 0) {
                    message += `└ kosong\n`;
                } else {
                    items.forEach(([item, qty], index) => {
                        const isLast = index === items.length - 1;
                        message += `${isLast ? ' └' : '├'} ${item} : ${qty}\n`;
                    });
                }
                
                message += `\n*Contoh* : ${usedPrefix + command} retas ${targetSN} inventory/Item 1\n`;
                message += `\n_Jumlah atau nominal peretasan bisa ("all" : Retas semua) atau ("1" : Retas sesuai nominal)_`;
            }
            else {
                message += `_Path "${path}" tidak ditemukan!_`;
            }

            return message;
        }

        if (subCommand === 'ls') {
            if (now - user.lastHack < cooldown) {
                const remaining = cooldown - (now - user.lastHack);
                return m.reply(`Tunggu ${Math.ceil(remaining / 1000)} detik sebelum hacking lagi.`);
            }

            const targetSN = args[1];
            const path = args[2];

            if (!targetSN) {
                return m.reply(`Format salah!\n\n*Contoh* :\n1. ${usedPrefix + command} ls 63336\n2. ${usedPrefix + command} ls 63336 inventory`);
            }

            if (!isValidSN(targetSN)) {
                return m.reply("Format SN tidak valid!\n\nGunakan kombinasi huruf / angka (min 5 karakter)");
            }

            const allUsers = global.db.users;
            const targetEntry = Object.entries(allUsers).find(([key, u]) => 
                u.regCode && u.regCode === targetSN
            );

            if (!targetEntry) {
                return m.reply(`Target dengan SN "${targetSN}" tidak ditemukan.`);
            }

            const [targetKey, target] = targetEntry;

            if (targetKey === m.sender) {
                return m.reply(`Tidak bisa hack diri sendiri!`);
            }

            const userLevel = user.level || 1;
            const targetLevel = target.level || 1;
            const levelDifference = userLevel - targetLevel;
            
            let successRate = 0.8;
            if (levelDifference > 0) successRate += (levelDifference * 0.08);
            if (levelDifference < 0) successRate -= (Math.abs(levelDifference) * 0.05);
            
            successRate = Math.max(0.5, Math.min(0.95, successRate));

            const isSuccess = Math.random() < successRate;

            if (!isSuccess) {
                user.lastHack = now;
                const penaltyChance = 0.2;
                if (Math.random() < penaltyChance) {
                    user.money = Math.max(0, (user.money || 0) - 500);
                    return m.reply(`*ACCESS DENIED!*\n\nFirewall target mendeteksi aktivitas mencurigakan!\n\nKamu didenda 500K Money karena ketahuan!`);
                }
                return m.reply(`*ACCESS DENIED!*\n\nFirewall target mendeteksi aktivitas mencurigakan!`);
            }

            let message;
            if (!path) {
                message = displayAllUserData(target, targetSN);
            } else {
                message = displaySpecificPath(target, targetSN, path);
            }
            
            if (!user.hackedTargets) user.hackedTargets = {};
            user.hackedTargets[targetSN] = {
                lastAccess: now,
                accessLevel: 'read',
                username: target.username
            };

            user.lastHack = now;
            return m.reply(message);
        }

        if (subCommand === 'retas') {
            const targetSN = args[1];
            let path = args[2];
            const amountArg = args[3]?.toLowerCase();
        
            if (!targetSN || !path) {
                return m.reply(`Format salah!\n\n*Contoh* :\n1. ${usedPrefix + command} retas 63336 money 1000\n2. ${usedPrefix + command} retas 63336 inventory/Potion all`);
            }
        
            if (!user.hackedTargets || !user.hackedTargets[targetSN]) {
                return m.reply(`Kamu belum mengakses target ini!\n\nSilakan gunakan perintah : ${usedPrefix + command} ls ${targetSN}`);
            }
        
            const lastAccess = user.hackedTargets[targetSN].lastAccess;
            if (now - lastAccess < transferCooldown) {
                const remaining = transferCooldown - (now - lastAccess);
                return m.reply(`Akses terlalu baru! Tunggu ${Math.ceil(remaining / 60000)} menit sebelum retas lagi.`);
            }
        
            const allUsers = global.db.users;
            const targetEntry = Object.entries(allUsers).find(([key, u]) => 
                u.regCode && u.regCode === targetSN
            );
        
            if (!targetEntry) {
                delete user.hackedTargets[targetSN];
                return m.reply(`Target dengan SN "${targetSN}" tidak ditemukan.`);
            }
        
            const [targetKey, target] = targetEntry;
        
            const transferableProperties = ['money', 'exp', 'healt', 'stamina', 'limit'];
            const protectedProperties = ['warning', 'premium', 'registered', 'level', 'banned', 'regCode', 'username'];
        
            let inventoryItem = null;
            if (path.startsWith('inventory/')) {
                inventoryItem = path.split('/')[1];
                path = 'inventory';
            }
        
            if (!transferableProperties.includes(path) && path !== 'inventory') {
                if (protectedProperties.includes(path)) {
                    return m.reply(`Path "${path}" dilindungi sistem dan tidak dapat diretas!`);
                }
                return m.reply(`Path "${path}" tidak valid untuk transfer.\n\nPath yang bisa diretas: ${transferableProperties.join(', ')}, inventory[/item]`);
            }
        
            let amount = 0;
            let isTakingAll = false;
        
            if (amountArg === 'all') {
                isTakingAll = true;
                if (path === 'inventory') {
                    if (!inventoryItem) {
                        return m.reply(`Untuk inventory, gunakan perintah : ${usedPrefix + command} retas ${targetSN} inventory/[item] all\n*Contoh* : ${usedPrefix + command} retas ${targetSN} inventory/Potion all`);
                    }
                } else {
                    amount = target[path] || 0;
                }
            } else {
                amount = parseInt(amountArg);
                if (!amount || amount <= 0) {
                    return m.reply(`Nominal tidak valid!\n\nGunakan angka atau "all" untuk mengambil semua.\n1. ${usedPrefix + command} retas 63336 money all\n2. ${usedPrefix + command} retas 63336 inventory/Potion 1`);
                }
            }
        
            if (path === 'inventory') {
                if (!inventoryItem && args[3] && !args[3].match(/^(all|\d+)$/i)) {
                    inventoryItem = args[3];
                }
                
                if (!inventoryItem) {
                    return m.reply(`Format salah untuk inventory!\n\n*Contoh* :\n1. ${usedPrefix + command} retas ${targetSN} inventory/Potion 1\n2. ${usedPrefix + command} retas ${targetSN} inventory/Potion all`);
                }
        
                const targetInventory = target.inventory || {};
                const userInventory = user.inventory || {};
        
                if (!targetInventory[inventoryItem] || targetInventory[inventoryItem] <= 0) {
                    return m.reply(`Item "${inventoryItem}" tidak ada di inventory target!`);
                }
        
                let takeAmount = 0;
                if (isTakingAll) {
                    takeAmount = targetInventory[inventoryItem];
                } else {
                    takeAmount = amount;
                    if (!takeAmount || takeAmount <= 0) {
                        return m.reply(`Nominal tidak valid!\n\nGunakan angka atau "all".\n- ${usedPrefix + command} retas ${targetSN} inventory/${inventoryItem} 1`);
                    }
                    if (takeAmount > targetInventory[inventoryItem]) {
                        return m.reply(`Item "${inventoryItem}" tidak mencukupi!\n\nTersedia : ${targetInventory[inventoryItem]}\nPermintaan : ${takeAmount}`);
                    }
                }
        
                const transferLimit = (user.level || 1) * 10;
                if (takeAmount > transferLimit && !isTakingAll) {
                    return m.reply(`Transfer melebihi batas! \n\nLimit transfer level ${user.level} : ${transferLimit} item`);
                }
        
                const transferSuccessRate = 0.8 + ((user.level || 1) * 0.02);
                const transferSuccess = Math.random() < Math.min(0.98, transferSuccessRate);
        
                if (!transferSuccess) {
                    user.lastHack = now;
                    delete user.hackedTargets[targetSN];
                    return m.reply(`*TRANSFER GAGAL!*\n\nSistem keamanan mendeteksi transfer tidak sah!\n\nAkses ke target ${targetSN} telah ditutup.`);
                }
        
                targetInventory[inventoryItem] -= takeAmount;
                if (targetInventory[inventoryItem] <= 0) {
                    delete targetInventory[inventoryItem];
                }
        
                userInventory[inventoryItem] = (userInventory[inventoryItem] || 0) + takeAmount;
        
                user.hackedTargets[targetSN].lastAccess = now;
        
                let message = `*HACKER*\n\n`;
                message += `- *Status* : Berhasil. 👍\n`;      
                message += `- *Target* : ${targetSN}\n`;
                message += `- *Item* : ${inventoryItem}\n`;
                message += `- *Nominal* : ${takeAmount}${isTakingAll ? ' (ALL)' : ''}\n`;
                message += `- *Sumber* : ${target.username || 'Unknown'}\n`;
                message += `- *Tujuan* : ${user.username || 'Anda'}\n\n`;
                message += `*Update Inventory*\n`;
                message += `- ${inventoryItem} Target : ${targetInventory[inventoryItem] || 0}\n`;
                message += `- ${inventoryItem} Kamu : ${userInventory[inventoryItem]}\n\n`;
                message += `_Transfer selesai dalam ${(Math.random() * 2 + 1).toFixed(2)} detik_`;
        
                user.lastHack = now;
                return m.reply(message);
            }
        
            const targetValue = target[path] || 0;
            
            if (amount > targetValue) {
                return m.reply(`Nilai di path "${path}" tidak mencukupi!\n\nNilai tersedia : ${targetValue}\nPermintaan : ${amount}`);
            }
        
            if (!isTakingAll) {
                const transferLimit = (user.level || 1) * 5000;
                if (amount > transferLimit) {
                    return m.reply(`Transfer melebihi batas!\n\nLimit transfer level ${user.level} : ${transferLimit}`);
                }
            }
        
            const transferSuccessRate = 0.8 + ((user.level || 1) * 0.02);
            const transferSuccess = Math.random() < Math.min(0.98, transferSuccessRate);
        
            if (!transferSuccess) {
                user.lastHack = now;
                delete user.hackedTargets[targetSN];
                return m.reply(`*TRANSFER GAGAL!*\n\nSistem keamanan mendeteksi transfer tidak sah!\n\nAkses ke target ${targetSN} telah ditutup.`);
            }
        
            target[path] -= amount;
            user[path] = (user[path] || 0) + amount;
        
            if (path === 'healt' && user.healt > 100) user.healt = 100;
            if (path === 'stamina' && user.stamina > 100) user.stamina = 100;
        
            user.hackedTargets[targetSN].lastAccess = now;
        
            let message = `*HACKER*\n\n`;
            message += `- *Status* : Berhasil. 👍\n`;       
            message += `- *Target* : ${targetSN}\n`;
            message += `- *Path* : ${path}\n`;
            message += `- *Nominal* : ${amount}${isTakingAll ? ' (ALL)' : ''}\n`;
            message += `- *Sumber* : ${target.username || 'Unknown'}\n`;
            message += `- *Tujuan* : ${user.username || 'Anda'}\n\n`;
            message += `*Update Nilai*\n`;
            message += `- ${path} Target : ${target[path]}\n`;
            message += `- ${path} Kamu : ${user[path]}\n\n`;
            message += `_Transfer selesai dalam ${(Math.random() * 2 + 1).toFixed(2)} detik_`;
        
            user.lastHack = now;
            return m.reply(message);
        }

        if (subCommand === 'change') {
            const targetSN = args[1];
            const path = args[2];
            const newValue = args.slice(3).join(' ');

            if (!targetSN || !path || !newValue) {
                return m.reply(`Format salah!\n\n*Contoh* : ${usedPrefix + command} change 63336 username nama_baru\n\n*Contoh penggunaan* : ${usedPrefix + command} change 63336 age 25`);
            }

            if (!user.hackedTargets || !user.hackedTargets[targetSN]) {
                return m.reply(`Kamu belum mengakses target ini!\n\nSilakan gunakan perintah : ${usedPrefix + command} ls ${targetSN}`);
            }

            const allUsers = global.db.users;
            const targetEntry = Object.entries(allUsers).find(([key, u]) => 
                u.regCode && u.regCode === targetSN
            );

            if (!targetEntry) {
                return m.reply(`Target dengan SN "${targetSN}" tidak ditemukan.`);
            }

            const [targetKey, target] = targetEntry;

            const changeableProperties = ['username', 'age', 'gender'];
            const protectedProperties = ['money', 'exp', 'level', 'regCode', 'banned', 'premium'];

            if (!changeableProperties.includes(path)) {
                if (protectedProperties.includes(path)) {
                    return m.reply(`Path "${path}" dilindungi sistem dan tidak dapat diubah!`);
                }
                return m.reply(`Path "${path}" tidak valid untuk diubah.\n\nPath yang bisa diubah : ${changeableProperties.join(', ')}`);
            }

            let validatedValue = newValue;
            if (path === 'age') {
                validatedValue = parseInt(newValue);
                if (isNaN(validatedValue) || validatedValue < 12 || validatedValue > 30) {
                    return m.reply(`Umur harus antara 12-30 tahun.`);
                }
            }
            if (path === 'gender') {
                validatedValue = newValue.toUpperCase();
                if (!['M', 'F'].includes(validatedValue)) {
                    return m.reply(`Gender harus "M" (Male) atau "F" (Female).`);
                }
            }

            const changeSuccessRate = 0.7 + ((user.level || 1) * 0.03);
            const changeSuccess = Math.random() < Math.min(0.9, changeSuccessRate);

            if (!changeSuccess) {
                user.lastHack = now;
                delete user.hackedTargets[targetSN];
                return m.reply(`*PERUBAHAN GAGAL!*\n\nSistem keamanan mendeteksi modifikasi data tidak sah!\n\nAkses ke target ${targetSN} telah ditutup.`);
            }

            const oldValue = target[path];

            target[path] = validatedValue;

            let message = `*HACKER*\n\n`;
            message += `- *Status* : Berhasil. 👍\n`;            
            message += `- *Target* : ${targetSN}\n`;
            message += `- *Path* : ${path}\n`;
            message += `- *Nilai Lama* : ${oldValue || 'Tidak ada'}\n`;
            message += `- *Nilai Baru* : ${validatedValue}\n\n`;
            message += `_Data berhasil diubah dalam ${(Math.random() * 3 + 1).toFixed(2)} detik_`;

            user.lastHack = now;
            return m.reply(message);
        }

        // DIHAPUS: Seluruh bagian targets command dihapus

        return m.reply(`*HACKER* (system)\n\n` +
            `*Persyaratan* :\n` +
            `- 1 Laptop (di inventory)\n` +
            `- *Cooldown* : 30 detik\n\n` +
            `*Perintah Tersedia* :\n` +
            `1. ${usedPrefix + command} ls [SN] - Lihat struktur / path & database\n` +
            `2. ${usedPrefix + command} ls [SN] [path] - Masuk ke path tertentu\n` +
            `3. ${usedPrefix + command} retas [SN] [path] [nominal / all] - Transfer nilai\n` +
            `4. ${usedPrefix + command} retas [SN] inventory[/item] [nominal / all] - Ambil item\n` +
            `5. ${usedPrefix + command} change [SN] [path] [nilai] - Ubah data target\n\n` +
            `*Path yang Bisa Diakses* :\n` +
            `- money, exp, healt, stamina, limit (bisa diretas)\n` +
            `- inventory (bisa ambil item)\n` +
            `- username, age, gender (bisa diubah)\n\n` +
            `*Contoh Penggunaan* :\n` +
            `1. ${usedPrefix + command} ls 10002\n` +
            `2. ${usedPrefix + command} retas 10002 money 3000\n` +
            `3. ${usedPrefix + command} retas 10002 inventory/Potion all\n` +
            `4. ${usedPrefix + command} change 10002 username nama_baru`);
    }
};