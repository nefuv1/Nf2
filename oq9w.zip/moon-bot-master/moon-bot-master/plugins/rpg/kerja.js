// versi penambahan korupsi
const formatNumber = require('../../lib/formatNumber');

module.exports = {
    help: ['kerja'],
    aliases: ['work', 'job', 'korupsi'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,    
    run: async (m, { 
        conn, 
        text, 
        usedPrefix, 
        command,
        args,
        users
    }) => {
        const userId = m.sender;
        const subCommand = args[0] ? args[0].toLowerCase() : 'status';

        if (!global.db.business) global.db.business = {
            jobListings: {},
            workers: {},
            lastPaymentCheck: Date.now(),
            corruptionLogs: {} 
        };

        const business = global.db.business;

        const getUserName = (userId) => {
            try {
                if (conn && typeof conn.getName === 'function') {
                    return conn.getName(userId) || userId;
                }
                return userId;
            } catch (error) {
                console.error('Error getting user name :', error);
                return userId;
            }
        };

        const handleCorruption = (userId) => {
            const ownedBusiness = Object.entries(business.jobListings).find(([_, job]) => 
                job.owner === userId
            );
            
            const workerJob = Object.entries(business.jobListings).find(([_, job]) => 
                job.workers.includes(userId)
            );

            if (!ownedBusiness && !workerJob) {
                return { success: false, message: "Anda tidak memiliki bisnis atau tidak bekerja di perusahaan manapun!" };
            }

            const [jobId, job] = ownedBusiness || workerJob;
            const isOwner = ownedBusiness !== undefined;
            const userRole = isOwner ? "Pemilik" : "Karyawan";

            if (job.companyEarnings < 5000000) {
                return { 
                    success: false, 
                    message: `Pendapatan perusahaan belum mencapai *5.000.000 Money*\nPendapatan saat ini : *${formatNumber(job.companyEarnings)} Money*\nMinimal untuk korupsi : *5.000.000 Money*` 
                };
            }

            const detectionChance = isOwner ? 0.4 : 0.6;
            const isCaught = Math.random() < detectionChance;

            const maxCorruptionAmount = Math.floor(job.companyEarnings * 0.3);
            const corruptionAmount = Math.floor(Math.random() * maxCorruptionAmount) + 1000000; 

            if (isCaught) {
                if (isOwner) {
                    const fineAmount = corruptionAmount * 2;
                    users.money = Math.max(0, (users.money || 0) - fineAmount);
                    
                    if (!business.corruptionLogs[jobId]) business.corruptionLogs[jobId] = [];
                    business.corruptionLogs[jobId].push({
                        userId: userId,
                        amount: corruptionAmount,
                        success: false,
                        timestamp: Date.now(),
                        role: 'owner',
                        fine: fineAmount
                    });

                    return { 
                        success: false, 
                        message: `*KERJA* (korupsi)\n\nSebagai pemilik "${job.jobName}", Anda gagal (ketahuan) mencoba korupsi sebesar *${formatNumber(corruptionAmount)} Money*!\n\n*HUKUMAN*\n- Denda : ${formatNumber(fineAmount)} Money\n- Reputasi perusahaan turun\n\n_Kelola perusahaan dengan jujur!_` 
                    };
                } else {
                    job.workers = job.workers.filter(worker => worker !== userId);
                    
                    if (!business.corruptionLogs[jobId]) business.corruptionLogs[jobId] = [];
                    business.corruptionLogs[jobId].push({
                        userId: userId,
                        amount: corruptionAmount,
                        success: false,
                        timestamp: Date.now(),
                        role: 'worker'
                    });

                    return { 
                        success: false, 
                        message: `*KERJA* (korupsi)\n\nAnda gagal (ketahuan) mencoba korupsi sebesar *${formatNumber(corruptionAmount)} Money* dari "${job.jobName}"\n\n*KONSEKUENSI*\n- *Status* : Dipecat\n- Dikeluarkan dari perusahaan\n- Tidak bisa kerja di perusahaan ini lagi\n\n_Cari pekerjaan baru dan jujur!_` 
                    };
                }
            } else {
                const stolenAmount = Math.min(corruptionAmount, job.companyEarnings);
                
                job.companyEarnings -= stolenAmount;
                
                users.money = (users.money || 0) + stolenAmount;

                if (!job.salaryDelay) job.salaryDelay = 0;
                job.salaryDelay = Math.min(job.salaryDelay + 3, 10); 

                if (!business.corruptionLogs[jobId]) business.corruptionLogs[jobId] = [];
                business.corruptionLogs[jobId].push({
                    userId: userId,
                    amount: stolenAmount,
                    success: true,
                    timestamp: Date.now(),
                    role: isOwner ? 'owner' : 'worker',
                    salaryDelay: job.salaryDelay
                });

                let message = `*KERJA* (korupsi)\n\n`;
                message += `${userRole} "${job.jobName}" berhasil mengambil *${formatNumber(stolenAmount)} Money* dari kas perusahaan!\n\n`;
                message += `*DAMPAK*\n`;
                message += `- *Pendapatan perusahaan* : ${formatNumber(job.companyEarnings)} Money\n`;
                message += `- *Gaji karyawan tertunda* : ${job.salaryDelay} cycle\n`;
                message += `- *Money Anda* : +${formatNumber(stolenAmount)} Money\n\n`;
                
                if (isOwner) {
                    message += `*Peringatan* : Terus pantau pendapatan perusahaan dan jangan serakah!`;
                } else {
                    message += `*Tips* : Bertindaklah dengan hati-hati, jangan sampai ketahuan!`;
                }

                return { success: true, message: message };
            }
        };

        if (subCommand === 'status' || !text) {
            const ownedBusiness = Object.entries(business.jobListings).filter(([_, job]) => 
                job.owner === userId
            );

            const workerJob = Object.entries(business.jobListings).find(([_, job]) => 
                job.workers.includes(userId)
            );

            let message = '';

            if (ownedBusiness.length > 0) {
                message += `PEMILIK BISNIS - ${getUserName(userId)}\n\n`;
                
                ownedBusiness.forEach(([id, job], index) => {
                    const hasWorkers = job.workers.length > 0;
                    
                    message += `BISNIS ${index + 1}: ${job.jobName}\n`;
                    message += `- *Deskripsi* : ${job.description}\n`;
                    message += `- *Karyawan* : ${job.workers.length}/${job.maxWorkers}\n`;
                    message += `- *Gaji / Karyawan* : ${formatNumber(job.salaryPerWorker)} Money\n`;
                    message += `- *Revenue / Karyawan* : ${formatNumber(job.revenuePerWorker)} Money\n`;
                    message += `- *Modal* : ${formatNumber(job.capital)} Money\n`;
                    message += `- *Total Revenue* : ${formatNumber(job.totalRevenue)} Money\n`;
                    message += `- *Total Gaji Dibayar* : ${formatNumber(job.totalSalaryPaid)} Money\n`;
                    message += `- *Pendapatan Perusahaan* : ${formatNumber(job.companyEarnings || 0)} Money\n`;
                    message += `- *Target Revenue* : ${formatNumber(job.revenueTarget)} Money\n`;
                    message += `- *Pendapatan Anda* : ${formatNumber(job.ownerEarnings)} Money\n`;
                    
                    if (job.companyEarnings >= 5000000) {
                        message += `- *Status Korupsi* : ✅ BISA (Min. 5 JT tercapai)\n`;
                    } else {
                        message += `- *Status Korupsi* : ❌ TIDAK BISA (Butuh *${formatNumber(5000000 - job.companyEarnings)} Money* lagi)\n`;
                    }
                    
                    if (job.salaryDelay > 0) {
                        message += `- *Gaji Tertunda* : ${job.salaryDelay} cycle\n`;
                    }
                    
                    message += `\n`;
                });

                message += `*Perintah Owner* :\n`;
                message += `- *${usedPrefix}kerja tutup* - Tutup bisnis\n`;
                message += `- *${usedPrefix}kerja bubarkan* - Bubarkan semua karyawan\n`;
                message += `- *${usedPrefix}korupsi* - Korupsi (jika pendapatan ≥ 5 JT)\n`;

            } else if (workerJob) {
                const [jobId, job] = workerJob;
                const totalEarned = business.workers[userId]?.totalEarned || 0;
                
                message += `KARYAWAN - ${getUserName(userId)}\n\n`;
                message += `- *Tempat Kerja* : ${job.jobName}\n`;
                message += `- *Deskripsi* : ${job.description}\n`;
                message += `- *Gaji* : ${formatNumber(job.salaryPerWorker)} Money / ${job.paymentInterval} menit\n`;
                message += `- *Total Diterima* : ${formatNumber(totalEarned)} Money\n`;
                
                if (job.companyEarnings >= 5000000) {
                    message += `- *Status Korupsi* : ⚠️ BERESIKO (Min. 5 JT tercapai)\n`;
                    message += `- *Peluang Ketahuan* : 60%\n`;
                } else {
                    message += `- *Status Korupsi* : ❌ TIDAK BISA (Butuh ${formatNumber(5000000 - job.companyEarnings)} Money lagi)\n`;
                }
                
                if (job.salaryDelay > 0) {
                    message += `- *Gaji Tertunda* : ${job.salaryDelay} cycle\n`;
                }
                
                message += `\nKirimkan perintah : ${usedPrefix}kerja keluar - Keluar dari pekerjaan\n`;
                message += `Kirimkan perintah : ${usedPrefix}korupsi - Korupsi (BERESIKO!)\n`;

            } else {
                const availableJobs = Object.entries(business.jobListings)
                    .filter(([_, job]) => job.workers.length < job.maxWorkers)
                    .map(([id, job], index) => {
                        let jobInfo = `${index + 1}. ${job.jobName} (${job.workers.length}/${job.maxWorkers} karyawan)\n`;
                        jobInfo += `   *Gaji* : ${formatNumber(job.salaryPerWorker)} Money / ${job.paymentInterval} menit\n`;
                        jobInfo += `   *Pendapatan Perusahaan* : ${formatNumber(job.companyEarnings || 0)} Money`;
                        
                        if (job.salaryDelay > 0) {
                            jobInfo += `\n   *Gaji Tertunda* : ${job.salaryDelay} cycle`;
                        }
                        
                        return jobInfo;
                    });

                message += `*KERJA* (daftar lowongan)\n\n`;
                
                if (availableJobs.length > 0) {
                    message += `${availableJobs.join('\n\n')}\n\n`;
                    message += `Kirimkan perntah : ${usedPrefix}kerja join [nomor] - Untuk melamar`;
                } else {
                    message += `Belum ada lowongan kerja tersedia.\nSilakan kirim perintah : ${usedPrefix}kerja buat - Untuk membuat bisnis.`;
                }
            }

            return m.reply(message);

        } else if (subCommand === 'korupsi') {
            const corruptionResult = handleCorruption(userId);
            return m.reply(corruptionResult.message);

        } else if (subCommand === 'buat' || subCommand === 'create') {
            const isWorker = Object.values(business.jobListings).some(job => 
                job.workers.includes(userId)
            );
            
            if (isWorker) {
                return m.reply('Anda tidak bisa membuat bisnis karena sedang bekerja di perusahaan lain. Keluar dari pekerjaan terlebih dahulu.');
            }

            const hasBusiness = Object.values(business.jobListings).some(job => 
                job.owner === userId
            );
            
            if (hasBusiness) {
                return m.reply('Anda sudah memiliki bisnis. Tutup bisnis yang ada terlebih dahulu sebelum membuat yang baru.');
            }

            const params = args.slice(1).join(' ');
            if (!params) {
                return m.reply(`*Format* : ${usedPrefix}kerja buat [nama] | [deskripsi] | [max karyawan] | [gaji] | [target revenue] | [modal] | [interval]\n\n*Contoh* : ${usedPrefix}kerja buat Restaurant | Menyajikan makanan | 5 | 100 | 100000 | 1000000 | 30\n\n*Modal* : 1.000.000 Money`);
            }

            const [jobName, description, maxWorkersStr, salaryStr, targetRevenueStr, capitalStr, intervalStr] = params.split('|').map(s => s.trim());
            
            if (!jobName || !description || !maxWorkersStr || !salaryStr || !targetRevenueStr || !capitalStr || !intervalStr) {
                return m.reply('Format salah. Pastikan semua field diisi.');
            }

            const maxWorkers = parseInt(maxWorkersStr);
            const salaryPerWorker = parseInt(salaryStr);
            const targetRevenue = parseInt(targetRevenueStr);
            const capital = parseInt(capitalStr);
            const paymentInterval = parseInt(intervalStr);

            if (isNaN(maxWorkers) || isNaN(salaryPerWorker) || isNaN(targetRevenue) || isNaN(capital) || isNaN(paymentInterval)) {
                return m.reply('Semua parameter harus berupa angka yang valid.');
            }
            
            if (capital < 1000000) return m.reply('Modal minimal *1.000.000 Money*');
            if (targetRevenue <= 0) return m.reply('Target revenue harus lebih besar dari 0');
            
            if (!users.money || users.money < capital) {
                return m.reply(`Modal tidak cukup. Dibutuhkan : ${formatNumber(capital)} Money`);
            }

            users.money -= capital;

            const jobId = `${userId}_${Date.now()}`;
            
            business.jobListings[jobId] = {
                owner: userId,
                jobName,
                description,
                maxWorkers,
                salaryPerWorker,
                revenuePerWorker: Math.floor(salaryPerWorker * 1.5),
                revenueTarget: targetRevenue,
                capital,
                paymentInterval,
                workers: [],
                createdAt: Date.now(),
                lastPayment: Date.now(),
                totalRevenue: 0,
                totalSalaryPaid: 0,
                companyEarnings: 0, 
                ownerEarnings: 0,
                lastPayout: 0,
                salaryDelay: 0 
            };

            return m.reply(`Bisnis "${jobName}" berhasil dibuat!\n\n- *Modal* : ${formatNumber(capital)} Money telah dipotong.\n- *Target revenue* : ${formatNumber(targetRevenue)} Money`);

        } else if (subCommand === 'join') {
            const jobNumber = parseInt(args[1]);
            const availableJobs = Object.entries(business.jobListings)
                .filter(([_, job]) => job.workers.length < job.maxWorkers);

            if (isNaN(jobNumber) || jobNumber < 1 || jobNumber > availableJobs.length) {
                return m.reply('Nomor pekerjaan tidak valid.');
            }

            const [jobId, job] = availableJobs[jobNumber - 1];

            const isOwner = Object.values(business.jobListings).some(j => j.owner === userId);
            if (isOwner) {
                return m.reply('Anda tidak bisa bekerja karena sudah memiliki bisnis sendiri.');
            }

            const alreadyWorking = Object.entries(business.jobListings).find(([_, j]) => 
                j.workers.includes(userId)
            );

            if (alreadyWorking) return m.reply('Anda sudah bekerja.');

            job.workers.push(userId);
            if (!business.workers[userId]) business.workers[userId] = { totalEarned: 0 };

            return m.reply(`Anda sekarang bekerja di "${job.jobName}"`);

        } else if (subCommand === 'keluar') {
            const jobEntry = Object.entries(business.jobListings).find(([_, job]) => 
                job.workers.includes(userId)
            );

            if (!jobEntry) return m.reply('Anda tidak sedang bekerja.');

            const [jobId, job] = jobEntry;
            job.workers = job.workers.filter(worker => worker !== userId);
            
            return m.reply(`Anda keluar dari "${job.jobName}"`);

        } else if (subCommand === 'tutup') {
            const ownedBusiness = Object.entries(business.jobListings).filter(([_, job]) => 
                job.owner === userId
            );

            if (ownedBusiness.length === 0) return m.reply('Anda tidak memiliki bisnis.');

            ownedBusiness.forEach(([jobId, job]) => {
                users.money += job.capital;
                if (job.companyEarnings > 0) {
                    users.money += job.companyEarnings;
                }
                delete business.jobListings[jobId];
            });

            return m.reply('Semua bisnis Anda telah ditutup. Modal dan pendapatan dikembalikan.');

        } else if (subCommand === 'bubarkan') {
            const ownedBusiness = Object.entries(business.jobListings).filter(([_, job]) => 
                job.owner === userId
            );

            if (ownedBusiness.length === 0) return m.reply('Anda tidak memiliki bisnis.');

            ownedBusiness.forEach(([jobId, job]) => {
                job.workers = [];
            });

            return m.reply('Semua karyawan telah dibubarkan.');

        } else {
            return m.reply(`Perintah tidak dikenali. Gunakan ${usedPrefix}kerja - Untuk melihat status.`);
        }
    }
};

setInterval(() => {
    if (!global.db.business) return;
    
    const business = global.db.business;
    const now = Date.now();
    
    for (const [jobId, job] of Object.entries(business.jobListings)) {
        if (now - job.lastPayment >= job.paymentInterval * 60000) {
            if (job.workers.length === 0) {
                job.lastPayment = now;
                continue;
            }
            
            const totalSalary = job.workers.length * job.salaryPerWorker;
            const companyRevenue = job.workers.length * job.revenuePerWorker;
            
            if (job.capital >= totalSalary) {
                if (job.salaryDelay > 0) {
                    job.salaryDelay--;
                    job.lastPayment = now;
                    continue;
                }
                
                job.workers.forEach(workerId => {
                    if (!business.workers[workerId]) {
                        business.workers[workerId] = { totalEarned: 0 };
                    }
                    
                    business.workers[workerId].totalEarned += job.salaryPerWorker;
                    
                    if (global.db.users[workerId]) {
                        global.db.users[workerId].money += job.salaryPerWorker;
                    }
                });
                
                job.companyEarnings += companyRevenue;
                job.totalRevenue += companyRevenue;
                
                job.capital -= totalSalary;
                job.totalSalaryPaid += totalSalary;
                
                job.lastPayment = now;
                
                if (job.companyEarnings >= job.revenueTarget) {
                    if (global.db.users[job.owner]) {
                        global.db.users[job.owner].money += job.companyEarnings;
                        job.ownerEarnings += job.companyEarnings;
                        
                        job.companyEarnings = 0;
                        job.lastPayout = now;
                    }
                }
                
            } else {
                if (global.db.users[job.owner]) {
                    if (job.companyEarnings > 0) {
                        global.db.users[job.owner].money += job.companyEarnings;
                    }
                }
                delete business.jobListings[jobId];
            }
        }
    }
}, 60000); // Cek setiap 1 menit
            
            

/** versi tanpa korupsi            
const formatNumber = require('../../lib/formatNumber');

module.exports = {
    help: ['kerja'],
    aliases: ['work', 'job'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,    
    run: async (m, { 
        conn, 
        text, 
        usedPrefix, 
        command,
        args,
        users
    }) => {
        const userId = m.sender;
        const subCommand = args[0] ? args[0].toLowerCase() : 'status';

        // Inisialisasi struktur data bisnis jika belum ada
        if (!global.db.business) global.db.business = {
            jobListings: {},
            workers: {},
            lastPaymentCheck: Date.now()
        };

        const business = global.db.business;

        // Fungsi untuk mendapatkan nama pengguna dengan aman
        const getUserName = (userId) => {
            try {
                if (conn && typeof conn.getName === 'function') {
                    return conn.getName(userId) || userId;
                }
                return userId;
            } catch (error) {
                console.error('Error getting user name :', error);
                return userId;
            }
        };

        // CEK STATUS UMUM (untuk semua user)
        if (subCommand === 'status' || !text) {
            // Cek jika user adalah owner bisnis
            const ownedBusiness = Object.entries(business.jobListings).filter(([_, job]) => 
                job.owner === userId
            );

            // Cek jika user adalah worker
            const workerJob = Object.entries(business.jobListings).find(([_, job]) => 
                job.workers.includes(userId)
            );

            let message = '';

            if (ownedBusiness.length > 0) {
                // TAMPILAN UNTUK OWNER
                message += `PEMILIK BISNIS - ${getUserName(userId)}\n\n`;
                
                ownedBusiness.forEach(([id, job], index) => {
                    const hasWorkers = job.workers.length > 0;
                    
                    message += `BISNIS ${index + 1}: ${job.jobName}\n`;
                    message += `- *Deskripsi* : ${job.description}\n`;
                    message += `- *Karyawan* : ${job.workers.length}/${job.maxWorkers}\n`;
                    message += `- *Gaji / Karyawan* : ${formatNumber(job.salaryPerWorker)} Money\n`;
                    message += `- *Revenue / Karyawan* : ${formatNumber(job.revenuePerWorker)} Money\n`;
                    message += `- *Modal* : ${formatNumber(job.capital)} Money\n`;
                    message += `- *Total Revenue* : ${formatNumber(job.totalRevenue)} Money\n`;
                    message += `- *Total Gaji Dibayar* : ${formatNumber(job.totalSalaryPaid)} Money\n`;
                    message += `- *Pendapatan Perusahaan* : ${formatNumber(job.companyEarnings || 0)} Money\n`;
                    message += `- *Target Revenue* : ${formatNumber(job.revenueTarget)} Money\n`;
                    message += `- *Pendapatan Anda* : ${formatNumber(job.ownerEarnings)} Money\n\n`;
                });

                message += `*Perintah Owner* :\n`;
                message += `- *${usedPrefix}kerja tutup* - Tutup bisnis\n`;
                message += `- *${usedPrefix}kerja bubarkan* - Bubarkan semua karyawan\n`;

            } else if (workerJob) {
                // TAMPILAN UNTUK WORKER
                const [jobId, job] = workerJob;
                const totalEarned = business.workers[userId]?.totalEarned || 0;
                
                message += `KARYAWAN - ${getUserName(userId)}\n\n`;
                message += `- *Tempat Kerja* : ${job.jobName}\n`;
                message += `- *Deskripsi* : ${job.description}\n`;
                message += `- *Gaji* : ${formatNumber(job.salaryPerWorker)} Money / ${job.paymentInterval} menit\n`;
                message += `- *Total Diterima* : ${formatNumber(totalEarned)} Money\n\n`;
                message += `Kirimkan perintah : ${usedPrefix}kerja keluar - Keluar dari pekerjaan`;

            } else {
                // TAMPILAN UNTUK PENCARI KERJA
                const availableJobs = Object.entries(business.jobListings)
                    .filter(([_, job]) => job.workers.length < job.maxWorkers)
                    .map(([id, job], index) => {
                        return `${index + 1}. ${job.jobName} (${job.workers.length}/${job.maxWorkers} karyawan)\n   *Gaji* : ${formatNumber(job.salaryPerWorker)} Money / ${job.paymentInterval} menit`;
                    });

                message += `DAFTAR LOWONGAN KERJA\n\n`;
                
                if (availableJobs.length > 0) {
                    message += `${availableJobs.join('\n\n')}\n\n`;
                    message += `Kirimkan perntah : ${usedPrefix}kerja join [nomor] - Untuk melamar`;
                } else {
                    message += `Belum ada lowongan kerja tersedia.\nKirimkan perintah : ${usedPrefix}kerja buat - Untuk membuat bisnis.`;
                }
            }

            return m.reply(message);

        // BUAT BISNIS (owner only)
        } else if (subCommand === 'buat' || subCommand === 'create') {
            // Cek jika user sudah menjadi worker di perusahaan lain
            const isWorker = Object.values(business.jobListings).some(job => 
                job.workers.includes(userId)
            );
            
            if (isWorker) {
                return m.reply('Anda tidak bisa membuat bisnis karena sedang bekerja di perusahaan lain. Keluar dari pekerjaan terlebih dahulu.');
            }

            // Cek jika user sudah memiliki bisnis
            const hasBusiness = Object.values(business.jobListings).some(job => 
                job.owner === userId
            );
            
            if (hasBusiness) {
                return m.reply('Anda sudah memiliki bisnis. Tutup bisnis yang ada terlebih dahulu sebelum membuat yang baru.');
            }

            const params = args.slice(1).join(' ');
            if (!params) {
                return m.reply(`*Format* : ${usedPrefix}kerja buat [nama] | [deskripsi] | [max karyawan] | [gaji] | [target revenue] | [modal] | [interval]\n\n*Contoh* : ${usedPrefix}kerja buat Restaurant | Menyajikan makanan | 5 | 100 | 100000 | 1000000 | 30\n\n*Modal* : 1.000.000 Money`);
            }

            const [jobName, description, maxWorkersStr, salaryStr, targetRevenueStr, capitalStr, intervalStr] = params.split('|').map(s => s.trim());
            
            if (!jobName || !description || !maxWorkersStr || !salaryStr || !targetRevenueStr || !capitalStr || !intervalStr) {
                return m.reply('Format salah. Pastikan semua field diisi.');
            }

            const maxWorkers = parseInt(maxWorkersStr);
            const salaryPerWorker = parseInt(salaryStr);
            const targetRevenue = parseInt(targetRevenueStr);
            const capital = parseInt(capitalStr);
            const paymentInterval = parseInt(intervalStr);

            // Validasi
            if (isNaN(maxWorkers) || isNaN(salaryPerWorker) || isNaN(targetRevenue) || isNaN(capital) || isNaN(paymentInterval)) {
                return m.reply('Semua parameter harus berupa angka yang valid.');
            }
            
            if (capital < 1000000) return m.reply('Modal minimal 1.000.000 Money');
            if (targetRevenue <= 0) return m.reply('Target revenue harus lebih besar dari 0');
            
            // Pastikan user memiliki cukup uang
            if (!users.money || users.money < capital) {
                return m.reply(`Modal tidak cukup. Dibutuhkan : ${formatNumber(capital)} Money`);
            }

            // Kurangi modal dari owner
            users.money -= capital;

            const jobId = `${userId}_${Date.now()}`;
            
            business.jobListings[jobId] = {
                owner: userId,
                jobName,
                description,
                maxWorkers,
                salaryPerWorker,
                revenuePerWorker: Math.floor(salaryPerWorker * 1.5), // Revenue 50% lebih tinggi dari gaji
                revenueTarget: targetRevenue,
                capital,
                paymentInterval,
                workers: [],
                createdAt: Date.now(),
                lastPayment: Date.now(),
                totalRevenue: 0,
                totalSalaryPaid: 0,
                companyEarnings: 0, // Pendapatan perusahaan yang belum dikirim ke owner
                ownerEarnings: 0,
                lastPayout: 0 // Waktu terakhir pembayaran ke owner
            };

            return m.reply(`Bisnis "${jobName}" berhasil dibuat!\n\n- *Modal* : ${formatNumber(capital)} Money telah dipotong.\n- *Target revenue* : ${formatNumber(targetRevenue)} Money`);

        // LAMAR KERJA (worker only)
        } else if (subCommand === 'join') {
            const jobNumber = parseInt(args[1]);
            const availableJobs = Object.entries(business.jobListings)
                .filter(([_, job]) => job.workers.length < job.maxWorkers);

            if (isNaN(jobNumber) || jobNumber < 1 || jobNumber > availableJobs.length) {
                return m.reply('Nomor pekerjaan tidak valid.');
            }

            const [jobId, job] = availableJobs[jobNumber - 1];

            // Cek jika user adalah owner bisnis lain
            const isOwner = Object.values(business.jobListings).some(j => j.owner === userId);
            if (isOwner) {
                return m.reply('Anda tidak bisa bekerja karena sudah memiliki bisnis sendiri.');
            }

            // Cek jika sudah bekerja
            const alreadyWorking = Object.entries(business.jobListings).find(([_, j]) => 
                j.workers.includes(userId)
            );

            if (alreadyWorking) return m.reply('Anda sudah bekerja.');

            job.workers.push(userId);
            if (!business.workers[userId]) business.workers[userId] = { totalEarned: 0 };

            return m.reply(`Anda sekarang bekerja di "${job.jobName}"`);

        // KELUAR KERJA (worker only)
        } else if (subCommand === 'keluar') {
            const jobEntry = Object.entries(business.jobListings).find(([_, job]) => 
                job.workers.includes(userId)
            );

            if (!jobEntry) return m.reply('Anda tidak sedang bekerja.');

            const [jobId, job] = jobEntry;
            job.workers = job.workers.filter(worker => worker !== userId);
            
            return m.reply(`Anda keluar dari "${job.jobName}"`);

        // TUTUP BISNIS (owner only)
        } else if (subCommand === 'tutup') {
            const ownedBusiness = Object.entries(business.jobListings).filter(([_, job]) => 
                job.owner === userId
            );

            if (ownedBusiness.length === 0) return m.reply('Anda tidak memiliki bisnis.');

            // Kembalikan modal ke owner
            ownedBusiness.forEach(([jobId, job]) => {
                users.money += job.capital;
                // Kirim pendapatan perusahaan yang belum dikirim
                if (job.companyEarnings > 0) {
                    users.money += job.companyEarnings;
                }
                delete business.jobListings[jobId];
            });

            return m.reply('Semua bisnis Anda telah ditutup. Modal dan pendapatan dikembalikan.');

        // BUBARKAN KARYAWAN (owner only)
        } else if (subCommand === 'bubarkan') {
            const ownedBusiness = Object.entries(business.jobListings).filter(([_, job]) => 
                job.owner === userId
            );

            if (ownedBusiness.length === 0) return m.reply('Anda tidak memiliki bisnis.');

            // Hapus semua karyawan
            ownedBusiness.forEach(([jobId, job]) => {
                job.workers = [];
            });

            return m.reply('Semua karyawan telah dibubarkan.');

        } else {
            return m.reply(`Perintah tidak dikenali. Gunakan ${usedPrefix}kerja - Untuk melihat status.`);
        }
    }
};

// Sistem pembayaran otomatis - dipanggil secara terpisah
setInterval(() => {
    if (!global.db.business) return;
    
    const business = global.db.business;
    const now = Date.now();
    
    for (const [jobId, job] of Object.entries(business.jobListings)) {
        // Proses pembayaran gaji dan revenue
        if (now - job.lastPayment >= job.paymentInterval * 60000) {
            if (job.workers.length === 0) {
                job.lastPayment = now;
                continue;
            }
            
            const totalSalary = job.workers.length * job.salaryPerWorker;
            const companyRevenue = job.workers.length * job.revenuePerWorker;
            
            if (job.capital >= totalSalary) {
                // Bayar gaji ke worker
                job.workers.forEach(workerId => {
                    if (!business.workers[workerId]) {
                        business.workers[workerId] = { totalEarned: 0 };
                    }
                    
                    business.workers[workerId].totalEarned += job.salaryPerWorker;
                    
                    if (global.db.users[workerId]) {
                        global.db.users[workerId].money += job.salaryPerWorker;
                    }
                });
                
                // Tambahkan revenue ke pendapatan perusahaan
                job.companyEarnings += companyRevenue;
                job.totalRevenue += companyRevenue;
                
                // Bayar gaji dari modal
                job.capital -= totalSalary;
                job.totalSalaryPaid += totalSalary;
                
                job.lastPayment = now;
                
                // Cek jika pendapatan perusahaan sudah mencapai target
                if (job.companyEarnings >= job.revenueTarget) {
                    // Kirim ke owner
                    if (global.db.users[job.owner]) {
                        global.db.users[job.owner].money += job.companyEarnings;
                        job.ownerEarnings += job.companyEarnings;
                        
                        // Reset pendapatan perusahaan
                        job.companyEarnings = 0;
                        job.lastPayout = now;
                    }
                }
                
            } else {
                // Bankruptcy
                if (global.db.users[job.owner]) {
                    // Kirim sisa pendapatan yang belum dikirim
                    if (job.companyEarnings > 0) {
                        global.db.users[job.owner].money += job.companyEarnings;
                    }
                }
                delete business.jobListings[jobId];
            }
        }
    }
}, 60000); // Cek setiap 1 menit
*/