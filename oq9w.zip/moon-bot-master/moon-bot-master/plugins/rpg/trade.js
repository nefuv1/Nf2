const formatNumber = require('../../lib/formatNumber');

// Harga pasar - update setiap 5 menit
let marketPrices = {};
let availableItems = [];

// Generate harga dasar dari global.item
function generateBasePrices() {
  const basePrices = {};
  
  for (const [itemName, itemData] of Object.entries(global.item)) {
    const basePrice = itemData.price;
    const volatility = {
      'perhiasan': 0.2, 'hewan': 0.25, 'ikan': 0.35, 
      'bibit': 0.4, 'barang': 0.3, 'buah': 0.3
    }[itemData.category] || 0.3;
    
    const min = Math.floor(basePrice * 0.7);
    const max = Math.floor(basePrice * 1.5);
    
    basePrices[itemName] = { min, max, volatility, category: itemData.category };
  }
  
  return basePrices;
}

const basePrices = generateBasePrices();

// Update harga pasar
function updateMarket() {
  marketPrices = {};
  const allItems = Object.keys(global.item);
  const itemCount = Math.floor(Math.random() * 11) + 15;
  availableItems = [];
  
  while (availableItems.length < itemCount && availableItems.length < allItems.length) {
    const randomItem = allItems[Math.floor(Math.random() * allItems.length)];
    if (!availableItems.includes(randomItem)) availableItems.push(randomItem);
  }
  
  for (const item of availableItems) {
    const priceRange = basePrices[item];
    if (priceRange) {
      const fluctuation = (Math.random() - 0.5) * 2 * priceRange.volatility;
      const basePrice = (priceRange.min + priceRange.max) / 2;
      const newPrice = Math.floor(basePrice * (1 + fluctuation));
      marketPrices[item] = Math.max(priceRange.min, Math.min(priceRange.max, newPrice));
    }
  }
}

// Inisialisasi
updateMarket();
setInterval(updateMarket, 5 * 60 * 1000);

module.exports = {
  help: ['trade'],
  aliases: ['market'],
  tags: 'rpg',
  register: true,
  rpg: true,
  group: true,
  run: async (m, { conn, Func, usedPrefix, command, text }) => {
    const userId = m.sender;
    if (!global.db.users[userId]) return m.reply('Data pengguna tidak ada di database. ');
    
    const user = global.db.users[userId];
    
    // Cek level requirement
    if (!user.level || user.level < 50) {
      return m.reply(`Kamu membutuhkan *50 Level*.\n\nLevel kamu : ${user.level || 0}`);
    }
    
    if (!user.inventory) user.inventory = {};
    if (typeof user.money !== 'number') user.money = 0;

    const args = text.split(' ');
    const cmd = args[0]?.toLowerCase();

    try {
      // Market info
      if (!cmd || cmd === 'market' || cmd === 'info') {
        let msg = `*TRADING* (pasar)\n\n`;
        msg += `- *Level* : ${user.level} ✓\n`;
        msg += `- *Items* : ${availableItems.length}\n`;
        msg += `- *Update* : 5 menit\n\n`;
        msg += `*Harga Terkini* :\n`;
        
        // Tampilkan beberapa item
        availableItems.slice(0, 10).forEach(item => {
          const price = marketPrices[item];
          const basePrice = global.item[item]?.price || 0;
          const trend = price > basePrice ? '📈' : price < basePrice ? '📉' : '➡️';
          msg += `- ${trend} ${item} || ${formatNumber(price)} Money\n`;
        });
        
        msg += `\n- *Money* : ${formatNumber(user.money)}`;
        msg += `\n\n*Contoh* : ${usedPrefix + command} beli [item] [nominal]`;
        msg += `\n*Contoh Penggunaan* : ${usedPrefix + command} beli potion 5`;        
        
        return m.reply(msg);
      }

      // Beli item
      if (cmd === 'beli' || cmd === 'buy') {
        const item = args[1]?.toLowerCase();
        let qty = parseInt(args[2]);

        if (!item) return m.reply(`*Format* : ${usedPrefix + command} beli [item] [nominal]`);
        if (!availableItems.includes(item)) return m.reply(`"${item}" tidak tersedia!`);
        
        if (!qty || qty < 1) qty = 1;

        const total = marketPrices[item] * qty;
        if (user.money < total) {
          return m.reply(`Money kamu tidak mencukupi!\n\nDibutuhkan : ${formatNumber(total)} Money`);
        }

        user.inventory[item] = (user.inventory[item] || 0) + qty;
        user.money -= total;

        let msg = `*TRADING* (buy)\n\n`;
        msg += `- *Item* : ${item}\n`;
        msg += `- *Harga* : ${formatNumber(marketPrices[item])}/item\n`;
        msg += `- *Total* : ${formatNumber(total)}\n`;
        msg += `- *Nominal* : ${user.inventory[item]}\n`;
        msg += `- *Sisa Money* : ${formatNumber(user.money)}`;

        return m.reply(msg);
      }

      // Help default
      return m.reply(`*TRADING* (sistem)\n
*Perintah* :
1. ${usedPrefix + command} market - Lihat pasar
2. ${usedPrefix + command} beli [item] [nominal] - Beli item

*Info* :
- Harga update 5 menit
- Level required : 50 ✓
- Money : ${formatNumber(user.money)}`);

    } catch (e) {
      console.error(e);
      throw Func.jsonFormat(e)
    }
  }
};