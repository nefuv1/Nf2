const formatNumber = require('../../lib/formatNumber')

module.exports = {
  help: ['bansos'],
  tags: 'rpg',
  register: true,
  rpg: true,
  group: true,      
  run: async (m, { conn, usedPrefix, command, Func }) => {
    const userId = m.sender;
    
    // FIX: Akses langsung ke global.db.users
    if (!global.db.users[userId]) {
      return m.reply(`Data pengguna tidak terdaftar di database`);
    }
    const user = global.db.users[userId];

    // Cooldown bansos 24 jam
    const cooldown = 24 * 60 * 60 * 1000; // 24 jam
    const now = Date.now();
    
    if (user.lastBansos && (now - user.lastBansos < cooldown)) {
      const remaining = cooldown - (now - user.lastBansos);
      const hours = Math.floor(remaining / (60 * 60 * 1000));
      const minutes = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000));
      const seconds = Math.floor((remaining % (60 * 1000)) / 1000);
      
      return m.reply(`Tunggu ${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')} sebelum mengambil bansos lagi.`);
    }

    // Random rewards untuk bansos
    const rewards = {
      money: Math.floor(Math.random() * 50000) + 10000, // 10k - 60k
      exp: Math.floor(Math.random() * 1000) + 500,      // 500 - 1500 exp
      limit: Math.floor(Math.random() * 5) + 1,         // 1 - 5 limit
    };

    // Random items dari daftar (hanya untuk inventory)
    const itemsList = ['garam', 'ayam', 'semangka', 'apel', 'jeruk', 'mangga', 'potion', 'ikan'];
    const randomItem = itemsList[Math.floor(Math.random() * itemsList.length)];
    const itemQuantity = Math.floor(Math.random() * 3) + 1; // 1-3 quantity

    // FIX: Update user data langsung ke global.db.users
    user.money = (user.money || 0) + rewards.money;
    user.exp = (user.exp || 0) + rewards.exp;
    user.limit = (user.limit || 0) + rewards.limit;
    
    // Add item to inventory (hanya item yang masuk inventory)
    if (!user.inventory) user.inventory = {};
    user.inventory[randomItem] = (user.inventory[randomItem] || 0) + itemQuantity;
    
    user.lastBansos = now;

    // Format message
    const message = `*BANSOS*\n\n` +
      `🤝 Kamu mendapatkan bansos dari developer :\n` +
      `- +${formatNumber(rewards.money)} Money\n` +
      `- +${formatNumber(rewards.exp)} EXP\n` +
      `- +${rewards.limit} Limit\n` +
      `- +${itemQuantity} ${randomItem.charAt(0).toUpperCase() + randomItem.slice(1)}`;

    await conn.reply(m.chat, message, m);
  }
};