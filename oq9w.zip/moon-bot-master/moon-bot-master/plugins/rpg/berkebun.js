const formatNumber = require('../../lib/formatNumber');
const moment = require('moment-timezone');
const timeout = 60000; // 1 menit cooldown

// Set timezone ke Indonesia
const timezone = 'Asia/Jakarta';

function addToInventory(user, item, qty) {
    if (!user.inventory) user.inventory = {};
    user.inventory[item] = (user.inventory[item] || 0) + qty;
}

function removeFromInventory(user, item, qty) {
    if (!user.inventory || !user.inventory[item] || user.inventory[item] < qty) {
        return false;
    }
    user.inventory[item] -= qty;
    if (user.inventory[item] <= 0) {
        delete user.inventory[item];
    }
    return true;
}

function formatDate(timestamp) {
    return moment(timestamp).tz(timezone).format('DD/MM/YYYY HH:mm');
}

function msToTime(ms) {
    const hours = Math.floor(ms / 3600000);
    const minutes = Math.floor((ms % 3600000) / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    return `${hours} jam ${minutes} menit ${seconds} detik`;
}

module.exports = {
    help: ['berkebun'],
    aliases: ['tanam', 'gardening', 'farm', 'plant'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,    
    run: async (m, { command, Func, text, usedPrefix, users }) => {
        const user = users;
        if (!user) return m.reply("Data pengguna tidak ada di database.");
        if (!user.inventory) user.inventory = {};
        
        // Inisialisasi kebun user jika belum ada
        if (!user.kebun) user.kebun = {
            lastPlant: 0,
            plants: []
        };

        // Pastikan plants adalah array
        if (!Array.isArray(user.kebun.plants)) {
            user.kebun.plants = [];
        }

        const args = text ? text.split(' ') : [];
        const subCommand = args[0]?.toLowerCase();

        if (!subCommand) {
            const now = Date.now();
            let message = `*GARDENING* (status)\n\n`;

            // FIX: Tambahkan pengecekan array sebelum menggunakan filter
            const finishedPlants = user.kebun.plants && Array.isArray(user.kebun.plants) 
                ? user.kebun.plants.filter(plant => 
                    plant && plant.plantTime && (now - plant.plantTime >= 3600000)
                  )
                : [];

            if (finishedPlants.length > 0) {
                let totalHarvest = 0;
                let harvestDetails = [];

                finishedPlants.forEach(plant => {
                    if (!plant) return; // Skip jika plant undefined
                    
                    // 1 bibit = 3-6 buah
                    const fruitYield = plant.quantity * (Math.floor(Math.random() * 4) + 3);
                    const fruitKey = plant.fruitName;
                    
                    addToInventory(user, fruitKey, fruitYield);
                    totalHarvest += fruitYield;
                    harvestDetails.push(`• ${plant.fruitName}: +${fruitYield} buah`);
                });

                // HAPUS TANAMAN YANG SUDAH DIPANEN
                user.kebun.plants = user.kebun.plants && Array.isArray(user.kebun.plants)
                    ? user.kebun.plants.filter(plant => 
                        plant && plant.plantTime && (now - plant.plantTime < 3600000)
                      )
                    : [];

                message += `*GARDENING* (panen)\n\n`;
                message += `*Total Hasil* : ${totalHarvest} buah\n\n`;
                message += `*Detail Panen* :\n`;
                message += harvestDetails.join('\n');
                message += `\n\n_Buah telah masuk ke inventory!_\n\n`;
                message += `━━━━━━━━━━━━━━━━━━━━\n\n`;
            }

            const activePlants = user.kebun.plants && Array.isArray(user.kebun.plants) 
                ? user.kebun.plants 
                : [];

            if (activePlants.length === 0) {
                message += `*Tanaman Aktif* : Tidak ada\n\n`;
                message += `*Cara Menanam* :\n`;
                message += `- ${usedPrefix}berkebun bibit mangga 5\n`;
                message += `- ${usedPrefix}berkebun bibit mangga 3 | lemon 2\n\n`;
                message += `*Waktu Tumbuh* : 1 jam\n`;
                message += `*Maksimal Kebun* : 3 kebun per user`;
            } else {
                message += `*Tanaman Aktif* : ${activePlants.length}/3\n\n`;
                
                activePlants.forEach((plant, index) => {
                    if (!plant) return; // Skip jika plant undefined
                    
                    const timeLeft = plant.plantTime + 3600000 - now;
                    const progress = Math.min(100, Math.floor((now - plant.plantTime) / 36000));
                    
                    message += `*Kebun ${index + 1}*\n`;
                    message += `- *Bibit* : ${plant.bibitName}\n`;
                    message += `- *Jumlah* : ${plant.quantity} bibit\n`;
                    message += `- *Ditanam* : ${formatDate(plant.plantTime)}\n`;
                    message += `- *Progress* : ${progress}% \n`;
                    
                    if (timeLeft > 0) {
                        message += `- *Sisa* : ${msToTime(timeLeft)}\n`;
                    } else {
                        message += `- *Status* : Panen\n`;
                    }
                    message += `\n`;
                });
                
                message += `_Buah akan otomatis masuk ke inventory saat panen!_`;
            }
            
            return m.reply(message);
        }

        if (subCommand === 'bibit') {
            const now = Date.now();
            
            // Cek cooldown
            if (now - user.kebun.lastPlant < timeout) {
                const remaining = timeout - (now - user.kebun.lastPlant);
                const remainingTime = msToTime(remaining);
                return m.reply(`Tunggu ${remainingTime} sebelum menanam lagi.`);
            }

            // CEK BATAS MAKSIMAL 3 KEBUN
            const activePlantCount = user.kebun.plants && Array.isArray(user.kebun.plants) 
                ? user.kebun.plants.length 
                : 0;
            
            if (activePlantCount >= 3) {
                return m.reply(`Kamu sudah mencapai batas maksimal 3 kebun!\n\nGunakan *${usedPrefix}berkebun* untuk melihat progress dan panen tanaman yang sudah siap.`);
            }

            const plantingArgs = args.slice(1).join(' ');
            if (!plantingArgs) {
                return m.reply(`Format salah!\n\n*Contoh* :\n- ${usedPrefix}berkebun bibit mangga 5\n- ${usedPrefix}berkebun bibit mangga 3 | lemon 2\n\n*Bibit tersedia* : Semangka, Apel, Pisang, Anggur, Mangga, Jeruk, Stroberi, Persik, Pir, Lemon, Kiwi, Cherry`);
            }

            // Parse multiple planting format
            const plantingList = [];
            if (plantingArgs.includes('|')) {
                // Format: bibit mangga 3|lemon 2
                const parts = plantingArgs.split('|');
                for (const part of parts) {
                    const [bibitName, quantityStr] = part.trim().split(' ');
                    const quantity = parseInt(quantityStr) || 1;
                    if (bibitName) {
                        plantingList.push({ 
                            bibitName: bibitName.charAt(0).toUpperCase() + bibitName.slice(1).toLowerCase(), 
                            quantity 
                        });
                    }
                }
            } else {
                // Format: bibit mangga 5
                const bibitName = args[1];
                const quantity = parseInt(args[2]) || 1;
                if (bibitName) {
                    plantingList.push({ 
                        bibitName: bibitName.charAt(0).toUpperCase() + bibitName.slice(1).toLowerCase(), 
                        quantity 
                    });
                }
            }

            if (plantingList.length === 0) {
                return m.reply(`Format tidak valid!\n\n*Contoh* : ${usedPrefix}berkebun bibit mangga 5`);
            }

            // CEK JUMLAH TOTAL KEBUN YANG AKAN DITANAM TIDAK MELEBIHI BATAS
            const totalNewPlants = plantingList.length;
            if (activePlantCount + totalNewPlants > 3) {
                return m.reply(`Kamu hanya bisa memiliki maksimal 3 kebun!\n\n*Kebun aktif* : ${activePlantCount}\n*Kebun baru* : ${totalNewPlants}\n\nKurangi jumlah jenis bibit atau panen dulu kebun yang sudah siap.`);
            }

            // Validasi bibit
            const validbibits = ['bibitsemangka', 'bibitapel', 'bibitpisang', 'bibitanggur', 'bibitmangga', 
                               'bibitjeruk', 'bibitstroberi', 'bibitpersik', 'bibitpir', 'bibitlemon', 
                               'bibitkiwi', 'bibitcherry'];

            const plantingResults = [];

            for (const planting of plantingList) {
                if (!validbibits.includes(`bibit${planting.bibitName.toLowerCase()}`)) {
                    return m.reply(`Bibit "${planting.bibitName}" tidak valid! 👎\n\nBibit tersedia : Semangka, Apel, Pisang, Anggur, Mangga, Jeruk, Stroberi, Persik, Pir, Lemon, Kiwi, Cherry`);
                }

                const bibitKey = `bibit${planting.bibitName.toLowerCase()}`;
                if (!user.inventory[bibitKey] || user.inventory[bibitKey] < planting.quantity) {
                    return m.reply(`Kamu tidak memiliki ${planting.quantity} bibit ${planting.bibitName}!\n\nKamu punya : ${user.inventory[bibitKey] || 0} bibit`);
                }

                plantingResults.push(planting);
            }

            // Kurangi bibit dari inventory & tambahkan ke kebun
            for (const planting of plantingResults) {
                const bibitKey = `bibit${planting.bibitName.toLowerCase()}`;
                removeFromInventory(user, bibitKey, planting.quantity);
                
                // Pastikan plants adalah array sebelum push
                if (!Array.isArray(user.kebun.plants)) {
                    user.kebun.plants = [];
                }
                
                // Tambahkan ke kebun dengan waktu terpisah
                user.kebun.plants.push({
                    bibitName: planting.bibitName,
                    quantity: planting.quantity,
                    plantTime: now, // Setiap kebun punya waktu tanam sendiri
                    fruitName: planting.bibitName
                });
            }

            user.kebun.lastPlant = now;

            let message = `*GARDENING*\n\n`;
            message += `*Mulai Tanam* : ${formatDate(now)}\n`;
            message += `*Waktu Tumbuh* : 1 jam\n`;
            message += `*Kebun Aktif* : ${activePlantCount + plantingResults.length}/3\n\n`;
            message += `*Detail* :\n`;
            
            plantingResults.forEach(planting => {
                message += `- ${planting.bibitName} : ${planting.quantity} bibit\n`;
            });
            
            message += `\n*Info* :\n`;
            message += `1. Buah akan otomatis masuk ke inventory setelah 1 jam\n`;
            message += `2. Gunakan perintah ${usedPrefix}berkebun - untuk cek progress\n`;
            message += `3. Maksimal 3 kebun per user`;

            return m.reply(message);
        }

        return m.reply(`*GARDENING*\n\n` +
            `*Cara Pakai* :\n` +
            `- ${usedPrefix}berkebun - Cek status & auto panen\n` +
            `- ${usedPrefix}berkebun bibit mangga 5 - (Tanam bibit)\n` +
            `- ${usedPrefix}berkebun bibit mangga 3 | lemon 2 - (Tanam banyak)\n\n` +
            `*Waktu Tumbuh* : 1 jam\n` +
            `*Maksimal Kebun* : 3 kebun per user\n\n` +
            `*Bibit tersedia* :\n` +
            `Semangka, Apel, Pisang, Anggur, Mangga, Jeruk,\n` +
            `Stroberi, Persik, Pir, Lemon, Kiwi, Cherry`);
    }
};

setInterval(() => {
    if (!global.db || !global.db.users) return;
    
    const now = Date.now();
    Object.values(global.db.users).forEach(user => {
        if (user.kebun && user.kebun.plants && Array.isArray(user.kebun.plants)) {
            const finishedPlants = user.kebun.plants.filter(plant => 
                plant && plant.plantTime && (now - plant.plantTime >= 3600000)
            );

            finishedPlants.forEach(plant => {
                if (!plant) return;
                const fruitYield = plant.quantity * (Math.floor(Math.random() * 4) + 3);
                const fruitKey = plant.fruitName;
                addToInventory(user, fruitKey, fruitYield);
            });

            user.kebun.plants = user.kebun.plants.filter(plant => 
                plant && plant.plantTime && (now - plant.plantTime < 3600000)
            );
        }
    });
}, 60000); // Cek setiap 1 menit