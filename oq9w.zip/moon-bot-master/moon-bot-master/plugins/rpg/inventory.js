const formatNumber = require('../../lib/formatNumber');

module.exports = {
    help: ['inventory'],
    aliases: ['inv', 'inventori', 'bag'],
    tags: 'rpg',
    register: true,
    rpg: true,
    group: true,
    run: async (m, { conn, text, usedPrefix, command, users, Func }) => {
        try {
            
            let target;
            if (m.mentionedJid.length > 0) {
                target = m.mentionedJid[0];
            } else if (text) {
                let match = text.match(/@(\d+)/);
                if (match) target = match[1] + '@s.whatsapp.net';
            } else {
                target = m.sender;
            }

            let user = global.db.users[target];
            if (!user) {
                return m.reply('Data pengguna tidak ada di database.');
            }

            if (!user.inventory) user.inventory = {};
            if (!user.registered) {
                return m.reply(`Pengguna belum terdaftar di database.`);
            }

            // Ambil role berdasarkan level
            const roleData = Func.role(user.level);
            const roleName = roleData?.name || 'Unranked';
            user.role = roleName;

            // Kategorikan item berdasarkan global.item
            const categories = {
                bibit: [],
                barang: [],
                buah: [],
                ikan: [],
                perhiasan: [],
                hewan: []
            };

            // Loop melalui inventory user dan kategorikan
            Object.entries(user.inventory).forEach(([itemName, quantity]) => {
                if (quantity > 0) {
                    const itemInfo = global.item[itemName];
                    if (itemInfo) {
                        const category = itemInfo.category;
                        if (categories[category]) {
                            categories[category].push({
                                name: itemName,
                                quantity: quantity,
                                price: itemInfo.price
                            });
                        }
                    } else {
                        categories.barang.push({
                            name: itemName,
                            quantity: quantity,
                            price: 0
                        });
                    }
                }
            });

            // Format pesan inventory
            let message = `*INVENTORY*\n\n`;
            message += `- *Username* : ${user.username || 'Unknown'}\n`;
            message += `- *Role* : ${roleName}\n`;
            message += `- *Level* : ${user.level || 1}\n\n`;

            // Bibit
            if (categories.bibit.length > 0) {
                message += `*Bibit*\n`;
                categories.bibit.forEach((item, index) => {
                    message += `${index + 1}. ${item.name} : ${formatNumber(item.quantity)}\n`;
                });
                message += `\n`;
            }

            // Barang
            if (categories.barang.length > 0) {
                message += `*Barang*\n`;
                categories.barang.forEach((item, index) => {
                    message += `${index + 1}. ${item.name} : ${formatNumber(item.quantity)}\n`;
                });
                message += `\n`;
            }

            // Buah
            if (categories.buah.length > 0) {
                message += `*Buah*\n`;
                categories.buah.forEach((item, index) => {
                    message += `${index + 1}. ${item.name} : ${formatNumber(item.quantity)}\n`;
                });
                message += `\n`;
            }

            // Ikan
            if (categories.ikan.length > 0) {
                message += `*Ikan*\n`;
                categories.ikan.forEach((item, index) => {
                    message += `${index + 1}. ${item.name} : ${formatNumber(item.quantity)}\n`;
                });
                message += `\n`;
            }

            // Perhiasan
            if (categories.perhiasan.length > 0) {
                message += `*Perhiasan*\n`;
                categories.perhiasan.forEach((item, index) => {
                    message += `${index + 1}. ${item.name} : ${formatNumber(item.quantity)}\n`;
                });
                message += `\n`;
            }

            // Hewan
            if (categories.hewan.length > 0) {
                message += `*Hewan*\n`;
                categories.hewan.forEach((item, index) => {
                    message += `${index + 1}. ${item.name} : ${formatNumber(item.quantity)}\n`;
                });
                message += `\n`;
            }

            // Cek jika inventory kosong
            const totalItems = Object.values(categories).reduce((total, category) => total + category.length, 0);
            if (totalItems === 0) {
                message += `*Inventory Kosong*\n`;
                message += `_Silakan berbelanja dulu di : ${usedPrefix}shop_\n\n`;
            }

            // Tambahan: Deteksi durability dan itemLevel
            if (user.durability && typeof user.durability === 'object' && Object.keys(user.durability).length > 0) {
                message += `*Durability*\n`;
                Object.entries(user.durability).forEach(([item, value], index) => {
                    message += `${index + 1}. ${item} : ${value}\n`;
                });
                message += `\n`;
            }

            if (user.itemLevel && typeof user.itemLevel === 'object' && Object.keys(user.itemLevel).length > 0) {
                message += `*Item Level*\n`;
                Object.entries(user.itemLevel).forEach(([item, level], index) => {
                    message += `${index + 1}. ${item} : Lv. ${level}\n`;
                });
                message += `\n`;
            }

            // Total item dan nilai inventory
            const totalInventoryValue = Object.entries(user.inventory).reduce((total, [itemName, quantity]) => {
                const itemInfo = global.item[itemName];
                if (itemInfo) {
                    return total + (itemInfo.price * quantity);
                }
                return total;
            }, 0);

            message += `*Statistik*\n`;
            message += `- *Total Item* : ${Object.keys(user.inventory).length}\n`;
            message += `- *Total Kuantitas* : ${Object.values(user.inventory).reduce((sum, qty) => sum + qty, 0)}\n`;
            message += `- *Nilai Inventory* : ${formatNumber(totalInventoryValue)} Money`;

            if (target !== m.sender) {
                const tagText = `@${target.split('@')[0]}`;
                message += `\n\nInventory milik : ${tagText}`;
            }

            const options = target !== m.sender ? { mentions: [target] } : {};
            
            return conn.reply(m.chat, message, m, options);

        } catch (e) {
            console.error(e);
            return conn.reply(m.chat, Func.jsonFormat(e), m);
        }
    }
};