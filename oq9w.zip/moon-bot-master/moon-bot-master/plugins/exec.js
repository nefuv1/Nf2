/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const { exec } = require('child_process')
const syntax = require('syntax-error')

module.exports = { 
   run: async (m, {
      conn,
      body,
      ctx,
      isOwner,
      Func,
      participants,
      Scraper
   }) => {
      if (typeof body === 'object' || !isOwner) return
      let command, text
      let x = body && body.trim().split`\n`,
         y = ''
      command = x[0] ? x[0].split` `[0] : ''
      y += x[0] ? x[0].split` `.slice`1`.join` ` : '', y += x ? x.slice`1`.join`\n` : ''
      text = y.trim()
      if (!text) return
      if (command === '=>') {
         try {
            var evL = await eval(`(async () => { return ${text} })()`)
            conn.reply(m.chat, Func.jsonFormat(evL), m)
         } catch (e) {
            let err = await syntax(text)
            m.reply(typeof err != 'undefined' ? Func.texted('monospace', err) + '\n\n' : '' + require('util').format(e))
         }
      } else if (command === '>') {
         try {
            var evL = await eval(`(async () => { ${text} })()`)
            m.reply(Func.jsonFormat(evL))
         } catch (e) {
            let err = await syntax(text)
            m.reply(typeof err != 'undefined' ? Func.texted('monospace', err) + '\n\n' : '' + Func.jsonFormat(e))
         }
      } else if (command == '$') {
         conn.sendReact(m.chat, global.react, m.key)
         exec(text.trim(), (err, stdout) => {
            if (err) return m.reply(err.toString())
            if (stdout) return m.reply(stdout.toString())
         })
      }
   },
   error: false
}