module.exports = {
   help: ['+block', '-unblock'],
   tags: 'owner',
   aliases: ['block', 'unblock'],
   owner: true,
   run: async (m, { conn, command, text, Func, usedPrefix }) => {
      try {
         const input = m?.mentionedJid?.[0] || m?.quoted?.sender || text
         if (!input) return m.reply(`Please tag/reply to user chat.\n\n*Example* : ${usedPrefix + command} @tag`)

         const p = await conn.onWhatsApp(input.trim())
         if (!p.length) return m.reply(`Invalid number.`)

         const jid = conn.decodeJid(p[0].jid)
         if (jid === conn.decodeJid(conn.user.id))
            return m.reply(`Can't block myself.`)

         if (command === 'block' || command === '+block') {
            await conn.updateBlockStatus(jid, 'block')
            m.reply(`@${jid.split`@`[0]} You have been blocked. 👍`)
         }

         if (command === 'unblock' || command === '-unblock') {
            await conn.updateBlockStatus(jid, 'unblock')
            m.reply(`@${jid.split`@`[0]} You have been unblocked. 👍`)
         }
      } catch (e) {
         conn.reply(m.chat, Func.jsonFormat(e), m)
      }
   }
}