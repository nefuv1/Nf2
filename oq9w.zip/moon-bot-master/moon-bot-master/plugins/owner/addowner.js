module.exports = {    
   help: ['+owner', '-owner'],    
   tags: 'owner',    
   aliases: ['addowner', 'delowner'],  
   owner: true,  
   run: async (m, { conn, command, text, Func, usedPrefix }) => {    
      try {    
         const input = m?.mentionedJid?.[0] || m?.quoted?.sender || text    
         if (!input) return m.reply(`Please @tag / reply to user chat.\n\n*Example* : ${usedPrefix + command} @tag`)    
    
         const p = await conn.onWhatsApp(input.trim())    
         if (!p.length) return m.reply(`Invalid number.`)    
    
         const jid = conn.decodeJid(p[0].jid)    
         const number = jid.replace(/@.+/, '')    
         let owners = global.db.setting.owners   
    
         if (command === '+owner' || command === 'addowner') {    
            if (owners.includes(number))     
               return m.reply(`This user is already an owner.`)    
            owners.push(number)    
            m.reply(`@${number} You have been added as owner. 👍`)    
         }     
    
         if (command === '-owner' || command === 'delowner') {    
            if (!owners.includes(number))     
               return m.reply(`This user is not the owner.`)    
            global.db.setting.owners = owners.filter(v => v !== number)    
            m.reply(`@${number} You are removed from the owner. 👎`)    
         }    
      } catch (e) {    
         conn.reply(m.chat, Func.jsonFormat(e), m)    
      }    
   }
}