module.exports = {
   help: ['setmenu'],
   tags: 'owner',
   owner: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      args,
      setting,
      text,
      Func
   }) => {
      try {
         if (!args || !args[0]) return m.reply(`*Example* : ${usedPrefix + command} 2`)
         if (!['1', '2', '3'].includes(args[0])) return m.reply(`Styles "${text}" is not available!`)
         conn.reply(m.chat, `Done. 👍`, m).then(() => setting.style = parseInt(args[0]))
      } catch (e) {
         conn.reply(m.chat, Func.jsonFormat(e), m)
      }
   }
}