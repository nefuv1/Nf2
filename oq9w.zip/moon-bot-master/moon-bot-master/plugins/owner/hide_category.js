module.exports = {
  help: ['+hide', '-hide'],
  aliases: ['hide', 'nohide'],
  tags: 'owner',
  owner: true,
  run: async (m, { conn, text, command, usedPrefix, plugins, setting, Func }) => {
    try {
      let allCategories = [...new Set([...plugins.values()].map(p => p.tags).filter(t => t && t !== 'main'))];
      
      let targets = text.toLowerCase().split(' ').filter(t => t);
      
      if (!targets.length) {
        let list = `*All Categories* :\n`;
        allCategories.forEach(cat => {
          const isHidden = setting.hidden?.includes(cat);
          list += `- ${cat}${isHidden ? ' ✓' : ''}\n`;
        });
        
        let examples = `\n*Example* : ${usedPrefix + command} admin`;
        
        return m.reply(`Please specify a category.\n\n${list}${examples}`);
      }

      // Tentukan apakah ini hide atau nohide
      const isHide = command === '+hide' || command === 'hide';
      const isNoHide = command === '-hide' || command === 'nohide';

      if (targets.includes('all')) {
        if (isHide) {
          setting.hidden = [...new Set([...setting.hidden || [], ...allCategories])];
          await conn.reply(m.chat, `All categories (${allCategories.length}) are now hidden. 👍`, m);
        } else if (isNoHide) {
          let removedCount = setting.hidden?.length || 0;
          setting.hidden = [];
          await conn.reply(m.chat, `All categories (${removedCount}) are no longer hidden. 👍`, m);
        }
        return;
      }

      let invalid = targets.filter(t => !allCategories.includes(t));
      if (invalid.length) return conn.reply(m.chat, `"${invalid.join(', ')}" not found.`, m);

      if (isHide) {
        let alreadyHidden = targets.filter(t => setting.hidden?.includes(t));
        let newTargets = targets.filter(t => !setting.hidden?.includes(t));
        
        if (newTargets.length) {
          setting.hidden = [...new Set([...setting.hidden || [], ...newTargets])];
          await conn.reply(m.chat, `"${newTargets.join(', ')}" is temporarily hidden. 👍`, m);
        }
        
        if (alreadyHidden.length) {
          await conn.reply(m.chat, `"${alreadyHidden.join(', ')}" already hidden.`, m);
        }
        
      } else if (isNoHide) {
        if (!setting.hidden?.length) return conn.reply(m.chat, `No hidden categories.`, m);
        
        let notHidden = targets.filter(t => !setting.hidden.includes(t));
        let removedTargets = targets.filter(t => setting.hidden.includes(t));
        
        if (removedTargets.length) {
          setting.hidden = setting.hidden.filter(cat => !removedTargets.includes(cat));
          await conn.reply(m.chat, `"${removedTargets.join(', ')}" is no longer hidden. 👍`, m);
        }
        
        if (notHidden.length) {
          await conn.reply(m.chat, `"${notHidden.join(', ')}" not in hidden list.`, m);
        }
      }
    } catch (e) {
      conn.reply(m.chat, Func.jsonFormat(e), m);
    }
  }
};