const { readFileSync } = require('fs')
module.exports = {
   help: ['restore'],
   tags: 'owner',
   owner: true,
   run: async (m, {
      conn,
      command,
      database,
      env,
      Func
   }) => {
      try {
         if (m.quoted && /document/.test(m.quoted.mtype) && /json/.test(m.quoted.fileName)) {
            const fn = await Func.getFile(await m.quoted.download())
            if (!fn.status) return m.reply(`File cannot be downloaded.`)
            global.db = JSON.parse(readFileSync(fn.file, 'utf-8'))
            conn.reply(m.chat, 'Done. 👍', m).then(async () => {
               await database.save(JSON.parse(readFileSync(fn.file, 'utf-8')))
            })
         } else conn.reply(m.chat, `Please reply to the data.json backup file.`, m)
      } catch (e) {
         return conn.reply(m.chat, Func.jsonFormat(e), m)
      }
   }
}