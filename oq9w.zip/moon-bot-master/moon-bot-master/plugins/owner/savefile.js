const fs = require('fs')
const path = require('path')

module.exports = {
   help: ['savefile'],
   aliases: ['sf'],
   tags: 'owner',
   owner: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      Func
   }) => {
      try {
         if (!text) return m.reply(`*Example* : ${usedPrefix + command} plugins/owner/fuck.js`)
         if (!m.quoted) return m.reply('Please reply to the script')
         const filePath = path.resolve(process.cwd(), text)
         const dir = path.dirname(filePath)
         if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true })
         }
         if (m.quoted.mimetype) {
            const buff = await m.quoted.download()
            fs.writeFileSync(filePath, buff)
            conn.reply(m.chat, `The document file was successfully saved *${text}*`, m)
         } else if (m.quoted.text) {
            fs.writeFileSync(filePath, m.quoted.text, 'utf-8')
            conn.reply(m.chat, `Done saved \`\`\`${text}\`\`\` 👍`, m);
         } else {
            conn.reply(m.chat, 'Please reply to the script', m)
         }
      } catch (e) {
         conn.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false
}