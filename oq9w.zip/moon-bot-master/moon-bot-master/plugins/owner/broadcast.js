module.exports = {
  help: ['bc', 'bcgc'],
  tags: 'owner',
  owner: true,
  run: async (m, { conn, command, text, Func }) => {
    try {
      const q = m.quoted || m
      const mime = (q.msg || q).mimetype || ''
      const ids = command == 'bc'
        ? Object.keys(global.db.chats).filter(v => v.endsWith('.net'))
        : Object.keys(global.db.groups)
      if (!ids.length) return m.reply('No recipients found.')

      conn.sendReact(m.chat, global.react, m.key)
      const sendMsg = async (jid, msg) => {
        await Func.delay(1200)
        await conn.sendMessage(jid, msg, { quoted: null })
      }

      if (text) {
        for (const jid of ids) {
          const mentions = command == 'bcgc'
            ? (await conn.groupMetadata(jid)).participants.map(v => v.id)
            : []
          await sendMsg(jid, { text, mentions })
        }
      } else if (/webp/.test(mime)) {
        const media = await q.download()
        for (const jid of ids) {
          const mentions = command == 'bcgc'
            ? (await conn.groupMetadata(jid)).participants.map(v => v.id)
            : []
          await Func.delay(1200)
          await conn.sendSticker(jid, media, null, {
            packname: global.db.setting.sk_pack,
            author: global.db.setting.sk_author,
            mentions
          })
        }
      } else if (/video|image\/(jpe?g|png)/.test(mime)) {
        const media = await q.download()
        for (const jid of ids) {
          await sendMsg(jid, {
            [mime.startsWith('video') ? 'video' : 'image']: media,
            caption: q.text || ''
          })
        }
      } else if (/audio/.test(mime)) {
        const media = await q.download()
        for (const jid of ids) {
          await sendMsg(jid, { audio: media, mimetype: 'audio/mpeg', ptt: q.ptt || false })
        }
      } else return m.reply('Please provide text & media.')

      m.reply(`Broadcast sent to ${ids.length} ${command == 'bc' ? 'chats' : 'groups'}. 👍`)
    } catch (e) {
      throw Func.jsonFormat(e)
    }
  },
  error: false
}