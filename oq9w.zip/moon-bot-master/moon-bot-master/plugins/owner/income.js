const fs = require('fs')
const path = require('path')
const formatNumber = require('../../lib/formatNumber')

module.exports = {
    help: ['income'],
    aliases: ['penghasilan', 'earning'],
    tags: 'info',
    owner: true,
    run: async (m, { usedPrefix, command, args }) => {
        try {
            const configPath = path.join(__dirname, '../../config.json')
            if (!fs.existsSync(configPath)) return m.reply('config.json file not found.')

            const config = JSON.parse(fs.readFileSync(configPath, 'utf8'))
            const ownerNumber = config.owner
            if (!ownerNumber) return m.reply('Owner not found in config.json.')

            const ownerKey = ownerNumber.includes('@s.whatsapp.net')
                ? ownerNumber
                : `${ownerNumber}@s.whatsapp.net`

            const owner = global.db.users[ownerKey]
            if (!owner) return m.reply('Owner data not found in database.')

            const income = owner.income
            if (!income || Object.keys(income).length === 0)
                return m.reply('No income data available.')

            // === HITUNG TOTAL SEMUA INCOME ===
            let totalMoney = 0
            let totalExp = 0
            let totalLimit = 0
            let totalTransactions = 0

            for (const data of Object.values(income)) {
                if (data.money) totalMoney += data.money
                if (data.exp) totalExp += data.exp
                if (data.limit) totalLimit += data.limit
                if (data.totalTransactions) totalTransactions += data.totalTransactions
            }

            // === FITUR TARIK ===
            if (args[0] && args[0].toLowerCase() === 'tarik') {
                const jenis = (args[1] || '').toLowerCase()
                const nominalArg = args[2]

                if (!['money', 'exp', 'limit'].includes(jenis))
                    return m.reply(`Incorrect format.\n*Use* : ${usedPrefix + command} tarik [money/exp/limit] [nominal/all]`)

                if (!nominalArg)
                    return m.reply(`*Example* : ${usedPrefix + command} tarik money 10000`)

                let totalJenis = jenis === 'money' ? totalMoney : jenis === 'exp' ? totalExp : totalLimit
                if (totalJenis <= 0) return m.reply(`There are no ${jenis} that can be withdrawn.`)

                let jumlahTarik = 0
                if (nominalArg.toLowerCase() === 'all') {
                    jumlahTarik = totalJenis
                } else {
                    const num = parseInt(nominalArg)
                    if (isNaN(num) || num <= 0) return m.reply('Nominal tidak valid.')
                    if (num > totalJenis) return m.reply(`Nominal exceeds total ${jenis} : ${formatNumber(totalJenis)}.`)
                    jumlahTarik = num
                }

                const jumlahSebelum = jumlahTarik

                // Tambahkan ke akun owner
                if (!owner[jenis]) owner[jenis] = 0
                owner[jenis] += jumlahTarik

                // Kurangi dari income (distribusi dari semua sumber income)
                for (const data of Object.values(income)) {
                    if (data[jenis] && jumlahTarik > 0) {
                        const dikurang = Math.min(jumlahTarik, data[jenis])
                        data[jenis] -= dikurang
                        jumlahTarik -= dikurang
                    }
                }

                const hasilTarik = jumlahSebelum - jumlahTarik
                const tampilJumlah = jenis === 'limit' ? hasilTarik : formatNumber(hasilTarik)

                return m.reply(
                    `*INCOME*\n\n` +
                    `- *Type* : ${jenis.toUpperCase()}\n` +
                    `- *Amount* : ${tampilJumlah}\n` +
                    `- *Status* : Success. 👍`
                )
            }

            // === TAMPILKAN DATA INCOME ===
            let msg = `*INCOME*\n\n`
            let i = 1

            for (const [key, data] of Object.entries(income)) {
                msg += `[${i++}]\n- *From* : ${key.replace(/([A-Z])/g, ' $1')}\n`
                if (data.money) msg += `- *Money* : ${formatNumber(data.money)}\n`
                if (data.exp) msg += `- *EXP* : ${formatNumber(data.exp)}\n`
                if (data.limit) msg += `- *Limit* : ${data.limit}\n`
                if (data.totalTransactions) msg += `Transactions : ${formatNumber(data.totalTransactions)}\n`
                msg += '\n'
            }

            msg += `*TOTAL*\n`
            msg += `- *Money* : ${formatNumber(totalMoney)}\n`
            msg += `- *EXP* : ${formatNumber(totalExp)}\n`
            msg += `- *Limit* : ${totalLimit}\n`
            msg += `Total Transactions : ${formatNumber(totalTransactions)}\n\n`
            msg += `*Withdrawal* : ${usedPrefix + command} tarik [money/exp/limit] [nominal/all]`

            return m.reply(msg)
        } catch (e) {
            console.error(e)
            throw Func.jsonFormat(e)
        }
    }
}