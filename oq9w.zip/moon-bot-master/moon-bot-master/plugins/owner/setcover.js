module.exports = {
  help: ['setcover'],
  tags: 'owner',
  owner: true,
  run: async (m, { conn, Scraper, Func }) => {
    try {
      let setting = global.db.setting
      let q = m.quoted ? m.quoted : m
      let mime = (q.msg || q).mimetype || ''

      if (!/image/.test(mime)) {
        return conn.reply(m.chat, 'Please provide an image.', m)
      }

      let img = await q.download()
      if (!img) {
        return conn.reply(m.chat, global.status.wrong, m)
      }

      let link = await Scraper.imgbb(img)
      if (!link.status) {
        return m.reply(Func.jsonFormat(link))
      }

      setting.cover = link.data.url
      conn.reply(m.chat, 'Done. 👍', m)
    } catch (e) {
      return conn.reply(m.chat, Func.jsonFormat(e), m)
    }
  }
}