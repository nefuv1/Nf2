const moment = require('moment-timezone');

module.exports = {
    help: ['acc'],
    aliases: ['approve'],
    tags: 'owner',
    owner: true,
    run: async (m, {
        conn,
        text,
        usedPrefix,
        command,
        args
    }) => {
    
        usedPrefix = usedPrefix || global.prefix || '.';

        if (!global.db.stores) global.db.stores = {
            pending: [],
            active: [],
            nextStoreId: 1
        };

        const subCommand = args[0]?.toLowerCase();
        
        if (!subCommand) {
            return showPendingStores(m, usedPrefix, command);
        } else if (subCommand === 'all') {
            return approveAllStores(m, conn, usedPrefix, command);
        } else {
            const storeIndex = parseInt(subCommand) - 1;
            return approveStore(m, conn, storeIndex, usedPrefix, command);
        }
    }
};

// Fungsi untuk menampilkan store yang pending
function showPendingStores(m, usedPrefix, command) {
    const pendingStores = global.db.stores.pending;

    if (pendingStores.length === 0) {
        return m.reply("There are no store registrations awaiting approval.");
    }
    
    let pendingList = `*STORE APPROVE*\n\n`;
    pendingList += `*Total Pending* : ${pendingStores.length}\n\n`;
    
    pendingStores.forEach((store, index) => {
        const registrationTime = moment(store.registrationDate);
        const now = moment().tz('Asia/Jakarta');
        const hoursPassed = now.diff(registrationTime, 'hours');
        const daysLeft = 3 - Math.floor(hoursPassed / 24);
        const hoursLeft = 24 - (hoursPassed % 24);
        
        pendingList += `[${index + 1}]\n`;
        pendingList += `- *Store Name* : ${store.storeName}\n`;
        pendingList += `- *Owner* : ${store.ownerName}\n`;
        pendingList += `- *Description* : ${store.description}\n`;
        pendingList += `- *Registration Date* : ${registrationTime.format('DD/MM/YYYY HH:mm')}\n`;
        pendingList += `- *Remaining time* : ${daysLeft} hari ${hoursLeft} jam\n`;
        pendingList += `- *Store ID* : ${global.db.stores.nextStoreId.toString().padStart(5, '0')}\n\n`;
    });
    
    pendingList += `*Approval Example* :\n`;
    pendingList += `1. ${usedPrefix + command} [queue-number] - Approve store tertentu.\n`;
    pendingList += `2. ${usedPrefix + command} all - Approve semua store.`;
    
    return m.reply(pendingList);
}

// Fungsi untuk approve store tertentu
async function approveStore(m, conn, storeIndex, usedPrefix, command) {
    const pendingStores = global.db.stores.pending;

    if (isNaN(storeIndex) || storeIndex < 0 || storeIndex >= pendingStores.length) {
        return m.reply(`Queue number is invalid!`);
    }
    
    const store = pendingStores[storeIndex];
    const storeId = global.db.stores.nextStoreId++;
    
    // Pindahkan dari pending ke active
    const approvedStore = {
        ...store,
        storeId: storeId,
        status: 'active',
        approvalDate: moment().tz('Asia/Jakarta').format(),
        products: [],
        totalSales: 0,
        totalRevenue: 0,
        rating: 0,
        totalRatings: 0,
        customerCount: 0,
        customers: new Set()
    };
    
    global.db.stores.active.push(approvedStore);
    global.db.stores.pending.splice(storeIndex, 1);
    
    // Kirim notifikasi ke user
    try {
        const userMessage = `*STORE APPROVED*\n\n` +
            `Selamat! Store Anda sudah aktif :\n` +
            `- *Nama Toko* : ${approvedStore.storeName}\n` +
            `- *ID Toko* : ${approvedStore.storeId.toString().padStart(5, '0')}\n` +
            `- *Deskripsi* : ${approvedStore.description}\n\n` +
            `*Pengaturan*\n` +
            `1. Menambah produk dari inventory\n` +
            `2. Mengatur stok & harga jual\n` +
            `3. Melihat statistik penjualan\n\n` +
            `*Tambahkan produk pertama anda* :\n` +
            `- ${usedPrefix}store add [item] [stock] [harga]\n\n` +
            `*Contoh penggunaan* : ${usedPrefix}store add Karung 10 1000`;
        
        await conn.sendMessage(store.ownerId, { text: userMessage });
    } catch (e) {
        console.log('Unable to send notification to user');
    }
    
    return m.reply(`*STORE APPROVED*\n\n` +
        `- *Store Details* :\n` +
        `- *Name* : ${approvedStore.storeName}\n` +
        `- *ID Store* : ${approvedStore.storeId.toString().padStart(5, '0')}\n` +
        `- *Owner* : ${approvedStore.ownerName}\n` +
        `- *Description* : ${approvedStore.description}\n\n` +
        `_Notification has been sent to the store owner!_`);
}

// Fungsi untuk approve semua store
async function approveAllStores(m, conn, usedPrefix, command) {
    const pendingStores = global.db.stores.pending;

    if (pendingStores.length === 0) {
        return m.reply("There are no stores to approve!");
    }
    
    let successCount = 0;
    let failedCount = 0;
    
    for (let i = pendingStores.length - 1; i >= 0; i--) {
        try {
            const store = pendingStores[i];
            const storeId = global.db.stores.nextStoreId++;
            
            const approvedStore = {
                ...store,
                storeId: storeId,
                status: 'active',
                approvalDate: moment().tz('Asia/Jakarta').format(),
                products: [],
                totalSales: 0,
                totalRevenue: 0,
                rating: 0,
                totalRatings: 0,
                customerCount: 0,
                customers: new Set()
            };
            
            global.db.stores.active.push(approvedStore);
            global.db.stores.pending.splice(i, 1);
            
            // Kirim notifikasi ke user
            try {
                const userMessage = `*STORE APPROVED*\n\n` +
            `Selamat! Store Anda sudah aktif :\n` +
            `- *Nama Store* : ${approvedStore.storeName}\n` +
            `- *ID Toko* : ${approvedStore.storeId.toString().padStart(5, '0')}\n` +
            `- *Deskripsi* : ${approvedStore.description}\n\n` +
            `*Sekarang Anda Bisa*\n` +
            `1. Menambah produk dari inventory\n` +
            `2. Mengatur stok & harga jual\n` +
            `3. Melihat statistik penjualan\n\n` +
            `*Tambahkan Produk Pertama Anda* :\n` +
            `- ${usedPrefix}store add [item] [stock] [harga]\n\n` +
            `*Contoh penggunaan* : ${usedPrefix}store add Karung 10 1000`;
                
                await conn.sendMessage(store.ownerId, { text: userMessage });
            } catch (e) {
                console.log(`Unable to send notification to ${store.ownerId}`);
            }
            
            successCount++;
        } catch (error) {
            console.error(error);
            failedCount++;
        }
    }
    
    return m.reply(`*STORE APPROVED* (all)\n\n` +
        `- *Succeed* : ${successCount} store\n` +
        `- *Fail* : ${failedCount} store\n\n` +
        `_Notification has been sent to all store owners!_`);
}