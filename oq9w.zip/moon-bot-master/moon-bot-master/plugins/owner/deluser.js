module.exports = {
  help: ['-user'],
  aliases: ['deluser', 'delusers', 'unuser'],
  tags: 'owner',
  owner: true,
  run: async (m, { conn, usedPrefix, command, text }) => {
    const clean = n => n.replace(/\s|[@+-]/g, '')
    const reply = msg => m.reply(msg)

    let user
    if (m.quoted) user = m.quoted.sender
    else if (m.mentionedJid?.[0]) user = m.mentionedJid[0]
    else if (text) {
      const num = clean(text)
      if (isNaN(num) || num.length > 15) return reply('Invalid number!')
      user = num + '@s.whatsapp.net'
    } else return reply(`Please @tag users.\n\n*Example* : ${usedPrefix + command} 62xxx`)

    const id = user.split('@')[0]
    if (!global.db?.users) return reply('User database not ready.')
    if (!global.db.users[user]) return reply(`@${id} not found in database. 👎`, null, { contextInfo: { mentionedJid: [user] } })

    delete global.db.users[user]
    reply(`@${id} has been removed from database. 👍`, null, { contextInfo: { mentionedJid: [user] } })
  }
}