const fetch = require('node-fetch');

module.exports = {
  help: ['reset'],
  tags: 'owner',
  owner: true,
  run: async (m, { conn, args, Func, usedPrefix, command }) => {
    
    if (!args || args.length === 0) {
      return conn.reply(m.chat, `*Type* :\n\n1. Limit\n2. EXP\n3. Level\n4. Money\n5. User\n6. Stamina\n7. Warn\n\n*Example* : ${usedPrefix + command} stamina`, m);
    }

    let type = args[0].toLowerCase();

    switch(type) {
      case 'limit':
        {
          let list = Object.entries(global.db.users);
          let val = !args[1] ? 5 : isNumber(args[1]) ? parseInt(args[1]) : 5;
          val = Math.max(1, val);
          list.map(([user, data]) => (data.limit = val));
          conn.reply(m.chat, `Reset successfully *${val}* / User. 👍`, m);
        }
        break;

      case 'exp':
        {
          let list = Object.entries(global.db.users);
          let val = !args[1] ? 50000 : isNumber(args[1]) ? parseInt(args[1]) : 50000;
          val = Math.max(1, val);
          list.map(([user, data]) => (data.exp = val));
          conn.reply(m.chat, `Reset successfully *${val}* / User. 👍`, m);
        }
        break;

      case 'level':
        {
          let list = Object.entries(global.db.users);
          let val = !args[1] ? 0 : isNumber(args[1]) ? parseInt(args[1]) : 0;
          val = Math.max(1, val);
          list.map(([user, data]) => (data.level = val));
          conn.reply(m.chat, `Reset successfully *${val}* / User. 👍`, m);
        }
        break;

      case 'money':
        {
          let list = Object.entries(global.db.users);
          let val = !args[1] ? 30000 : isNumber(args[1]) ? parseInt(args[1]) : 30000;
          val = Math.max(1, val);
          list.map(([user, data]) => (data.money = val));
          conn.reply(m.chat, `Reset successfully *${val}* / User. 👍`, m);
        }
        break;

      case 'user':
        {
          let arr = Object.entries(global.db.users)
            .filter(user => !user[1].registered && !user[1].unreg)
            .map(user => user[0]);
          let msg = `Reset successfully *${arr.length}* / User. 👍`;
          for (let x of arr) delete global.db.users[x];
          conn.reply(m.chat, msg, m);
        }
        break;

      case 'stamina':
        {
          let list = Object.entries(global.db.users);
          list.map(([user, data]) => (data.stamina = 100));
          conn.reply(m.chat, `All users' stamina has been reset to *100*. 👍`, m);
        }
        break;

      case 'warn':
        {
          let list = Object.entries(global.db.users);
          list.map(([user, data]) => (data.warn = 0));
          conn.reply(m.chat, `All users' warns have been reset to *0*. 👍`, m);
        }
        break;

      default:
        conn.reply(m.chat, `Invalid type. Use : Limit, EXP, Level, Money, User, Stamina or Warn`, m);
    }
  }
};

function isNumber(x = 0) {
  x = parseInt(x);
  return !isNaN(x) && typeof x == 'number';
}