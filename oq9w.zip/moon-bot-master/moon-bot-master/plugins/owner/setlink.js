module.exports = {
   help: ['setlink'],
   tags: 'owner',
   owner: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      Func
   }) => {
      try {
         let setting = global.db.setting
         if (!text) return conn.reply(m.chat, `*Example* : ${global.db.setting.link}`, m)
         const isUrl = Func.isUrl(text)
         if (!isUrl) return conn.reply(m.chat, `URL is invalid.`, m)
         setting.link = text
         conn.reply(m.chat, `Done. 👍.`, m)
      } catch (e) {
         conn.reply(m.chat, Func.jsonFormat(e), m)
      }
   }
}