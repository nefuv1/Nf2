const { writeFileSync, readFileSync, existsSync } = require('fs');
const path = require('path');

module.exports = {
   help: ['backup'],
   aliases: ['bkp', 'bckp'],
   tags: 'owner',
   owner: true,
   run: async (m, { conn, Func, database, env, text, usedPrefix, command }) => {
      try {
         if (!text) {
            return conn.reply(m.chat, `*Options*\n\n1. creds.json\n2. data.json\n\n*Example* : ${usedPrefix + command} 1`, m);
         }

         const option = text.trim();

         if (option === '1') {
            const credsPath = path.join(__dirname, '../../session/creds.json'); // sesuaikan path folder session
            if (!existsSync(credsPath)) {
               return conn.reply(m.chat, `Creds.json not found in session folder!`, m);
            }
            await conn.sendFile(m.chat, readFileSync(credsPath), 'creds.json', '', m);
            return;
         }

         if (option === '2') {
            await database.save(global.db);
            writeFileSync(env.database + '.json', JSON.stringify(global.db, null, 3), 'utf-8');
            await conn.sendFile(m.chat, readFileSync('./' + env.database + '.json'), env.database + '.json', '', m);
            return;
         }
         
         return conn.reply(m.chat, `*Gunakan* :\n1. ${usedPrefix + command} 1  → creds.json\n2. ${usedPrefix + command} 2  → data.json`, m);
      } catch (e) {
         console.error(e);
         throw Func.jsonFormat(e)
      }
   }
};



/**
const { writeFileSync, readFileSync } = require('fs')
module.exports = {
   help: ['backup'],
   tags: 'owner',
   owner: true,
   run: async (m, {
      conn,
      database,
      env,
      Func
   }) => {
      try {
         conn.sendReact(m.chat, global.react, m.key)
         await database.save(global.db)
         writeFileSync(env.database + '.json', JSON.stringify(global.db, null, 3), 'utf-8')
         await conn.sendFile(m.chat, readFileSync('./' + env.database + '.json'), env.database + '.json', '', m)
      } catch (e) {
         return conn.reply(m.chat, Func.jsonFormat(e), m)
      }
   }
}
*/