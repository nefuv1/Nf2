module.exports = {
   help: ['+prem', '-prem'],
   aliases: ['addprem', 'delprem', 'unprem'],
   tags: 'owner',
   owner: true,
   run: async (m, { conn, usedPrefix, command, args, text }) => {
      let jid, days = parseInt(args[0]) || 30, ms = 86400000 * days
      const reply = (t, mention) => conn.reply(m.chat, t, m, mention ? { mentions: [mention] } : {})

      const getUser = async (input, dayIndex = 1) => {
         if (m.quoted) return conn.decodeJid(m.quoted.sender)
         if (m.mentionedJid[0]) return conn.decodeJid(m.mentionedJid[0])
         if (text && text.includes('|')) {
            let [num, d] = text.split`|`
            let wa = (await conn.onWhatsApp(num))[0] || {}
            if (!wa.exists) return null
            days = parseInt(d) || 30
            ms = 86400000 * days
            return conn.decodeJid(wa.jid)
         }
         if (text) {
            let wa = (await conn.onWhatsApp(text))[0] || {}
            if (!wa.exists) return null
            return conn.decodeJid(wa.jid)
         }
         return null
      }

      // === ADD PREMIUM ===
      if (['+prem', 'addprem'].includes(command)) {
         jid = await getUser()
         if (!jid) return reply(`*Example* :\n- ${usedPrefix + command} 62xxx | 7\n- ${usedPrefix + command} @0 7\n- ${usedPrefix + command} 7 - (Reply to user chat)`)
         let user = global.db.users[jid]
         if (!user) return reply('User not found.')

         // Hitung limit berdasarkan jumlah hari (3000 per hari)
         const additionalLimit = 3000 * days
        
         user.expired = user.premium ? user.expired + ms : Date.now() + ms
         user.limit += additionalLimit
         user.premium = true

         reply(`Premium for ${days} days added to @${jid.replace(/@.+/, '')}. 👍\n\n- +${additionalLimit.toLocaleString()} limit (Total : ${user.limit.toLocaleString()})`, jid)
      }

      // === REMOVE PREMIUM ===
      if (['-prem', 'delprem', 'unprem'].includes(command)) {
         jid = await getUser()
         if (!jid) return reply('Please @tag / reply to user chat.')
         let user = global.db.users[jid]
         if (!user?.premium) return reply('This user is not premium.')

         // Hitung sisa hari untuk mengurangi limit
         const remainingDays = Math.max(0, Math.ceil((user.expired - Date.now()) / 86400000))
         const limitToRemove = 3000 * remainingDays
        
         const defaultLimit = 15
         user.limit = Math.max(defaultLimit, user.limit - limitToRemove)
         user.premium = false
         user.expired = 0

         reply(`Premium removed from @${jid.replace(/@.+/, '')}. 👎\n\nCurrent limit : ${user.limit.toLocaleString()}`, jid)
      }
   }
}