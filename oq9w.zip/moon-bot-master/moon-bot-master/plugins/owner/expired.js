module.exports = {
  help: ['+expired', '-expired'],
  aliases: ['expired', 'addexpired', 'delexpired'],
  tags: 'owner',
  owner: true,
  run: async (m, { conn, usedPrefix, command, args, Func }) => {
    try {
      const isAdd = ['+expired', 'addexpired', 'expired'].includes(command)
      let group = m.isGroup ? m.chat : args[0]
      let days = parseInt(m.isGroup ? args[0] : args[1])

      if (!group) return m.reply(`Please provide group ID.\n\n*Example* : ${usedPrefix + command} 123xxx@g.us 30`)
      if (isAdd && (!days || isNaN(days))) return m.reply(`Invalid days.\n\n*Example* : ${usedPrefix + command} ${group} 30`)

      // Ensure group data exists
      if (!global.db.groups[group]) global.db.groups[group] = { activity: Date.now(), expired: 0, stay: false }

      const now = Date.now(), data = global.db.groups[group]

      // === ADD EXPIRED ===
      if (isAdd) {
        const add = 86400000 * days
        data.expired = data.expired > now ? data.expired + add : now + add
        data.stay = false
        const countdown = Func.toDate(data.expired - now)

        // Send info to group if bot is inside it
        try {
          const meta = await conn.groupMetadata(group)
          const members = meta.participants.map(v => v.id)
          await conn.sendMessage(group, {
            text: `Group extended for *${days} days*. 👍\n\n- *New Expired* : ${countdown}\n- *By* : @${m.sender.split('@')[0]}`,
            mentions: [...members, m.sender]
          })
        } catch { /* Skip if bot not in group */ }

        return m.reply(`Group *${group}* extended for ${days} days. 👍\n\nNew expired : ${countdown}`)
      }

      // === REMOVE EXPIRED ===
      data.expired = 0
      try {
        const meta = await conn.groupMetadata(group)
        const members = meta.participants.map(v => v.id)
        await conn.sendMessage(group, {
          text: `Group active period has been deleted. 👍\n\n- *By* : @${m.sender.split('@')[0]}\n_Bot will stay until removed manually_`,
          mentions: [...members, m.sender]
        })
      } catch {}

      m.reply(`Expired for group *${group}* has been removed. 👍`)
    } catch (e) {
      throw Func.jsonFormat(e)
    }
  }
}