module.exports = {
  help: ['join'],
  tags: 'owner',
  owner: true,
  run: async (m, { conn, usedPrefix, command, args, text, Func }) => {
    const linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i;
    let [_, code] = text.match(linkRegex) || [];

    if (!args[0]) return m.reply(`*Example* : ${usedPrefix}join https://chat.whatsapp.com/Dtid3yl0mwh3NLbJjOKIp1 5`);
    if (!code) return m.reply('Invalid group link!');
    if (!args[1]) return m.reply(`Enter the number of rental days!`);
    if (isNaN(args[1])) return m.reply(`Use numbers as the number of days!`);

    m.react(global.react)
    await Func.delay(3000);

    try {
      let res = await conn.groupAcceptInvite(code);
      let metadata = await conn.groupMetadata(res);
      
      // PERBAIKAN: Pastikan participants ada sebelum menggunakan map
      let participants = metadata.participants ? metadata.participants.map(v => v.id) : [];
      
      // Cek jika bot sudah menjadi member
      let botNumber = conn.user.id.split(':')[0] + '@s.whatsapp.net';
      let botIsMember = participants.includes(botNumber);

      let now = Date.now();
      let duration = 86400000 * parseFloat(args[1]); // jumlah hari ke milidetik

      // Inisialisasi group data jika belum ada
      if (!global.db.groups[res]) {
        global.db.groups[res] = {
          activity: now,
          expired: now + duration,
          stay: false,
          mute: false,
          adminonly: false,
          antilink: false,
          antiporn: false,
          antitoxic: false,
          antivirtex: false,
          antisticker: false,
          antiviwonce: false,
          antitagsw: false,
          member: {}
        };
      } else {
        // Tambah waktu jika sudah ada
        if (now < global.db.groups[res].expired) {
          global.db.groups[res].expired += duration;
        } else {
          global.db.groups[res].expired = now + duration;
        }
      }

      let groupName = metadata.subject;
      let remaining = Func.toDate(global.db.groups[res].expired - now);

      if (botIsMember) {
        return m.reply(`Bot is already in the group.\n\n- *Group name*: ${groupName}\n- *Active period extended*: ${remaining}`);
      }

      // Kirim pesan welcome ke grup - hanya jika participants ada
      if (participants.length > 0) {
        await conn.sendMessage(res, {
          text: `Hello everyone 👋\n\nI am GeniusAI, a WhatsApp bot ready to help you get information, download media, and other interesting features.\n\nThe bot will exit automatically after the active period ends.\n\n- *Timeout*: ${remaining}`,
          mentions: participants
        });
      } else {
        await conn.sendMessage(res, {
          text: `Hello everyone 👋\n\nI am GeniusAI, a WhatsApp bot ready to help you get information, download media, and other interesting features.\n\nThe bot will exit automatically after the active period ends.\n\n- *Timeout*: ${remaining}`
        });
      }

      m.reply(`Bot successfully joined the group. 👍\n\n- *Group name*: ${groupName}\n- *Expired*: ${remaining}`);

    } catch (e) {
      console.log(e);
           throw Func.jsonFormat(e)
    }
  }
};