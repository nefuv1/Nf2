const formatNumber = require('../../lib/formatNumber')

module.exports = {
   help: ['pay'],
   tags: 'owner',
   owner: true,
   run: async (m, { conn, Func, usedPrefix, command, args }) => {
      try {
         let type = (args[0] || '').toLowerCase()
         let count = args[1] && !isNaN(args[1]) ? Math.max(parseInt(args[1]), 1) : null
         
         // Determine target
         let who =
            m.mentionedJid && m.mentionedJid[0]
               ? m.mentionedJid[0] // @tag
               : m.quoted && m.quoted.sender
               ? m.quoted.sender // reply
               : args[2] && args[2].match(/^\d+$/)
               ? args[2].replace(/[^0-9]/g, '') + '@s.whatsapp.net' // phone number
               : m.sender // default = command sender

         if (!type || !count) {
            return m.reply(`Please specify the type, amount, @tag.\n\n*Example* : ${usedPrefix + command} EXP 1000 @tag\n\n*Type* :\n1. Money\n2. Limit\n3. EXP`)
         }

         if (typeof global.db.users[who] == 'undefined') 
            return m.reply('This user is not registered in the database.')

         switch (type) {
            case 'exp':
               global.db.users[who].exp += count
               conn.reply(m.chat, `+${formatNumber(count)} ${type} successfully added to @${who.split`@`[0]}`, m, { mentions: [who] })
            break
            case 'money':
               global.db.users[who].money += count
               conn.reply(m.chat, `+${formatNumber(count)} ${type} successfully added to @${who.split`@`[0]}`, m, { mentions: [who] })
            break
            case 'limit':
               global.db.users[who].limit += count
               conn.reply(m.chat, `+${formatNumber(count)} ${type} successfully added to @${who.split`@`[0]}`, m, { mentions: [who] })
            break
            default:
               return m.reply(
                  `Invalid type!\n\n*Available types* :\n1. EXP\n2. Money\n3. Limit`
               )
         }

      } catch (e) {
         console.log(e)
           throw Func.jsonFormat(e)
      }
   }
}