module.exports = {
   help: ['+ban', '-unban'],
   aliases: ['ban', 'unban'],
   tags: 'owner',
   owner: true,
   run: async (m, { conn, isOwner, Func, text, isAdmin, command }) => {
      let who;

      if (m.isGroup) {
         if (!(isOwner)) {
            m.reply(global.status.owner);
            return;
         }
         who =
            m.mentionedJid && m.mentionedJid.length > 0
               ? m.mentionedJid[0]
               : m.quoted
               ? m.quoted.sender
               : text
               ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
               : null;
      } else {
         if (!isOwner) {
            m.reply(global.status.owner);
            return;
         }
         who =
            m.mentionedJid && m.mentionedJid.length > 0
               ? m.mentionedJid[0]
               : m.quoted
               ? m.quoted.sender
               : text
               ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
               : m.chat;
      }

      // Jika who gagal diambil
      if (!who) {
         return m.reply(`Please @tag users.\n\n*Example* : ${usedPrefix + command} @tag`);
      }

      try {
         if (/^ban$/i.test(command) || /^ban$/i.test(command)) {
            if (who.endsWith('g.us')) {
               if (!global.db.groups[who]) global.db.groups[who] = {};
               global.db.groups[who].isBanned = true;
            } else {
               if (!global.db.users[who]) global.db.users[who] = {};
               global.db.users[who].banned = true;
            }
            conn.reply(
               m.chat,
               `@${who.split('@')[0]} You have been banned. 👍`,
               m,
               { mentions: [who] }
            );
         } else if (/^unban$/i.test(command) || /^unban$/i.test(command)) {
            if (who.endsWith('g.us')) {
               if (!global.db.groups[who]) global.db.groups[who] = {};
               global.db.groups[who].isBanned = false;
            } else {
               if (!global.db.users[who]) global.db.users[who] = {};
               global.db.users[who].banned = false;
            }
            conn.reply(
               m.chat,
               `@${who.split('@')[0]} You have been unbanned. 👍`,
               m,
               { mentions: [who] }
            );
         }
      } catch (e) {
         console.error(e);
           throw Func.jsonFormat(e)
      }
   },
};