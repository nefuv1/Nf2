const path = require('path')

module.exports = {
   help: ['plugdis', 'plugen'],
   tags: 'owner',
   owner: true,
   run: async (m, {
      conn,
      args,
      command,
      usedPrefix,
      plugins: plugs,
      Func
   }) => {
      let pluginDisable = global.db.setting.pluginDisable
      if (!args || !args[0]) return conn.reply(m.chat, `*Example* : ${usedPrefix + command} menu`, m)
      let allPluginFiles = [...new Set([...plugs.values()].map(p => path.parse(p.filePath).name))]
      if (!allPluginFiles.includes(args[0])) return conn.reply(m.chat, `Plugin ${args[0]}.js not found.`, m)
      let plugin = [...plugs.values()].find(p => path.parse(p.filePath).name === args[0])
      let actualFilename = path.basename(plugin.filePath)
      if (command === 'plugdis') {
         if (pluginDisable.includes(args[0])) return conn.reply(m.chat, `Plugin ${actualFilename}.js previously has been disabled.`, m)
         pluginDisable.push(args[0])
         conn.reply(m.chat, `Done. 👍`, m)
      } else if (command === 'plugen') {
         if (!pluginDisable.includes(args[0])) return conn.reply(m.chat, `Plugin ${actualFilename} not found.`, m)
         global.db.setting.pluginDisable = global.db.setting.pluginDisable.filter(v => v !== args[0])
         conn.reply(m.chat, `Done. 👍`, m)
      }
   },
   error: false
}