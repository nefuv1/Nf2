/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const PhoneNum = require('awesome-phonenumber')
const formatNumber = require('../../lib/formatNumber')

module.exports = {
   help: ['profile'],
   aliases: ['profil', 'me'],
   tags: 'user',
   register: true,
   run: async (m, { conn, text, command, usedPrefix, blockList, env, Func }) => {

      m.react(global.react)

      let target
      if (m.mentionedJid?.length > 0) {
         target = m.mentionedJid[0]
      } else if (m.quoted?.sender) {
         target = m.quoted.sender
      } else {
         target = m.sender
      }

      let user = global.db.users[target]
      if (!user) return m.reply(`This user is not registered.`)

      const roleData = Func.role(user.level)
      const roleName = roleData?.name || 'Unranked'
      user.role = roleName // simpan ke data user

      let blocked = blockList.includes(target)
      let pasangan = user.partner ? '@' + user.partner.split('@')[0] : '×'
      let regCode = user.registered && user.regCode ? user.regCode : 'Not registered yet'
      let stamina = user.stamina || 0
      let healt = user.healt || 100

      let userWarning = user.warning || 0
      let warningText = `${userWarning}/3`

      let number = target.split('@')[0]
      let format = PhoneNum('+' + number)
      let country = new Intl.DisplayNames(['en'], { type: 'region' }).of(format.getRegionCode('international'))

      let caption = `*USER PROFILE*\n\n`
      caption += `- *Username* : ${user.username || '-'}\n`
      caption += `- *Tags* : @${target.split('@')[0]}\n`    
      caption += `- *Age* : ${user.age || '-'}\n`
      caption += `- *Gender* : ${user.gender || '-'}\n`
      caption += `- *Exp* : ${formatNumber(user.exp)}\n`
      caption += `- *Money* : ${formatNumber(user.money)}\n`
      caption += `- *Limit* : ${formatNumber(user.limit)}\n`
      caption += `- *Hitstat* : ${formatNumber(user.hit)}\n`
      caption += `- *Warning* : ${warningText}\n`
      caption += `- *Level* : ${user.level || 0}\n`
      caption += `- *Role* : ${roleName}\n\n`

      caption += `*USER STATUS*\n\n`
      caption += `- *Blocked* : ${(blocked ? '√' : '×')}\n`
      caption += `- *Banned* : ${(new Date - user.ban_temporary < env.timer) ? Func.toTime(new Date(user.ban_temporary + env.timeout) - new Date()) + ' (' + ((env.timeout / 1000) / 60) + ' min)' : user.banned ? '√' : '×'}\n`
      caption += `- *Use In Private* : ${(Object.keys(global.db.chats).includes(target) ? '√' : '×')}\n`
      caption += `- *Premium* : ${(user.premium ? '√' : '×')}\n`
      caption += `- *Expired* : ${user.expired == 0 ? '-' : Func.timeReverse(user.expired - new Date() * 1)}\n`
      caption += `- *Verified* : ${(user.registered ? '√' : '×')}\n\n`

      caption += `*EXTRA INFO*\n\n`
      caption += `- *Country* : ${country?.toUpperCase() || '-'}\n`
      caption += `- *Partner* : ${pasangan}\n`
      caption += `- *SN* : ${regCode}\n`
      caption += `- *Stamina* : ${stamina}/100\n`
      caption += `- *Health* : ${healt}/100`

      let mentions = [target]
      if (user.partner) mentions.push(user.partner)

      conn.reply(m.chat, caption, m, { mentions })
   }
}



/** Profile lama tanpa (username, age, and gender)

const PhoneNum = require('awesome-phonenumber')
const formatNumber = require('../../lib/formatNumber') 

const formatDetailNumber = (num) => {
    if (typeof num !== 'number') num = Number(num) || 0
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')
}

module.exports = {
    help: ['profile'],
    aliases: ['profil','me'],
    tags: 'user',
    register: true,
    run: async (m, { conn, text, blockList, env, Func }) => {
    
    m.react(global.react)

        let target
        if (m.mentionedJid?.length > 0) {
            target = m.mentionedJid[0]
        } else if (m.quoted?.sender) {
            target = m.quoted.sender
        } else {
            target = m.sender
        }

        let user = global.db.users[target]
        if (!user) return m.reply(`This user is not registered.`)

        let blocked = blockList.includes(target)
        let pasangan = user.partner ? '@' + user.partner.split('@')[0] : '×'
        let regCode = user.registered && user.regCode ? user.regCode : 'Not registered yet'
        let stamina = user.stamina || 0

        let number = target.split('@')[0]
        let format = PhoneNum('+' + number)
        let country = new Intl.DisplayNames(['en'], { type: 'region' }).of(format.getRegionCode('international'))

        let caption = `*USER PROFILE*\n\n`
        caption += `- *Tags* : @${target.split('@')[0]}\n`
        caption += `- *Exp* : ${formatNumber(user.exp)}\n`
        caption += `- *Money* : ${formatNumber(user.money)}\n`
        caption += `- *Limit* : ${formatDetailNumber(user.limit)}\n`
        caption += `- *Hitstat* : ${formatDetailNumber(user.hit)}\n`
        caption += `- *Warning* : ${(m.isGroup ? (typeof global.db.groups[m.chat]?.member[target] != 'undefined' ? global.db.groups[m.chat].member[target].warning : 0) : user.warning) + ' / 5'}\n`
        caption += `- *Level* : ${user.level || 0}\n` // Tambah level
        caption += `- *Role* : ${user.role || '-'}\n\n` // Tambah role        

        caption += `*USER STATUS*\n\n`
        caption += `- *Blocked* : ${(blocked ? '√' : '×')}\n`
        caption += `- *Banned* : ${(new Date - user.ban_temporary < env.timer) ? Func.toTime(new Date(user.ban_temporary + env.timeout) - new Date()) + ' (' + ((env.timeout / 1000) / 60) + ' min)' : user.banned ? '√' : '×'}\n`
        caption += `- *Use In Private* : ${(Object.keys(global.db.chats).includes(target) ? '√' : '×')}\n`
        caption += `- *Premium* : ${(user.premium ? '√' : '×')}\n`
        caption += `- *Expired* : ${user.expired == 0 ? '-' : Func.timeReverse(user.expired - new Date() * 1)}\n`
        caption += `- *Verified* : ${(user.registered ? '√' : '×')}\n\n`

        caption += `*EXTRA INFO*\n\n`
        caption += `- *Country* : ${country?.toUpperCase() || '-'}\n`
        caption += `- *Partner* : ${pasangan}\n`
        caption += `- *SN* : ${regCode}\n`
        caption += `- *Stamina* : ${stamina} / 100`

        let mentions = [target]
        if (user.partner) mentions.push(user.partner)

        conn.reply(m.chat, caption, m, { mentions })
    }
}
*/