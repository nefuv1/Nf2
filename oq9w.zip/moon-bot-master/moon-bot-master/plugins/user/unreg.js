/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {  
  help: ['unregister'],  
  aliases: ['unreg'],  
  tags: 'user',
  register: true,
  run: async (m, { args, usedPrefix, command, conn, users }) => {  
    const userId = m.sender;  
    const now = Date.now();  
    const cooldown = 7 * 24 * 60 * 60 * 1000; // 7 hari dalam ms

    if (users.lastUnreg && now - users.lastUnreg < cooldown) {  
      const sisa = cooldown - (now - users.lastUnreg);  
      const hari = Math.floor(sisa / (24 * 60 * 60 * 1000));  
      const jam = Math.floor((sisa % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));  
      const menit = Math.floor((sisa % (60 * 60 * 1000)) / (60 * 1000));  
      return m.reply(`You have already unregistered. Please wait another ${hari} day(s) ${jam} hour(s) ${menit} minute(s).`);  
    }  

    if (!args[0]) {  
      return m.reply(`Please provide your serial number (SN).\n\n*Example* : ${usedPrefix + command} your_SN`);  
    }  

    const inputSN = args[0].trim();  
    const realSN = users.regCode;  

    if (inputSN !== realSN) {  
      return m.reply('Your serial number (SN) is incorrect. Please check it again correctly. 👎');  
    }  

    users.lastUnreg = now;

    users.registered = false;
    users.regTime = 0;
    users.name = '';
    users.age = 0;
    users.limit = 0;
    users.exp = 0;
    users.money = 0;
    users.regCode = '';

    return m.reply('Your registration has been cancelled. You can register again after 7 days. 👍');  
  }
};