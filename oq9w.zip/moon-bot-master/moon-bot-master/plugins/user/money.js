/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const formatNumber = require('../../lib/formatNumber')

function formatLimit(num) {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')
}

module.exports = {
  help: ['exp', 'limit', 'money'],
  aliases: ['xp'],
  tags: 'user',
  register: true,
  run: async (m, { conn, command, text }) => {
  
  m.react(global.react)
  
    let target
    if (m.mentionedJid.length > 0) {
      target = m.mentionedJid[0]
    } else if (text) {
      let match = text.match(/@(\d+)/)
      if (match) target = match[1] + '@s.whatsapp.net'
    } else {
      target = m.sender
    }

    let user = global.db.users[target]

    if (!user) {
      return m.reply(`The user you tagged is not registered`)
    }

    let tagText = `@${target.split('@')[0]}`

    if (/^(exp|xp)$/i.test(command)) {
      if (user.exp < 1) return m.reply(`You have no EXP.`)
      return m.reply(`*Tag* : ${tagText}\n\n${formatNumber(user.exp)} EXP`)
    }

    if (/^limit$/i.test(command)) {
      if (user.limit < 1) return m.reply(`You have no Limit.`)
      return m.reply(`*Tag* : ${tagText}\n\n${formatLimit(user.limit)} Limit`)
    }

    if (/^money$/i.test(command)) {
      if (user.money < 1) return m.reply(`You have no Money.`)
      return m.reply(`*Tag* : ${tagText}\n\n${formatNumber(user.money)} Money`)
    }
  }
}