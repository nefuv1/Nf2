/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const queue = [];  
const cooldown = 7 * 24 * 60 * 60 * 1000; // 7 days in ms  
  
function generateSN() {  
   return Math.floor(100000 + Math.random() * 90000).toString(); // random 5 digits  
}  
  
function formatTime(ms) {  
   let totalSeconds = Math.floor(ms / 1000);  
   let hours = Math.floor(totalSeconds / 3600);  
   let minutes = Math.floor((totalSeconds % 3600) / 60);  
   let seconds = totalSeconds % 60;  
   return [hours, minutes, seconds]  
      .map(v => v.toString().padStart(2, '0'))  
      .join(':');  
}  
  
module.exports = {  
   help: ['register'],  
   aliases: ['reg', 'daftar'],  
   tags: 'user',  
   run: async (m, { users, isOwner, text, command, usedPrefix }) => {  
      const userId = m.sender;  
      const now = Date.now();  

      if (!users[userId]) users[userId] = {};
      const user = users[userId];

      if (user.registered) {  
         return m.reply('Your number is already registered. 👍');  
      }  
  
      if (user.lastUnreg && (now - user.lastUnreg < cooldown)) {  
         const remaining = cooldown - (now - user.lastUnreg);  
         const days = Math.floor(remaining / (24 * 60 * 60 * 1000));  
         const timeLeft = remaining % (24 * 60 * 60 * 1000);  
         const timeFormatted = formatTime(timeLeft);  
         return m.reply(  
            `You have unregistered recently.\nPlease wait *${days} day(s)* and *${timeFormatted}* before registering again.`  
         );  
      }

      const pos = queue.findIndex(q => q.userId === userId);
      if (pos !== -1) {
         const nowQueue = Date.now();
         if (pos === 0) {
            const timeLeft = queue[0].finishTime - nowQueue;
            return m.reply(`Your registration is in progress.\n\nRemaining time : ${formatTime(timeLeft)}`);
         } else {
            const list = queue
               .map((q, i) => {
                  const tag = '@' + q.userId.split('@')[0];
                  if (i === 0) {
                     const timeLeft = q.finishTime - nowQueue;
                     return `${i + 1}. ${tag} (processing - ${formatTime(timeLeft)} left)`;
                  } else return `${i + 1}. ${tag} (waiting)`;
               })
               .join('\n');
            return m.reply(`You are in the waiting list.\n\nCurrent queue :\n${list}`);
         }
      }

      /** 🔹 Isi profile pertama kali */
      if (!text) {
         return m.reply(`Please fill in your profile first.\n\n*Example* : ${usedPrefix}${command} username | age | gender\n\n1. *Username* : lowercase, without spaces/symbols (e.g. agung)\n2. *Age* : 12 - 30 tahun (cth: 18)\n3. *Gender* : M (male) / F (female)`)
      }

      let input = text.split('|').map(v => v.trim())
      if (input.length < 3) return m.reply(`Wrong Format!\n\n*Use* : ${usedPrefix}${command} username | age | gender`)

      let [username, age, gender] = input

      if (!/^[a-z0-9]+$/.test(username)) return m.reply(`Usernames can only be lowercase letters & numbers, no spaces.`)

      age = parseInt(age)
      if (isNaN(age) || age < 12 || age > 30) return m.reply(`Age must be between 12 - 30 years.`)

      gender = gender.toUpperCase()
      if (!['M', 'F'].includes(gender)) return m.reply(`Gender is only "M" or "F".`)

      if (isOwner) {  
         completeRegister(m, userId, now, username, age, gender);  
         return;  
      }  
  
      const isFirst = queue.length === 0;  
      const finishTime = now + 3 * 60 * 1000;  
      queue.push({ userId, finishTime, username, age, gender });  
  
      if (isFirst) {  
         m.reply('Please wait...\n\nYour registration is being processed (-3 minutes)');  
         setTimeout(async () => {  
            completeRegister(m, userId, now, username, age, gender);  
            queue.shift();  
            prosesAntrean(m);  
         }, 3 * 60 * 1000);  
      } else {  
         m.reply('Please wait...\n\nYou have been added to the registration queue.');  
      }  
   },  
};  
  
function completeRegister(m, userId, now, username, age, gender) {  
   if (!global.db.users[userId]) global.db.users[userId] = {};  
   const userData = global.db.users[userId];  
   const sn = generateSN();  

   if (userData.stamina == null) userData.stamina = 0;  
   if (userData.healt == null) userData.healt = 0;  

   Object.assign(userData, {  
      registered: true,  
      regTime: now,  
      name: username,
      username: username,
      age: age,
      gender: gender,
      limit: (userData.limit || 0) + 10,  
      exp: (userData.exp || 0) + 100000,  
      money: (userData.money || 0) + 300000,  
      stamina: userData.stamina + 100,  
      healt: userData.healt + 100,  
      regCode: sn,  
      lastReg: now  
   });  

   m.reply(`Registration Successful!\n\nCongratulations, you can enjoy this bot. 👍`);  
}  
  
function prosesAntrean(m) {  
   if (queue.length === 0) return;  
   const next = queue[0];  
   setTimeout(async () => {  
      completeRegister(m, next.userId, Date.now(), next.username, next.age, next.gender);  
      queue.shift();  
      prosesAntrean(m);  
   }, 3 * 60 * 1000);  
}