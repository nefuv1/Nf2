/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const moment = require('moment-timezone')
const formatNumber = require('../../lib/formatNumber')

const formatDetailNumber = (num) => {
    if (typeof num !== 'number') num = Number(num) || 0
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')
}

module.exports = {
   help: ['buylimit'],
   tags: 'user',
   register: true,
   run: async (m, { conn, args, Func }) => {
      try {
         m.react(global.react)
         
         if (!global.db) global.db = {}
         if (!global.db.settings) global.db.settings = {}
         if (typeof global.db.settings.limitStock === 'undefined') global.db.settings.limitStock = 10000
         if (!global.db.settings.limitRestockTime) global.db.settings.limitRestockTime = null

         const config = require('../../config.json')
         const ownerNumber = config.owner + '@s.whatsapp.net'
         let users = global.db.users[m.sender]
         let stock = global.db.settings.limitStock

         const now = moment().tz('Asia/Jakarta')
         if (global.db.settings.limitRestockTime) {
            const lastRestock = moment(global.db.settings.limitRestockTime).tz('Asia/Jakarta')
            const diffHours = now.diff(lastRestock, 'hours')
            
            if (diffHours >= 72) {
               global.db.settings.limitStock = 10000
               global.db.settings.limitRestockTime = now.format()
               stock = 10000
               await Func.saveDatabase?.()
            }
         }

         if (stock <= 0) {
            const lastRestock = global.db.settings.limitRestockTime 
               ? moment(global.db.settings.limitRestockTime).tz('Asia/Jakarta')
               : now
            const nextRestock = lastRestock.clone().add(3, 'days')
            const duration = moment.duration(nextRestock.diff(now))
            const remainingDays = Math.floor(duration.asDays())
            const remainingHours = duration.hours()
            const remainingMinutes = duration.minutes()
            
            return conn.reply(
               m.chat, 
               `Restricted stock!\n\nAutomatic restock will be available again in *${remainingDays} days ${remainingHours} hours ${remainingMinutes} minutes*.`,
               m
            )
         }

         let count = args[0] ? parseInt(args[0]) : 1
         if (isNaN(count) || count < 1) count = 1

         if (count > stock) {
            return conn.reply(m.chat, `Sorry, only *${formatDetailNumber(stock)} / 10.000* Limit left in stock.`, m)
         }

         let pricePerLimit = Math.max(10000, 10000 + users.exp * 0.01)
         let totalPrice = Math.floor(pricePerLimit * count)

         if (users.exp >= totalPrice) {
            users.exp -= totalPrice
            users.limit += count
            global.db.settings.limitStock -= count

            if (ownerNumber && global.db.users[ownerNumber]) {
               if (!global.db.users[ownerNumber].income) global.db.users[ownerNumber].income = {}
               if (!global.db.users[ownerNumber].income.incomeBuyLimit) {
                  global.db.users[ownerNumber].income.incomeBuyLimit = {
                     exp: 0,
                     totalTransactions: 0
                  }
               }
               global.db.users[ownerNumber].income.incomeBuyLimit.exp += totalPrice
               global.db.users[ownerNumber].income.incomeBuyLimit.totalTransactions++
            }

            await Func.saveDatabase?.()

            conn.reply(
               m.chat, 
               `You spent *-${formatNumber(totalPrice)}* EXP to buy *+${formatNumber(count)}* limit. 👍\n\nStock : ${formatDetailNumber(global.db.settings.limitStock)}`,
               m
            )

            if (global.db.settings.limitStock <= 0) {
               global.db.settings.limitRestockTime = now.format()
               await Func.saveDatabase?.()
            }

         } else {
            conn.reply(
               m.chat, 
               `You don't have enough EXP to buy *${formatNumber(count)}* limit. 👎\nNeed ${formatNumber(totalPrice)} EXP\n\n- *Your EXP* : ${formatNumber(users.exp)}`,
               m
            )
         }

      } catch (e) {
         console.error(e)
         return conn.reply(m.chat, Func.jsonFormat(e), m)
      }
   }
}