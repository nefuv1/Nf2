/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const formatNumber = require('../../lib/formatNumber')

function formatDuration(ms) {
  if (ms <= 0) return '0 days, 00:00:00'
  const totalSeconds = Math.floor(ms / 1000)
  const days = Math.floor(totalSeconds / 86400)
  const hours = Math.floor((totalSeconds % 86400) / 3600)
  const minutes = Math.floor((totalSeconds % 3600) / 60)
  const seconds = totalSeconds % 60
  const pad = n => n.toString().padStart(2, '0')
  return `${days} days, ${pad(hours)}:${pad(minutes)}:${pad(seconds)}`
}

module.exports = {
  help: ['weekly'],
  tags: 'user',
  register: true,
  run: async (m, { conn, users, command }) => {
    try {
      m.react(global.react)

      const timeClaim = 7 * 24 * 60 * 60 * 1000 // 1 week
      users.lastweekly = users.lastweekly || 0

      const timeout = users.lastweekly + timeClaim - Date.now()
      const exp = Math.floor(Math.random() * 501) + 500
      const money = Math.floor(Math.random() * 501) + 500
      const limit = Math.floor(Math.random() * 5) + 1

      if (timeout <= 0) {
        users.exp += exp
        users.money += money
        users.limit += limit
        users.lastweekly = Date.now()

        conn.reply(
          m.chat,
          `🎉 Congratulations! you get :\n\n` +
          `- +${formatNumber(exp)} EXP\n` +
          `- +${formatNumber(money)} Money\n` +
          `- +${formatNumber(limit)} Limit`,
          m
        )
      } else {
        conn.reply(
          m.chat,
          `Please wait *${formatDuration(timeout)}* to claim ${command} again.`,
          m
        )
      }
    } catch (e) {
      throw Func.jsonFormat(e)
    }
  }
}