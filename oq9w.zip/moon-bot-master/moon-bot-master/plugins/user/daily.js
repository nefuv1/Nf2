/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const formatNumber = require('../../lib/formatNumber')

function formatDuration(ms) {
  if (ms <= 0) return '0 days, 00:00:00'
  const totalSeconds = Math.floor(ms / 1000)
  const days = Math.floor(totalSeconds / 86400)
  const hours = Math.floor((totalSeconds % 86400) / 3600)
  const minutes = Math.floor((totalSeconds % 3600) / 60)
  const seconds = totalSeconds % 60
  const pad = n => n.toString().padStart(2, '0')
  return `${days} days, ${pad(hours)}:${pad(minutes)}:${pad(seconds)}`
}

module.exports = {
  help: ['daily'],
  tags: 'user',
  register: true,
  run: async (m, { conn, users, command, Func }) => {
    try {
      m.react(global.react)

      const timeClaim = 86400000 // 24 hours
      users.lastclaim = users.lastclaim || 0

      const timeout = users.lastclaim + timeClaim - Date.now()
      const exp = Func.randomInt(200, 500)
      const money = Func.randomInt(200, 500)

      if (timeout <= 0) {
        users.exp += exp
        users.money += money
        users.lastclaim = Date.now()

        conn.reply(
          m.chat,
          `🎉 Congratulations! you get :\n\n` +
          `- +${formatNumber(exp)} EXP\n` +
          `- +${formatNumber(money)} Money`,
          m
        )
      } else {
        conn.reply(
          m.chat,
          `Please wait *${formatDuration(timeout)}* to claim ${command || 'daily'} again.`,
          m
        )
      }
    } catch (e) {
      throw Func.jsonFormat(e)
    }
  }
}