/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const formatNumber = require('../../lib/formatNumber')

module.exports = {
  help: ['leaderboard'],
  aliases: ['lb'],  
  tags: 'user',
  run: async (m, { conn, args, participants }) => {
    let users = Object.entries(global.db.users).map(([key, value]) => {
      return { ...value, jid: key }
    })

    let sortedExp = [...users].sort((a, b) => (b.exp || 0) - (a.exp || 0))
    let sortedLim = [...users].sort((a, b) => (b.limit || 0) - (a.limit || 0))
    let sortedLevel = [...users].sort((a, b) => (b.level || 0) - (a.level || 0))
    let sortedMoney = [...users].sort((a, b) => (b.money || 0) - (a.money || 0))

    let usersExp = sortedExp.map(v => v.jid)
    let usersLim = sortedLim.map(v => v.jid)
    let usersLevel = sortedLevel.map(v => v.jid)
    let usersMoney = sortedMoney.map(v => v.jid)

    let len = args[0] && args[0].length > 0
      ? Math.min(10, Math.max(parseInt(args[0]), 10))
      : Math.min(10, sortedExp.length)

    let text = `*LEADERBOARD*
    
*"EXP" Top ${len}*
You : *${usersExp.indexOf(m.sender) + 1}* dari *${usersExp.length}*

${sortedExp.slice(0, len).map(({ jid, exp }, i) => {
      let display = participants.some(p => jid === p.jid) ? `(${conn.getName(jid)}) wa.me/` : '@'
      return `${i + 1}. ${display}${jid.split`@`[0]} *${formatNumber(exp || 0)} EXP*`
    }).join('\n')}

*"LIMIT" Top ${len}*
You : *${usersLim.indexOf(m.sender) + 1}* dari *${usersLim.length}*

${sortedLim.slice(0, len).map(({ jid, limit }, i) => {
      let display = participants.some(p => jid === p.jid) ? `(${conn.getName(jid)}) wa.me/` : '@'
      return `${i + 1}. ${display}${jid.split`@`[0]} *${formatNumber(limit || 0)} Limit*`
    }).join('\n')}

*"LEVEL" Top ${len}*
You : *${usersLevel.indexOf(m.sender) + 1}* dari *${usersLevel.length}*

${sortedLevel.slice(0, len).map(({ jid, level }, i) => {
      let display = participants.some(p => jid === p.jid) ? `(${conn.getName(jid)}) wa.me/` : '@'
      return `${i + 1}. ${display}${jid.split`@`[0]} *Level ${level || 0}*`
    }).join('\n')}

*"MONEY" Top ${len}*
You : *${usersMoney.indexOf(m.sender) + 1}* dari *${usersMoney.length}*

${sortedMoney.slice(0, len).map(({ jid, money }, i) => {
      let display = participants.some(p => jid === p.jid) ? `(${conn.getName(jid)}) wa.me/` : '@'
      return `${i + 1}. ${display}${jid.split`@`[0]} *${formatNumber(money || 0)} Money*`
    }).join('\n')}
`.trim()

    conn.reply(m.chat, text, m, {
      contextInfo: {
        mentionedJid: [
          ...usersExp.slice(0, len),
          ...usersLim.slice(0, len),
          ...usersLevel.slice(0, len),
          ...usersMoney.slice(0, len),
        ].filter(v => !participants.some(p => v === p.jid))
      }
    })
  }
}