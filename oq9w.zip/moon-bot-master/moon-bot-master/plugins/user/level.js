/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const { xpRange, canLevelUp } = new (require('../../lib/system/levelling'))

module.exports = {
  help: ['level'],
  aliases: ['levelup'],
  tags: 'user',
  register: true,
  run: async (m, { conn, users, env, Func }) => {
    try {
      let user = Object.entries(global.db.users).map(([key, value]) => {
        return { ...value, jid: key }
      })
      let { xp, min, max } = xpRange(users.level, env.multiplier)
      let sortedLevel = user.sort((a, b) => b.level - a.level)

      if (!canLevelUp(users.level, users.exp, env.multiplier)) {
        return conn.reply(m.chat, `*LEVEL*\n\n*Level* : ${users.level}\n*EXP* : ${users.exp} / ${max}\n\nLess [ *${max - users.exp}* ] EXP to level up.`, m)
      }

      let before = users.level
      while (canLevelUp(users.level, users.exp, env.multiplier)) {
        users.level++
      }
      if (before !== users.level) {
        return conn.reply(m.chat, `*LEVEL UP*\n\nFrom : [ ${before} ] ➠ [ ${users.level} ]\nCongratulations you leveled up..`, m)
      }
    } catch (e) {
      console.error(e)
           throw Func.jsonFormat(e)
    }
  }
}