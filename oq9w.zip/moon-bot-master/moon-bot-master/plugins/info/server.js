/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const os = require('os')
module.exports = {
   help: ['server'],
   aliases: ['srvr'],
   tags: 'info',
   run: async (m, {
      conn,
      Func
   }) => {
      try {
         const json = await Func.fetchJson('http://ip-api.com/json')
         delete json.status
         delete json.query
         let caption = `*SERVER*\n\n`
         caption += `- *OS* : ${os.type()} (${os.arch()} / ${os.release()})\n`
         caption += `- *Ram* : ${Func.formatSize(process.memoryUsage().rss)} / ${Func.formatSize(os.totalmem())}\n`
         for (let key in json) caption += `- *${Func.ucword(key)}* : ${json[key]}\n`
         caption += `- *Uptime* : ${Func.toTime(os.uptime * 1000)}\n`
         caption += `- *Processor* : ${os.cpus()[0].model}`
         m.reply(caption)
      } catch (e) {
         console.log(e)
      }
   }
}