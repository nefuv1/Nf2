/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['total'],
   aliases: ['feature', 'fitur'],
   tags: 'info',
   run: async (m, { conn, plugins }) => {
      let users = Object.values(global.db.users)

      let total = users.length
      let totalM = users.filter(u => u.gender === 'M').length
      let totalF = users.filter(u => u.gender === 'F').length

      let totalFeature = plugins ? plugins.size : Object.keys(global.plugins).length

      let persenM = total ? ((totalM / total) * 100).toFixed(1) : 0
      let persenF = total ? ((totalF / total) * 100).toFixed(1) : 0

      let teks = `*TOTAL*\n\n`
      teks += `- *Total users* : ${total}\n`
      teks += `- *Total features* : ${totalFeature}\n\n`
      teks += `- *Male* : ${totalM} (${persenM}%)\n`
      teks += `- *Female* : ${totalF} (${persenF}%)`

      conn.reply(m.chat, teks.trim(), m)
   },
   error: false
}