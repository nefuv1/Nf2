/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['owner'],
   aliases: ['creator', 'dev', 'developer'],
   tags: 'info',
   run: async (m, {
      conn,
      env
   }) => {
      conn.sendContact(m.chat, [{
         name: env.owner_name,
         number: env.owner,
         about: 'Owner & Creator'
      }], m, {
         org: 'Agung Support',
         website: 'https://profile.agungtect.web.id',
         email: 'agungdev3@gmail.com'
      })
   }
}