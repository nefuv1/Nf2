/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
    help: ['donate'],
    aliases: ['donasi', 'saweria', 'support'],
    tags: 'info',
    run: async (m, { 
        conn, 
        usedPrefix, 
        command,
        Func
    }) => {
        let caption = `*DONATEE*
    
*Donate to Support Bot Development*
We really appreciate your support. Donations are very meaningful for better bot development and new features.

*Donation Number*
- *DANA* : 6283126390134 (a/n Yulanah / Agung Store)
- *GOPAY* : 6283126390134 (a/n Yulanah / Agung Mahesa)

*Donate via QR Code* 
Scan the QR code above to donate with your favorite e-wallet. The QR code is *All Payment*

*Donate via Saweria URL*
You can also donate via this Saweria url, Click the link below.
URL: saweria.co/siagungg

*Thank You for Your Donation!*
May your kindness be rewarded with abundant blessings and ease in all matters. Every support really helps the development of this bot in the future.
`.trim();

        try {
            await conn.sendMessage(m.chat, { 
                image: { url: 'https://qu.ax/OxHj.jpg' }, // URL gambar QR Code
                caption: caption,
                footer: 'Your support is highly appreciated!',
                mentions: [m.sender]
            }, { quoted: m });
        } catch (e) {
            console.error(e);
           throw Func.jsonFormat(e)
        }
    }
};