/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const moment = require('moment-timezone')

module.exports = {
   help: ['botstat'],
   aliases: ['stat', 'status'],
   tags: 'info',
   run: async (m, { conn, blockList, setting, plugins, Func }) => {
      try {
         let users = Object.entries(global.db.users || {})
         let chats = Object.keys(global.db.chats || {})
         let groups = Object.keys(global.db.groups || {})
         
         class Hit extends Array {
            total(key) {
               return this.reduce((a, b) => a + (b[key] || 0), 0)
            }
         }
         
         let sum = new Hit(...Object.values(global.db.statistic || {}))
         const stats = {
            users: users.length,
            chats: chats.filter(v => v.endsWith('.net')).length,
            groups: groups.filter(v => v.endsWith('g.us')).length,
            banned: users.filter(([_, v]) => v.banned).length,
            blocked: blockList.length,
            premium: users.filter(([_, v]) => v.premium).length,
            cmd: plugins.size,
            hitstat: sum.total('hitstat') != 0 ? sum.total('hitstat') : 0,
            uptime: Func.toTime(process.uptime() * 1000),
         }
         
         const statistic = (Func, stats, setting) => {
            return `*BOTSTAT*

- ${Func.formatNumber(stats.groups)} Groups Joined
- ${Func.formatNumber(stats.chats)} Personal Chats
- ${Func.formatNumber(stats.users)} Users In Database
- ${Func.formatNumber(stats.banned)} Users Banned
- ${Func.formatNumber(stats.blocked)} Users Blocked
- ${Func.formatNumber(stats.premium)} Premium Users
- ${Func.formatNumber(stats.hitstat)} Commands Hit
- ${Func.formatNumber(stats.cmd)} Commands Loaded
- *Runtime* : ${stats.uptime}

*SYSTEM*

- ${setting.antispam ? '[ √ ]' : '[ × ]'} Anti Spam
- ${setting.anticall ? '[ √ ]' : '[ × ]'} Anti Call
- ${setting.autobackup ? '[ √ ]' : '[ × ]'} Auto Backup
- ${setting.debug ? '[ √ ]' : '[ × ]'} Debug Mode
- ${setting.groupmode ? '[ √ ]' : '[ × ]'} Group Mode
- ${setting.privatemode ? '[ √ ]' : '[ × ]'} Private Mode
- ${setting.online ? '[ √ ]' : '[ × ]'} Always Online
- ${setting.noprefix ? '[ √ ]' : '[ × ]'} No Prefix
- ${setting.self ? '[ √ ]' : '[ × ]'} Self Mode
- *Prefix* : ( ${setting.prefix ? setting.prefix.map(v => v).join(' ') : usedPrefix} )
- *Reset At* : ${moment(setting.lastReset || new Date()).format('DD/MM/YYYY HH:mm')}`
         }

         let message = statistic(Func, stats, setting)
         m.reply(message)
         
      } catch (e) {
           throw Func.jsonFormat(e)
      }
   }
}