/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const moment = require('moment-timezone')
moment.tz.setDefault(process.env.TZ).locale('id')

module.exports = {
   help: ['hitstat'],
   aliases: ['hit'],
   tags: 'info',
   run: async (m, { conn, usedPrefix, command, setting, Func }) => {
      const types = command == 'hitstat' ? global.db.statistic : Object.fromEntries(Object.entries(global.db.statistic).filter(([_, prop]) => moment(prop.lasthit).format('DDMMYY') == moment(new Date).format('DDMMYY')))
      
      let stat = Object.keys(types)
      if (stat.length == 0) return m.reply(`No command is used.`)
      
      class Hit extends Array {
         total(key) {
            return this.reduce((a, b) => a + (b[key] || 0), 0)
         }
      }
      
      let sum = new Hit(...Object.values(types))
      let sorted = command == 'hitstat' ? Object.entries(types).sort((a, b) => b[1].hitstat - a[1].hitstat) : Object.entries(types).sort((a, b) => b[1].today - a[1].today)
      let show = Math.min(10, sorted.length)
      
      let teks = `*HITSTAT*\n\n`
      teks += `*Total* : ${Func.formatNumber(command == 'hitstat' ? sum.total('hitstat') : sum.total('today'))}\n\n`
      
      teks += sorted.slice(0, show).map(([cmd, prop], i) => {
         return `[${i + 1}]\n- *Command* : \`\`\`${usedPrefix}${cmd}\`\`\`\n- *Hit* : ${Func.formatNumber(command == 'hitstat' ? prop.hitstat : prop.today)}x\n- *Last Hit* : ${moment(prop.lasthit).format('DD/MM/YY HH:mm:ss')}`
      }).join('\n\n')

      m.reply(teks)
   }
}