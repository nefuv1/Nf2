/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const moment = require('moment-timezone')
moment.tz.setDefault(process.env.TZ).locale('id')

module.exports = {
   help: ['listgroup'],
   aliases: ['groups','grouplist','listgc','gclist'],
   tags: 'info',
   run: async (m, { conn, usedPrefix, command, Func }) => {
      try {
         let groups = Object.entries(await conn.groupFetchAllParticipating()).map(entry => entry[1]).filter(group => !group.isCommunity)
         
         if (groups.length === 0) return m.reply('The bot has not joined any groups yet.')
         
         let caption = `*GROUP LIST*\n\n`
         caption += `*Total Groups* : ${groups.length} groups\n\n`
         
         groups.map((x, i) => {
            let v = global.db.groups[x.id]
            if (!v) {
               global.db.groups[x.id] = {
                  activity: new Date * 1,
                  mute: false,
                  welcome: true,
                  left: true,
                  autodetect: false,
                  autosticker: false,
                  antidelete: false,
                  antilink: false,
                  antivirtex: false,
                  antisticker: false,
                  antitagsw: false,
                  antiporn: false,
                  antiviewonce: false,
                  antitoxic: false,
                  member: {},
                  expired: 0,
                  stay: false
               }
               v = global.db.groups[x.id]
            }
            
            let expiredText = '';
            if (v.stay) {
               expiredText = '*FOREVER*';
            } else if (v.expired == 0) {
               expiredText = '*NOT SET*';
            } else {
               const now = new Date() * 1;
               const remaining = v.expired - now;
               
               if (remaining <= 0) {
                  expiredText = '*EXPIRED*';
               } else {
                  const expiredDate = moment(v.expired);
                  const nowDate = moment();
                  const diff = moment.duration(remaining);
                  
                  if (diff.asDays() >= 1) {
                     expiredText = `${Math.floor(diff.asDays())} days ${diff.hours()}h ${diff.minutes()}m`;
                  } else if (diff.asHours() >= 1) {
                     expiredText = `${Math.floor(diff.asHours())}h ${diff.minutes()}m ${diff.seconds()}s`;
                  } else if (diff.asMinutes() >= 1) {
                     expiredText = `${Math.floor(diff.asMinutes())}m ${diff.seconds()}s`;
                  } else {
                     expiredText = `${Math.floor(diff.asSeconds())}s`;
                  }
                  
                  expiredText += `\nUntil: ${expiredDate.format('DD/MM/YYYY HH:mm:ss')}`;
               }
            }
            
            const lastActivity = v.activity ? moment(v.activity).format('DD/MM/YY HH:mm:ss') : 'Never';
            const activityAgo = v.activity ? moment(v.activity).fromNow() : 'Never';
            
            caption += `[${i + 1}]\n`
            caption += `- *Name* : ${x.subject}\n`
            caption += `- *Members* : ${x.participants.length} people\n`
            caption += `- *ID* : ${x.id.split`@`[0]}\n`
            caption += `- *Status* : ${v.mute ? 'MUTED' : 'ACTIVE'}\n`
            caption += `- *Expired* : ${expiredText}\n`
            caption += `- *Last Activity* : ${lastActivity}\n`
            caption += `- *(${activityAgo})*\n\n`
         })

         m.reply(caption)
         
      } catch (e) {
         console.error(e);
           throw Func.jsonFormat(e)
      }
   }
}
