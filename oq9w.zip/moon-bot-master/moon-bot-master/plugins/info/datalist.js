/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const moment = require('moment-timezone')
moment.tz.setDefault('Asia/Jakarta')

module.exports = {
   help: ['listprem', 'listban', 'listblock', 'listchat'],
   tags: 'info',
   run: async (m, { conn, command, blockList, isOwner, Func }) => {
      try {
         if (command == 'listprem') {
            const data = Object.entries(global.db.users || {}).filter(([_, data]) => data.premium)
            if (data.length == 0) return m.reply(`Empty data. 👎`)
            
            let teks = `*LIST PREMIUM*\n\n`
            teks += data.map(([jid, data], i) => {
               return `[${i + 1}]\n- *Tags* : @${jid.replace(/@.+/, '')}\n- *Limit* : ${Func.formatNumber(data.limit)}\n- *Expired* : ${Func.timeReverse(data.expired - new Date() * 1)}`
            }).join('\n\n')
            
            m.reply(teks)

         } else if (command == 'listban') {
            const data = Object.entries(global.db.users || {}).filter(([_, data]) => data.banned)
            if (data.length == 0) return m.reply(`Empty data. 👎`)
            
            let teks = `*LIST BANNED*\n\n`
            teks += data.map(([jid, _], i) => {
               return `[${i + 1}]\n- *Tags* : @${jid.replace(/@.+/, '')}`
            }).join('\n\n')
            
            m.reply(teks)

         } else if (command == 'listblock') {
            if (blockList.length < 1) return m.reply(`Empty data. 👎`)
            
            let teks = `*LIST BLOCK*\n\n`
            teks += blockList.map((v, i) => {
               return `[${i + 1}]\n- *Tags* : @${conn.decodeJid(v).replace(/@.+/, '')}`
            }).join('\n\n')
            
            m.reply(teks)

         } else if (command == 'listchat') {
            if (!isOwner) return m.reply(global.status.owner)
            
            const data = Object.entries(global.db.chats || {}).filter(([jid, _]) => jid.endsWith('.net'))
            if (data.length == 0) return m.reply(`Empty data. 👎`)
            
            let teks = `*LIST CHAT*\n\n`
            teks += data.sort((a, b) => b[1].lastseen - a[1].lastseen).map(([jid, data], i) => {
               return `[${i + 1}]\n- *Tags* : @${jid.replace(/@.+/, '')}\n- *Chat* : ${Func.formatNumber(data.chat)}\n- *LastChat* : ${moment(data.lastseen).format('DD/MM/YY HH:mm:ss')}`
            }).join('\n\n')
            
            m.reply(teks)
         }
      } catch (e) {
           throw Func.jsonFormat(e)
      }
   }
}