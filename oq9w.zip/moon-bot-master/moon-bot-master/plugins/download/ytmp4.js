/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const fetch = require('node-fetch');

async function downloadYouTube(videoId, format = "mp4") {
    const headers = {
        "accept-encoding": "gzip, deflate, br, zstd",
        "origin": "https://ht.flvto.online",
        "content-type": "application/json",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    };
    
    const body = JSON.stringify({
        "id": videoId,
        "fileType": format
    });
    
    const response = await fetch(`https://ht.flvto.online/converter`, {
        headers, 
        body, 
        method: "POST"
    });
    
    if (!response.ok) throw new Error(`${response.status} ${response.statusText}\n${await response.text()}`);
    const json = await response.json();
    return json;
}

function extractVideoId(url) {
    const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
    const match = url.match(regex);
    return match ? match[1] : null;
}

function formatSize(bytes) {
    if (!bytes) return 'Unknown';
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
}

function formatDuration(seconds) {
    if (!seconds) return 'Unknown';
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hours > 0) {
        return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    } else {
        return `${minutes}:${secs.toString().padStart(2, '0')}`;
    }
}

module.exports = {
   help: ['ytmp4'],
   aliases: ['ytv'],
   tags: 'download',
   limit: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      args,
      users,
      env,
      Func
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingYtmp4 = user.isProcessingYtmp4 || false;
         
         if (user.isProcessingYtmp4) throw global.status.previously;
         if (!args[0]) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://youtu.be/zaRFmdtLhQ8\n\nIt is recommended to download audio that is at least *30 minutes* long, no more than *1 hour*.`;
         if (!/^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/.test(args[0])) throw 'Invalid YouTube URL.';
         
         user.isProcessingYtmp4 = true;
         conn.sendReact(m.chat, global.react, m.key);
         
         const videoId = extractVideoId(args[0]);
         if (!videoId) throw 'Could not extract video ID from URL';
         
         const json = await downloadYouTube(videoId, "mp4");
         
         if (!json || json.status !== 'success') {
             throw json.msg || 'Failed to download video information';
         }

         let videoUrl, quality, fileSize;
         
         if (json.formats && json.formats.length > 0) {
             const format = json.formats.find(f => f.itag === 18) || json.formats[0];
             videoUrl = format.url;
             quality = format.qualityLabel || 'Unknown';
             fileSize = format.contentLength ? formatSize(format.contentLength) : 'Unknown';
         } else if (json.link) {
             videoUrl = json.link;
             quality = 'Unknown';
             fileSize = json.filesize ? formatSize(json.filesize) : 'Unknown';
         } else {
             throw 'No video formats available';
         }

         let txt = `*YOUTUBE MP4*\n\n`;
         txt += `- *Title* : ${json.title || 'Unknown'}\n`;
         txt += `- *Duration* : ${formatDuration(json.duration)}\n`;
         txt += `- *Quality* : ${quality}\n`;
         txt += `- *Size* : ${fileSize}`;

         const sizeInMB = fileSize !== 'Unknown' ? parseFloat(fileSize) : 0;
         const chSize = Func.sizeLimit(fileSize, users.premium ? env.max_upload : env.max_upload_free);
         const isOver = users.premium ? 
             `File size (${fileSize}) exceeds the maximum limit.` : 
             `File size (${fileSize}), you can only download files with a maximum size of ${env.max_upload_free} MB and for premium users a maximum of ${env.max_upload} MB.`;
         
         if (chSize.oversize) throw isOver;

         const videoResponse = await fetch(videoUrl);
         if (!videoResponse.ok) throw 'Failed to download video file';
         
         const videoBuffer = await videoResponse.buffer();

         await conn.sendMessage(m.chat, {
             video: videoBuffer,
             caption: txt,
             fileName: `${json.title || 'youtube_video'}.mp4`
         }, { quoted: m });
         
      } catch (e) {
         console.error(e);
         throw Func.jsonFormat(e);
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingYtmp4 = false;
         }
      }
   }
};

/** versi api alyachan
module.exports = {
   help: ['ytmp4'],
   aliases: ['ytv'],
   tags: 'download',
   limit: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      args,
      users,
      env,
      Func
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingYtmp4 = user.isProcessingYtmp4 || false;
         
         if (user.isProcessingYtmp4) throw global.status.previously
         if (!args[0]) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://youtu.be/zaRFmdtLhQ8`
         if (!/^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/.test(args[0])) throw 'Invalid YouTube URL.'
         
         user.isProcessingYtmp4 = true;
         conn.sendReact(m.chat, global.react, m.key);
         
         const json = await Api.get('/ytv', {
            url: args[0]
         });
         if (!json.status) throw Func.jsonFormat(json)
         
         let txt = `*YOUTUBE MP4*\n\n`
         txt += `- *Title* : ${json.title}\n`
         txt += `- *Duration* : ${json.duration}\n`
         txt += `- *Views* : ${json.views}\n`
         txt += `- *Size* : ${json.data.size}`
         
         const chSize = Func.sizeLimit(json.data.size, users.premium ? env.max_upload : env.max_upload_free);
         const isOver = users.premium ? `File size (${json.data.size}) exceeds the maximum limit.` : `File size (${json.data.size}), you can only download files with a maximum size of ${env.max_upload_free} MB and for premium users a maximum of ${env.max_upload} MB.`;
         
         if (chSize.oversize) throw isOver
         conn.sendFile(m.chat, json.data.url, json.data.filename, txt, m);
         
      } catch (e) {
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingYtmp4 = false;
         }
      }
   }
}
*/