/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require("axios");

async function pindl(url) {
  try {
    const api = 'https://pinterestdownloader.io/frontendService/DownloaderService';
    const { data } = await axios.get(api, {
      params: { url }
    });
    return data;
  } catch (e) {
    throw new Error('Failed to fetch data from Pinterest downloader API.');
  }
}

module.exports = {
  help: ['pinterestdl'],
  aliases: ['pindl'],
  tags: 'download',
  limit: true,
  run: async (m, { conn, Func, text, usedPrefix, command }) => {
    try {
      let user = global.db.users[m.sender] || {};
      user.isProcessingPindl = user.isProcessingPindl || false;

      if (user.isProcessingPindl) throw global.status.previously
      if (!text) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://pin.it/5yeybIFUA`

      user.isProcessingPindl = true;
      m.react(global.react);

      const data = await pindl(text);

      if (!data || !data.medias || data.medias.length === 0) {
        throw new Error('No media found in the response');
      }

      let media = null;
      const videoMedia = data.medias.find(m => m.extension === 'mp4');
      if (videoMedia) {
        media = videoMedia;
      } else {
        media = data.medias.sort((a, b) => b.size - a.size)[0]; // ambil gambar terbesar
      }

      if (!media || !media.url) {
        throw new Error('No valid media URL found');
      }

      await conn.sendFile(m.chat, media.url, '', `${text}`, m);

    } catch (e) {
      console.error(e);
           throw Func.jsonFormat(e)
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingPindl = false;
      }
    }
  }
};