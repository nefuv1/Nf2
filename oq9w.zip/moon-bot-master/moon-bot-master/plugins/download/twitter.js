/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');
const cheerio = require('cheerio');

async function scrapeTwitter(videoUrl) {
  const apiUrl = "https://snaptwitter.com/action.php";
  try {
    const { data: html } = await axios.get("https://snaptwitter.com/", {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
      }
    });
    const $tok = cheerio.load(html);
    const tokenValue = $tok('input[name="token"]').attr("value");

    const formData = new URLSearchParams();
    formData.append("url", videoUrl);
    formData.append("token", tokenValue || "");

    const config = {
      headers: { 
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
      },
    };
    
    const response = await axios.post(apiUrl, formData, config);
    const $ = cheerio.load(response.data.data);

    const result = {
      imgUrl: $(".videotikmate-left img").attr("src"),
      downloadLink: `${$(".abuttons a").attr("href")}`,
      videoTitle: $(".videotikmate-middle h1").text().trim(),
      videoDescription: $(".videotikmate-middle p span").text().trim(),
    };

    return result;
  } catch (error) {
    console.error("Error downloading video:", error);
    throw new Error("Failed to download video data");
  }
}

module.exports = {
  help: ['x'],
  aliases: ['twitter', 'twit'],
  tags: 'download',
  limit: true,
  run: async (m, {
    conn,
    usedPrefix,
    command,
    args,
    Func
  }) => {
    try {
      let user = global.db.users[m.sender] || {};
      user.isProcessingTwitter = user.isProcessingTwitter || false;
      
      if (user.isProcessingTwitter) throw global.status.previously;
      if (!args[0]) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://twitter.com/gofoodindonesia/status/1229369819511709697`;
      if (!args[0].match(/(https?:\/\/)?(www\.)?(twitter\.com|x\.com)\/([a-zA-Z0-9_]+)\/status\/(\d+)/)) throw global.status.invalid;
      
      user.isProcessingTwitter = true;
      m.react(global.react);
      
      const json = await scrapeTwitter(args[0]);
      
      if (!json || !json.downloadLink) {
        throw new Error('Failed to download Twitter video');
      }
      
      const videoResponse = await axios.get(json.downloadLink, {
        responseType: 'arraybuffer',
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
      });
      
      const videoBuffer = Buffer.from(videoResponse.data);
      
      await conn.sendMessage(m.chat, {
        video: videoBuffer,
        caption: `*X*\n\n- *Title* : ${json.videoTitle || 'No title'}\n- *Description* : ${json.videoDescription || 'No description'}`,
        mentions: [m.sender]
      }, { quoted: m });
      
    } catch (e) {
      console.log(e);
      throw Func.jsonFormat(e);
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingTwitter = false;
      }
    }
  }
};



/** Api Alya Chan
module.exports = {
   help: ['x'],
   aliases: ['twitter', 'twit'],
   tags: 'download',
   limit: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      args,
      Func
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingTwitter = user.isProcessingTwitter || false;
         
         if (user.isProcessingTwitter) throw global.status.previously
         if (!args[0]) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://twitter.com/gofoodindonesia/status/1229369819511709697`
         if (!args[0].match(/(https?:\/\/)?(www\.)?(twitter\.com|x\.com)\/([a-zA-Z0-9_]+)\/status\/(\d+)/)) throw global.status.invalid
         
         user.isProcessingTwitter = true;
         m.react(global.react)
         
         var json = await Api.get('api/twitter', {
            url: args[0]
         })
         if (!json.status) throw Func.jsonFormat(json)
         
         let url = json.data.find((v) => v.url).url
         await conn.sendFile(m.chat, url, '', ``, m)
         
      } catch (e) {
         console.log(e)
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingTwitter = false;
         }
      }
   }
}
*/