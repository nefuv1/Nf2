/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['threads'],
   aliases: ['trads'],
   tags: 'download',
   limit: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      args,
      Func
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingThreads = user.isProcessingThreads || false;
         
         if (user.isProcessingThreads) throw global.status.previously
         if (!args[0]) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://www.threads.net/t/CuiXbGvPyJz/?igshid=NTc4MTIwNjQ2YQ==`
         if (!/https?:\/\/(?:www\.)?(threads\.(net|com)|[\w-]+\.com)\/[^\s"]*/i.test(args[0])) throw global.status.invalid
         
         user.isProcessingThreads = true;
         m.react(global.react)
         
         var json = await Api.get('api/threads', {
            url: args[0]
         })
         if (!json.status) throw Func.jsonFormat(json)
         
         for (let i of json.data) {
            conn.sendFile(m.chat, i.url, '', ``, m)
         }
         
      } catch (e) {
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingThreads = false;
         }
      }
   }
}