/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['igstory'],
   aliases: ['igs'],
   tags: 'download',
   limit: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      args,
      Func
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingIgs = user.isProcessingIgs || false;
         
         if (user.isProcessingIgs) throw global.status.previously
         if (!args || !args[0]) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://instagram.com/stories/pandusjahrir/3064777897102858938?igshid=MDJmNzVkMjY=`
         
         user.isProcessingIgs = true;
         conn.sendReact(m.chat, global.react, m.key)
         
         const json = await Api.get('/igs', {
            q: args[0]
         })
         if (!json.status) throw Func.jsonFormat(json)
         
         json.data.map(async (v, i) => {
            conn.sendFile(m.chat, v.url, v.type == 'video' ? Func.filename('mp4') : Func.filename('jpg'), ``, m)
            await Func.delay(1500)
         })
         
      } catch (e) {
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingIgs = false;
         }
      }
   }
}