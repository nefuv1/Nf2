/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['googledrive'],
   aliases: ['gdrive'],
   tags: 'download',
   limit: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      args,
      users,
      env,
      Func
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingGdrive = user.isProcessingGdrive || false;
         
         if (user.isProcessingGdrive) throw global.status.previously
         if (!args || !args[0]) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://drive.google.com/file/d/1SluvqDGhjFqg2f-74RJB8DjobcCZO_rY/view?usp=drive_link`
         if (!args[0].match('drive.google.com')) throw global.status.invalid
         
         user.isProcessingGdrive = true;
         conn.sendReact(m.chat, global.react, m.key);
         
         const json = await Api.get('/gdrive', {
            url: args[0]
         });
         
         if (!json.status) throw Func.jsonFormat(json)
         
         const chSize = Func.sizeLimit(json.data.size, users.premium ? env.max_upload : env.max_upload_free);
         const isOver = users.premium ? 
            `File size (${json.data.size}) exceeds the maximum limit.` : 
            `File size (${json.data.size}), you can only download files with a maximum size of ${env.max_upload_free} MB and for premium users a maximum of ${env.max_upload} MB.`;
         
         if (chSize.oversize) throw isOver
         
         conn.sendFile(m.chat, json.data.url, json.data.filename, '', m);
         
      } catch (e) {
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingGdrive = false;
         }
      }
   }
};