/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');
const cheerio = require('cheerio');

module.exports = {
  help: ['tiktok'],
  aliases: ['tt', 'tiktok-wm', 'tiktok-mp3'],
  tags: 'download',
  limit: true,
  run: async (m, { conn, text, usedPrefix, command, Func }) => {
    try {
      let user = global.db.users[m.sender] || {};
      user.isProcessingTiktok = user.isProcessingTiktok || false;
      
      if (user.isProcessingTiktok) throw global.status.previously
      
      if (!text) {
        if (!m.quoted || !m.quoted.text) {
          throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://www.tiktok.com/@cikaseiska/video/7379107227363200261?is_from_webapp=1&sender_device=pc&web_id=7330639260519974418`
        }
        text = m.quoted.text;
      }

      const url = text.match(/https?:\/\/[^ ]+tiktok\.com\/[^\s]+/i)?.[0];
      if (!url) throw global.status.invalid

      user.isProcessingTiktok = true;
      
      m.react(global.react);

      try {
        const json = await Func.fetchJson(API('alya', '/api/tiktok', { url }, 'apikey'));

        if (json.status && json.data) {
          await handleAPIResponse(json, m, conn, command);
          return;
        }
      } catch (apiError) {
        console.error('[Primary API Error]', apiError.message);
      }

      try {
        await handleFallbackMethods(url, m, conn, command);
      } catch (fallbackError) {
        console.error('[Fallback Error]', fallbackError.message);
        throw fallbackError;
      }

    } catch (e) {
      console.error(e);
           throw Func.jsonFormat(e)
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingTiktok = false;
      }
    }
  }
};

async function handleAPIResponse(json, m, conn, command) {
  const teks = `${json.title}\n${Func.settings.footer}`;
  const videoResult = json.data.find(v => v.type === 'nowatermark');
  const audioResult = json.music_info?.url;

  switch (command) {
    case 'tiktok':
    case 'tt':
      if (videoResult) {
        await conn.sendFile(m.chat, videoResult.url, Func.filename('mp4'), teks, m);
      } else {
        for (const x of json.data) {
          await conn.sendFile(m.chat, x.url, Func.filename('jpg'), teks, m);
        }
      }
      if (audioResult) {
        await sendAudio(conn, m, audioResult, json.title);
      }
      break;

    case 'tiktok-wm':
      const videoWM = json.data.find(v => v.type === 'watermark');
      if (videoWM) {
        await conn.sendFile(m.chat, videoWM.url, Func.filename('mp4'), teks, m);
      }
      if (audioResult) {
        await sendAudio(conn, m, audioResult, json.title);
      }
      break;

    case 'tiktok-mp3':
      if (audioResult) {
        await sendAudio(conn, m, audioResult, json.title);
      } else {
        throw new Error('Failed to fetch audio from TikTok link');
      }
      break;
  }
}

async function handleFallbackMethods(url, m, conn, command) {
  const imageResult = await getTikTokImages(url);
  if (imageResult.success && imageResult.urls.length > 0) {
    const audio = await tiktokDownloader(url);
    for (let i = 0; i < imageResult.urls.length; i++) {
      await conn.sendFile(m.chat, imageResult.urls[i], `slide_${i + 1}.jpg`, '', m);
    }
    if (audio.music) {
      await sendAudio(conn, m, audio.music, audio.title);
    }
    return;
  }

  const p = await tiktokDownloader(url);
  
  if (command === 'tiktok-mp3') {
    if (p.music) {
      await sendAudio(conn, m, p.music, p.title);
    } else {
      throw new Error('No audio found in this TikTok');
    }
    return;
  }

  const videoUrl = command === 'tiktok-wm' ? p.watermark : p.no_watermark;
  if (!videoUrl) throw new Error('Video URL not found');

  const tag = await conn.sendFile(m.chat, videoUrl, 'tiktok.mp4', p.title, m);
  
  if (p.music && command !== 'tiktok-mp3') {
    await sendAudio(conn, m, p.music, p.title, tag);
  }
}

async function sendAudio(conn, m, audioUrl, title, quoted) {
  return conn.sendMessage(m.chat, {
    audio: { url: audioUrl },
    mimetype: 'audio/mp4',
    fileName: `${title}.mp3`
  }, { quoted: quoted || m });
}

async function tiktokDownloader(query) {
  const data = new URLSearchParams();
  data.set('url', query);
  data.set('hd', '1');

  const res = await axios.post('https://tikwm.com/api/', data.toString(), {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      'Cookie': 'current_language=en',
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K)',
    }
  });

  const videos = res.data.data;
  return {
    title: videos.title,
    cover: videos.cover,
    origin_cover: videos.origin_cover,
    no_watermark: videos.play,
    watermark: videos.wmplay,
    music: videos.music
  };
}

async function getTikTokImages(tiktokUrl) {
  try {
    const response = await axios.post('https://tikvideo.app/api/ajaxSearch',
      `q=${encodeURIComponent(tiktokUrl)}&lang=en&cftoken=`, {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'X-Requested-With': 'XMLHttpRequest',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K)',
          'Referer': 'https://tikvideo.app/en/download-tiktok-photo'
        }
      });

    if (response.data.status !== 'ok') return { success: false };

    const $ = cheerio.load(response.data.data);
    const urls = [];

    $('.photo-list .download-items__thumb img').each((_, el) => {
      const src = $(el).attr('src');
      if (src) urls.push(src);
    });

    return { success: urls.length > 0, urls };
  } catch (err) {
    return { success: false, error: err.message };
  }
}