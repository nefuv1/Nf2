/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');
const crypto = require('crypto');

const savetube = {
  api: {
    base: "https://media.savetube.me/api",
    cdn: "/random-cdn",
    info: "/v2/info",
    download: "/download"
  },
  headers: {
    'accept': '*/*',
    'content-type': 'application/json',
    'origin': 'https://yt.savetube.me',
    'referer': 'https://yt.savetube.me/',
    'user-agent': 'Postify/1.0.0'
  },

  crypto: {
    hexToBuffer: (hexString) => {
      if (!hexString) throw new Error('Hex string is required');
      const matches = hexString.match(/.{1,2}/g);
      if (!matches) throw new Error('Invalid hex string');
      return Buffer.from(matches.join(''), 'hex');
    },

    decrypt: async (enc) => {
      if (!enc) throw new Error('Encrypted data is required');
      
      try {
        const secretKey = 'C5D58EF67A7584E4A29F6C35BBC4EB12';
        const data = Buffer.from(enc, 'base64');
        if (data.length < 16) throw new Error('Invalid encrypted data length');
        
        const iv = data.slice(0, 16);
        const content = data.slice(16);
        const key = savetube.crypto.hexToBuffer(secretKey);

        const decipher = crypto.createDecipheriv('aes-128-cbc', key, iv);
        let decrypted = decipher.update(content);
        decrypted = Buffer.concat([decrypted, decipher.final()]);
        return JSON.parse(decrypted.toString());
      } catch (error) {
        throw new Error('Decryption failed: ' + error.message);
      }
    }
  },

  isUrl: str => {
    try { 
      new URL(str); 
      return true; 
    } catch (_) { 
      return false; 
    }
  },

  youtube: url => {
    if (!url) return null;
    const a = [
      /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
      /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
      /youtube\.com\/v\/([a-zA-Z0-9_-]{11})/,
      /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
      /youtu\.be\/([a-zA-Z0-9_-]{11})/
    ];
    for (let b of a) {
      if (b.test(url)) return url.match(b)[1];
    }
    return null;
  },

  request: async (endpoint, data = {}, method = 'post') => {
    try {
      const { data: response } = await axios({
        method,
        url: `${endpoint.startsWith('http') ? '' : savetube.api.base}${endpoint}`,
        data: method === 'post' ? data : undefined,
        params: method === 'get' ? data : undefined,
        headers: savetube.headers,
        timeout: 30000
      });
      return { status: true, code: 200, data: response };
    } catch (error) {
      return { status: false, code: error.response?.status || 500, error: error.message };
    }
  },

  getCDN: async () => {
    const response = await savetube.request(savetube.api.cdn, {}, 'get');
    if (!response.status) return response;
    return { status: true, code: 200, data: response.data.cdn };
  },

  download: async (link) => {
    if (!link) return { status: false, code: 400, error: "Provide a YouTube video link." };
    if (!savetube.isUrl(link)) return { status: false, code: 400, error: "Provide the correct YouTube video link." };

    const id = savetube.youtube(link);
    if (!id) return { status: false, code: 400, error: "YouTube video ID cannot be extracted." };

    try {
      const cdnx = await savetube.getCDN();
      if (!cdnx.status) return cdnx;
      const cdn = cdnx.data;

      const result = await savetube.request(`https://${cdn}${savetube.api.info}`, {
        url: `https://www.youtube.com/watch?v=${id}`
      });
      
      if (!result.status) return result;
      if (!result.data || !result.data.data) {
        return { status: false, code: 500, error: "Invalid response from server" };
      }

      const decrypted = await savetube.crypto.decrypt(result.data.data);

      const dl = await savetube.request(`https://${cdn}${savetube.api.download}`, {
        id: id,
        downloadType: 'audio',
        quality: '128',
        key: decrypted.key
      });

      if (!dl.status) return dl;
      if (!dl.data || !dl.data.data) {
        return { status: false, code: 500, error: "Invalid download response" };
      }

      const fileSize = dl.data.data.size || 0;
      
      return {
        status: true,
        code: 200,
        result: {
          title: decrypted.title || "Unknown Title",
          type: 'audio',
          format: 'mp3',
          thumbnail: decrypted.thumbnail || `https://i.ytimg.com/vi/${id}/maxresdefault.jpg`,
          download: dl.data.data.downloadUrl,
          id,
          key: decrypted.key,
          duration: decrypted.duration || 'Unknown',
          quality: '128',
          downloaded: dl.data.data.downloaded || false,
          size: fileSize
        }
      };
    } catch (error) {
      return { status: false, code: 500, error: error.message };
    }
  }
};

function formatFileSize(bytes) {
  if (bytes === 0 || !bytes) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function checkFileSizeLimit(fileSize, isPremium = false, env = {}) {
  const maxUploadFree = env.max_upload_free || 50; // 50MB default
  const maxUpload = env.max_upload || 100; // 100MB default
  
  const maxSizeBytes = isPremium ? maxUpload * 1024 * 1024 : maxUploadFree * 1024 * 1024;
  
  return {
    oversize: fileSize > maxSizeBytes,
    maxSize: maxSizeBytes,
    currentSize: fileSize,
    maxSizeMB: isPremium ? maxUpload : maxUploadFree
  };
}

module.exports = {
  help: ['ytmp3'],
  aliases: ['yta'],
  tags: 'download',
  limit: true,
  run: async (m, { conn, usedPrefix, command, args, users, env, Func }) => {
    try {
      let user = global.db.users[m.sender] || {};
      user.isProcessingYtmp3 = user.isProcessingYtmp3 || false;

      if (user.isProcessingYtmp3) throw global.status.previously;
      if (!args[0]) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://youtu.be/zaRFmdtLhQ8\n\nIt is recommended to download audio that is at least *30 minutes* long, no more than *1 hour*.`;

      user.isProcessingYtmp3 = true;
      conn.sendReact(m.chat, global.react, m.key);

      const res = await savetube.download(args[0]);
      if (!res.status) throw res.error;

      let { title, download, thumbnail, duration, quality, size } = res.result;

      const safeSize = size || 0;
      const isPremium = users.premium || false;
      
      const sizeCheck = checkFileSizeLimit(safeSize, isPremium, env);

      if (sizeCheck.oversize) {
        const currentSizeFormatted = formatFileSize(safeSize);
        const maxSizeFormatted = formatFileSize(sizeCheck.maxSize);
        
        const isOver = isPremium
          ? `File size (${currentSizeFormatted}) exceeds the maximum limit.`
          : `File size (${currentSizeFormatted}), you can only download files with a maximum size of ${maxSizeFormatted} MB and for premium users a maximum of ${formatFileSize((env.max_upload || 100) * 1024 * 1024)}) MB.`;
        throw isOver;
      }
          
      let txt = `*YOUTUBE MP3*\n\n`;
      txt += `- *Title* : ${title}\n`;
      txt += `- *Duration* : ${duration}\n`;
      txt += `- *Quality* : ${quality}kbps\n`;
      txt += `- *File Size* : ${formatFileSize(safeSize)}`;

      try {
        const audioResponse = await axios.get(download, {
          responseType: 'arraybuffer',
          timeout: 60000
        });
        
        const audioBuffer = Buffer.from(audioResponse.data);
        
        if (conn.sendMessageModify) {
          await conn.sendMessageModify(m.chat, txt, m, {
            largeThumb: true,
            thumbnail: thumbnail
          });
        } else {
          await conn.reply(m.chat, txt, m);
        }

        await conn.sendMessage(m.chat, {
          audio: audioBuffer,
          mimetype: 'audio/mpeg',
          fileName: `${title}.mp3`
        }, { quoted: m });

      } catch (sendError) {
        console.error('Send error : ', sendError);
        await conn.sendMessageModify(m.chat, txt, m, {
          largeThumb: true,
          thumbnail: thumbnail
        });

        await conn.sendFile(m.chat, download, `${title}.mp3`, '', m, {
          document: true,
          mimetype: 'audio/mpeg'
        });
      }

    } catch (e) {
      if (Func.jsonFormat && typeof Func.jsonFormat === 'function') {
        throw Func.jsonFormat(e);
      } else {
        const errorMessage = e.message || String(e);
        throw errorMessage;
      }
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingYtmp3 = false;
      }
    }
  }
};