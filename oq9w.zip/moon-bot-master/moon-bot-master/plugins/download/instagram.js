/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const { toAudio } = require('../../lib/system/converter');
const axios = require('axios');
const cheerio = require('cheerio');

module.exports = {
  help: ['instagram'],
  aliases: ['ig'],
  tags: 'download',
  limit: true,
  run: async (m, { conn, Func, usedPrefix, command, args }) => {
    try {
      let user = global.db.users[m.sender] || {};
      user.isProcessingIg = user.isProcessingIg || false;
      
      if (user.isProcessingIg) throw global.status.previously
      if (!args[0]) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://www.instagram.com/reel/DM4eJdRTXrA/?igsh=YzljYTk1ODg3Zg==`
      if (!args[0].match(/(https:\/\/www.instagram.com)/gi)) throw global.status.invalid

      user.isProcessingIg = true;
      m.react(global.react);
      
      const url = args[0];

      // === SERVER 1: Alya ===
      try {
        const json = await Api.get('/ig', { url });
        if (!json.status) throw new Error(json.msg || "Unknown error from Alya");

        for (let media of json.data) {
          try {
            const isImage = media.type === 'image';
            const isVideo = media.type === 'video';

            if (isVideo && media.thumbnail) {
              const thumbRes = await axios.get(media.thumbnail, { responseType: 'arraybuffer' });
              const thumbBuffer = Buffer.from(thumbRes.data, 'binary');
              await conn.sendMessage(m.chat, {
                image: thumbBuffer,
                caption: media.title || '',
              }, { quoted: m });
            }

            const mediaRes = await axios.get(media.url, { responseType: 'arraybuffer' });
            const mediaBuffer = Buffer.from(mediaRes.data, 'binary');

            if (isImage) {
              await conn.sendMessage(m.chat, {
                image: mediaBuffer,
                caption: media.title || '',
              }, { quoted: m });
            } else if (isVideo) {
              await conn.sendMessage(m.chat, {
                video: mediaBuffer,
                caption: media.title || '',
              }, { quoted: m });

              const audio = await toAudio(mediaBuffer, 'mp4');
              if (audio.data) {
                await conn.sendMessage(m.chat, {
                  audio: audio.data,
                  mimetype: 'audio/mpeg'
                }, { quoted: m });
              }
            }

          } catch (err) {
            console.log(`[Alya Error Parsing Media] ${err.message}`);
          }
        }

      } catch (e1) {
        console.log(e1.message);

        // === SERVER 2: yt1s.io ===
        try {
          const { data } = await axios.post(
            'https://yt1s.io/api/ajaxSearch',
            new URLSearchParams({ p: 'home', q: url, w: '', lang: 'en' }),
            {
              headers: {
                'User-Agent': 'Mozilla/5.0',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
              },
            }
          );

          if (data.status !== 'ok') throw new Error('yt1s.io: Status is not OK');

          const $ = cheerio.load(data.data);
          const downloads = $('a.abutton.is-success.is-fullwidth.btn-premium')
            .map((_, el) => ({
              title: $(el).attr('title'),
              url: $(el).attr('href'),
            }))
            .get();

          if (!downloads.length) throw new Error('Media not found on yt1s.io');

          for (const dl of downloads) {
            const res = await axios.get(dl.url, { responseType: 'arraybuffer' });
            const buffer = Buffer.from(res.data, 'binary');
            const mimeType = res.headers['content-type'];

            if (mimeType.includes('image')) {
              await conn.sendMessage(m.chat, {
                image: buffer,
              }, { quoted: m });
            } else if (mimeType.includes('video')) {
              await conn.sendMessage(m.chat, {
                video: buffer,
              }, { quoted: m });

              const audio = await toAudio(buffer, 'mp4');
              if (audio.data) {
                await conn.sendMessage(m.chat, {
                  audio: audio.data,
                  mimetype: 'audio/mpeg'
                }, { quoted: m });
              }
            }
          }

        } catch (e2) {
          console.log(e2.message);

          // === SERVER 3: hitube.io ===
          try {
            const sessionId = `hitube.io_${Math.random().toString(36).substring(2, 12)}_${Date.now()}`;
            
            const encodedUrl = encodeURIComponent(url);
            
            const response = await axios.get(`https://api.hitube.io/st-tik/ins/dl?url=${encodedUrl}&sessionid=${sessionId}`, {
              headers: {
                'Accept': 'application/json, text/plain, */*',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36',
                'Referer': 'https://www.hitube.io/id/instagram-video-download'
              }
            });

            if (response.data.code !== 200 || !response.data.result || !response.data.result.insBos) {
              throw new Error('hitube.io: Invalid response structure');
            }

            const mediaData = response.data.result.insBos[0];
            
            if (!mediaData.url) {
              throw new Error('hitube.io: No media URL found');
            }

            const mediaUrl = mediaData.url;
            
            const res = await axios.get(mediaUrl, { 
              responseType: 'arraybuffer',
              headers: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36'
              }
            });
            
            const buffer = Buffer.from(res.data);

            await conn.sendMessage(m.chat, {
              video: buffer,
              caption: response.data.result.introduce || ''
            }, { quoted: m });

            const audio = await toAudio(buffer, 'mp4');
            if (audio.data) {
              await conn.sendMessage(m.chat, {
                audio: audio.data,
                mimetype: 'audio/mpeg'
              }, { quoted: m });
            }

          } catch (e3) {
            console.log('Error Server 3 : ' + e3.message);
          }
        }
      }

    } catch (e) {
      console.error(e);
           throw Func.jsonFormat(e)
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingIg = false;
      }
    }
  }
};