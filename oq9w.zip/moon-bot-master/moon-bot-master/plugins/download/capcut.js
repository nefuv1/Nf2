/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios')

module.exports = {
   help: ['capcut'],
   aliases: ['cc'],
   tags: 'download',
   limit: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      args,
      Func
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingCapcut = user.isProcessingCapcut || false;
         
         if (user.isProcessingCapcut) throw global.status.previously
         if (!args[0]) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://www.capcut.com/id-id/template-detail/tapi-ku-berada-di/7307790890452389128`
         
         if (!args[0].match(/capcut\.com/)) throw global.status.invalid
         
         user.isProcessingCapcut = true;
         conn.sendReact(m.chat, global.react, m.key)
         const encodedUrl = encodeURIComponent(args[0])
         
         const { data } = await axios.get(
            `https://api.siputzx.my.id/api/d/capcut?url=${encodedUrl}`,
            {
               headers: {
                  'Accept': '*/*',
                  'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36'
               }
            }
         )

         if (!data.status || !data.data) throw `Failed to fetch data from API.`
         
         const videoData = data.data
         
         if (!videoData.contentUrl) throw `No video URL found.`

         const title = videoData.name || 'CapCut Video'
         const thumbnail = Array.isArray(videoData.thumbnailUrl) ? videoData.thumbnailUrl[0] : videoData.thumbnailUrl
         const videoUrl = videoData.contentUrl
         const uploadDate = videoData.uploadDate || '-'
         const description = videoData.description || '-'

         if (thumbnail) {
            await conn.sendFile(m.chat, thumbnail, 'thumbnail.jpg', ``, m) }

         await conn.sendFile(m.chat, videoUrl, Func.filename('mp4'),
            `*CAPCUT*\n\n` +
            `- *Title* : ${title}\n` +
            `- *Description* : ${description}\n` +
            `- *Upload Date* : ${uploadDate}\n` +
            `- *Source* : CapCut\n` +
            `- *Quality* : Original\n` +
            `- *Status* : Success`, m)

      } catch (e) {
         throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingCapcut = false;
         }
      }
   }
}


/** Versi Api Alya || Nanti Untuk Update Di Gabung Saja Buat Fallback Ke Api Alya Saja
module.exports = {
   help: ['capcut'],
   aliases: ['cc'],
   tags: 'download',
   limit: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      args,
      Func,
      Api
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingCapcut = user.isProcessingCapcut || false;
         
         if (user.isProcessingCapcut) throw global.status.previously
         if (!args[0]) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://www.capcut.com/id-id/template-detail/tapi-ku-berada-di/7307790890452389128`
         
         if (!args[0].match('capcut.com')) throw global.status.invalid
         
         user.isProcessingCapcut = true;
         conn.sendReact(m.chat, global.react, m.key)
         
         // langsung download no watermark
         const json = await Api.get('/capcut-dl', {
            url: args[0], 
            type: 'nowatermark'
         })
         if (!json.status) throw Func.jsonFormat(json)
         
         conn.sendFile(m.chat, json.data.url, Func.filename('mp4'), 
            `*CAPCUT DOWNLOAD*\n\n- *Title* : ${json.data.title}\n- *Description* : ${json.data.description}`, m)
         
      } catch (e) {
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingCapcut = false;
         }
      }
   }
}
*/