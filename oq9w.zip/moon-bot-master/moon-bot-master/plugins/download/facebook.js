/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');
const cheerio = require('cheerio');

const fsaver = {
    download: async (url) => {
        const fetchUrl = `https://fsaver.net/download/?url=${url}`;
        const headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
        };
        const res = await axios.get(fetchUrl, { headers });
        const $ = cheerio.load(res.data);
        const videoSrc = $('.video__item').attr('src');
        if (!videoSrc) throw new Error('Video tidak ditemukan.');
        return { video: `https://fsaver.net${videoSrc}` };
    }
};

module.exports = {
    help: ['facebook'],
    aliases: ['fb'],
    tags: 'download',
    limit: true,
    run: async (m, { conn, usedPrefix, command, args, Func, Api }) => {

        let user = global.db.users[m.sender] || {};
        user.isProcessingFacebook = user.isProcessingFacebook || false;

        if (user.isProcessingFacebook) throw global.status.previously;
        user.isProcessingFacebook = true;

        try {
            if (!args[0]) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://www.facebook.com/share/r/1WCkXg8fsT/`
            if (!args[0].match(/(?:https?:\/\/(web\.|www\.|m\.)?(facebook|fb)\.(com|watch)\S+)?$/)) throw global.status.invalid
            
            conn.sendReact(m.chat, global.react, m.key);
            const url = args[0];

            // === SERVER 1: Alya ===
            try {
                const json = await Api.get('/fb', { url: args[0] });
                if (!json.status) throw Func.jsonFormat(json)
                
                const result = json.data.find(v => v.quality == 'HD') || json.data.find(v => v.quality == 'SD');
                if (result) {
                    conn.sendFile(m.chat, result.url, Func.filename(result.quality === 'jpeg' ? 'jpeg' : 'mp4'), `◦ *Quality* : ${result.quality}`, m);
                } else {
                    for (const v of json.data) {
                        await conn.sendFile(m.chat, v.url, Func.filename(v.quality === 'jpeg' ? 'jpeg' : 'mp4'), `◦ *Quality* : ${v.quality}`, m);
                        await Func.delay(1500);
                    }
                }

            } catch (e1) {
                console.log('Server 1 error:', e1.message);

                // === SERVER 2: fdownload.app ===
                try {
                    const response = await axios.post(
                        "https://fdownload.app/api/ajaxSearch",
                        new URLSearchParams({ p: "home", q: url, lang: "en", w: "" }),
                        {
                            headers: {
                                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                                "User-Agent": "Mozilla/5.0",
                                "X-Requested-With": "XMLHttpRequest",
                                "Referer": "https://fdownload.app/en"
                            }
                        }
                    );

                    if (!response.data || response.data.status !== "ok") throw new Error("Failed to get data from fdownload.app");

                    const $ = cheerio.load(response.data.data);
                    let results = [];
                    $("table tbody tr").each((_, el) => {
                        const quality = $(el).find(".video-quality").text().trim();
                        const status = $(el).find("td:nth-child(2)").text().trim().toLowerCase();
                        const videoUrl = $(el).find("td:nth-child(3) a").attr("href");
                        if (quality && videoUrl && status === "no") {
                            results.push({ resolution: quality, url: videoUrl });
                        }
                    });

                    if (!results.length) throw new Error("No downloadable media found");

                    const highest = results.reduce((prev, curr) =>
                        parseInt(curr.resolution) > parseInt(prev.resolution) ? curr : prev
                    );

                    const res = await axios.get(highest.url, { responseType: 'arraybuffer' });
                    const buffer = Buffer.from(res.data);
                    await conn.sendFile(m.chat, buffer, 'facebook.mp4', `${highest.resolution} Quality`, m);

                } catch (e2) {
                    console.log(e2.message);

                    // === SERVER 3: fsaver.net ===
                    try {
                        const result = await fsaver.download(url);
                        if (!result || !result.video) throw new Error("fsaver.net: Video not found");

                        const res = await axios.get(result.video, { responseType: 'arraybuffer' });
                        const buffer = Buffer.from(res.data);
                        await conn.sendFile(m.chat, buffer, 'facebook.mp4', '', m);

                    } catch (e3) {
                        console.log(e3.message);
                        throw `*Error Server 3* : ${e3.message}`
                    }
                }
            }

        } catch (e) {
            console.error(e);
            throw Func.jsonFormat(e)
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingFacebook = false;
            }
        }
    }
};