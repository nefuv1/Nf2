/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');

module.exports = {
  help: ['mediafire'],
  aliases: ['mf'],
  tags: 'download',
  limit: 30,
  premium: true,
  run: async (m, { conn, usedPrefix, command, args, users, env, Func }) => {
    try {
      let user = global.db.users[m.sender] || {};
      user.isProcessingMediafire = user.isProcessingMediafire || false;
      
      if (user.isProcessingMediafire) throw global.status.previously
      if (!args || !args[0]) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://www.mediafire.com/file/c2fyjyrfckwgkum/ZETSv1%25282%2529.zip/file`
      if (!args[0].match(/(https:\/\/www.mediafire.com\/)/gi)) throw global.status.invalid
      
      user.isProcessingMediafire = true;
      conn.sendReact(m.chat, global.react, m.key);
      
      const json = await Api.get('/mediafire', {
        url: args[0]
      });
      
      if (!json.status) throw Func.jsonFormat(json)
      
      const chSize = Func.sizeLimit(json.data.size, users.premium ? env.max_upload : env.max_upload_free);
      const isOver = users.premium ? 
        `File size (${json.data.size}) exceeds the maximum limit.` : 
        `File size (${json.data.size}), you can only download files with a maximum size of ${env.max_upload_free} MB and for premium users a maximum of ${env.max_upload} MB.`;
      
      if (chSize.oversize) throw isOver
      
      await conn.sendFile(m.chat, json.data.url, json.data.filename, '', m);
      
    } catch (e) {
           throw Func.jsonFormat(e)
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingMediafire = false;
      }
    }
  }
};