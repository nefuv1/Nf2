const timer = 18000; // 18 detik
const apkmodSessions = {};

module.exports = {
   help: ['apkmod'],
   aliases: ['apkmodget'],
   tags: 'download',
   limit: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      isPrem,
      Func,
      Api,
      env,
      users
   }) => {
      try {
         const id = m.sender;
         let user = global.db.users[m.sender] || {};
         user.isProcessingApkmod = user.isProcessingApkmod || false;
         
         if (user.isProcessingApkmod) throw global.status.previously
         user.isProcessingApkmod = true;

         switch (command) {
            case 'apkmod': {
               if (!text) throw `Please provide a title.\n\n*Example* : ${usedPrefix + command} GeniusAI`

               m.react(global.react);

               const json = await Api.get('/apkmod', { q: text });
               if (!json.status || json.data.length === 0) throw 'Application not found.'

               let result = `To download mod apk, use this command *${usedPrefix}apkmodget number*\n*Example* : ${usedPrefix}apkmodget 1\n\n`;
               json.data.forEach((v, i) => {
                  result += `[${i + 1}]\n`;
                  result += `- *Name* : ${v.name}\n`;
                  result += `- *Size* : ${v.size || 'N/A'}\n`;
                  result += `- Version: ${v.version || 'N/A'}\n`;
                  result += `- *MOD* : ${v.mod || 'N/A'}\n`;
                  result += `- *Command* : ${usedPrefix}apkmodget ${i + 1}\n\n`;
               });

               const listMessage = await m.reply(result);

               apkmodSessions[id] = {
                  data: json.data,
                  createdAt: Date.now(),
                  key: listMessage.key,
               };

               setTimeout(async () => {
                  const session = apkmodSessions[id];
                  if (session && Date.now() - session.createdAt >= timer) {
                     try {
                        await conn.sendMessage(m.chat, { delete: session.key });
                     } catch (e) {}
                     delete apkmodSessions[id];
                  }
               }, timer + 1000);
            }
            break;

            case 'apkmodget': {
               if (!text) throw 'Please enter a number from the search results.'
               const index = parseInt(text) - 1;
               if (isNaN(index) || index < 0) throw 'Invalid number.'

               m.react(global.react);

               const session = apkmodSessions[id];
               if (!session || Date.now() - session.createdAt >= timer) {
                  delete apkmodSessions[id];
                  throw 'Your session has expired. Please search again.'
               }

               if (index >= session.data.length) throw 'Application not found.'

               const apk = session.data[index];
               const json = await Api.get('/apkmod-get', { url: apk.url });
               if (!json.status) throw Func.jsonFormat(json)

               const chSize = Func.sizeLimit(json.data.size, users.premium ? env.max_upload : env.max_upload_free);
               const isOver = users.premium ? `File size (${json.data.size}) exceeds the maximum limit.` : `File size (${json.data.size}), you can only download files with a maximum size of ${env.max_upload_free} MB and for premium users a maximum of ${env.max_upload} MB.`;

               if (chSize.oversize) throw isOver

               let teks = `*APK MOD*\n\n`;
               teks += `- *Name* : ${json.data.name}\n`;
               teks += `- *Size* : ${json.data.size}\n`;
               teks += `- *Rating* : ${json.data.rating || 'N/A'}\n`;
               teks += `- *Version* : ${json.data.version}\n`;
               teks += `- *MOD* : ${json.data.mod}\n`;
               teks += `- *Requirements* : ${json.data.requirement || 'N/A'}\n`;
               teks += `- *Developer* : ${json.data.developer || 'N/A'}`;

               await conn.sendMessageModify(m.chat, teks, m, {
                  largeThumb: true,
                  thumbnail: json.data.thumbnail || json.data.img
               });

               await conn.sendFile(m.chat, json.data.downloadLinks[0].url || json.data.url, json.data.downloadLinks[0].filename || `${json.data.name}.apk`, '', m);

               if (session.key) await conn.sendMessage(m.chat, { delete: session.key });
               delete apkmodSessions[id];
            }
            break;
         }

      } catch (e) {
         console.error(e);
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingApkmod = false;
         }
      }
   }
};