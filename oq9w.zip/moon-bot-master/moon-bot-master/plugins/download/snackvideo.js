/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');
const cheerio = require('cheerio');

async function scrapeSnackVideo(url) {
  try {
    const { data: html } = await axios.get(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
      },
      timeout: 30000,
    });

    const $ = cheerio.load(html);
    const videoDataScript = $("#VideoObject").html();

    if (!videoDataScript) {
      throw new Error("Video data not found in the page.");
    }

    const videoData = JSON.parse(videoDataScript);

    const result = {
      url: videoData.url || "",
      title: videoData.name || "",
      description: videoData.description || "",
      thumbnail: videoData.thumbnailUrl ? videoData.thumbnailUrl[0] : "",
      uploadDate: videoData.uploadDate ? new Date(videoData.uploadDate).toISOString().split("T")[0] : "",
      videoUrl: videoData.contentUrl || "",
      duration: formatDuration(videoData.duration),
      interaction: {
        views:
          videoData.interactionStatistic?.find(
            (stat) => stat.interactionType["@type"] === "https://schema.org/WatchAction",
          )?.userInteractionCount || 0,
        likes:
          videoData.interactionStatistic?.find(
            (stat) => stat.interactionType["@type"] === "https://schema.org/LikeAction",
          )?.userInteractionCount || 0,
        shares:
          videoData.interactionStatistic?.find(
            (stat) => stat.interactionType["@type"] === "https://schema.org/ShareAction",
          )?.userInteractionCount || 0,
      },
      creator: {
        name: videoData.creator?.mainEntity?.name || "",
        profileUrl: videoData.creator?.mainEntity?.url || "",
        bio: videoData.creator?.mainEntity?.description || "",
      },
    };

    return result;
  } catch (error) {
    console.error("API Error:", error.message);
    throw new Error("Failed to get response from API");
  }
}

function formatDuration(duration) {
  const match = duration.match(/^PT(\d+)M(\d+)S$/);
  if (match) {
    return `${match[1]} minutes ${match[2]} seconds`;
  }
  return duration;
}

module.exports = {
  help: ['snackvideo'],
  aliases: ['sv', 'snack'],
  tags: 'download',
  limit: true,
  run: async (m, {
    conn,
    usedPrefix,
    command,
    args,
    Func
  }) => {
    try {
      let user = global.db.users[m.sender] || {};
      user.isProcessingSnackVideo = user.isProcessingSnackVideo || false;
      
      if (user.isProcessingSnackVideo) throw global.status.previously;
      if (!args[0]) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://s.snackvideo.com/p/dwlMd51U`;
      if (!args[0].match(/^https?:\/\/(www\.)?s\.snackvideo\.com\//)) throw global.status.invalid;
      
      user.isProcessingSnackVideo = true;
      m.react(global.react);      
      
      const result = await scrapeSnackVideo(args[0]);
      
      if (!result || !result.videoUrl) {
        throw 'Failed to download video. The link may be invalid or an error occurred.';
      }

      const videoResponse = await axios.get(result.videoUrl, {
        responseType: 'arraybuffer',
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36",
          "Referer": "https://s.snackvideo.com/"
        }
      });
      
      const videoBuffer = Buffer.from(videoResponse.data);

      let caption = `*SNACK VIDEO*\n\n`;
      
      if (result.title) caption += `- *Title* : ${result.title}\n`;
      if (result.duration) caption += `- *Duration* : ${result.duration}\n`;
      if (result.uploadDate) caption += `- *Upload Date* : ${result.uploadDate}\n`;
      
      if (result.interaction.views) caption += `- *Views* : ${result.interaction.views}\n`;
      if (result.interaction.likes) caption += `- *Likes* : ${result.interaction.likes}\n`;
      if (result.interaction.shares) caption += `- *Shares* : ${result.interaction.shares}\n`;
      
      if (result.creator.name) caption += `- *Creator* : ${result.creator.name}\n`;
      if (result.description) caption += `- *Description* : ${result.description}`;

      await conn.sendMessage(m.chat, {
        video: videoBuffer,
        caption: caption,
        mentions: [m.sender]
      }, { quoted: m });
      
    } catch (e) {
      console.log(e);
      throw Func.jsonFormat(e);
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingSnackVideo = false;
      }
    }
  }
};