/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');

const timer = 18000; // 18 detik
const apkSessions = {};

module.exports = {
   help: ['apk'],
   aliases: ['apkget'],
   tags: 'download',
   limit: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      isPrem,
      Func,
      Api,
      env,
      users
   }) => {
      try {
         const id = m.sender;
         let user = global.db.users[m.sender] || {};
         user.isProcessingApk = user.isProcessingApk || false;
         
         if (user.isProcessingApk) throw global.status.previously
         user.isProcessingApk = true;

         switch (command) {
            case 'apk': {
               if (!text) throw `Please provide a title.\n\n*Example* : ${usedPrefix + command} GeniusAI`

               m.react(global.react);

               const json = await Api.get('/playstore', { q: text });
               if (!json.status || json.data.length === 0) throw 'Application not found.'

               let result = `To download apk, use this command *${usedPrefix}apkget number*\n*Example* : ${usedPrefix}apkget 1\n\n`;
               json.data.slice(0, 10).forEach((v, i) => {
                  result += `[${i + 1}]\n`;
                  result += `- *Title* : ${v.title}\n`;
                  result += `- *Size* : ${v.size || 'N/A'}\n`;
                  result += `- *Rating* : ${v.rating || 'N/A'}\n`;
                  result += `- *Command* : ${usedPrefix}apkget ${i + 1}\n\n`;
               });

               const listMessage = await m.reply(result);

               apkSessions[id] = {
                  data: json.data,
                  createdAt: Date.now(),
                  key: listMessage.key,
               };

               setTimeout(async () => {
                  const session = apkSessions[id];
                  if (session && Date.now() - session.createdAt >= timer) {
                     try {
                        await conn.sendMessage(m.chat, { delete: session.key });
                     } catch (e) {}
                     delete apkSessions[id];
                  }
               }, timer + 1000);
            }
            break;

            case 'apkget': {
               if (!text) throw 'Please enter a number from the search results.'
               const index = parseInt(text) - 1;
               if (isNaN(index) || index < 0) throw 'Invalid number.'

               m.react(global.react);

               const session = apkSessions[id];
               if (!session || Date.now() - session.createdAt >= timer) {
                  delete apkSessions[id];
                  throw 'Your session has expired. Please search again.'
               }

               if (index >= session.data.length) throw 'Application not found.'

               const apk = session.data[index];
               const json = await Api.get('/playstore-get', { url: apk.url });
               if (!json.status) throw Func.jsonFormat(json)

               const chSize = Func.sizeLimit(json.data.downloadLinks[0].size, users.premium ? env.max_upload : env.max_upload_free);
               const isOver = users.premium ? `File size (${json.data.downloadLinks[0].size}) exceeds the maximum limit.` : `File size (${json.data.downloadLinks[0].size}), you can only download files with a maximum size of ${env.max_upload_free} MB and for premium users a maximum of ${env.max_upload} MB.`;

               if (chSize.oversize) throw isOver

               let teks = `*APK*\n\n`;
               teks += `- *Name* : ${json.data.title}\n`;
               teks += `- *Size* : ${json.data.downloadLinks[0].size}\n`;
               teks += `- *Version* : ${json.data.version}\n`;
               teks += `- *Update* : ${json.data.update}\n`;
               teks += `- *Requirement* : ${json.data.requirement}\n`;
               teks += `- *Developer* : ${json.data.developer}`;

               await conn.sendMessageModify(m.chat, teks, m, {
                  largeThumb: true,
                  thumbnail: json.data.img
               });

               await conn.sendFile(m.chat, json.data.downloadLinks[0].url, json.data.downloadLinks[0].filename, '', m);

               if (session.key) await conn.sendMessage(m.chat, { delete: session.key });
               delete apkSessions[id];
            }
            break;
         }

      } catch (e) {
         console.error(e);
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingApk = false;
         }
      }
   }
};