/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['terabox'],
   aliases: ['tbox'],
   tags: 'download',
   limit: 30,
   premium: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      args,
      users,
      env,
      Func
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingTerabox = user.isProcessingTerabox || false;
         
         if (user.isProcessingTerabox) throw global.status.previously
         if (!args || !args[0]) throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://terabox.com/s/1jDTI6wLo066ALCYQ69sDyA`
         if (!args[0].match(/(?:https?:\/\/(www\.)?terabox\.(com|app)\S+)?$/)) throw global.status.invalid
         
         user.isProcessingTerabox = true;
         conn.sendReact(m.chat, global.react, m.key);
         
         const json = await Api.get('/terabox', {
            url: args[0]
         });
         if (!json.status) throw Func.jsonFormat(json)
         
         const chSize = Func.sizeLimit(json.data.size, users.premium ? env.max_upload : env.max_upload_free);
         const isOver = users.premium ? 
            `File size (${json.data.size}) exceeds the maximum limit.` : 
            `File size (${json.data.size}), you can only download files with a maximum size of ${env.max_upload_free} MB and for premium users a maximum of ${env.max_upload} MB.`;
         
         if (chSize.oversize) throw isOver
         
         conn.sendFile(m.chat, json.data.url, json.data.filename, '', m);
         
      } catch (e) {
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingTerabox = false;
         }
      }
   }
};