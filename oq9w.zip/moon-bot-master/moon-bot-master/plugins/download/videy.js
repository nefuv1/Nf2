/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');

async function getSizeMB(url) {
  try {
    const response = await axios.head(url);
    const sizeBytes = parseInt(response.headers['content-length'], 10);
    const sizeMB = sizeBytes / (1024 * 1024);
    return { size: sizeMB.toFixed(2) + ' MB', sizeMB };
  } catch (error) {
    console.error('Size Check Error:', error);
    return { size: 'Unknown', sizeMB: 0 };
  }
}

function isUrl(url) {
  const pattern = new RegExp('^(https?:\\/\\/)?' +
    '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.?)+[a-z]{2,}|' +
    '((\\d{1,3}\\.){3}\\d{1,3}))' +
    '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' +
    '(\\?[;&a-z\\d%_.~+=-]*)?' +
    '(\\#[-a-z\\d_]*)?$', 'i');
  return !!pattern.test(url);
}

module.exports = {
  help: ['videy'],
  tags: 'download',
  premium: true,
  register: true,
  limit: 30,
  run: async (m, { conn, text, usedPrefix, command, users, env, Func }) => {
    try {
      let user = global.db.users[m.sender] || {};
      user.isProcessingVidey = user.isProcessingVidey || false;
      
      if (user.isProcessingVidey) throw global.status.previously
      
      if (!text) {
        if (!m.quoted || !m.quoted.text) {
          throw `Please provide URL.\n\n*Example* : ${usedPrefix + command} https://videy.co/v/?id=MD4QKKQt1`
        }
        text = m.quoted.text;
      }

      user.isProcessingVidey = true;
      
      m.react(global.react);

      if (!isUrl(text) || !/videy\.co/.test(text)) {
        throw global.status.invalid
      }

      let id = text.split("id=")[1];
      if (!id) throw 'No video ID found in the link'

      await m.reply('"Make sure to download positive content and avoid inappropriate or negative content such as adult material or other negative things."');

      let videoUrl = `https://cdn.videy.co/${id}.mp4`;
      let { size, sizeMB } = await getSizeMB(videoUrl);

      const chSize = Func.sizeLimit(size, users.premium ? env.max_upload : env.max_upload_free);
      const isOver = users.premium ? 
        `File size (${size}) exceeds the maximum limit.` : 
        `File size (${size}), you can only download files with a maximum size of ${env.max_upload_free} MB and for premium users a maximum of ${env.max_upload} MB.`;
      
      if (chSize.oversize) throw isOver

      let caption = '';

      await conn.sendMessage(m.chat, {
        video: { url: videoUrl },
        caption: caption,
        mentions: [m.sender]
      }, { quoted: m });

    } catch (e) {
      console.error(e);
           throw Func.jsonFormat(e)      

    } finally {
      if ([m.sender]) {
        global.db.users[m.sender].isProcessingVidey = false;
      }
    }
  }
};