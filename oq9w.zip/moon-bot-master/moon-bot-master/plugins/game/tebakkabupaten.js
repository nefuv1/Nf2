const cheerio = require('cheerio');
const fetch = require('node-fetch');
const Jimp = require('jimp');

module.exports = {
  help: ['tebakkabupaten'],
  aliases: ['tbkkabupaten'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true; // Set to false to disable auto-delete
    
    let timeout = 60000;
    let poin = 3999;
    let blurLevel = 5; // Ubah sesuai kebutuhan: 1 = sedikit blur, 10 = buram banget
    
    conn.tebakkabupaten = conn.tebakkabupaten || {};
    let id = m.chat;

    if (id in conn.tebakkabupaten) {
      conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.tebakkabupaten[id][0]);
      throw false;
    }

    let json = await getRandomKabupaten();
    if (!json?.url) throw 'Gagal mengambil gambar kabupaten';

    // Blur gambar
    let imgBuffer = await fetch(json.url).then(v => v.buffer());
    let jimpImg = await Jimp.read(imgBuffer);
    jimpImg.blur(blurLevel);
    let blurredBuffer = await jimpImg.getBufferAsync(Jimp.MIME_JPEG);

    let caption = `*TEBAK KABUPATEN*

Kabupaten apakah pada gambar di atas ?
    
*Timeout* : ${(timeout / 1000).toFixed(2)} detik
*Game ID* : GAME-010
Untuk bantuan kirim perintah : ${usedPrefix}hkab 

*Bonus* : 
- 3.999 EXP

Balas soal ini untuk menjawab!
`.trim();

    let sentMsg = await conn.sendFile(m.chat, blurredBuffer, 'kabupaten.jpg', caption, m);
    conn.tebakkabupaten[id] = [
      sentMsg,
      json, 
      poin,
      setTimeout(() => {
        if (conn.tebakkabupaten[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.tebakkabupaten[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {});
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.title}*`, conn.tebakkabupaten[id][0]);
          delete conn.tebakkabupaten[id];
        }
      }, timeout),
      deleteAfterAnswer // Store delete option
    ];
  }
}

const baseUrl = 'https://id.m.wikipedia.org';

async function getRandomKabupaten() {
  try {
    const response = await fetch(baseUrl + '/wiki/Daftar_kabupaten_di_Indonesia');
    const html = await response.text();
    const $ = cheerio.load(html);

    const kabupatenList = $('td a[href^="/wiki/Kabupaten"]').map((index, el) => ({
      link: baseUrl + $(el).attr('href'),
      name: $(el).attr('title')
    })).get().filter(item => item.link && item.name);

    if (!kabupatenList.length) return null;

    const randomIndex = Math.floor(Math.random() * kabupatenList.length);
    const randomKabupaten = kabupatenList[randomIndex];
    const imageUrl = await fetchImageUrl(randomKabupaten.link);
    const title = randomKabupaten.name.replace('Kabupaten ', '');
    const finalUrl = imageUrl?.replace(/\/\d+px-/, '/1080px-');

    return {
      link: randomKabupaten.link,
      title,
      url: finalUrl
    };
  } catch (error) {
    console.error(error);
    return null;
  }
}

async function fetchImageUrl(url) {
  try {
    const response = await fetch(url);
    const html = await response.text();
    const $ = cheerio.load(html);
    const src = $('tr.mergedtoprow td.infobox-full-data.maptable div.ib-settlement-cols-row div.ib-settlement-cols-cell a.mw-file-description img.mw-file-element').attr('src');
    return src ? 'https:' + src : null;
  } catch (error) {
    return null;
  }
}