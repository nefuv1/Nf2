let fetch = require('node-fetch')

module.exports = {
  help: ['tebakgame'],
  aliases: ['tbkgame'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true // Set to false to disable auto-delete
    
    let timeout = 60000
    let poin = 3999
    
    conn.tebakgame = conn.tebakgame ? conn.tebakgame : {}
    let id = m.chat
    if (id in conn.tebakgame) {
      conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.tebakgame[id][0])
      throw false
    }
    
    let src = await (await fetch('https://raw.githubusercontent.com/qisyana/scrape/main/tebakgame.json')).json()
    let json = src[Math.floor(Math.random() * src.length)]
    
    let caption = `*TEBAK GAME*
  
*Timeout* : ${(timeout / 1000).toFixed(2)} detik
*Game ID* : GAME-012
Untuk bantuan kirim perintah : ${usedPrefix}hgame

*Bonus* : 
- 3.999 EXP

Balas soal ini untuk menjawab!
    `.trim()
    
    let sentMsg = await conn.sendFile(m.chat, json.img, 'tebakgame.jpg', caption, m, false, {
      thumbnail: Buffer.alloc(0)
    })
    
    conn.tebakgame[id] = [
      sentMsg,
      json,
      poin,
      setTimeout(() => {
        if (conn.tebakgame[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.tebakgame[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.jawaban}*`, conn.tebakgame[id][0])
          delete conn.tebakgame[id]
        }
      }, timeout),
      deleteAfterAnswer // Store delete option
    ]
  }
}