module.exports = {
   help: ['suit'],
   tags: 'game',
   game: true,
   register: true,
   group: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      Func
   }) => {
      let timeout = 60000

      conn.suit = conn.suit ? conn.suit : {}
      if (Object.values(conn.suit).find(room => room.id.startsWith('suit') && [room.p, room.p2].includes(m.sender))) {
         return conn.reply(m.chat, `Kamu belum menyelesaikan suit sebelumnya.`, m)
      }

      if (!m.mentionedJid[0]) {
         return m.reply(`Silakan @tag lawan anda.\n\n*Contoh* : ${usedPrefix + command} @0`)
      }

      if (Object.values(conn.suit).find(room => room.id.startsWith('suit') && [room.p, room.p2].includes(m.mentionedJid[0]))) {
         return conn.reply(m.chat, `Orang yang kamu undang, sedang bermain suit dengan orang lain.`, m)
      }

      let id = 'suit_' + new Date() * 1
      let teks = `*SUIT* (PVP)\n\n`
      teks += `@${m.sender.split`@`[0]} menantang @${m.mentionedJid[0].split`@`[0]} untuk bermain suit.\n\n`
      teks += `Silahkan @${m.mentionedJid[0].split`@`[0]} kirim *${usedPrefix}YES* untuk mulai bermain atau kirim *${usedPrefix}NO* untuk menolak.`

      conn.suit[id] = {
         chat: await conn.reply(m.chat, teks, m),
         id,
         p: m.sender,
         p2: m.mentionedJid[0],
         status: 'wait',
         waktu: setTimeout(() => {
            if (conn.suit[id]) {
               return conn.reply(m.chat, `Sesi game suit telah berakhir.`, m).then(() => delete conn.suit[id])
            }
         }, timeout),
         reward: 3999,
         timeout
      }
   },
   error: false
}