let fetch = require('node-fetch');
let Jimp = require('jimp');

module.exports = {
  help: ['tebakbendera'],
  aliases: ['tbkbendera'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true; // Set to false to disable auto-delete

    let timeout = 60000;
    let poin = 3999;
    let limit = 1;
    let src;
    let blurLevel = 5; // GANTI ini untuk atur tingkat blur: 1 = sedikit, 10 = buram banget

    conn.tebakbendera = conn.tebakbendera || {};
    let id = m.chat;

    if (id in conn.tebakbendera) {
      conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.tebakbendera[id][0]);
      throw false;
    }

    if (!src) src = require('../../json/tebakbendera.json');
    let json = src[Math.floor(Math.random() * src.length)];
    if (!json) throw json;

    let response;
    try {
      response = await fetch(json.img);
      if (!response.ok) {
        throw new Error(`Gagal fetch gambar. URL :\n- ${json.img}\n- *Status* : ${response.status} ${response.statusText}`);
      }
    } catch (e) {
      await conn.reply(m.chat, `Terjadi error saat mengambil gambar :\n- *Error* : ${e.message}`, m);
      throw e;
    }

    let imgBuffer;
    try {
      imgBuffer = await response.buffer();
      // hilangkan threshold size yang terlalu besar
      if (!imgBuffer || imgBuffer.length < 50) {
        throw new Error(`Gambar rusak / kosong. URL : ${json.img}`);
      }
    } catch (e) {
      await conn.reply(m.chat, `Terjadi error saat mengambil gambar :\n- *Error* : ${e.message}`, m);
      throw e;
    }

    let jimpImg;
    let blurredBuffer;
    try {
      jimpImg = await Jimp.read(imgBuffer);
      jimpImg.blur(blurLevel);
      blurredBuffer = await jimpImg.getBufferAsync(Jimp.MIME_JPEG);
    } catch (e) {
      await conn.reply(m.chat, `Terjadi error saat memproses gambar :\n- *Error* : ${e.message}\n- *URL*: ${json.img}`, m);
      throw e;
    }

    let caption = `*TEBAK BENDERA*

*Timeout* : ${(timeout / 1000).toFixed(2)} detik
*Game ID* : GAME-014
Untuk bantuan kirim perintah : ${usedPrefix}hben

*Bonus* : 
- 3.999 EXP
- 1 Limit

Balas soal ini untuk menjawab!`.trim();

    let sentMsg = await conn.sendFile(m.chat, blurredBuffer, 'flag.jpg', caption, m);
    conn.tebakbendera[id] = [
      sentMsg,
      json,
      poin,
      setTimeout(() => {
        if (conn.tebakbendera[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, {
              delete: {
                remoteJid: m.chat,
                id: conn.tebakbendera[id][0].id,
                fromMe: true
              }
            }).catch(() => {});
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.name}*`, conn.tebakbendera[id][0]);
          delete conn.tebakbendera[id];
        }
      }, timeout),
      deleteAfterAnswer // Store delete option
    ];
  }
}