let fetch = require('node-fetch')

module.exports = {
  help: ['lengkapikalimat'],
  aliases: ['lkpkalimat'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true // Set to false to disable auto-delete
    
    let timeout = 60000
    let poin = 3999
    
    conn.lengkapikalimat = conn.lengkapikalimat ? conn.lengkapikalimat : {}
    let id = m.chat
    if (id in conn.lengkapikalimat) {
      conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.lengkapikalimat[id][0])
      throw false
    }
    
    let src = await (await fetch('https://raw.githubusercontent.com/qisyana/scrape/main/lengkapikalimat.json')).json()
    let json = src[Math.floor(Math.random() * src.length)]
    let caption = `*LENGKAPI KALIMAT*

${json.pertanyaan}

*Timeout* : ${(timeout / 1000).toFixed(2)} detik
*Game ID* : GAME-018
Untuk bantuan kirim perintah : ${usedPrefix}hkal

*Bonus* : 
- 3.999 EXP

Balas soal ini untuk menjawab!
    `.trim()
    
    let sentMsg = await conn.reply(m.chat, caption, m)
    conn.lengkapikalimat[id] = [
      sentMsg,
      json,
      poin,
      setTimeout(() => {
        if (conn.lengkapikalimat[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.lengkapikalimat[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.jawaban}*`, conn.lengkapikalimat[id][0])
          delete conn.lengkapikalimat[id]
        }
      }, timeout),
      deleteAfterAnswer // Store delete option
    ]
  }
}