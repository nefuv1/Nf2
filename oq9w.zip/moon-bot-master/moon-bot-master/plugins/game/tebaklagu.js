let fetch = require('node-fetch')

module.exports = {
  help: ['tebaklagu'],
  aliases: ['tbklagu'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true // Set to false to disable auto-delete
    
    let timeout = 60000
    let poin = 3999
    
    conn.tebaklagu = conn.tebaklagu ? conn.tebaklagu : {}
    let id = m.chat
    if (id in conn.tebaklagu) {
      conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.tebaklagu[id][0])
      throw false
    }

    let src = await (await fetch('https://raw.githubusercontent.com/Aiinne/scrape/main/tebaklagu.json')).json()
    let json = src[Math.floor(Math.random() * src.length)]
    
    let caption = `*TEBAK LAGU*
  
*Artist* : ${json.artis}
*Title* : _____

*Timeout* : ${(timeout / 1000).toFixed(2)} detik
*Game ID* : GAME-006
Untuk bantuan kirim perintah : ${usedPrefix}hlagu

*Bonus* : 
- 3.999 EXP

Balas soal ini untuk menjawab!
    `.trim()
    
    let sentMsg = await m.reply(caption)
    conn.tebaklagu[id] = [
      sentMsg,
      json,
      poin,
      setTimeout(() => {
        if (conn.tebaklagu[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.tebaklagu[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.judul}*`, conn.tebaklagu[id][0])
          delete conn.tebaklagu[id]
        }
      }, timeout),
      deleteAfterAnswer // Store delete option
    ]

    try {
        let audioRes = await fetch(json.lagu);
        if (!audioRes.ok) throw new Error(`Failed to retrieve audio : ${audioRes.statusText}`);
        let audioBuffer = await audioRes.buffer();
    
        await conn.sendMessage(m.chat, {
            audio: audioBuffer,
            mimetype: 'audio/mpeg',
            ptt: false // true kalau mau dikirim sebagai VN (voice note)
        }, { quoted: m });
    } catch (e) {
        console.error(e);
        m.reply(`Failed to execute command.\n\n- *Command* : ${command}\n- *Error* : ${e.message}`);
    }    

  }
}