const jimp = require('jimp')

const resize = async (image, width, height) => {
    const read = await jimp.read(image);
    const data = await read.resize(width, height).getBufferAsync(jimp.MIME_JPEG);
    return data;
};

const {
    emoji_role,
    sesi,
    playerOnGame,
    playerOnRoom,
    playerExit,
    dataPlayer,
    dataPlayerById,
    getPlayerById,
    getPlayerById2,
    killWerewolf,
    killww,
    dreamySeer,
    sorcerer,
    protectGuardian,
    roleShuffle,
    roleChanger,
    roleAmount,
    roleGenerator,
    addTimer,
    startGame,
    playerHidup,
    playerMati,
    vote,
    voteResult,
    clearAllVote,
    getWinner,
    win,
    pagi,
    malam,
    skill,
    voteStart,
    voteDone,
    voting,
    run,
    run_vote,
    run_malam,
    run_pagi
} = require('../../lib/werewolf')

let thumb = "https://user-images.githubusercontent.com/72728486/235316834-f9f84ba0-8df3-4444-81d8-db5270995e6d.jpg";
    
module.exports = {
  help: ['werewolf'],
  aliases: ['ww'],  
  tags: 'game',
  game: true,
  group: true,
  run: async (m, { conn, command, usedPrefix, args }) => {
    const {
        sender,
        chat
    } = m;
    
    // Inisialisasi yang benar
    if (!conn.werewolf) conn.werewolf = {};
    const ww = conn.werewolf;
    const data = ww[chat];
    const value = args[0];
    const target = args[1];

    // [ Membuat Room ]
    if (value === "create") {
        if (chat in ww) return m.reply("Group masih dalam sesi permainan");
        if (playerOnGame(sender, ww) === true)
            return m.reply("Kamu masih dalam sesi game");
        ww[chat] = {
            room: chat,
            owner: sender,
            status: false,
            iswin: null,
            cooldown: null,
            day: 0,
            time: "malem",
            player: [],
            dead: [],
            voting: false,
            seer: false,
            guardian: [],
        };
        await m.reply(`Room berhasil dibuat! 👍\n*Gunakan* : ${usedPrefix + command} join - Untuk bergabung`);

    } else if (value === "join") {
        if (!ww[chat]) return m.reply("Belum ada sesi permainan");
        if (ww[chat].status === true)
            return m.reply("Sesi permainan sudah dimulai");
        if (ww[chat].player.length > 16)
            return m.reply("Maaf jumlah player telah penuh");
        if (playerOnRoom(sender, chat, ww) === true)
            return m.reply("Kamu sudah join di room ini");
        if (playerOnGame(sender, ww) === true)
            return m.reply("Kamu masih dalam sesi game");
        let data = {
            id: sender,
            number: ww[chat].player.length + 1,
            sesi: chat,
            status: false,
            role: false,
            effect: [],
            vote: 0,
            isdead: false,
            isvote: false,
        };
        ww[chat].player.push(data);
        let player = [];
        let text = `\n*WEREWOLF* (player join)\n\n`;
        for (let i = 0; i < ww[chat].player.length; i++) {
            text += `${ww[chat].player[i].number}. @${ww[chat].player[i].id.replace(
          "@s.whatsapp.net",
          ""
        )}\n`;
            player.push(ww[chat].player[i].id);
        }
        text += `\nJumlah player minimal 5 sampai 15`;
        text += `\n\n*Gunakan* :`;
        text += `\n- ${usedPrefix + command} join - Untuk bergabung`;
        text += `\n- ${usedPrefix + command} player - Daftar player`; 
        text += `\n- ${usedPrefix + command} start - Mulai permainan`;  
        text += `\n- ${usedPrefix + command} exit - Keluar dari room`;        
        text += `\n- ${usedPrefix + command} delete - Hapus room`;        
        conn.sendMessage(
            m.chat, {
                text: text.trim(),
                mentions: player,
            }, {
                quoted: m
            }
        );

        // [ Game Play ]
    } else if (value === "start") {
        if (!ww[chat]) return m.reply("Belum ada sesi permainan");
        if (ww[chat].player.length === 0)
            return m.reply("Room belum memiliki player");
        if (ww[chat].player.length < 2)
            return m.reply("Maaf jumlah player belum memenuhi syarat");
        if (playerOnRoom(sender, chat, ww) === false)
            return m.reply("Kamu belum join di room ini");
        
        // Perbaikan: Cek cooldown dengan benar
        if (ww[chat].cooldown && ww[chat].cooldown > Date.now()) {
            if (ww[chat].time === "voting") {
                clearAllVote(chat, ww);
                addTimer(chat, ww);
                return await run_vote(conn, chat, ww);
            } else if (ww[chat].time === "malem") {
                clearAllVote(chat, ww);
                addTimer(chat, ww);
                return await run_malam(conn, chat, ww);
            } else if (ww[chat].time === "pagi") {
                clearAllVote(chat, ww);
                addTimer(chat, ww);
                return await run_pagi(conn, chat, ww);
            }
        }
        
        if (ww[chat].status === true)
            return m.reply("Sesi permainan telah dimulai");
        if (ww[chat].owner !== sender)
            return m.reply(
                `Hanya @${ww[chat].owner.split("@")[0]} yang dapat memulai permainan`, null, {
                    mentions: [ww[chat].owner]
                }
            );
        
        let list1 = "";
        let list2 = "";
        let player = [];
        roleGenerator(chat, ww);
        addTimer(chat, ww);
        startGame(chat, ww);
        
        for (let i = 0; i < ww[chat].player.length; i++) {
            list1 += `(${ww[chat].player[i].number}) @${ww[chat].player[
          i
        ].id.replace("@s.whatsapp.net", "")}\n`;
            player.push(ww[chat].player[i].id);
        }
        
        for (let i = 0; i < ww[chat].player.length; i++) {
            list2 += `${ww[chat].player[i].number}. @${ww[chat].player[
          i
        ].id.replace("@s.whatsapp.net", "")} ${
          ww[chat].player[i].role === "werewolf" ||
          ww[chat].player[i].role === "sorcerer"
            ? `[${ww[chat].player[i].role}]`
            : ""
        }\n`;
            player.push(ww[chat].player[i].id);
        }
        
        for (let i = 0; i < ww[chat].player.length; i++) {
            // Perbaikan: Ganti conn.getName dengan alternatif yang aman
            const playerName = `Player ${ww[chat].player[i].number}`;
            
            // [ Werewolf ]
            if (ww[chat].player[i].role === "werewolf") {
                if (ww[chat].player[i].isdead != true) {
                    var text = `*WEREWOLF*\n\nHai ${playerName}, Kamu telah dipilih untuk memerankan *Werewolf* ${emoji_role(
              "werewolf"
            )} pada permainan kali ini, silahkan pilih salah satu player yang ingin kamu makan pada malam hari ini\n\n*List Player* :\n${list2}\n*Ketik* : ${usedPrefix}wwpc kill [nomor_urutan] - Untuk membunuh player`;                 
                    await conn.sendMessage(ww[chat].player[i].id, {
                        text: text,
                        mentions: player,
                    });
                }

                // [ villager ]
            } else if (ww[chat].player[i].role === "warga") {
                if (ww[chat].player[i].isdead != true) {
                    let text = `*WEREWOLF*\n\nHai ${playerName} Peran kamu adalah *Warga Desa* ${emoji_role(
              "warga"
            )}, tetap waspada, mungkin *Werewolf* akan memakanmu malam ini, silakan masuk kerumah masing masing.\n\n*List Player* :\n${list1}`;
                    await conn.sendMessage(ww[chat].player[i].id, {
                        text: text,
                        mentions: player,
                    });
                }

                // [ Penerawangan ]
            } else if (ww[chat].player[i].role === "seer") {
                if (ww[chat].player[i].isdead != true) {
                    let text = `*WEREWOLF*\n\nHai ${playerName} Kamu telah terpilih  untuk menjadi *Penerawang* ${emoji_role(
              "seer"
            )}. Dengan sihir yang kamu punya, kamu bisa mengetahui peran pemain pilihanmu.\n\n*List Player* :\n${list1}\n*Ketik* : ${usedPrefix}wwpc dreamy [nomor_urutan] - Untuk melihat role player`;
                 
                    await conn.sendMessage(ww[chat].player[i].id, {
                        text: text,
                        mentions: player,
                    });
                }

                // [ Guardian ]
            } else if (ww[chat].player[i].role === "guardian") {
                if (ww[chat].player[i].isdead != true) {
                    let text = `*WEREWOLF*\n\nHai ${playerName} Kamu terpilih untuk memerankan *Malaikat Pelindung* ${emoji_role(
              "guardian"
            )}, dengan kekuatan yang kamu miliki, kamu bisa melindungi para warga, silahkan pilih salah 1 player yang ingin kamu lindungi\n\n*List Player* :\n${list1}\n*Ketik* : ${usedPrefix}wwpc deff [nomor_urutan] - Untuk melindungi player`;
                 
                    await conn.sendMessage(ww[chat].player[i].id, {
                        text: text,
                        mentions: player,
                    });
                }

                // [ Sorcerer ]
            } else if (ww[chat].player[i].role === "sorcerer") {
                if (ww[chat].player[i].isdead != true) {
                    let text = `*WEREWOLF*\n\nHai ${playerName} Kamu terpilih sebagai Penyihir ${emoji_role(
              "sorcerer"
            )}, dengan kekuasaan yang kamu punya, kamu bisa membuka identitas para player, silakan pilih 1 orang yang ingin kamu buka identitasnya\n\n*List Player* :\n${list2}\n*Ketik* ${usedPrefix}wwpc sorcerer [nomor_urutan] - Untuk melihat role player`;
                
                    await conn.sendMessage(ww[chat].player[i].id, {
                        text: text,
                        mentions: player,
                    });
                }
            }
        }
        
        await conn.sendMessage(m.chat, {
            text: "*WEREWOLF*\n\nGame telah dimulai, para player akan memerankan perannya masing masing, silahkan cek chat pribadi untuk melihat role kalian. Berhati-hatilah para warga, mungkin malam ini adalah malah terakhir untukmu",
            contextInfo: {
                externalAdReply: {
                    title: "",
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    thumbnail: await resize(thumb, 300, 175),
                    sourceUrl: "",
                    mediaUrl: thumb,
                },
                mentionedJid: player,
            },            
//            mentions: player,
        });
        
        await run(conn, chat, ww);
        
    } else if (value === "vote") {
        if (!ww[chat]) return m.reply("Belum ada sesi permainan");
        if (ww[chat].status === false)
            return m.reply("Sesi permainan belum dimulai");
        if (ww[chat].time !== "voting")
            return m.reply("Sesi voting belum dimulai");
        if (playerOnRoom(sender, chat, ww) === false)
            return m.reply("Kamu bukan player");
        if (dataPlayer(sender, ww).isdead === true)
            return m.reply("Kamu sudah mati");
        if (!target || target.length < 1)
            return m.reply("Masukan nomor player");
        if (isNaN(target)) return m.reply("Gunakan hanya nomor");
        if (dataPlayer(sender, ww).isvote === true)
            return m.reply("Kamu sudah melakukan voting");
        let b = getPlayerById(chat, sender, parseInt(target), ww);
        if (!b) return m.reply("Player tidak ditemukan");
        if (b.db.isdead === true)
            return m.reply(`Player ${target} sudah mati.`);
        if (ww[chat].player.length < parseInt(target))
            return m.reply("Invalid");
        if (getPlayerById(chat, sender, parseInt(target), ww) === false)
            return m.reply("Player tidak terdaftar!");
        vote(chat, parseInt(target), sender, ww);
        return m.reply("Voting! 👍");
        
    } else if (value == "exit") {
        if (!ww[chat]) return m.reply("Tidak ada sesi permainan");
        if (playerOnRoom(sender, chat, ww) === false)
            return m.reply("Kamu tidak dalam sesi permainan");
        if (ww[chat].status === true)
            return m.reply("Permainan sudah dimulai, kamu tidak bisa keluar");
        m.reply(`@${sender.split("@")[0]} Keluar dari permainan`, {
            mentions: [sender]
        });
        playerExit(chat, sender, ww);
        
    } else if (value === "delete") {
        if (!ww[chat]) return m.reply("Tidak ada sesi permainan");
        if (ww[chat].owner !== sender)
            return m.reply(
                `Hanya @${ww[chat].owner.split("@")[0]} yang dapat menghapus sesi permainan ini`, null, {
                    mentions: [ww[chat].owner]
                }
            );
        m.reply("Sesi permainan berhasil dihapus").then(() => {
            delete ww[chat];
        });
        
    } else if (value === "player") {
        if (!ww[chat]) return m.reply("Tidak ada sesi permainan");
        if (playerOnRoom(sender, chat, ww) === false)
            return m.reply("Kamu tidak dalam sesi permainan");
        if (ww[chat].player.length === 0)
            return m.reply("Sesi permainan belum memiliki player");
        let player = [];
        let text = "\n*WEREWOLF*\n\n*List Player* :\n";
        for (let i = 0; i < ww[chat].player.length; i++) {
            text += `${ww[chat].player[i].number}. @${ww[chat].player[i].id.replace(
          "@s.whatsapp.net",
          ""
        )} ${
          ww[chat].player[i].isdead === true
            ? `☠️ ${ww[chat].player[i].role}`
            : ""
        }\n`;
            player.push(ww[chat].player[i].id);
        }
        conn.sendMessage(
            m.chat, {
                text: text,
                mentions: player,
            }, {
                quoted: m
            }
        );
    } else {
        let text = `\n*WEREWOLF*\n\nPermainan sosial yang berlangsung dalam beberapa putaran/ronde. Para pemain dituntut untuk mencari seorang penjaga yang ada di permainan. Para pemain diberi waktu, peran, serta kemampuannya masing-masing untuk bermain permainan ini.\n\n*Perintah*\n`;
        text += `1. ${usedPrefix + command} create - Membuat room\n`;
        text += `2. ${usedPrefix + command} join - Bergabung ke room\n`;
        text += `3. ${usedPrefix + command} start - Mulai permainan\n`;
        text += `4. ${usedPrefix + command} vote [nomor_urutan] - Vote player (saat voting)\n`
        text += `5. ${usedPrefix + command} exit - Keluar dari room\n`;
        text += `6. ${usedPrefix + command} delete - Hapus room\n`;
        text += `7. ${usedPrefix + command} player - Daftar player\n\n`;
        text += `\n*Perintah Private* (di chat pribadi)\n`;
        text += `1. ${usedPrefix + command} kill [nomor_urutan] - Werewolf bunuh player\n`;      
        text += `2. ${usedPrefix + command} dreamy [nomor_urutan] - Seer memilih role\n`;          
        text += `3. ${usedPrefix + command} deff [nomor_urutan] - Guardian melindungi\n`;
        text += `4. ${usedPrefix + command} sorcerer [nomor_urutan] - Sorcerer memilih role\n\n`;  
        text += `Dapat di mainkan oleh 5 sampai 15 orang`;  
        conn.sendMessage(
            m.chat, {
                text: text.trim(),
            }, {
                quoted: m
            }
        );
    }
  }
}