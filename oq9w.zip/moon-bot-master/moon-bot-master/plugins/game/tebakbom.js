module.exports = {
  help: ['bomb'],
  aliases: ['bom', 'tbkbom', 'tebakbom', 'tebakbomb'],
  tags: 'game', 
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    conn.tebakbom = conn.tebakbom ? conn.tebakbom : {}
    let id = m.chat,
       timeout = 180000
    if (id in conn.tebakbom) return conn.reply(m.chat, 'Masih ada sesi yang belum selesai di chat ini!', conn.tebakbom[id][0])
    const bom = ['💥', '✅', '✅', '✅', '✅', '✅', '✅', '✅', '✅'].sort(() => Math.random() - 0.5)
    const number = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣']
    const array = []
    bom.map((v, i) => array.push({
       emot: v,
       number: number[i],
       position: i + 1,
       state: false
    }))
    let teks = `*BOMB*\n\n`
    teks += `*Timeout* : ${((timeout / 1000) / 60)} menit\n\n`; 
    teks += array.slice(0, 3).map(v => v.state ? v.emot : v.number).join('') + '\n'
    teks += array.slice(3, 6).map(v => v.state ? v.emot : v.number).join('') + '\n'
    teks += array.slice(6).map(v => v.state ? v.emot : v.number).join('') + '\n\n'
    teks += `Silakan kirim angka 1-9\nUntuk membuka 9 kotak di atas!`;
    teks += ` `
    conn.tebakbom[id] = [
       await conn.reply(m.chat, teks, m),
       array,
       setTimeout(() => {
          let v = array.find(v => v.emot == '💥')
          if (conn.tebakbom[id]) conn.reply(m.chat, `Waktu habis!\nBomb berada di kotak : ${v.number}`, conn.tebakbom[id][0])
          delete conn.tebakbom[id]
       }, timeout)
    ]
  }
}