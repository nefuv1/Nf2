const fetch = require('node-fetch')

module.exports = {
  help: ['tebaklirik'],
  aliases: ['tbklirik'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true // Set to false to disable auto-delete
    
    let timeout = 60000
    let poin = 3999
    
    conn.tebaklirik = conn.tebaklirik ? conn.tebaklirik : {}
    let id = m.chat
    if (id in conn.tebaklirik) {
      conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini', conn.tebaklirik[id][0])
      throw false
    }
    
    let res = await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaklirik.json')
    if (!res.ok) throw await `${res.status} ${res.statusText}`
    let data = await res.json()
    let json = data[Math.floor(Math.random() * data.length)]
    
    let caption = `*TEBAK LIRIK*
      
${json.soal}

*Timeout* : ${(timeout / 1000).toFixed(2)} detik
*Game ID* : GAME-005
Untuk bantuan kirim perintah : ${usedPrefix}hlirik

Bonus: 
- 3.999 EXP

Balas soal ini untuk menjawab!
    `.trim()
    
    let sentMsg = await conn.reply(m.chat, caption, m)
    conn.tebaklirik[id] = [
      sentMsg,
      json,
      poin,
      setTimeout(() => {
        if (conn.tebaklirik[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.tebaklirik[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.jawaban}*`, conn.tebaklirik[id][0])
          delete conn.tebaklirik[id]
        }
      }, timeout),
      deleteAfterAnswer // Store delete option
    ]
  }
}