let fetch = require('node-fetch')

module.exports = {
  help: ['susunkata'],
  aliases: ['sskata'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true // Set to false to disable auto-delete
    
    let timeout = 60000
    let poin = 3999
    
    conn.susunkata = conn.susunkata ? conn.susunkata : {}
    let id = m.chat
    if (id in conn.susunkata) {
      conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.susunkata[id][0])
      throw false
    }
    
    let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/susunkata.json')).json()
    let json = src[Math.floor(Math.random() * src.length)]
    
    let caption = `*SUSUN KATA*
  
${json.soal}

*Type* : ${json.tipe}
*Timeout* : ${(timeout / 1000).toFixed(2)} detik
*Game ID* : GAME-015
Untuk bantuan kirim perintah : ${usedPrefix}hsuska

*Bonus* : 
- 3.999 EXP

Balas soal ini untuk menjawab!
    `.trim()
    
    let sentMsg = await conn.reply(m.chat, caption, m)
    conn.susunkata[id] = [
      sentMsg,
      json,
      poin,
      setTimeout(() => {
        if (conn.susunkata[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.susunkata[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.jawaban}*`, conn.susunkata[id][0])
          delete conn.susunkata[id]
        }
      }, timeout),
      deleteAfterAnswer // Store delete option
    ]
  }
}