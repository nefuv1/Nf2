let fetch = require('node-fetch')

module.exports = {
  help: ['tebakkata'],
  aliases: ['tbkkata'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true // Set to false to disable auto-delete
    
    let timeout = 60000
    let poin = 3999
    
    conn.tebakkata = conn.tebakkata ? conn.tebakkata : {}
    let id = m.chat
    if (id in conn.tebakkata) {
      conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.tebakkata[id][0])
      throw false
    }
    
    let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkata.json')).json()
    let json = src[Math.floor(Math.random() * src.length)]
    
    let caption = `*TEBAK KATA*

${json.soal}

*Timeout* : ${(timeout / 1000).toFixed(2)} detik
*Game ID* : GAME-008
Untuk bantuan kirim perintah : ${usedPrefix}hkata

*Bonus* : 
- 3.999 EXP

Balas soal ini untuk menjawab!
    `.trim()
    
    let sentMsg = await conn.reply(m.chat, caption, m)
    conn.tebakkata[id] = [
      sentMsg,
      json,
      poin,
      setTimeout(() => {
        if (conn.tebakkata[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.tebakkata[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.jawaban}*`, conn.tebakkata[id][0])
          delete conn.tebakkata[id]
        }
      }, timeout),
      deleteAfterAnswer // Store delete option
    ]
  }
}