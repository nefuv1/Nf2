let fetch = require('node-fetch')

module.exports = {
  help: ['caklontong'],
  aliases: ['cklontong'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true // Ubah ke false jika tidak ingin auto delete
    
    let timeout = 60000
    let poin = 3999
    let limit = 1
    
    conn.caklontong = conn.caklontong ? conn.caklontong : {}
    let id = m.chat
    if (id in conn.caklontong) {
      conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.caklontong[id][0])
      throw false
    }
    
    let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/caklontong.json')).json()
    let json = src[Math.floor(Math.random() * src.length)]
    let caption = `*CAK LONTONG*
  
${json.soal}

*Timeout* : ${(timeout / 1000).toFixed(2)} detik
*Game ID* : GAME-023
Untuk bantuan kirim perintah : ${usedPrefix}hcalo

*Bonus* : 
- 3.999 EXP
- ${limit} Limit

Balas soal ini untuk menjawab!
    `.trim()
    
    let sentMsg = await conn.reply(m.chat, caption, m)
    conn.caklontong[id] = [
      sentMsg,
      json,
      poin,
      setTimeout(() => {
        if (conn.caklontong[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.caklontong[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.jawaban}*\n\n${json.deskripsi}`, conn.caklontong[id][0])
          delete conn.caklontong[id]
        }
      }, timeout),
      deleteAfterAnswer // Store delete option
    ]
  }
}