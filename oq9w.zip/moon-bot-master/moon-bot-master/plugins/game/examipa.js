const fs = require('fs');

module.exports = {
  help: ['examipa'],
  aliases: ['exipa'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true; // Set to false to disable auto-delete
    
    let timeout = 60000;
    let poin = 3999;
    
    conn.game = conn.game ? conn.game : {};
    let id = 'examipa-' + m.chat;
    if (id in conn.game) return conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.game[id][0]);

    let src = JSON.parse(fs.readFileSync(require('path').join(__dirname, '../../json/examipa.json'), 'utf-8'));
    let json = src[Math.floor(Math.random() * src.length)];
    let caption = `*IPA*

*Sekolah* : SMP/SMA, 7/12
*Pelajaran* : ILMU PENGETAHUAN ALAM

${json.soal}

*Timeout* : ${(timeout / 1000).toFixed(2)} detik
*Game ID* : GAME-021
Untuk bantuan kirim perintah : ${usedPrefix}hipa

*Bonus* : 
- 3.999 EXP

Balas soal ini untuk menjawab!
`.trim();

    let sentMsg = await m.reply(caption);
    conn.game[id] = [
      sentMsg,
      json, 
      poin,
      setTimeout(() => {
        if (conn.game[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.game[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {});
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.jawaban}*`, conn.game[id][0]);
          delete conn.game[id];
        }
      }, timeout),
      1, // Jumlah kesempatan menjawab
      deleteAfterAnswer // Store delete option
    ];
  }
}