const similarity = require('similarity')
const threshold = 0.72

module.exports = {
  run: async (m, { conn, users, Func }) => {
    try {
      conn.family100 = conn.family100 ? conn.family100 : {}
      let id = 'family100_' + m.chat
      if (!(id in conn.family100)) return true
      
      let room = conn.family100[id]
      let text = m.text.toLowerCase().replace(/[^\w\s\-]+/, '')
      let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
      
      if (!isSurrender) {
        let index = room.jawaban.findIndex(jawaban => jawaban.toLowerCase() === text)
        if (index < 0) {
          // Cek similarity jika jawaban tidak tepat
          let maxSimilarity = Math.max(...room.jawaban
            .filter((_, idx) => !room.terjawab[idx])
            .map(jawaban => similarity(jawaban.toLowerCase(), text))
          )
          if (maxSimilarity >= threshold) m.reply('Sedikit lagi! 👎')
          return true
        }
        if (room.terjawab[index]) return true
        
        // Berikan reward
        users.money += room.winScore
        room.terjawab[index] = m.sender
      }
      
      let isWin = room.terjawab.every(v => v)
      let caption = `*FAMILY100*
  
${room.soal}
  
*Game ID* : GAME-020
Terdapat *${room.jawaban.length}* jawaban${room.jawaban.find(v => v.includes(' ')) ? `
(beberapa jawaban terdapat spasi)`: ''}
  
${isWin ? `*Semua Jawaban Terjawab*` : isSurrender ? '*Menyerah*' : ''}
${room.jawaban.map((jawaban, index) => {
  if (isSurrender || room.terjawab[index]) {
    let userMention = room.terjawab[index] ? '@' + room.terjawab[index].split('@')[0] : ''
    return `(${index + 1}) ${jawaban} ${userMention}`.trim()
  }
  return false
}).filter(v => v).join('\n')}
  
*Bonus* :
- ${isSurrender ? '' : `+1.000 Money`}`.trim()
      
      m.reply(caption).then(msg => {
        conn.family100[id].msg = msg
      }).catch(_ => _)
      
      if (isWin || isSurrender) delete conn.family100[id]
    } catch (e) {
      console.log(e)
    }
    return true
  },
  error: false
}