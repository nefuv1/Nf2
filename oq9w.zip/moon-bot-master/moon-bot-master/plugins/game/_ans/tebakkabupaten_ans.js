const similarity = require('similarity')
const threshold = 0.72

module.exports = {
  run: async (m, { conn, users, Func }) => {
    let id = m.chat
    conn.tebakkabupaten = conn.tebakkabupaten ? conn.tebakkabupaten : {}
    
    // Cek jika ini adalah jawaban untuk game tebakkabupaten
    if (m.quoted && /TEBAK KABUPATEN/i.test(m.quoted.text)) {
      if (!(id in conn.tebakkabupaten) && /Game ID.*GAME-010/i.test(m.quoted.text)) return conn.reply(m.chat, 'Soal itu telah berakhir.', m)
      
      if (m.quoted.id == conn.tebakkabupaten[id][0].id) {
        let json = JSON.parse(JSON.stringify(conn.tebakkabupaten[id][1]))
        const deleteAfterAnswer = conn.tebakkabupaten[id][4] // Get delete option

        // CEK JIKA USER MENYERAH
        const surrenderWords = ['nyerah', 'menyerah', 'give up'];
        if (surrenderWords.includes(m.text.toLowerCase())) {
          if (deleteAfterAnswer) {
            await conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.tebakkabupaten[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
            
            setTimeout(() => {
              conn.sendMessage(m.chat, { 
                delete: { 
                  remoteJid: m.chat, 
                  id: m.id, 
                  fromMe: false 
                } 
              }).catch(() => {})
            }, 2000)
          }
          
          conn.reply(m.chat, `Kamu menyerah!\nJawabannya adalah : *${json.title}*`, conn.tebakkabupaten[id][0])
          clearTimeout(conn.tebakkabupaten[id][3])
          delete conn.tebakkabupaten[id]
          return
        }        
        
        if (m.text.toLowerCase() == json.title.toLowerCase().trim()) {
          // Berikan reward
          users.exp += conn.tebakkabupaten[id][2]
          
          if (deleteAfterAnswer) {
            // Delete question message
            await conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.tebakkabupaten[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
            
            // Delete answer message after delay
            setTimeout(() => {
              conn.sendMessage(m.chat, { 
                delete: { 
                  remoteJid: m.chat, 
                  id: m.id, 
                  fromMe: false 
                } 
              }).catch(() => {})
            }, 2000)
          }
          
          m.reply(`*Yeay, Benar. 👍*\n\n- +3.999 EXP`)
          clearTimeout(conn.tebakkabupaten[id][3])
          delete conn.tebakkabupaten[id]
          
        } else if (similarity(m.text.toLowerCase(), json.title.toLowerCase().trim()) >= threshold) {
          m.reply(`Sedikit lagi! 👎`)
        } else {
          m.reply(`Salah! 👎`)
        }
      }
    }
  },
  error: false
}