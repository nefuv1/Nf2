// Versi Thumbnail Kirim Lewat Iklan
module.exports = {
run: async (m, { conn, users, Func }) => {
    let id = m.chat;
    let reward = 9999;
    let body = typeof m.text == 'string' ? m.text : false;
    
    conn.tebakbom = conn.tebakbom ? conn.tebakbom : {};    
        
    if (!(id in conn.tebakbom)) {    
      if (m.quoted && /BOMB/i.test(m.quoted.text)) {    
        return conn.reply(m.chat, `Sesi tebakbomb sudah berakhir.`, m);    
      }    
      return;    
    }    
        
    if (!isNaN(body)) {    
        let timeout = 180000;    
        let json = conn.tebakbom[id][1].find(v => v.position == body);    
            
        if (!json) return conn.reply(m.chat, `Untuk membuka kotak kirim angka 1-9`, m);    
            
        if (json.emot == '💥') {    
            json.state = true;    
            let bomb = conn.tebakbom[id][1];    
            let teks = `*BOMB*\n\n`;    
            teks += `Kamu Kalah!\n\n`;    
            teks += bomb.slice(0, 3).map(v => v.state ? v.emot : v.number).join('') + '\n';    
            teks += bomb.slice(3, 6).map(v => v.state ? v.emot : v.number).join('') + '\n';    
            teks += bomb.slice(6).map(v => v.state ? v.emot : v.number).join('') + '\n\n';    
            teks += `*Permainan Selesai!*\nKotak berisi bomb terbuka.`;    
                
            // GANTI sendFile dengan sendMessageModify
            conn.sendMessageModify(m.chat, teks, null, {    
              largeThumb: true,    
              thumbnail: 'https://telegra.ph/file/287cbe90fe5263682121d.jpg',    
            });    
            clearTimeout(conn.tebakbom[id][2]);    
            delete conn.tebakbom[id];    
                
        } else if (json.state) {    
            return conn.reply(m.chat, `Kotak ${json.number} sudah di buka silahkan pilih yang lain.`, m);    
                
        } else {    
            json.state = true;    
            let changes = conn.tebakbom[id][1];    
            let open = changes.filter(v => v.state && v.emot != '💥').length;    
                
            if (open >= 8) {    
                let teks = `*BOMB*\n\n`;    
                teks += `*Timeout* : ${((timeout / 1000) / 60)} menit\n\n`      
                teks += changes.slice(0, 3).map(v => v.state ? v.emot : v.number).join('') + '\n';    
                teks += changes.slice(3, 6).map(v => v.state ? v.emot : v.number).join('') + '\n';    
                teks += changes.slice(6).map(v => v.state ? v.emot : v.number).join('') + '\n\n';    
                teks += '*Bonus* :\n- 9.999 EXP\n\n';
                teks += `*Permainan Selesai!*\nKotak berisi bomb tidak terbuka.`;    
                    
                // GANTI sendFile dengan sendMessageModify
                conn.sendMessageModify(m.chat, teks, null, {    
                  largeThumb: true,    
                  thumbnail: 'https://telegra.ph/file/f6ebfea2758b947e1e49d.jpg',    
                });    
                    
                if (users && users[m.sender]) {    
                  users[m.sender].exp += reward;    
                }    
                    
                clearTimeout(conn.tebakbom[id][2]);    
                delete conn.tebakbom[id];    
                    
            } else {    
                let teks = `*BOMB*\n\n`;    
                teks += `*Timeout* : ${((timeout / 1000) / 60)} menit\n\n`;       
                teks += changes.slice(0, 3).map(v => v.state ? v.emot : v.number).join('') + '\n';    
                teks += changes.slice(3, 6).map(v => v.state ? v.emot : v.number).join('') + '\n';    
                teks += changes.slice(6).map(v => v.state ? v.emot : v.number).join('') + '\n\n';    
                teks += `Silakan kirim angka 1-9\nUntuk membuka 9 kotak di atas!`;    
                    
                let smallReward = Math.floor(reward / 8);    
                if (users && users[m.sender]) {    
                  users[m.sender].exp += smallReward;    
                }    
                    
                await conn.reply(m.chat, teks, m);    
              }    
            }    
          }
        }
      }