const similarity = require('similarity')
const threshold = 0.72

module.exports = {
  run: async (m, { conn, users, Func }) => {
    let id = m.chat
    conn.tebakjkt48 = conn.tebakjkt48 ? conn.tebakjkt48 : {}
    
    // Cek jika ini adalah jawaban untuk game tebakjkt48
    if (m.quoted && /TEBAK JKT48/i.test(m.quoted.text)) {
      if (!(id in conn.tebakjkt48) && /Game ID.*GAME-011/i.test(m.quoted.text)) return conn.reply(m.chat, 'Soal itu telah berakhir.', m)
      
      if (m.quoted.id == conn.tebakjkt48[id][0].id) {
        let json = JSON.parse(JSON.stringify(conn.tebakjkt48[id][1]))
        const deleteAfterAnswer = conn.tebakjkt48[id][4] // Get delete option
        
        // CEK JIKA USER MENYERAH
        const surrenderWords = ['nyerah', 'menyerah', 'give up'];
        if (surrenderWords.includes(m.text.toLowerCase())) {
          if (deleteAfterAnswer) {
            await conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.tebakjkt48[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
            
            setTimeout(() => {
              conn.sendMessage(m.chat, { 
                delete: { 
                  remoteJid: m.chat, 
                  id: m.id, 
                  fromMe: false 
                } 
              }).catch(() => {})
            }, 2000)
          }
          
          conn.reply(m.chat, `Kamu menyerah!\nJawabannya adalah : *${json.jawaban}*`, conn.tebakjkt48[id][0])
          clearTimeout(conn.tebakjkt48[id][3])
          delete conn.tebakjkt48[id]
          return
        }
                
        if (m.text.toLowerCase() == json.jawaban.toLowerCase().trim()) {
          // Berikan reward
          users.exp += conn.tebakjkt48[id][2]
          
          if (deleteAfterAnswer) {
            // Delete question message
            await conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.tebakjkt48[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
            
            // Delete answer message after delay
            setTimeout(() => {
              conn.sendMessage(m.chat, { 
                delete: { 
                  remoteJid: m.chat, 
                  id: m.id, 
                  fromMe: false 
                } 
              }).catch(() => {})
            }, 2000)
          }
          
          m.reply(`*Yeay, Benar. 👍*\n\n- +3.999 EXP`)
          clearTimeout(conn.tebakjkt48[id][3])
          delete conn.tebakjkt48[id]
          
        } else if (similarity(m.text.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) {
          m.reply(`Sedikit lagi! 👎`)
        } else {
          m.reply(`Salah! 👎`)
        }
      }
    }
  },
  error: false
}