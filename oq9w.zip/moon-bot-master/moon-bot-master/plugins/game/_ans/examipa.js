const similarity = require('similarity')
const threshold = 0.72

module.exports = {
  run: async (m, { conn, users, Func }) => {
    let id = 'examipa-' + m.chat
    conn.game = conn.game ? conn.game : {}
    
    // Cek jika ini adalah jawaban untuk game examipa
    if (m.quoted && /IPA/i.test(m.quoted.text)) {
      if (!(id in conn.game) && /Game ID.*GAME-021/i.test(m.quoted.text)) return conn.reply(m.chat, 'Soal itu telah berakhir.', m)
      
      if (m.quoted.id == conn.game[id][0].id) {
        let json = JSON.parse(JSON.stringify(conn.game[id][1]))
        const deleteAfterAnswer = conn.game[id][5] // Get delete option
        const attemptsLeft = conn.game[id][4] // Get remaining attempts

        // CEK JIKA USER MENYERAH
        const surrenderWords = ['nyerah', 'menyerah', 'give up'];
        if (surrenderWords.includes(m.text.toLowerCase())) {
          if (deleteAfterAnswer) {
            await conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.game[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
            
            setTimeout(() => {
              conn.sendMessage(m.chat, { 
                delete: { 
                  remoteJid: m.chat, 
                  id: m.id, 
                  fromMe: false 
                } 
              }).catch(() => {})
            }, 2000)
          }
          
          conn.reply(m.chat, `Kamu menyerah!\nJawabannya adalah : *${json.jawaban}*`, conn.game[id][0])
          clearTimeout(conn.game[id][3])
          delete conn.game[id]
          return
        }
                
        if (m.text.toLowerCase() == json.jawaban.toLowerCase().trim()) {
          // Berikan reward
          users.exp += conn.game[id][2]
          
          if (deleteAfterAnswer) {
            // Delete question message
            await conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.game[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
            
            // Delete answer message after delay
            setTimeout(() => {
              conn.sendMessage(m.chat, { 
                delete: { 
                  remoteJid: m.chat, 
                  id: m.id, 
                  fromMe: false 
                } 
              }).catch(() => {})
            }, 2000)
          }
          
          m.reply(`*Yeay, Benar. 👍*\n\n- +3.999 EXP`)
          clearTimeout(conn.game[id][3])
          delete conn.game[id]
          
        } else if (similarity(m.text.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) {
          m.reply(`Sedikit lagi! 👎`)
        } else {
          // Kurangi kesempatan menjawab
          conn.game[id][4] -= 1
          
          if (conn.game[id][4] <= 0) {
            if (deleteAfterAnswer) {
              await conn.sendMessage(m.chat, { 
                delete: { 
                  remoteJid: m.chat, 
                  id: conn.game[id][0].id, 
                  fromMe: true 
                } 
              }).catch(() => {})
            }
            conn.reply(m.chat, `Kesempatan habis!\nJawabannya adalah : *${json.jawaban}*`, conn.game[id][0])
            clearTimeout(conn.game[id][3])
            delete conn.game[id]
          } else {
            m.reply(`Salah! 👎\nMasih ada ${conn.game[id][4]} kesempatan`)
          }
        }
      }
    }
  },
  error: false
}