const similarity = require('similarity')
const threshold = 0.72

module.exports = {
  run: async (m, { conn, users, Func }) => {
    let id = m.chat
    conn.siapakahaku = conn.siapakahaku ? conn.siapakahaku : {}
    
    // Cek jika ini adalah jawaban untuk game siapakahaku
    if (m.quoted && /SIAPAKAH AKU/i.test(m.quoted.text)) {
      if (!(id in conn.siapakahaku) && /Game ID.*GAME-016/i.test(m.quoted.text)) return conn.reply(m.chat, 'Soal itu telah berakhir.', m)
      
      if (m.quoted.id == conn.siapakahaku[id][0].id) {
        let json = JSON.parse(JSON.stringify(conn.siapakahaku[id][1]))
        const deleteAfterAnswer = conn.siapakahaku[id][4] // Get delete option

        // CEK JIKA USER MENYERAH
        const surrenderWords = ['nyerah', 'menyerah', 'give up'];
        if (surrenderWords.includes(m.text.toLowerCase())) {
          if (deleteAfterAnswer) {
            await conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.siapakahaku[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
            
            setTimeout(() => {
              conn.sendMessage(m.chat, { 
                delete: { 
                  remoteJid: m.chat, 
                  id: m.id, 
                  fromMe: false 
                } 
              }).catch(() => {})
            }, 2000)
          }
          
          conn.reply(m.chat, `Kamu menyerah!\nJawabannya adalah : *${json.jawaban}*`, conn.siapakahaku[id][0])
          clearTimeout(conn.siapakahaku[id][3])
          delete conn.siapakahaku[id]
          return
        }
                
        if (m.text.toLowerCase() == json.jawaban.toLowerCase().trim()) {
          // Berikan reward
          users.exp += 3999
          users.limit += 1
          
          if (deleteAfterAnswer) {
            // Delete question message
            await conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.siapakahaku[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
            
            // Delete answer message after delay
            setTimeout(() => {
              conn.sendMessage(m.chat, { 
                delete: { 
                  remoteJid: m.chat, 
                  id: m.id, 
                  fromMe: false 
                } 
              }).catch(() => {})
            }, 2000)
          }
          
          m.reply(`*Yeay, Benar. 👍*\n\n- +3.999 EXP\n- +1 Limit`)
          clearTimeout(conn.siapakahaku[id][3])
          delete conn.siapakahaku[id]
          
        } else if (similarity(m.text.toLowerCase(), json.jawaban.toLowerCase().trim()) >= threshold) {
          m.reply(`Sedikit lagi! 👎`)
        } else {
          m.reply(`Salah! 👎`)
        }
      }
    }
  },
  error: false
}