const formatNumber = (num) => {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
};

module.exports = {
  run: async (m, { conn, users, Func }) => {
    if (!/^-?[0-9]+(\.[0-9]+)?$/.test(m.text)) return true
    let id = m.chat
    if (!m.quoted || m.quoted.sender != conn.user.jid || !/MATH/i.test(m.quoted.text)) return true
    
    conn.math = conn.math ? conn.math : {}
    if (!(id in conn.math)) return m.reply('Soal itu telah berakhir.')
    
    if (m.quoted.id == conn.math[id][0].id) {
      let math = JSON.parse(JSON.stringify(conn.math[id][1]))
      const deleteAfterAnswer = conn.math[id][4] // Get delete option
      
      if (m.text == math.result) {
        users.exp += math.bonus
        users.limit += math.limit
        
        if (deleteAfterAnswer) {
          // Delete question message
          await conn.sendMessage(m.chat, { 
            delete: { 
              remoteJid: m.chat, 
              id: conn.math[id][0].id, 
              fromMe: true 
            } 
          }).catch(() => {})
          
          // Delete answer message after delay
          setTimeout(() => {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: m.id, 
                fromMe: false 
              } 
            }).catch(() => {})
          }, 2000)
        }
        
        clearTimeout(conn.math[id][3])
        delete conn.math[id]
        m.reply(`*Yeay, Benar. 👍*\n\n- +${formatNumber(math.bonus)} EXP\n- ${math.limit > 0 ? `+${math.limit} Limit` : ''}`)
      } else {
        if (--conn.math[id][2] == 0) {
          if (deleteAfterAnswer) {
            await conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.math[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
          }
          clearTimeout(conn.math[id][3])
          delete conn.math[id]
          m.reply(`Kesempatan habis!\nJawabannya adalah : *${math.result}*`)
        } else {
          m.reply(`Salah! 👎\nMasih ada ${conn.math[id][2]} kesempatan`)
        }
      }
    }
    return true
  },
  error: false
}