module.exports = {
  run: async (m, { conn, usedPrefix, command, Func }) => {
    let winScore = 50000
    let playScore = 10000

    conn.ttt = conn.ttt ? conn.ttt : {}
    
    // AUTO CLEANUP: Update last activity untuk semua room
    let now = Date.now()
    for (let roomId in conn.ttt) {
      let room = conn.ttt[roomId]
      if (room.state === 'PLAYING' && [room.game.playerX, room.game.playerO].includes(m.sender)) {
        room.lastActivity = now
      }
    }
    
    let room = Object.values(conn.ttt).find(room =>
      room.id && room.game && room.state &&
      room.id.startsWith('tictactoe') &&
      [room.game.playerX, room.game.playerO].includes(m.sender) &&
      room.state == 'PLAYING'
    )

    if (room) {
      // UPDATE ACTIVITY
      room.lastActivity = now
      
      if (!/^([1-9]|(me)?nyerah|surr?ender)$/i.test(m.text)) return true

      let isSurrender = !/^[1-9]$/.test(m.text)
      if (m.sender !== room.game.currentTurn && !isSurrender) return true

      if (!isSurrender) {
        let ok = room.game.turn(m.sender === room.game.playerO, parseInt(m.text) - 1)
        if (ok < 1) {
          m.reply({
            '-3': 'Game telah berakhir.',
            '-2': 'Invalid!',
            '-1': 'Posisi Invalid!',
            0: 'Posisi Invalid!'
          }[ok])
          return true
        }
      }

      let isWin = m.sender === room.game.winner
      let isTie = room.game.board === 511

      let arr = room.game.render().map(v => {
        return {
          X: '❌',
          O: '⭕',
          1: '1️⃣',
          2: '2️⃣',
          3: '3️⃣',
          4: '4️⃣',
          5: '5️⃣',
          6: '6️⃣',
          7: '7️⃣',
          8: '8️⃣',
          9: '9️⃣',
        }[v]
      })

      if (isSurrender) {
        room.game._currentTurn = m.sender === room.game.playerX
        isWin = true
      }

      let winner = isSurrender ? room.game.currentTurn : room.game.winner

      let str = `*TICTACTOE*
      
*Room ID* : ${room.id}
*Game ID* : GAME-024

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

${isWin ? `*@${winner.split('@')[0]} Yeay, Menang. 🏆*

- +${Func.formatNumber(winScore)} Money` :
  isTie ? `Game telah selesai, hasil SERI\n\n- +${Func.formatNumber(playScore)} Money` :
    `*Giliran* : @${room.game.currentTurn.split('@')[0]}`}

1. @${room.game.playerX.split('@')[0]} : ❌
2. @${room.game.playerO.split('@')[0]} : ⭕

Untuk menyerah kirim perintah : nyerah`.trim()

      if ((room.game._currentTurn ^ isSurrender ? room.x : room.o) !== m.chat) {
        room[room.game._currentTurn ^ isSurrender ? 'x' : 'o'] = m.chat
      }

      if (room.x !== room.o) await conn.reply(room.x, str, m)
      await conn.reply(room.o, str, m)

      // AUTO DELETE: Hapus room ketika game selesai
      if (isTie || isWin) {
        let users = global.db.users
        if (users[room.game.playerX]) users[room.game.playerX].money += playScore
        if (users[room.game.playerO]) users[room.game.playerO].money += playScore
        if (isWin && users[winner]) users[winner].money += winScore - playScore

        // Hapus room setelah game selesai
        setTimeout(() => {
          if (conn.ttt[room.id]) {
            delete conn.ttt[room.id]
          }
        }, 5000) // Hapus setelah 5 detik
      }
    }
    return true
  },
  error: false
}