// versi mendeteksi otomatis jawaban tanpa reply
const { sKata, cKata } = require('../../../lib/sambung-kata.js')
const formatNumber = require('../../../lib/formatNumber')

module.exports = {
  run: async (m, { conn, users, Func }) => {
    let id = m.chat
    if (!conn.skata || !(id in conn.skata)) return
    
    let room = conn.skata[id]
    if (room.status !== 'play') return
    
    let member = room.player
    let isPlayerTurn = room.curr === m.sender
    let isEliminated = room.eliminated.includes(m.sender)
    let isInGame = member.includes(m.sender)
    
    // FIX: TANPA REPLY - Cek apakah user adalah pemain yang sedang bermain
    if (!isInGame) return // Hanya pemain yang bisa jawab
    
    // Handle surrender (tanpa reply)
    if (m.text.toLowerCase() === 'nyerah') {
      if (!isPlayerTurn) return m.reply('Bukan giliranmu!')
      
      clearTimeout(room.waktu)
      
      await conn.reply(m.chat, `@${m.sender.split('@')[0]} telah menyerah! 🏳️`, room.chat, {
        contextInfo: { mentionedJid: member }
      })
      
      room.eliminated.push(m.sender)
      let index = member.indexOf(m.sender)
      member.splice(index, 1)
      
      // FIX: Error ketika member.length === 0 (main sendiri menyerah)
      if (member.length === 0) {
        // Game berakhir tanpa pemenang
        delete conn.skata[id]
        return
      }
      
      if (member.length === 1) {
        // Game over - winner
        let winner = member[0]
        // FIX: Pastikan user data ada sebelum akses
        if (!global.db.users[winner]) global.db.users[winner] = {}
        global.db.users[winner].exp += room.win_point
        await conn.reply(m.chat, `*@${winner.split('@')[0]} Yeay, Menang. 🎉*\n\n- +${formatNumber(room.win_point)} EXP`, room.chat, {
          contextInfo: { mentionedJid: member }
        })
        delete conn.skata[id]
      } else {
        // Continue game
        room.curr = member[0]
        room.kata = await genKata()
        
        let requiredStart = filter(room.kata)
        let nextQuestion = `*SAMBUNG KATA*\n\n*Sekarang* : @${room.curr.split('@')[0]}\n*Mulai* : ${room.kata.toUpperCase()}\n\n*${requiredStart.toUpperCase()}... ?*\n\nBalas soal ini untuk menjawab!`
        
        room.chat = await conn.reply(m.chat, nextQuestion, room.chat, {
          contextInfo: { mentionedJid: member }
        })
        
        // Reset timeout
        clearTimeout(room.waktu)
        room.waktu = setTimeout(() => {
          // Timeout handler dengan AUTO DELETE
          if (room.curr && room.curr.split) {
            conn.reply(m.chat, `Waktu habis!\n@${room.curr.split('@')[0]} tereliminasi`, room.chat, {
              contextInfo: { mentionedJid: member }
            }).then(() => {
              // FIX: HAPUS SESSION SETELAH TIMEOUT
              room.eliminated.push(room.curr)
              let index = member.indexOf(room.curr)
              member.splice(index, 1)
              
              if (member.length <= 1) {
                delete conn.skata[id]
              }
            })
          }
        }, 60000)
      }
      return
    }
    
    // FIX: TANPA REPLY - Handle answer tanpa perlu mereply pesan
    if (isPlayerTurn) {
      let answer = m.text.toLowerCase().trim().replace(/[^a-z]/gi, '')
      
      // Skip jika bukan kata (terlalu pendek atau command)
      if (answer.length < 2 || answer.startsWith('!') || answer.startsWith('/') || answer.startsWith('.')) {
        return
      }
      
      // FIX: Gunakan filter yang sama seperti di soal
      let requiredStart = filter(room.kata).toLowerCase()
      
      // Validate answer
      if (!answer.startsWith(requiredStart)) {
        return m.reply(`Jawaban harus dimulai dari "${requiredStart.toUpperCase()}"`)
      }
      
      if (answer === room.kata.toLowerCase()) {
        return m.reply('Jawaban tidak boleh sama dengan soal!')
      }
      
      if (room.basi.includes(answer)) {
        return m.reply('Kata ini sudah digunakan!')
      }
      
      // Check if word exists in KBBI
      let checkResult = await cKata(answer)
      if (!checkResult.status) {
        return m.reply(`Kata "${answer.toUpperCase()}" tidak ditemukan di KBBI!`)
      }
      
      // Valid answer - process
      clearTimeout(room.waktu)
      room.basi.push(answer)
      room.win_point += 500
      
      let bonus = Math.floor(Math.random() * 1000) + 500
      // FIX: Pastikan user data ada sebelum akses
      if (!global.db.users[m.sender]) global.db.users[m.sender] = {}
      global.db.users[m.sender].exp += bonus
      
      // Move to next player
      let currentIndex = member.indexOf(m.sender)
      let nextIndex = (currentIndex + 1) % member.length
      room.curr = member[nextIndex]
      
      // FIX: Update kata untuk putaran berikutnya
      room.kata = answer
      let nextRequiredStart = filter(answer)
      
      let successMsg = `*SAMBUNG KATA*\n\nBenar. 👍\n*Dari* : @${m.sender.split('@')[0]} +${formatNumber(bonus)} EXP\n\n*Sekarang* : @${room.curr.split('@')[0]}\n*Mulai* : ${answer.toUpperCase()}\n\n*${nextRequiredStart.toUpperCase()}... ?*\n\n*Total* : ${formatNumber(room.win_point)} EXP\n\nBalas soal ini untuk menjawab!`
      
      room.chat = await conn.reply(m.chat, successMsg, room.chat, {
        contextInfo: { mentionedJid: member }
      })
      
      // Reset timeout for next player dengan AUTO DELETE
      room.waktu = setTimeout(() => {
        // FIX: Pastikan room.curr masih ada sebelum split
        if (room.curr && room.curr.split) {
          conn.reply(m.chat, `Waktu habis!\n@${room.curr.split('@')[0]} tereliminasi`, room.chat, {
            contextInfo: { mentionedJid: member }
          }).then(() => {
            // FIX: HAPUS SESSION SETELAH TIMEOUT
            room.eliminated.push(room.curr)
            let index = member.indexOf(room.curr)
            member.splice(index, 1)
            
            if (member.length <= 1) {
              delete conn.skata[id]
            }
          })
        }
      }, 60000)
      
    } else if (isInGame && !isPlayerTurn) {
      // FIX: Hanya beri peringatan jika bukan gilirannya
      m.reply('Tunggu giliranmu!')
    }
    // Tidak perlu handle eliminated/not in game karena sudah di-filter di atas
  }
}

// Helper functions (PASTIKAN SAMA dengan skata.js)
async function genKata() {
  let json = await sKata()
  let result = json.kata
  while (result.length < 3 || result.length > 10) {
    json = await sKata()
    result = json.kata
  }
  return result
}

// FIX: FUNGSI FILTER YANG SAMA PERSIS
function filter(text) {
  if (!text || text.length < 2) return text
  
  // Ambil 2-3 karakter terakhir berdasarkan panjang kata
  if (text.length <= 3) {
    return text.slice(-2) // Untuk kata pendek, ambil 2 karakter
  } else if (text.length <= 5) {
    return text.slice(-2) // Untuk kata sedang, ambil 2 karakter
  } else {
    return text.slice(-3) // Untuk kata panjang, ambil 3 karakter
  }
}



/**
const { sKata, cKata } = require('../../../lib/sambung-kata.js')

module.exports = {
  run: async (m, { conn, users, Func }) => {
    let id = m.chat
    if (!conn.skata || !(id in conn.skata)) return
    
    let room = conn.skata[id]
    if (room.status !== 'play') return
    
    let member = room.player
    let isPlayerTurn = room.curr === m.sender
    let isEliminated = room.eliminated.includes(m.sender)
    let isInGame = member.includes(m.sender)
    
    // Check if message is a reply to game question
    if (!m.quoted || !m.quoted.fromMe || m.quoted.id !== room.chat?.id) return
    
    // Handle surrender
    if (m.text.toLowerCase() === 'nyerah') {
      if (!isPlayerTurn) return m.reply('Bukan giliranmu!')
      
      clearTimeout(room.waktu)
      
      await conn.reply(m.chat, `@${m.sender.split('@')[0]} telah menyerah! 🏳️`, room.chat, {
        contextInfo: { mentionedJid: member }
      })
      
      room.eliminated.push(m.sender)
      let index = member.indexOf(m.sender)
      member.splice(index, 1)
      
      if (member.length === 1) {
        // Game over
        let winner = member[0]
        global.db.users[winner].exp += room.win_point
        await conn.reply(m.chat, `*@${winner.split('@')[0]} Yeay, Menang. 🎉*\n\n- +${room.win_point} EXP`, room.chat, {
          contextInfo: { mentionedJid: member }
        })
        delete conn.skata[id]
      } else {
        // Continue game
        room.curr = member[0]
        room.kata = await genKata()
        
        let requiredStart = filter(room.kata)
        let nextQuestion = `*SAMBUNG KATA*\n\n*Sekarang* : @${room.curr.split('@')[0]}\n*Mulai* : ${room.kata.toUpperCase()}\n\n*${requiredStart.toUpperCase()}... ?*\n\nBalas pesan ini untuk menjawab!`
        
        room.chat = await conn.reply(m.chat, nextQuestion, room.chat, {
          contextInfo: { mentionedJid: member }
        })
        
        // Reset timeout
        clearTimeout(room.waktu)
        room.waktu = setTimeout(() => {
          // Timeout handler
          conn.reply(m.chat, `Waktu habis!\n@${room.curr.split('@')[0]} tereliminasi`, room.chat, {
            contextInfo: { mentionedJid: member }
          })
        }, 60000)
      }
      return
    }
    
    // Handle answer
    if (isPlayerTurn) {
      let answer = m.text.toLowerCase().trim().replace(/[^a-z]/gi, '')
      
      // FIX: Gunakan filter yang sama seperti di soal
      let requiredStart = filter(room.kata).toLowerCase()
      
      console.log(`DEBUG: Kata = ${room.kata}, Filter = ${requiredStart}, Answer = ${answer}`) // Untuk debugging
      
      // Validate answer
      if (!answer.startsWith(requiredStart)) {
        return m.reply(`Jawaban harus dimulai dari "${requiredStart.toUpperCase()}"`)
      }
      
      if (answer === room.kata.toLowerCase()) {
        return m.reply('Jawaban tidak boleh sama dengan soal!')
      }
      
      if (room.basi.includes(answer)) {
        return m.reply('Kata ini sudah digunakan!')
      }
      
      // Check if word exists in KBBI
      let checkResult = await cKata(answer)
      if (!checkResult.status) {
        return m.reply(`Kata "${answer.toUpperCase()}" tidak ditemukan di KBBI!`)
      }
      
      // Valid answer - process
      clearTimeout(room.waktu)
      room.basi.push(answer)
      room.win_point += 500
      
      let bonus = Math.floor(Math.random() * 1000) + 500
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].exp += bonus
      }
      
      // Move to next player
      let currentIndex = member.indexOf(m.sender)
      let nextIndex = (currentIndex + 1) % member.length
      room.curr = member[nextIndex]
      
      // FIX: Update kata untuk putaran berikutnya
      room.kata = answer
      let nextRequiredStart = filter(answer)
      
      let successMsg = `*SAMBUNG KATA*\n\nBenar. 👍\n*Dari* : @${m.sender.split('@')[0]} +${bonus} EXP\n\n*Sekarang* : @${room.curr.split('@')[0]}\n*Mulai* : ${answer.toUpperCase()}\n\n*${nextRequiredStart.toUpperCase()}... ?*\n\n*Total* : ${room.win_point} EXP\n\nBalas soal ini untuk menjawab!`
      
      room.chat = await conn.reply(m.chat, successMsg, room.chat, {
        contextInfo: { mentionedJid: member }
      })
      
      // Reset timeout for next player
      room.waktu = setTimeout(() => {
        conn.reply(m.chat, `Waktu habis!\n@${room.curr.split('@')[0]} tereliminasi`, room.chat, {
          contextInfo: { mentionedJid: member }
        })
      }, 60000)
      
    } else if (isInGame && !isPlayerTurn) {
      m.reply('Tunggu giliranmu!')
    } else if (isEliminated) {
      m.reply('Kamu sudah tereliminasi!')
    } else {
      m.reply('Kamu tidak berada dalam game ini!')
    }
  }
}

// Helper functions (PASTIKAN SAMA dengan skata.js)
async function genKata() {
  let json = await sKata()
  let result = json.kata
  while (result.length < 3 || result.length > 10) {
    json = await sKata()
    result = json.kata
  }
  return result
}

// FIX: FUNGSI FILTER YANG SAMA PERSIS
function filter(text) {
  if (!text || text.length < 2) return text
  
  // Ambil 2-3 karakter terakhir berdasarkan panjang kata
  if (text.length <= 3) {
    return text.slice(-2) // Untuk kata pendek, ambil 2 karakter
  } else if (text.length <= 5) {
    return text.slice(-2) // Untuk kata sedang, ambil 2 karakter
  } else {
    return text.slice(-3) // Untuk kata panjang, ambil 3 karakter
  }
}
*/