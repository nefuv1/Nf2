const formatNumber = require('../../../lib/formatNumber')

module.exports = {
  run: async (m, { conn, users }) => {
    let id = m.sender
    
    // Cek apakah user memiliki sesi tebak nomor
    if (!conn.tebaknomor || !(id in conn.tebaknomor)) return
    
    let game = conn.tebaknomor[id]
    let userGuess = m.text.trim()
    
    // Handle perintah stop
    if (userGuess.toLowerCase() === 'stop') {
      clearTimeout(game.timeout) // Hapus timeout
      delete conn.tebaknomor[id] // Hapus session
      return conn.reply(m.chat, 'Game tebak nomor dihentikan!', m)
    }
    
    // Validasi input harus angka
    let guess = parseInt(userGuess)
    if (isNaN(guess) || guess < 1 || guess > 10) {
      return conn.reply(m.chat, 'Silakan kirim angka antara 1-10 saja!', m)
    }
    
    // Kurangi kesempatan
    game.attempts--
    
    // Hitung waktu tersisa realtime
    const elapsed = (Date.now() - game.startTime) / 1000
    const remaining = Math.max(0, 60 - elapsed).toFixed(2)
    
    // Cek apakah tebakan benar
    if (guess === game.hiddenNumber) {
      // Menang
      clearTimeout(game.timeout) // Hapus timeout
      
      let reward = 9999
      if (users && users[id]) {
        users[id].exp += reward
      }
      
      let winText = `*Yeay, Benar. 👍*\n\n`
      winText += `- +${formatNumber(reward)} EXP`
      
      await conn.reply(m.chat, winText, m)
      delete conn.tebaknomor[id] // Hapus session
      
    } else if (game.attempts <= 0) {
      // Habis kesempatan - kalah
      clearTimeout(game.timeout) // Hapus timeout
      
      let loseText = `Kesempatan habis!\n`
      loseText += `Jawabannya adalah : *${game.hiddenNumber}*`
      
      await conn.reply(m.chat, loseText, m)
      delete conn.tebaknomor[id] // Hapus session
      
    } else {
      // Tebakan salah, masih ada kesempatan
      let hint = guess < game.hiddenNumber ? 'terlalu Rendah!' : 'terlalu Tinggi!'
      
      let continueText = `*Timeout* : ${remaining} detik\n`      
      continueText += `*Kesempatan* : ${game.attempts}x\n\n`
      continueText += `Anda menebak *${guess}* ${hint}`      
      
      await conn.reply(m.chat, continueText, m)
    }
  }
}