const similarity = require('similarity')
const threshold = 0.72

module.exports = {
  run: async (m, { conn, users, Func }) => {
    let id = m.chat
    conn.tebakkimia = conn.tebakkimia ? conn.tebakkimia : {}
    
    // Cek jika ini adalah jawaban untuk game tebakkimia
    if (m.quoted && /TEBAK KIMIA/i.test(m.quoted.text)) {
      if (!(id in conn.tebakkimia) && /Game ID.*GAME-007/i.test(m.quoted.text)) return conn.reply(m.chat, 'Soal itu telah berakhir.', m)
      
      if (m.quoted.id == conn.tebakkimia[id][0].id) {
        let json = JSON.parse(JSON.stringify(conn.tebakkimia[id][1]))
        const deleteAfterAnswer = conn.tebakkimia[id][4] // Get delete option
        
        // CEK JIKA USER MENYERAH
        const surrenderWords = ['nyerah', 'menyerah', 'give up'];
        if (surrenderWords.includes(m.text.toLowerCase())) {
          if (deleteAfterAnswer) {
            await conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.tebakkimia[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
            
            setTimeout(() => {
              conn.sendMessage(m.chat, { 
                delete: { 
                  remoteJid: m.chat, 
                  id: m.id, 
                  fromMe: false 
                } 
              }).catch(() => {})
            }, 2000)
          }
          
          conn.reply(m.chat, `Kamu menyerah!\nJawabannya adalah : *${json.unsur}*`, conn.tebakkimia[id][0])
          clearTimeout(conn.tebakkimia[id][3])
          delete conn.tebakkimia[id]
          return
        }
                
        if (m.text.toLowerCase() == json.unsur.toLowerCase().trim()) {
          // Berikan reward
          users.exp += conn.tebakkimia[id][2]
          
          if (deleteAfterAnswer) {
            // Delete question message
            await conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.tebakkimia[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
            
            // Delete answer message after delay
            setTimeout(() => {
              conn.sendMessage(m.chat, { 
                delete: { 
                  remoteJid: m.chat, 
                  id: m.id, 
                  fromMe: false 
                } 
              }).catch(() => {})
            }, 2000)
          }
          
          m.reply(`*Yeay, Benar. 👍*\n\n- +3.999 EXP`)
          clearTimeout(conn.tebakkimia[id][3])
          delete conn.tebakkimia[id]
          
        } else if (similarity(m.text.toLowerCase(), json.unsur.toLowerCase().trim()) >= threshold) {
          m.reply(`Sedikit lagi! 👎`)
        } else {
          m.reply(`Salah! 👎`)
        }
      }
    }
  },
  error: false
}