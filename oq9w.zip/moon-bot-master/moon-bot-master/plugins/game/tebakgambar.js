let fetch = require('node-fetch')

module.exports = {
  help: ['tebakgambar'],
  aliases: ['tbkgambar'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true // Set to false to disable auto-delete
    
    let timeout = 60000
    let poin = 3999
    
    conn.tebakgambar = conn.tebakgambar ? conn.tebakgambar : {}
    let id = m.chat
    if (id in conn.tebakgambar) {
      conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.tebakgambar[id][0])
      throw false
    }
    
    let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json')).json()
    let json = src[Math.floor(Math.random() * src.length)]
    
    let caption = `*TEBAK GAMBAR*
  
${json.deskripsi}

*Timeout* : ${(timeout / 1000).toFixed(2)} detik
*Game ID* : GAME-013
Untuk bantuan kirim perintah : ${usedPrefix}hgambar

*Bonus* : 
- 3.999 EXP

Balas soal ini untuk menjawab!
    `.trim()
    
    let sentMsg = await conn.sendMessage(m.chat, { 
      image: { url: json.img }, 
      caption: caption 
    }, { quoted: m })
    
    conn.tebakgambar[id] = [
      sentMsg,
      json,
      poin,
      setTimeout(() => {
        if (conn.tebakgambar[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.tebakgambar[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.jawaban}*`, conn.tebakgambar[id][0])
          delete conn.tebakgambar[id]
        }
      }, timeout),
      deleteAfterAnswer // Store delete option
    ]
  }
}