const fs = require('fs');
const path = require('path');

module.exports = {
  help: ['tebaklogo'],
  aliases: ['tbklogo'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true // Set to false to disable auto-delete
    
    let timeout = 60000
    let poin = 3999
    
    conn.game = conn.game ? conn.game : {}
    let id = 'tebaklogo-' + m.chat
    if (id in conn.game) return conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.game[id][0])
    
    let src = JSON.parse(fs.readFileSync(path.join(__dirname, '../../json/tebaklogo.json'), 'utf-8'));    
    let json = src[Math.floor(Math.random() * src.length)]    
    
    let caption = `*TEBAK LOGO*
    
${json.deskripsi}

*Timeout* : ${(timeout / 1000).toFixed(2)} detik
*Game ID* : GAME-004
Untuk bantuan kirim perintah : ${usedPrefix}hlogo

*Bonus* : 
- 3.999 EXP

Balas soal ini untuk menjawab!
`.trim()
    
    let sentMsg = await conn.sendFile(m.chat, json.img, 'tebaklogo.jpg', caption, m)
    conn.game[id] = [
        sentMsg,
        json,
        poin,
        setTimeout(() => {
            if (conn.game[id]) {
                if (deleteAfterAnswer) {
                    conn.sendMessage(m.chat, { 
                        delete: { 
                            remoteJid: m.chat, 
                            id: conn.game[id][0].id, 
                            fromMe: true 
                        } 
                    }).catch(() => {})
                }
                conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.jawaban}*`, conn.game[id][0])
                delete conn.game[id]
            }
        }, timeout),
        deleteAfterAnswer // Store delete option
    ]
  }
}