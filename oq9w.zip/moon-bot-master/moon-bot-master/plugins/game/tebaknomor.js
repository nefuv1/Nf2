module.exports = {
  help: ['tebaknomor'],
  aliases: ['tbknomor'],
  tags: 'game',
  game: true,
  register: true,
  onlyprem: true,
  run: async (m, { conn, command, usedPrefix }) => {
    conn.tebaknomor = conn.tebaknomor ? conn.tebaknomor : {}
    let id = m.sender
    
    // Jika sudah ada sesi yang berjalan
    if (id in conn.tebaknomor) {
      return conn.reply(m.chat, 'Masih ada sesi yang belum selesai di chat ini!', m)
    }
    
    // Generate angka acak dari 1-10
    const hiddenNumber = Math.floor(Math.random() * 10) + 1
    let attempts = 3
    let timeLeft = 60.00 // 60 detik
    
    // Fungsi untuk update timeout realtime
    const updateTimeoutDisplay = () => {
      timeLeft -= 0.01
      if (timeLeft <= 0) {
        timeLeft = 0.00
      }
      return timeLeft.toFixed(2)
    }
    
    conn.tebaknomor[id] = {
      hiddenNumber: hiddenNumber,
      attempts: attempts,
      chatId: m.chat,
      startTime: Date.now(),
      timeLeft: timeLeft,
      updateTimeoutDisplay: updateTimeoutDisplay,
      timeout: setTimeout(() => {
        if (conn.tebaknomor[id]) {
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${conn.tebaknomor[id].hiddenNumber}*`, m)
//          delete conn.tebaknomor[id]
        }
      }, 60000) // 1 menit timeout
    }
    
    let teks = `*TEBAK NOMOR*\n\n`
    teks += `*Timeout* : ${timeLeft.toFixed(2)} detik\n`
    teks += `*Kesempatan* : ${attempts}x\n`    
    teks += `Untuk berhenti kirim perintah : ${usedPrefix}stop\n\n`
    teks += `Saya telah menyembunyikan 1 nomor dari 1 sampai 10.\n`
    teks += `Anda cukup menembak nya, nomor berapakah yang saya sembunyikan?`    
    
    await conn.reply(m.chat, teks, m)
  }
}