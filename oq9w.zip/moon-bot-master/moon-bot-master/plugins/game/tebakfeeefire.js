let fetch = require('node-fetch')

module.exports = {
  help: ['tebakfreefire'],
  aliases: ['tbkfreefire', 'tebakff'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true // Set to false to disable auto-delete
    
    let timeout = 60000
    let poin = 3999
    
    conn.tebakfreefire = conn.tebakfreefire ? conn.tebakfreefire : {}
    let id = m.chat
    if (id in conn.tebakfreefire) {
      conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.tebakfreefire[id][0])
      throw false
    }
    
    let src = require('../../json/tebakfreefire.json')
    let json = src[Math.floor(Math.random() * src.length)]
    
    let caption = `*TEBAK CHARACTER FREE FIRE*

Siapakah nama character Free Fire di atas?

*Timeout* : ${(timeout / 1000).toFixed(2)} detik
*Game ID* : GAME-024
Untuk bantuan kirim perintah : ${usedPrefix}hff

*Bonus* : 
- 3.999 EXP

Balas soal ini untuk menjawab!
    `.trim()
    
    let sentMsg = await conn.sendMessage(m.chat, { 
      image: { url: json.gambar },
      caption: caption
    }, { quoted: m })
    
    conn.tebakfreefire[id] = [
      sentMsg,
      json,
      poin,
      setTimeout(() => {
        if (conn.tebakfreefire[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.tebakfreefire[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.name}*`, conn.tebakfreefire[id][0])
          delete conn.tebakfreefire[id]
        }
      }, timeout),
      deleteAfterAnswer // Store delete option
    ]
  }
}