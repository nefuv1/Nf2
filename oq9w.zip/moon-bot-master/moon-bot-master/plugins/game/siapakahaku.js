let fetch = require('node-fetch')

module.exports = {
  help: ['siapakahaku'],
  aliases: ['spkhaku'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true // Set to false to disable auto-delete
    
    let timeout = 60000
    let poin = 3999
    let limit = 1
    
    conn.siapakahaku = conn.siapakahaku ? conn.siapakahaku : {}
    let id = m.chat
    if (id in conn.siapakahaku) {
      conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.siapakahaku[id][0])
      throw false
    }
    
    let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/siapakahaku.json')).json()
    let json = src[Math.floor(Math.random() * src.length)]
    
    let caption = `*SIAPAKAH AKU*
              
Siapakah aku? ${json.soal}          
      
*Timeout* : ${(timeout / 1000).toFixed(2)} detik          
*Game ID* : GAME-016
Untuk bantuan kirim perintah : ${usedPrefix}haku
  
*Bonus* :           
- 3.999 EXP          
- ${limit} Limit          

Balas soal ini untuk menjawab!          
    `.trim()
    
    let sentMsg = await conn.reply(m.chat, caption, m)
    conn.siapakahaku[id] = [
      sentMsg,
      json,
      poin,
      setTimeout(() => {
        if (conn.siapakahaku[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.siapakahaku[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.jawaban}*`, conn.siapakahaku[id][0])
          delete conn.siapakahaku[id]
        }
      }, timeout),
      deleteAfterAnswer // Store delete option
    ]
  }
}