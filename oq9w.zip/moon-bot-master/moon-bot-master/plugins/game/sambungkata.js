// versi otomatis mendeteksi jawaban tanpa reply
const { sKata, cKata } = require('../../lib/sambung-kata.js')
const formatNumber = require('../../lib/formatNumber')

const game = `*SAMBUNG KATA*

Game Kata Bersambung adalah
permainan yang dimana setiap
pemainnya diharuskan membuat
kata dari akhir kata yang
berasal dari kata sebelumnya.`.trim()

const rules = `*PERATURAN*

1. Jawaban merupakan kata dasar
yaitu tidak mengandung 
spasi dan imbuhan (me-, -an, dll).

2. Pemain yang bertahan akan
mendapatkan hadiah EXP

*Contoh* :
1. !skata join - (Untuk bergabung)
2. !skata start - (Untuk memulai/bermain sendiri)`.trim()

module.exports = {
  help: ['sambungkata'],
  aliases: ['skata'],
  tags: 'game',
  group: true,
  game: true,
  register: true,
  run: async (m, { conn, text, usedPrefix, command }) => {
    conn.skata = conn.skata ? conn.skata : {}
    let id = m.chat
    
    // FIX: CEK DAN HAPUS SESSION YANG SUDAH SELESAI
    if (conn.skata[id] && conn.skata[id].status === 'play') {
      // Cek apakah game masih berjalan dengan pemain yang valid
      let room = conn.skata[id]
      if (room.player.length === 0 || (room.player.length === 1 && room.eliminated.includes(room.player[0]))) {
        // Game sudah selesai tapi session belum dihapus
        delete conn.skata[id]
      }
    }
    
    // Initialize game room
    if (!(id in conn.skata)) {
      conn.skata[id] = {
        id,
        player: [],
        status: 'wait',
        eliminated: [],
        basi: [],
        diam: false,
        win_point: 0,
        curr: '',
        kata: '',
        chat: null,
        waktu: null,
        waktu_list: null
      }
    }
    
    let room = conn.skata[id]
    let member = room.player
    
    // Handle join
    if (text === 'join') {
      if (room.status !== 'wait') return m.reply('Masih ada sesi game yang belum selesai di chat ini!')
      if (member.includes(m.sender)) return m.reply('Kamu sudah bergabung!')
      
      member.push(m.sender)
      clearTimeout(room.waktu_list)
      
      room.waktu_list = setTimeout(() => {
        conn.reply(m.chat, 'Waktu pendaftaran habis! Game dibatalkan.', room.chat)
        delete conn.skata[id]
      }, 120000)
      
      let playerList = member.map((v, i) => `${i + 1}. @${v.split('@')[0]}`).join('\n')
      let caption = `*SAMBUNG KATA*\n\n*Pemain* :\n${playerList}\n\n*Kirim* :\n1. ${usedPrefix + command} join - (Untuk bergabung)\n2. ${usedPrefix + command} start - (Untuk memulai/bermain sendiri)`
      
      room.chat = await conn.reply(m.chat, caption, m, { 
        mentions: conn.parseMention(caption) 
      })
      return
    }
    
    // Handle start
    if (text === 'start') {
      if (room.status !== 'wait') return m.reply('Game sudah berjalan!')
      
      // FIX: BISA MAIN SENDIRI - Auto join jika belum join
      if (!member.includes(m.sender)) {
        member.push(m.sender)
      }
      
      // FIX: BISA MAIN SENDIRI - Minimal 1 pemain saja
      if (member.length < 1) return m.reply('Minimal 1 pemain!')
      
      // Generate first word
      room.kata = await genKata()
      room.status = 'play'
      room.curr = member[0]
      room.win_point = 1000
      
      // Initialize player data
      for (let playerId of member) {
        if (!global.db.users[playerId]) global.db.users[playerId] = {}
        if (!global.db.users[playerId].skata) global.db.users[playerId].skata = 0
      }
      
      clearTimeout(room.waktu_list)
      
      let requiredStart = filter(room.kata)
      let question = `*SAMBUNG KATA*\n\n*Sekarang* : @${room.curr.split('@')[0]}\n*Mulai* : ${room.kata.toUpperCase()}\n*Total* : ${member.length} pemain\n\n*${requiredStart.toUpperCase()}... ?*\n\n- nyerah - (Untuk menyerah)\n\nBalas soal ini untuk menjawab!`
      
      room.chat = await conn.reply(m.chat, question, m, { 
        contextInfo: { mentionedJid: member } 
      })
      
      // Set timeout for answer
      room.waktu = setTimeout(async () => {
        if (room.status !== 'play') return
        
        let eliminatedMsg = `Waktu habis!\n@${room.curr.split('@')[0]} tereliminasi`
        await conn.reply(m.chat, eliminatedMsg, room.chat, { 
          contextInfo: { mentionedJid: member } 
        })
        
        room.eliminated.push(room.curr)
        let index = member.indexOf(room.curr)
        member.splice(index, 1)
        
        if (member.length === 1) {
          // Game over - winner
          let winner = member[0]
          global.db.users[winner].exp += room.win_point
          await conn.reply(m.chat, `*@${winner.split('@')[0]} Yeay, Menang. 🎉*\n\n- +${formatNumber(room.win_point)} EXP`, room.chat, {
            contextInfo: { mentionedJid: member }
          })
          delete conn.skata[id]
        } else if (member.length === 0) {
          // FIX: SEMUA PEMAIN TERELIMINASI - HAPUS SESSION
          // await conn.reply(m.chat, `*Game berakhir!* 🎮\n\nSemua pemain telah tereliminasi.`, room.chat)
          delete conn.skata[id]
        } else {
          // Continue game
          room.curr = member[0]
          room.kata = await genKata()
          room.diam = false
          
          let requiredStart = filter(room.kata)
          let nextQuestion = `*SAMBUNG KATA*\n\n*Sekarang* : @${room.curr.split('@')[0]}\n*Mulai* : ${room.kata.toUpperCase()}\n\n*${requiredStart.toUpperCase()}... ?*\n\nBalas soal ini untuk menjawab!`
          
          room.chat = await conn.reply(m.chat, nextQuestion, room.chat, {
            contextInfo: { mentionedJid: member }
          })
          
          // Reset timeout for next player
          clearTimeout(room.waktu)
          room.waktu = setTimeout(() => {
            // Handle timeout for next player
            conn.reply(m.chat, `Waktu habis! @${room.curr.split('@')[0]} tereliminasi`, room.chat, {
              contextInfo: { mentionedJid: member }
            })
          }, 60000)
        }
      }, 60000) // 60 seconds timeout
      
      return
    }
    
    // Show help if no valid command
    if (!text || (text !== 'join' && text !== 'start')) {
      return m.reply(`${game}\n\n${rules}`)
    }
  }
}

// Helper functions
async function genKata() {
  let json = await sKata()
  let result = json.kata
  // Ensure word length is appropriate
  while (result.length < 3 || result.length > 10) {
    json = await sKata()
    result = json.kata
  }
  return result
}

// FIX: FUNGSI FILTER YANG BENAR
function filter(text) {
  if (!text || text.length < 2) return text
  
  // Ambil 2-3 karakter terakhir berdasarkan panjang kata
  if (text.length <= 3) {
    return text.slice(-2) // Untuk kata pendek, ambil 2 karakter
  } else if (text.length <= 5) {
    return text.slice(-2) // Untuk kata sedang, ambil 2 karakter
  } else {
    return text.slice(-3) // Untuk kata panjang, ambil 3 karakter
  }
}



/**
const { sKata, cKata } = require('../../lib/sambung-kata.js')

const game = `*SAMBUNG KATA*

Game Kata Bersambung adalah
permainan yang dimana setiap
pemainnya diharuskan membuat
kata dari akhir kata yang
berasal dari kata sebelumnya.`.trim()

const rules = `*PERATURAN*

1. Jawaban merupakan kata dasar
yaitu tidak mengandung 
spasi dan imbuhan (me-, -an, dll).

2. Pemain yang bertahan akan
mendapatkan hadiah
500 EXP x jumlah pemain.

*Contoh* :
1. !skata join - (Untuk bergabung)
2. !skata start - (Untuk memulai permainan)`.trim()

module.exports = {
  help: ['sambungkata'],
  aliases: ['skata'],
  tags: 'game',
  group: true,
  game: true,
  register: true,
  run: async (m, { conn, text, usedPrefix, command }) => {
    conn.skata = conn.skata ? conn.skata : {}
    let id = m.chat
    
    // Initialize game room
    if (!(id in conn.skata)) {
      conn.skata[id] = {
        id,
        player: [],
        status: 'wait',
        eliminated: [],
        basi: [],
        diam: false,
        win_point: 0,
        curr: '',
        kata: '',
        chat: null,
        waktu: null,
        waktu_list: null
      }
    }
    
    let room = conn.skata[id]
    let member = room.player
    
    // Handle join
    if (text === 'join') {
      if (room.status !== 'wait') return m.reply('Game sudah dimulai, tunggu game berikutnya!')
      if (member.includes(m.sender)) return m.reply('Kamu sudah bergabung!')
      
      member.push(m.sender)
      clearTimeout(room.waktu_list)
      
      room.waktu_list = setTimeout(() => {
        conn.reply(m.chat, 'Waktu pendaftaran habis! Game dibatalkan.', room.chat)
        delete conn.skata[id]
      }, 120000)
      
      let playerList = member.map((v, i) => `${i + 1}. @${v.split('@')[0]}`).join('\n')
      let caption = `*SAMBUNG KATA*\n\n*Pemain* :\n${playerList}\n\n*Kirim* :\n1. ${usedPrefix + command} join - (Untuk bergabung)\n2. ${usedPrefix + command} start - (Untuk memulai)`
      
      room.chat = await conn.reply(m.chat, caption, m, { 
        mentions: conn.parseMention(caption) 
      })
      return
    }
    
    // Handle start
    if (text === 'start') {
      if (room.status !== 'wait') return m.reply('Game sudah berjalan!')
      if (!member.includes(m.sender)) return m.reply('Kamu belum bergabung!')
      if (member.length < 2) return m.reply('Minimal 2 pemain!')
      
      // Generate first word
      room.kata = await genKata()
      room.status = 'play'
      room.curr = member[0]
      room.win_point = 1000
      
      // Initialize player data
      for (let playerId of member) {
        if (!global.db.users[playerId]) global.db.users[playerId] = {}
        if (!global.db.users[playerId].skata) global.db.users[playerId].skata = 0
      }
      
      clearTimeout(room.waktu_list)
      
      let requiredStart = filter(room.kata)
      let question = `*SAMBUNG KATA*\n\n*Sekarang* : @${room.curr.split('@')[0]}\n*Mulai* : ${room.kata.toUpperCase()}\n*Total* : ${member.length} pemain\n\n*${requiredStart.toUpperCase()}... ?*\n\n- nyerah - (Untuk menyerah)\n\nBalas soal ini untuk menjawab!`
      
      room.chat = await conn.reply(m.chat, question, m, { 
        contextInfo: { mentionedJid: member } 
      })
      
      // Set timeout for answer
      room.waktu = setTimeout(async () => {
        if (room.status !== 'play') return
        
        let eliminatedMsg = `Waktu habis!\n@${room.curr.split('@')[0]} tereliminasi`
        await conn.reply(m.chat, eliminatedMsg, room.chat, { 
          contextInfo: { mentionedJid: member } 
        })
        
        room.eliminated.push(room.curr)
        let index = member.indexOf(room.curr)
        member.splice(index, 1)
        
        if (member.length === 1) {
          // Game over - winner
          let winner = member[0]
          global.db.users[winner].exp += room.win_point
          await conn.reply(m.chat, `*@${winner.split('@')[0]} Yeay, Menang. 🎉*\n\n- +${room.win_point} EXP`, room.chat, {
            contextInfo: { mentionedJid: member }
          })
          delete conn.skata[id]
        } else {
          // Continue game
          room.curr = member[0]
          room.kata = await genKata()
          room.diam = false
          
          let requiredStart = filter(room.kata)
          let nextQuestion = `*SAMBUNG KATA*\n\n*Sekarang* : @${room.curr.split('@')[0]}\n*Mulai* : ${room.kata.toUpperCase()}\n\n*${requiredStart.toUpperCase()}... ?*\n\nBalas soal ini untuk menjawab!`
          
          room.chat = await conn.reply(m.chat, nextQuestion, room.chat, {
            contextInfo: { mentionedJid: member }
          })
          
          // Reset timeout for next player
          clearTimeout(room.waktu)
          room.waktu = setTimeout(() => {
            // Handle timeout for next player
            conn.reply(m.chat, `Waktu habis! @${room.curr.split('@')[0]} tereliminasi`, room.chat, {
              contextInfo: { mentionedJid: member }
            })
          }, 60000)
        }
      }, 60000) // 60 seconds timeout
      
      return
    }
    
    // Show help if no valid command
    if (!text || (text !== 'join' && text !== 'start')) {
      return m.reply(`${game}\n\n${rules}`)
    }
  }
}

// Helper functions
async function genKata() {
  let json = await sKata()
  let result = json.kata
  // Ensure word length is appropriate
  while (result.length < 3 || result.length > 10) {
    json = await sKata()
    result = json.kata
  }
  return result
}

// FIX: FUNGSI FILTER YANG BENAR
function filter(text) {
  if (!text || text.length < 2) return text
  
  // Ambil 2-3 karakter terakhir berdasarkan panjang kata
  if (text.length <= 3) {
    return text.slice(-2) // Untuk kata pendek, ambil 2 karakter
  } else if (text.length <= 5) {
    return text.slice(-2) // Untuk kata sedang, ambil 2 karakter
  } else {
    return text.slice(-3) // Untuk kata panjang, ambil 3 karakter
  }
}
*/