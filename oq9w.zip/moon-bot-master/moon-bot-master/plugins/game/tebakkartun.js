const fetch = require('node-fetch');
const Jimp = require('jimp');
const fs = require('fs');
const path = require('path');

module.exports = {
  help: ['tebakkartun'],
  aliases: ['tbkkartun'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true; // Set to false to disable auto-delete
    
    let timeout = 60000;
    let poin = 3999;
    let blurLevel = 5;
    
    conn.tebakkartun = conn.tebakkartun || {};
    let id = m.chat;

    if (id in conn.tebakkartun) {
      conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.tebakkartun[id][0]);
      throw false;
    }

    let res = await fetch('https://api.siputzx.my.id/api/games/tebakkartun');
    if (!res.ok) throw 'Gagal mengambil data dari API.';
    let json = await res.json();
    if (!json.status || !json.data) throw 'Data tidak ditemukan dari API.';

    let { name, img } = json.data;

    // Simpan ke json/tebakkartun.json
    const filePath = path.join(__dirname, '../../json/tebakkartun.json');
    let existing = [];
    try {
      if (fs.existsSync(filePath)) {
        existing = JSON.parse(fs.readFileSync(filePath));
      }
    } catch (e) {
      existing = [];
    }

    const isAlreadyExist = existing.some(item => item.name === name && item.img === img);
    if (!isAlreadyExist) {
      existing.push({ name, img });
      fs.writeFileSync(filePath, JSON.stringify(existing, null, 2));
    }

    // Blur gambar
    let imgBuffer = await (await fetch(img)).buffer();
    let jimpImg = await Jimp.read(imgBuffer);
    jimpImg.blur(blurLevel);
    let blurredBuffer = await jimpImg.getBufferAsync(Jimp.MIME_JPEG);

    let caption = `*TEBAK KARTUN*

Apa nama tokoh / judul kartun pada gambar di atas ?

*Timeout* : ${(timeout / 1000).toFixed(2)} detik
*Game ID* : GAME-009
Untuk bantuan kirim perintah : ${usedPrefix}hkartun 

*Bonus* :
- 3.999 EXP

Balas soal ini untuk menjawab!`.trim();

    let sentMsg = await conn.sendFile(m.chat, blurredBuffer, 'kartun.jpg', caption, m);
    conn.tebakkartun[id] = [
      sentMsg,
      { jawaban: name },
      poin,
      setTimeout(() => {
        if (conn.tebakkartun[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.tebakkartun[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {});
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${name}*`, conn.tebakkartun[id][0]);
          delete conn.tebakkartun[id];
        }
      }, timeout),
      deleteAfterAnswer // Store delete option
    ];
  }
}