const {
    emoji_role,
    sesi,
    playerOnGame,
    playerOnRoom,
    playerExit,
    dataPlayer,
    dataPlayerById,
    getPlayerById,
    getPlayerById2,
    killWerewolf,
    killww,
    dreamySeer,
    sorcerer,
    protectGuardian,
    roleShuffle,
    roleChanger,
    roleAmount,
    roleGenerator,
    addTimer,
    startGame,
    playerHidup,
    playerMati,
    vote,
    voteResult,
    clearAllVote,
    getWinner,
    win,
    pagi,
    malam,
    skill,
    voteStart,
    voteDone,
    voting,
    run,
    run_vote,
    run_malam,
    run_pagi
} = require('../../lib/werewolf.js')

module.exports = {
  aliases: ['wwpc','pc'],
  private: true,
  run: async (m, { conn, usedPrefix, command, args }) => {
    let { sender, chat } = m
    
    if (!conn.werewolf) conn.werewolf = {};
    let ww = conn.werewolf;
    
    let value = (args[0] || '').toLowerCase()
    let target = args[1]

    if (playerOnGame(sender, ww) === false)
        return m.reply("Kamu tidak berada dalam sesi game")
        
    const playerData = dataPlayer(sender, ww)
    if (!playerData) return m.reply("Data player tidak ditemukan")
    
    if (playerData.status === true)
        return m.reply("Skill telah digunakan, hanya bisa digunakan sekali setiap malam")
    if (playerData.isdead === true)
        return m.reply("Kamu sudah mati")
    if (!target || target.length < 1 || target.split('').length > 2) 
        return m.reply(`Silakan berikan nomor urutan player.\n\n*Contoh* : ${usedPrefix + command} kill 0 - Untuk membuat player`)
    if (isNaN(target)) 
        return m.reply("Gunakan hanya nomor urutan player")
        
    let byId = getPlayerById2(sender, parseInt(target), ww)
    if (!byId) return m.reply("Player tidak ditemukan")
    if (byId.db.isdead === true) 
        return m.reply("Player sudah mati")
    if (byId.db.id === sender)
        return m.reply("Tidak bisa menggunakan skill untuk diri sendiri")

    if (value === "kill") {
        if (playerData.role !== "werewolf")
            return m.reply("Peran ini bukan untuk kamu")

        if (byId.db.role === "sorcerer") 
            return m.reply("Tidak bisa menggunakan skill untuk teman")

        m.reply("Berhasil membunuh player " + parseInt(target))
        playerData.status = true
        killWerewolf(sender, parseInt(target), ww)
        
    } else if (value === "dreamy") {
        if (playerData.role !== "seer") 
            return m.reply("Peran ini bukan untuk kamu")

        let dreamy = dreamySeer(sender, parseInt(target), ww)
        m.reply(`Berhasil membuka identitas player *${target}* adalah : *${dreamy}*`)
        playerData.status = true
        
    } else if (value === "deff") {
        if (playerData.role !== "guardian") 
            return m.reply("Peran ini bukan untuk kamu")

        m.reply(`Berhasil melindungi player *${target}*`)
        protectGuardian(sender, parseInt(target), ww)
        playerData.status = true
        
    } else if (value === "sorcerer") {
        if (playerData.role !== "sorcerer") 
            return m.reply("Peran ini bukan untuk kamu")

        let sorker = sorcerer(sender, parseInt(target), ww)
        m.reply(`Berhasil membuka identitas player *${target}* adalah : *${sorker}*`)
        playerData.status = true
        
    } else {
        m.reply(`Perintah tidak valid.\n\n*Gunakan* :\n- ${usedPrefix + command} kill [nomor_urutan] - Werewolf bunuh player\n- ${usedPrefix + command} dreamy [nomor_urutan] - Seer melihat role \n- ${usedPrefix + command} deff [nomor_urutan] - Guardian melindungi\n- ${usedPrefix + command} sorcerer [nomor_urutan] - Sorcerer melihat role`)
    }
  }
}