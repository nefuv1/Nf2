module.exports = {
  help: ['family100'],
  aliases: ['fmly100'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix, env, Func }) => {
    conn.family100 = conn.family100 ? conn.family100 : {}
    let winScore = 1000
    let id = 'family100_' + m.chat
    if (id in conn.family100) return conn.reply(m.chat, 'Masih ada kuis yang belum terjawab di chat ini!', conn.family100[id].msg)
    
    let src = await Func.fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json')
    let json = src[Math.floor(Math.random() * src.length)]
    let caption = `*FAMILY00*

${json.soal}

*Game ID* : GAME-019
Terdapat *${json.jawaban.length}* jawaban${json.jawaban.find(v => v.includes(' ')) ? `
(beberapa jawaban terdapat spasi)
`: ''}

*Bonus* :
- 1.000 Money`.trim()
    
    conn.family100[id] = {
      id,
      msg: await m.reply(caption),
      ...json,
      terjawab: Array.from(json.jawaban, () => false),
      winScore,
    }
  }
}