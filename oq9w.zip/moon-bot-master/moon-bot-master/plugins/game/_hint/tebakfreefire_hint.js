module.exports = {
  aliases: ['hff'],
  limit: true,
  run: async (m, { conn }) => {
    conn.tebakfreefire = conn.tebakfreefire ? conn.tebakfreefire : {}
    let id = m.chat
    if (!(id in conn.tebakfreefire)) throw false
    
    let json = conn.tebakfreefire[id][1]
    let hint = json.name.replace(/[AIUEOaiueo]/ig, '_')
    
    conn.sendMessage(m.chat, {
      text: '```' + hint + '```' + `\nSilakan balas soalnya, bukan pesan ini.`
    }, { quoted: m })
  }
}