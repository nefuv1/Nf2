module.exports = {
  aliases: ['hsuska'],
  limit: true,
  run: async (m, { conn }) => {
    conn.susunkata = conn.susunkata ? conn.susunkata : {}
    let id = m.chat
    if (!(id in conn.susunkata)) throw false
    
    let json = conn.susunkata[id][1]
    let hint = json.jawaban.replace(/[AIUEOaiueo]/ig, '_')
    
    conn.sendMessage(m.chat, {
      text: '```' + hint + '```' + `\nSilakan balas soalnya, bukan pesan ini.`
    }, { quoted: m })
  }
}