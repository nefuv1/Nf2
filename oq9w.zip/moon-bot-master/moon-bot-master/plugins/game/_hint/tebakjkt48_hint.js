module.exports = {
  aliases: ['hjkt'],
  limit: true,
  run: async (m, { conn }) => {
    conn.tebakjkt48 = conn.tebakjkt48 ? conn.tebakjkt48 : {}
    let id = m.chat
    if (!(id in conn.tebakjkt48)) throw false
    
    let json = conn.tebakjkt48[id][1]
    let hint = json.jawaban.replace(/[AIUEOaiueo]/ig, '_')
    
    conn.sendMessage(m.chat, {
      text: '```' + hint + '```' + `\nSilakan balas soalnya, bukan pesan ini.`
    }, { quoted: m })
  }
}