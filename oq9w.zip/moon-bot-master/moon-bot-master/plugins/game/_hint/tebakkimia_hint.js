module.exports = {
  aliases: ['hkimia'],
  limit: true,
  run: async (m, { conn }) => {
    conn.tebakkimia = conn.tebakkimia ? conn.tebakkimia : {}
    let id = m.chat
    if (!(id in conn.tebakkimia)) throw false
    
    let json = conn.tebakkimia[id][1]
    let hint = json.unsur.replace(/[AIUEOaiueo]/ig, '_')
    
    conn.sendMessage(m.chat, {
      text: '```' + hint + '```' + `\nSilakan balas soalnya, bukan pesan ini.`
    }, { quoted: m })
  }
}