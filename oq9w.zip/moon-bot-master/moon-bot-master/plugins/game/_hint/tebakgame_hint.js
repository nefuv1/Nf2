module.exports = {
  aliases: ['hgame'],
  limit: true,
  run: async (m, { conn }) => {
    conn.tebakgame = conn.tebakgame ? conn.tebakgame : {}
    let id = m.chat
    if (!(id in conn.tebakgame)) throw false
    
    let json = conn.tebakgame[id][1]
    let hint = json.jawaban.replace(/[AIUEOaiueo]/ig, '_')
    
    conn.sendMessage(m.chat, {
      text: '```' + hint + '```' + `\nSilakan balas soalnya, bukan pesan ini.`
    }, { quoted: m })
  }
}