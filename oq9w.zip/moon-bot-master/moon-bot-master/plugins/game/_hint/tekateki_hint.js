module.exports = {
  aliases: ['hteki'],
  limit: true,
  run: async (m, { conn }) => {
    conn.tekateki = conn.tekateki ? conn.tekateki : {}
    let id = m.chat
    if (!(id in conn.tekateki)) throw false
    let json = conn.tekateki[id][1]
    let ans = json.jawaban.trim()
    let clue = ans.replace(/[bcdfghjklmnpqrstvwxyz]/g, '_')
    conn.reply(m.chat, '```' + clue + '```\nSilakan balas soalnya, bukan pesan ini.', conn.tekateki[id][0])
  }
}