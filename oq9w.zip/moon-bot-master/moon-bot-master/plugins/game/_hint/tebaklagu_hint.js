module.exports = {
  aliases: ['hlagu'],
  limit: true,
  run: async (m, { conn }) => {
    conn.tebaklagu = conn.tebaklagu ? conn.tebaklagu : {}
    let id = m.chat
    if (!(id in conn.tebaklagu)) throw false
    
    let json = conn.tebaklagu[id][1]
    let hint = json.judul.replace(/[AIUEOaiueo]/ig, '_')
    
    conn.sendMessage(m.chat, {
      text: '```' + hint + '```' + `\nSilakan balas soalnya, bukan pesan ini.`
    }, { quoted: m })
  }
}