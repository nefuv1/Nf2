module.exports = {
  aliases: ['hmtk'],
  limit: true,
  run: async (m, { conn }) => {
    conn.game = conn.game ? conn.game : {}
    let id = 'exammtk-' + m.chat
    if (!(id in conn.game)) throw false
    
    let json = conn.game[id][1]
    let hint = json.jawaban.replace(/[AIUEOaiueo]/ig, '_')
    
    conn.sendMessage(m.chat, {
      text: '```' + hint + '```' + `\nSilakan balas soalnya, bukan pesan ini.`
    }, { quoted: m })
  }
}