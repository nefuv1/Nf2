module.exports = {
  aliases: ['hotak'],
  limit: true,
  run: async (m, { conn }) => {
    conn.asahotak = conn.asahotak ? conn.asahotak : {}
    let id = m.chat
    if (!(id in conn.asahotak)) throw false
    let json = conn.asahotak[id][1]
    let ans = json.jawaban
    let clue = ans.replace(/[bcdfghjklmnpqrstvwxyz]/g, '_')
    conn.reply(m.chat, '```' + clue + '```\nSilakan balas soalnya, bukan pesan ini.', conn.asahotak[id][0])
  }
}