module.exports = {
  aliases: ['hkartun'],
  limit: true,
  run: async (m, { conn }) => {
    conn.tebakkartun = conn.tebakkartun ? conn.tebakkartun : {}
    let id = m.chat
    if (!(id in conn.tebakkartun)) throw false
    
    let json = conn.tebakkartun[id][1]
    let hint = json.jawaban.replace(/[AIUEOaiueo]/ig, '_')
    
    conn.sendMessage(m.chat, {
      text: '```' + hint + '```' + `\nSilakan balas soalnya, bukan pesan ini.`
    }, { quoted: m })
  }
}