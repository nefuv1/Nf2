module.exports = {
   help: ['yes', 'no', 'batu', 'gunting', 'kertas'],
   game: true,
   register: true,
   run: async (m, {
      conn,
      usedPrefix,
      command
   }) => {
      try {
         let users = global.db.users
         conn.suit = conn.suit ? conn.suit : {}
         let room = Object.values(conn.suit).find(room => room.id && room.status && [room.p, room.p2].includes(m.sender))

         if (room) {
            let win = ''
            let tie = false

            // yes / no
            if (m.sender == room.p2 && /(yes|no)/.test(command) && m.isGroup && room.status == 'wait') {
               if (command == 'no') {
                  conn.reply(m.chat, `@${room.p2.split`@`[0]} menolak undangan, suit dibatalkan.`, m)
                  delete conn.suit[room.id]
                  return true
               }

               room.status = 'play'
               room.asal = m.chat
               clearTimeout(room.waktu)

               let teks = `Suit telah dikirimkan ke chat @${room.p.split`@`[0]} dan @${room.p2.split`@`[0]}.\nSilahkan pilih suit di chat masing-masing.`
               conn.reply(m.chat, teks, m)

               let infos = `Silahkan pilih ( ${usedPrefix}kertas, ${usedPrefix}gunting, ${usedPrefix}batu )\n\nJika sudah memilih silakan ketik lalu kirim disini!\n`
               infos += `- *Menang* : 3.999 EXP\n- *Seri* : 1.999 EXP\n\n_Jika kalah maka tidak mendapatkan apa-apa!_`

               if (!room.pilih) conn.reply(room.p, infos)
               if (!room.pilih2) conn.reply(room.p2, infos)

               room.waktu_milih = setTimeout(() => {
                  if (!room.pilih && !room.pilih2) conn.reply(m.chat, `Sesi game suit telah dihapus karena tidak ada aktivitas.`)
                  else if (!room.pilih || !room.pilih2) {
                     conn.reply(m.chat, `@${(room.pilih ? room.p2 : room.p).split`@`[0]} tidak memilih suit, game dibatalkan.`)
                  }
                  delete conn.suit[room.id]
                  return true
               }, room.timeout)
            }

            // pilih suit
            let jwb = m.sender == room.p
            let jwb2 = m.sender == room.p2
            let g = /gunting/i
            let b = /batu/i
            let k = /kertas/i
            let reg = /(gunting|batu|kertas)/i

            if (jwb && reg.test(command) && !room.pilih && !m.isGroup) {
               room.pilih = reg.exec(command.toLowerCase())[0]
               room.text = command
               conn.reply(m.chat, `Kamu telah memilih ${command}${!room.pilih2 ? `, silahkan tunggu lawan memilih...` : ''}`, m)
               if (!room.pilih2) conn.reply(room.p2, `Lawan sudah memilih suit, sekarang giliranmu.`)
            }

            if (jwb2 && reg.test(command) && !room.pilih2 && !m.isGroup) {
               room.pilih2 = reg.exec(command.toLowerCase())[0]
               room.text2 = command
               conn.reply(m.chat, `Kamu telah memilih ${command}${!room.pilih ? `, silahkan tunggu lawan.` : ''}`, m)
               if (!room.pilih) conn.reply(room.p, `Lawan sudah memilih suit, sekarang giliranmu.`)
            }

            // cek hasil
            let stage = room.pilih
            let stage2 = room.pilih2

            if (room.pilih && room.pilih2) {
               clearTimeout(room.waktu_milih)

               if (b.test(stage) && g.test(stage2)) win = room.p
               else if (b.test(stage) && k.test(stage2)) win = room.p2
               else if (g.test(stage) && k.test(stage2)) win = room.p
               else if (g.test(stage) && b.test(stage2)) win = room.p2
               else if (k.test(stage) && b.test(stage2)) win = room.p
               else if (k.test(stage) && g.test(stage2)) win = room.p2
               else if (stage == stage2) tie = true

               let teks = `*SUIT* (PVP)\n\n`
               teks += `Status : ${tie ? 'Seri' : 'Selesai'}\n\n`
               teks += `1. @${room.p.split`@`[0]} (${room.text}) || ${tie ? `Seri +1.999 EXP` : room.p == win ? `Menang +3.999 EXP` : `Lose 0 EXP`}\n`
               teks += `2. @${room.p2.split`@`[0]} (${room.text2}) || ${tie ? `Seri +1.999 EXP` : room.p2 == win ? `Menang +3.999 EXP` : `Lose 0 EXP`}`

               conn.reply(room.asal, teks, m, {
                  mentions: [room.p, room.p2]
               })

               if (tie) {
                  users[room.p].exp += Math.floor(room.reward / 2)
                  users[room.p2].exp += Math.floor(room.reward / 2)
               } else {
                  let isw = win == room.p ? room.p : room.p2
                  users[isw].exp += room.reward
               }
               delete conn.suit[room.id]
            }
         }
      } catch (e) {
         conn.reply(m.chat, e.message, m)
      }
   },
   error: false
}