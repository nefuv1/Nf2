const formatNumber = (num) => {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
};

module.exports = {
  help: ['math'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, args, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true; // Set to false to disable auto-delete
    
    conn.math = conn.math ? conn.math : {}
    if (args.length < 1) return m.reply(`
*Mode* : ${Object.keys(modes).join(' | ')}

*Contoh* : ${usedPrefix}math medium
    `.trim()) 
    
    let mode = args[0].toLowerCase()
    if (!(mode in modes)) return m.reply(`
*Mode* : ${Object.keys(modes).join(' | ')}

*Contoh* : ${usedPrefix}math medium
    `.trim()) 
    
    let id = m.chat
    if (id in conn.math) return conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.math[id][0])
    
    let math = genMath(mode)
    let sentMsg = await conn.reply(m.chat, `*MATH*\n\nBerapa hasil dari *${math.str}* ?
    
*Timeout* : ${(math.time / 1000).toFixed(2)} detik
*Game ID* : GAME-017

*Bonus* :
- ${formatNumber(math.bonus)} EXP
- ${formatNumber(math.limit > 0 ? `${math.limit} Limit` : '')}
 
Balas soal ini untuk menjawab!`, m)
    
    conn.math[id] = [
      sentMsg,
      math,
      4, // Number of attempts
      setTimeout(() => {
        if (conn.math[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.math[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${math.result}*`, conn.math[id][0])
          delete conn.math[id]
        }
      }, math.time),
      deleteAfterAnswer // Store delete option
    ]
  }
}

let modes = {
  noob: [-3, 3, -3, 3, '+-', 15000, 10, 0],
  easy: [-10, 10, -10, 10, '*/+-', 20000, 40, 0],
  medium: [-40, 40, -20, 20, '*/+-', 40000, 150, 0],
  hard: [-100, 100, -70, 70, '*/+-', 60000, 350, 1],
  extreme: [-999999, 999999, -999999, 999999, '*/', 30000, 9999, 4],
  impossible: [-99999999999, 99999999999, -99999999999, 999999999999, '*/', 30000, 35000, 9],
  impossible2: [-999999999999999, 999999999999999, -999, 999, '/', 30000, 50000, 14],
  hell: [-9999999999999999, 9999999999999999, -999999, 999999, '*/+-', 20000, 75000, 19],
  ultra: [-999999999999999999, 999999999999999999, -9999999, 9999999, '*/', 15000, 100000, 24],
  insane: [-999999999999999999999, 999999999999999999999, -99999999, 99999999, '*/+-', 10000, 150000, 29]
}

let operators = {
  '+': '+',
  '-': '-',
  '*': '×',
  '/': '÷'
}

function genMath(mode) {
  let [a1, a2, b1, b2, ops, time, bonus, limit] = modes[mode]
  let a = randomInt(a1, a2)
  let b = randomInt(b1, b2)
  let op = pickRandom([...ops])
  let result = (new Function(`return ${a} ${op.replace('/', '*')} ${b < 0 ? `(${b})`: b}`))()
  if (op == '/') [a, result] = [result, a]
  return {
    str: `${a} ${operators[op]} ${b}`,
    mode,
    time,
    bonus,
    limit,
    result
  }
}

function randomInt(from, to) {
  if (from > to) [from, to] = [to, from]
  from = Math.floor(from)
  to = Math.floor(to)
  return Math.floor((to - from) * Math.random() + from)
}

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}