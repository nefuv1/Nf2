let fetch = require('node-fetch')

module.exports = {
  help: ['tekateki'],
  aliases: ['tkatki'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true // Set to false to disable auto-delete
    
    let timeout = 60000
    let poin = 3999
    
    conn.tekateki = conn.tekateki ? conn.tekateki : {}
    let id = m.chat
    if (id in conn.tekateki) {
      conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.tekateki[id][0])
      throw false
    }
    
    let src = await (await fetch('https://raw.githubusercontent.com/qisyana/scrape/main/tekateki.json')).json()
    let json = src[Math.floor(Math.random() * src.length)]
    
    let caption = `*TEKA TEKI*
  
${json.pertanyaan}

*Timeout* : ${(timeout / 1000).toFixed(2)} detik
*Game ID* : GAME-002
Untuk bantuan kirim perintah : ${usedPrefix}hteki

*Bonus* : 
- 3.999 EXP

Balas soal ini untuk menjawab!
    `.trim()
    
    let sentMsg = await conn.reply(m.chat, caption, m)
    conn.tekateki[id] = [
      sentMsg,
      json,
      poin,
      setTimeout(() => {
        if (conn.tekateki[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.tekateki[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.jawaban}*`, conn.tekateki[id][0])
          delete conn.tekateki[id]
        }
      }, timeout),
      deleteAfterAnswer // Store delete option
    ]
  }
}