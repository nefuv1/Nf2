let fetch = require('node-fetch')

module.exports = {
  help: ['asahotak'],
  aliases: ['ashotak'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true // Ubah ke false jika tidak ingin auto delete
    
    let timeout = 60000     
    let poin = 3999        
    let limit = 1          
    
    conn.asahotak = conn.asahotak ? conn.asahotak : {}          
    let id = m.chat          
    if (id in conn.asahotak) {          
      conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.asahotak[id][0])          
      throw false          
    }          
    
    let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/asahotak.json')).json()          
    let json = src[Math.floor(Math.random() * src.length)]          
    
    let caption = `*ASAH OTAK*
              
${json.soal}          
      
*Timeout* : ${(timeout / 1000).toFixed(2)} detik          
*Game ID* : GAME-001
Untuk bantuan kirim perintah : ${usedPrefix}hotak
  
*Bonus* :           
- 3.999 EXP          
- ${limit} Limit          

Balas soal ini untuk menjawab!          
    `.trim()          

    let sentMsg = await conn.reply(m.chat, caption, m)
    conn.asahotak[id] = [          
      sentMsg,
      json,          
      poin,          
      setTimeout(() => {          
        if (conn.asahotak[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.asahotak[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.jawaban}*`, conn.asahotak[id][0])          
          delete conn.asahotak[id]
        }          
      }, timeout),
      deleteAfterAnswer // Store delete option
    ]          
  }
}