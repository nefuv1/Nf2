let fetch = require('node-fetch')

module.exports = {
  help: ['tebakkimia'],
  aliases: ['tbkkimia'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    // Configurable delete option
    const deleteAfterAnswer = true // Set to false to disable auto-delete
    
    let timeout = 60000
    let poin = 3999
    
    conn.tebakkimia = conn.tebakkimia ? conn.tebakkimia : {}
    let id = m.chat
    if (id in conn.tebakkimia) {
      conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.tebakkimia[id][0])
      throw false
    }
    
    let src = await (await fetch('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkimia.json')).json()
    let json = src[Math.floor(Math.random() * src.length)]
    
    let caption = `*TEBAK KIMIA*

Nama unsur dari lambang ${json.lambang} adalah...

*Timeout* : ${(timeout / 1000).toFixed(2)} detik
*Game ID* : GAME-007
Untuk bantuan kirim perintah : ${usedPrefix}hkimia

*Bonus* : 
- 3.999 EXP

Balas soal ini untuk menjawab!
    `.trim()
    
    let sentMsg = await conn.reply(m.chat, caption, m)
    conn.tebakkimia[id] = [
      sentMsg,
      json,
      poin,
      setTimeout(() => {
        if (conn.tebakkimia[id]) {
          if (deleteAfterAnswer) {
            conn.sendMessage(m.chat, { 
              delete: { 
                remoteJid: m.chat, 
                id: conn.tebakkimia[id][0].id, 
                fromMe: true 
              } 
            }).catch(() => {})
          }
          conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.unsur}*`, conn.tebakkimia[id][0])
          delete conn.tebakkimia[id]
        }
      }, timeout),
      deleteAfterAnswer // Store delete option
    ]
  }
}