const TicTacToe = require('../../lib/tictactoe')

module.exports = {
  help: ['tictactoe'],
  aliases: ['ttt'],   
  tags: 'game',
  game: true,
  group: true,
  register: true,
  run: async (m, { conn, usedPrefix, command, text, Func }) => {
    conn.ttt = conn.ttt ? conn.ttt : {}
    
    // AUTO CLEANUP: Hapus room yang sudah selesai atau expired
    let now = Date.now()
    for (let roomId in conn.ttt) {
      let room = conn.ttt[roomId]
      // Hapus room yang WAITING lebih dari 10 menit
      if (room.state === 'WAITING' && now - room.createdAt > 600000) {
        delete conn.ttt[roomId]
        continue
      }
      // Hapus room yang PLAYING lebih dari 30 menit (game mandek)
      if (room.state === 'PLAYING' && now - room.lastActivity > 1800000) {
        delete conn.ttt[roomId]
      }
    }
    
    if (Object.values(conn.ttt).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))) {
      return conn.reply(m.chat, 'Anda masih berada di sesi room tictactoe ini!', m)
    }
    
    let room = Object.values(conn.ttt).find(room => room.state === 'WAITING' && (text ? room.name === text : true))
    
    if (room) {
      m.reply('Lawan ditemukan!')
      room.o = m.chat
      room.game.playerO = m.sender
      room.state = 'PLAYING'
      room.lastActivity = now // UPDATE ACTIVITY
      
      let arr = room.game.render().map(v => {
        return {
          X: '❌',
          O: '⭕',
          1: '1️⃣',
          2: '2️⃣',
          3: '3️⃣',
          4: '4️⃣',
          5: '5️⃣',
          6: '6️⃣',
          7: '7️⃣',
          8: '8️⃣',
          9: '9️⃣',
        }[v]
      })
      
      let str = `*TICTACTOE*

*Room ID* : ${room.id}
*Game ID* : GAME-024

Menunggu @${room.game.currentTurn.split('@')[0]}...
Untuk memulai permainan.

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

*PERATURAN*

1. Buat 3 baris tanda X/O secara vertikal, 
horizontal atau diagonal untuk menang.

2. Kirim : nyerah - (Keluar dari permainan)`.trim()
      
      if (room.x !== room.o) await conn.reply(room.x, str, m)
      await conn.reply(room.o, str, m)
      
    } else {
      room = {
        id: 'tictactoe-' + (+new Date),
        x: m.chat,
        o: '',
        game: new TicTacToe(m.sender, 'o'),
        state: 'WAITING',
        createdAt: now, // TIMESTAMP CREATION
        lastActivity: now // TIMESTAMP ACTIVITY
      }
      if (text) room.name = text
      m.reply('Menunggu lawan!...' + (text ? ` mengetik perintah ${usedPrefix + command} ${text}` : ''))
      conn.ttt[room.id] = room
    }
  }
}