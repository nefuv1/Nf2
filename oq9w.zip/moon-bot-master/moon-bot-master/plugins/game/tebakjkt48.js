const axios = require('axios');
const Jimp = require('jimp');
const fs = require('fs');
const path = require('path');

module.exports = {
  help: ['tebakjkt48'],
  aliases: ['tbkjkt48'],
  tags: 'game',
  onlyprem: true,
  game: true,
  register: true,
  run: async (m, { conn, usedPrefix }) => {
    const deleteAfterAnswer = true;
    const timeout = 60000;
    const poin = 3999;
    const blurLevel = 5;

    conn.tebakjkt48 = conn.tebakjkt48 || {};
    const id = m.chat;

    if (id in conn.tebakjkt48) {
      conn.reply(m.chat, 'Masih ada soal yang belum terjawab di chat ini!', conn.tebakjkt48[id][0]);
      throw false;
    }

    let src = await tebakJkt48();
    if (!Array.isArray(src) || !src.length) {
      return conn.reply(m.chat, 'Gagal mengambil data JKT48! Pastikan file JSON tersedia dan valid.', m);
    }

    let json = src[Math.floor(Math.random() * src.length)];
    if (!json || !json.gambar) {
      return conn.reply(m.chat, 'Data gambar tidak ditemukan di JSON!', m);
    }

    try {
      const imgBuffer = (await axios.get(json.gambar, { responseType: 'arraybuffer' })).data;
      const jimpImg = await Jimp.read(imgBuffer);
      jimpImg.blur(blurLevel);
      const blurredBuffer = await jimpImg.getBufferAsync(Jimp.MIME_JPEG);

      const caption = `*TEBAK JKT48*

Siapakah member JKT48 pada gambar di atas ?

*Timeout* : ${(timeout / 1000).toFixed(2)} detik
*Game ID* : GAME-011
Untuk bantuan kirim perintah : ${usedPrefix}hjkt

*Bonus* :
- 3.999 EXP

Balas soal ini untuk menjawab!`.trim();

      const sentMsg = await conn.sendFile(m.chat, blurredBuffer, 'tebakjkt48.jpg', caption, m);
      conn.tebakjkt48[id] = [
        sentMsg,
        json,
        poin,
        setTimeout(() => {
          if (conn.tebakjkt48[id]) {
            if (deleteAfterAnswer) {
              conn.sendMessage(m.chat, {
                delete: {
                  remoteJid: m.chat,
                  id: conn.tebakjkt48[id][0].id,
                  fromMe: true
                }
              }).catch(() => {});
            }
            conn.reply(m.chat, `Waktu habis!\nJawabannya adalah : *${json.jawaban}*`, conn.tebakjkt48[id][0]);
            delete conn.tebakjkt48[id];
          }
        }, timeout),
        deleteAfterAnswer
      ];
    } catch (err) {
      console.error(err);
      m.reply(`Failed to execute command.\n\n- *Command* : ${command}\n- *Error* : ${err.message}`);
    }
  }
};

async function tebakJkt48() {
  try {
    const filePath = path.join(__dirname, '../../json/tebakjkt48.json');
    if (!fs.existsSync(filePath)) {
      throw new Error('File JSON tidak ditemukan di : ' + filePath);
    }
    const data = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error load JSON tebakJkt48 :', error.message);
    return [];
  }
}