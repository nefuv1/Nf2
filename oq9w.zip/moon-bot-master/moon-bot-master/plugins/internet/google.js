/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['google', 'gimage'],
   tags: 'internet',
   limit: true,
   register: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      Func
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingGoogle = user.isProcessingGoogle || false;
         
         if (user.isProcessingGoogle) throw global.status.previously
         if (!text) throw `Please provide a title.\n\n*Example* : ${usedPrefix + command} TechBOT`
         
         user.isProcessingGoogle = true;
         m.react(global.react);
         
         if (command == 'google') {
            let json = await Api.get('api/google', {
               q: text
            })
            let teks = `*GOOGLE*\n\n`
            json.data.map((v, i) => {
               teks += `[${i + 1}]\n`
               teks += `- *Title* : ` + v.title + `\n`
               teks += `- *Snippet* : ` + v.snippet + `\n`
               teks += `- *Link* : ` + v.url + `\n\n`
            })
            m.reply(teks)
         }
         
         if (command == 'gimage') {
            let json = await Api.get('api/google-image', {
               q: text
            })
            for (let i = 0; i < 5; i++) {
               let random = Math.floor(json.data.length * Math.random())
               let caption = `*GOOGLE IMAGE*\n\n`
               caption += `- *Title* : ${json.data[random].origin.title}\n`
               caption += `- *Dimensions* : ${json.data[random].width} × ${json.data[random].height}`
               conn.sendFile(m.chat, json.data[random].url, 'google.jpg', caption, m)
               await Func.delay(2500)
            }
         }
         
      } catch (e) {
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingGoogle = false;
         }
      }
   }
}