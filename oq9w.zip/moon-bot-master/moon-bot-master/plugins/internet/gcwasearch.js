/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios')
const cheerio = require('cheerio')
const moment = require('moment-timezone')

module.exports = {
    help: ['gcsearch'],
    tags: 'internet',
    aliases: ['gcwa', 'gcs', 'wagc', 'groupwa', 'wagroup'],
    register: true,
    limit: 30,
    premium: true,
    private: true,
    run: async (m, { text, conn, usedPrefix, command }) => {
        try {
            let user = global.db.users[m.sender] || {};
            user.isProcessingGcs = user.isProcessingGcs || false;

            if (user.isProcessingGcs) throw global.status.previously;
            if (!text) throw `Please provide a title.\n\n*Example* : ${usedPrefix + command} TechBOT`;

            user.isProcessingGcs = true;
            m.react(global.react);

            const keywords = text.split(',');
            const headers = {
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "Referer": "https://groupda1.link/add/group/search",
                "Accept-Language": "en-US,en;q=0.9",
                "Accept": "text/html, */*; q=0.01",
                "Host": "groupda1.link",
                "Origin": "https://groupda1.link",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
            };

            const results = [];

            for (const keywordRaw of keywords) {
                const keyword = keywordRaw.trim();
                let loop_count = 0;

                while (loop_count < 10) {
                    const data = new URLSearchParams({
                        group_no: `${loop_count}`,
                        search: true,
                        keyword: keyword,
                        category: "Any Category",
                        country: "Indonesia",
                        language: "Bahasa Apa Pun"
                    });

                    try {
                        const response = await axios.post(
                            "https://groupda1.link/add/group/loadresult",
                            data.toString(),
                            { headers, timeout: 10000 }
                        );

                        const html = response.data;
                        if (!html || html.length === 0) break;

                        const $ = cheerio.load(html);
                        let found = false;

                        for (const div of $('.maindiv').toArray()) {
                            const tag = $(div).find('a[href]');
                            if (!tag.length) continue;

                            const link = tag.attr('href');
                            const title = tag.attr('title')?.replace('Whatsapp group invite link : ', '') || 'Without title';
                            const desc = $(div).find('p.descri').text().trim() || 'No description';
                            const group_id = link.split('/').pop();
                            const group_link = `https://chat.whatsapp.com/${group_id}`;

                            if (!results.some(g => g.Code === group_id)) {
                                results.push({
                                    Name: title,
                                    Code: group_id,
                                    Link: group_link,
                                    Description: desc,
                                    Keyword: keyword
                                });
                                found = true;
                            }
                        }

                        if (!found) break;
                        loop_count++;
                        await new Promise(resolve => setTimeout(resolve, 800));
                    } catch (err) {
                        console.error(`Error page ${loop_count + 1} : ${err.message}`);
                        break;
                    }
                }
            }

            if (results.length === 0) throw `"${text}" Not found / No results!`;

            const show = results.slice(0, 10);
            const waktu = moment().tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm');

            let msg = `*GROUP SEARCH*\n\n`;
            msg += `- *Time* : ${waktu}\n`;
            msg += `- *Keywords* : ${text}\n`;
            msg += `- *Found* : ${results.length} grup\n\n`;

            for (let i = 0; i < show.length; i++) {
                const g = show[i];
                msg += `[${i + 1}]\n`;
                msg += `- *Name* : ${g.Name}\n`;
                msg += `- *Description* : ${g.Description}\n`;
                msg += `- *URL* : ${g.Link}\n`;
                msg += `- *Keyword* : ${g.Keyword}\n\n`;
            }

            await conn.reply(m.chat, msg, m);

        } catch (e) {
            throw e;
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingGcs = false;
            }
        }
    },
    error: false
}