/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const fetch = require('node-fetch');

global.ghSessions = global.ghSessions || [];

function formatDate(n, locale = 'en') {
    const d = new Date(n);
    return d.toLocaleDateString(locale, {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric',
        hour: 'numeric',
        minute: 'numeric',
        second: 'numeric'
    });
}

module.exports = {
    help: ['githubsearch'],
    aliases: ['ghs', 'github', 'ghsearch'],
    tags: 'internet',
    limit: true,
    register: true,
    run: async (m, { 
        conn, 
        text, 
        usedPrefix, 
        command,
        Func
    }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingGh = user.isProcessingGh || false;

        if (user.isProcessingGh) throw global.status.previously;
        user.isProcessingGh = true;

        try {
            const timer = 18000; // 18 detik
            const check = global.ghSessions.find(v => v.jid == m.sender);
            const query = check ? text : text.trim();

            if (!query) throw `Please provide a title.\n\n*Example* : ${usedPrefix + command} TechBOT`

            if (!check && !isNaN(text)) throw 'Your session has expired / does not exist, do a search again using the keywords you want.'

            if (check && !isNaN(text)) {
                const index = Number(text) - 1;
                const selectedRepo = check.results[index];
                if (!selectedRepo) throw 'Invalid number or session expired.'

                const [, userName, repo] = selectedRepo.clone_url.match(/github\.com\/([^\/]+)\/(.+?)(\.git)?$/) || [];
                const url = `https://api.github.com/repos/${userName}/${repo}/zipball`;
                
                const headRes = await fetch(url, { method: 'HEAD' });
                const contentDisposition = headRes.headers.get('content-disposition');
                const filename = contentDisposition ? contentDisposition.match(/attachment; filename=(.*)/)[1] : `${repo}.zip`;

                await conn.sendMessage(m.chat, {
                    document: { url: url },
                    mimetype: 'application/zip',
                    fileName: filename,
                    caption: ''
                }, { quoted: m });

                await conn.sendMessage(m.chat, { delete: check.key });
                global.ghSessions = global.ghSessions.filter(v => v.jid != m.sender);
                
                return;
            }

            m.react(global.react);

            const res = await fetch(`https://api.github.com/search/repositories?q=${encodeURIComponent(query)}&per_page=10`);
            if (!res.ok) throw 'Error fetching data from GitHub API.'

            const json = await res.json();
            if (json.total_count === 0) throw `"${query}" Not found / No results!`

            const results = json.items.slice(0, 10);
            let str = `To download the file, use this command *${usedPrefix + command} (number)*\n*Example* : ${usedPrefix + command} 1\n\n`;
            
            str += results.map((repo, i) => {
                return `[${i + 1}]\n- *Repository* : ${repo.name}\n- *Developer* : ${repo.owner.login}\n- *Forked* : ${repo.fork ? '✅' : '❌'}\n- *Private*: ${repo.private ? '✅' : '❌'}\n- *Created* : ${formatDate(repo.created_at)}\n- *Updated* : ${formatDate(repo.updated_at)}\n- 👁 ${repo.watchers} 🍴 ${repo.forks} ⭐ ${repo.stargazers_count}\n${repo.description ? `- *Description* : ${repo.description}` : ''}\n- *Clone* : \`git clone ${repo.clone_url}\``;
            }).join('\n\n');

            const msg = await m.reply(str);
            
            const existingIndex = global.ghSessions.findIndex(v => v.jid == m.sender);
            if (existingIndex !== -1) {
                global.ghSessions[existingIndex] = {
                    jid: m.sender,
                    results,
                    created_at: Date.now(),
                    key: msg.key
                };
            } else {
                global.ghSessions.push({
                    jid: m.sender,
                    results,
                    created_at: Date.now(),
                    key: msg.key
                });
            }

            setTimeout(() => {
                const sessionIndex = global.ghSessions.findIndex(v => v.jid == m.sender);
                if (sessionIndex !== -1 && Date.now() - global.ghSessions[sessionIndex].created_at > timer) {
                    conn.sendMessage(m.chat, { delete: global.ghSessions[sessionIndex].key });
                    global.ghSessions.splice(sessionIndex, 1);
                }
            }, timer + 1000);

        } catch (e) {
            console.error(e);
            throw Func.jsonFormat(e)
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingGh = false;
            }
        }
    }
};