/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
   help: ['brainly'],
   tags: 'internet',
   limit: true,
   register: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      text,
      Func
   }) => {
      try {
         let user = global.db.users[m.sender] || {};
         user.isProcessingBrainly = user.isProcessingBrainly || false;
         
         if (user.isProcessingBrainly) throw global.status.previously
         if (!text) throw `Please provide a title.\n\n*Example* : ${usedPrefix + command} TechBOT`
         
         user.isProcessingBrainly = true;
         m.react(global.react);
         
         const json = await Api.get('api/brainly', {
            q: text, lang: 'id'
         })
         if (!json.status) throw Func.jsonFormat(json)
         
         let teks = `*BRAINLY*\n\n`
         json.data.map((v, i) => {
            teks += `[${(i + 1)}]\n`
            teks += `${v.question}\n`
            teks += `- *Answer* : \n${v.answers}\n\n`
         })
         
         m.reply(teks);
         
      } catch (e) {
           throw Func.jsonFormat(e)
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingBrainly = false;
         }
      }
   }
}