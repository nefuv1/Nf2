/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const cheerio = require("cheerio");
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

const getHentaiList = async () => {
  const page = Math.floor(Math.random() * 1153);
  const response = await fetch(`https://sfmcompile.club/page/${page}`);
  const htmlText = await response.text();
  const $ = cheerio.load(htmlText);

  const hasil = [];
  $("#primary > div > div > ul > li > article").each(function (a, b) {
    hasil.push({
      title: $(b).find("header > h2").text(),
      link: $(b).find("header > h2 > a").attr("href"),
      category: $(b).find("header > div.entry-before-title > span > span").text().replace("in ", ""),
      share_count: $(b).find("header > div.entry-after-title > p > span.entry-shares").text(),
      views_count: $(b).find("header > div.entry-after-title > p > span.entry-views").text(),
      type: $(b).find("source").attr("type") || "image/jpeg",
      video_1: $(b).find("source").attr("src") || $(b).find("img").attr("data-src"),
      video_2: $(b).find("video > a").attr("href") || "",
      description: $(b).find("div.entry-content").text().trim() || "No description available",
      thumbnail: $(b).find("img").attr("src") || $(b).find("img").attr("data-src"),
    });
  });

  return hasil;
};

const getCaption = (obj) => `*HENTAI VIDEO*

- *Title* : ${obj.title}
- *Link* : ${obj.link}
- *Category* : ${obj.category}
- *Share Count* : ${obj.share_count}
- *Views Count* : ${obj.views_count}
- *Type* : ${obj.type}
- *Description* : ${obj.description}`;

module.exports = {
  help: ['hentaivideos'],
  aliases: ['hentaivid', 'henvid'],
  tags: 'internet',
  premium: true,
  limit: 30,
  register: true,
  private: true,
  run: async (m, { conn, text, usedPrefix, Func, command }) => {

    let user = global.db.users[m.sender] || {};
    user.isProcessingHentaivideos = user.isProcessingHentaivideos || false;

    if (user.isProcessingHentaivideos) throw global.status.previously;
    user.isProcessingHentaivideos = true;

    try {
      global.hentaiSessions = global.hentaiSessions || {};
      const session = global.hentaiSessions[m.sender];

      if (!text) {
        m.react(global.react);

        const list = await getHentaiList();
        const teks = list.map((obj, i) => `*${i + 1}.* ${obj.title}`).join("\n");

        let { key } = await m.reply(
          `To download the videos, use this command *${usedPrefix + command} (number)*\n*Example* : ${usedPrefix + command} 1\n\n${teks}`
        );

        if (session) {
          clearTimeout(session.timeout);
          if (session.key) {
            await conn.sendMessage(m.chat, { delete: session.key });
          }
        }

        global.hentaiSessions[m.sender] = {
          list,
          key: key,
          created_at: Date.now(),
          timeout: setTimeout(() => {
            if (global.hentaiSessions[m.sender]) {
              conn.sendMessage(m.chat, { delete: global.hentaiSessions[m.sender].key });
              delete global.hentaiSessions[m.sender];
            }
          }, 18000) // 18 detik
        };

      } else {
        if (!session || Date.now() - session.created_at > 18000) {
          throw "Session has expired, please search again."
        }

        const index = parseInt(text.trim());
        if (isNaN(index) || index < 1 || index > session.list.length) {
          throw "Enter a valid video number."
        }

        const selectedObj = session.list[index - 1];
        const videoUrl = selectedObj.video_1 || selectedObj.video_2;

        if (!videoUrl) {
          throw new Error("Video URL not found");
        }

        await conn.sendMessage(m.chat, {
          video: { url: videoUrl },
          caption: getCaption(selectedObj),
          mentions: [m.sender]
        }, { quoted: m });

        clearTimeout(session.timeout);
        await conn.sendMessage(m.chat, { delete: session.key });
        delete global.hentaiSessions[m.sender];
      }

    } catch (e) {
      console.error(e);
      throw Func.jsonFormat(e)
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingHentaivideos = false;
      }
    }
  }
};