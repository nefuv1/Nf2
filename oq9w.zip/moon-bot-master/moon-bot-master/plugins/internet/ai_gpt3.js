/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');

async function gpt3Query(prompt, content) {
    try {
        const messages = [
            { role: "system", content: prompt.trim() },
            { role: "user", content: content.trim() }
        ];

        const response = await axios.post(
            "https://chatbot-ji1z.onrender.com/chatbot-ji1z",
            { messages },
            {
                timeout: 30000,
                headers: {
                    "Accept": "text/event-stream",
                    "Content-Type": "application/json",
                    "origin": "https://seoschmiede.at",
                },
            }
        );

        if (!response.data || !response.data.choices || !response.data.choices[0]) {
            throw new Error('Invalid response structure from API');
        }

        return response.data.choices[0].message.content;
    } catch (err) {
        throw new Error('Request failed : ' + err.message);
    }
}

// === Command ===
module.exports = {
    help: ['gpt3'],
    aliases: ['ai', 'chatgpt', 'gpt', 'openai'],
    tags: 'ai',
    limit: 3,
    register: true,
    run: async (m, { conn, text, usedPrefix, command, Func }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingGpt3 = user.isProcessingGpt3 || false;

        if (user.isProcessingGpt3) throw global.status.previously;
        user.isProcessingGpt3 = true;

        try {
            if (!text) {
                throw `Please ask questions.\n\n*Example* : ${usedPrefix + command} TechBOT`
            }

            let waitMsg = await conn.reply(m.chat, '...', m);

            try {
                const response = await gpt3Query('GPT-3', text);
                await conn.sendMessage(m.chat, {
                    text: response,
                    edit: waitMsg.key
                });
            } catch (apiError) {
                    throw `${apiError.message}`
            }

        } catch (e) {
            throw Func.jsonFormat(e);
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingGpt3 = false;
            }
        }
    }
};