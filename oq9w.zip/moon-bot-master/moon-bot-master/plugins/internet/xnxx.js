/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');    
const cheerio = require('cheerio');    
    
const SESSION_TIMEOUT = 18000; // 18 detik    
    
module.exports = {    
  help: ['xnxx'],    
  tags: 'internet',    
  premium: true,    
  register: true,    
  limit: 30,  
  private: true, 
  run: async (m, { conn, text, usedPrefix, command, set, Func }) => {    
    try {    
      let user = global.db.users[m.sender] || {};    
      user.isProcessingXnxx = user.isProcessingXnxx || false;    
      
      if (user.isProcessingXnxx) throw global.status.previously    
    
      conn.xnxx = conn.xnxx || {};    
      const session = conn.xnxx[m.sender];    
    
      if (!text) {    
        throw `Please provide a title.\n\n*Example* : ${usedPrefix + command} TechBOT`    
      }    
          
      m.react(global.react);    
      user.isProcessingXnxx = true;    

      if (!isNaN(text) && session && session.results) {    
        const videoIndex = parseInt(text) - 1;    
        if (videoIndex < 0 || videoIndex >= session.results.length) {    
          throw 'Invalid number(s). Please select from the list above.'    
        }    
    
        const selected = session.results[videoIndex];    
        const videoData = await getVideoDownloadLinks(selected.link);    
    
        delete conn.xnxx[m.sender];    
        if (session.key) {    
          conn.sendMessage(m.chat, { delete: session.key }).catch(() => {});    
        }    
    
        if (videoData.high) {    
          await conn.sendMessage(m.chat, {    
            video: { url: videoData.high },    
            caption: ``    
          }, { quoted: m });    
        } else if (videoData.low) {    
          await conn.sendMessage(m.chat, {    
            video: { url: videoData.low },    
            caption: ``    
          }, { quoted: m });    
        } else {    
          throw 'Unable to fetch video download link.'    
        }    
        return;    
      }    
    
      const searchResults = await searchXNXX(text);    
      const limitedResults = searchResults.slice(0, 10);    
    
      if (limitedResults.length === 0) {    
        throw `"${text}" Not found / No results!`    
      }    
    
      const hasil = `To download the videos, use this command *${usedPrefix + command} (number)*\n*Example* : ${usedPrefix + command} 1\n\n${limitedResults.map((v, i) => `[${i + 1}]\n- *Title* : ${v.title}\n- *Source* : ${v.link}\n- *Info* : ${v.info}`).join("\n\n")}`;    
    
      let listMsg = await conn.reply(m.chat, hasil, m);    
    
      conn.xnxx[m.sender] = {    
        results: limitedResults,    
        created_at: Date.now(),    
        key: listMsg.key    
      };    
    
      setTimeout(() => {    
        if (conn.xnxx[m.sender] && Date.now() - conn.xnxx[m.sender].created_at > SESSION_TIMEOUT) {    
          conn.sendMessage(m.chat, { delete: conn.xnxx[m.sender].key }).catch(() => {});    
          delete conn.xnxx[m.sender];    
        }    
      }, SESSION_TIMEOUT + 1000);    
    } catch (e) {    
      console.error(e);    
      throw Func.jsonFormat(e);    
    } finally {    
      if (global.db.users[m.sender]) {    
        global.db.users[m.sender].isProcessingXnxx = false;    
      }    
    }    
  }    
};    
    
async function searchXNXX(query) {    
  try {    
    const response = await axios.get(`https://www.xnxx.com/search/${encodeURIComponent(query)}`);    
    const $ = cheerio.load(response.data);    
    let results = [];    
    
    $('div.mozaique').find('div.thumb-under').each((index, element) => {    
      const title = $(element).find('a').attr('title');    
      const link = 'https://www.xnxx.com' + $(element).find('a').attr('href');    
      const info = $(element).find('p.metadata').text().trim();    
      results.push({ title, link, info });    
    });    
    
    return results;    
  } catch (error) {    
    console.error(error);    
    return [];    
  }    
}    
    
async function getVideoDownloadLinks(url) {    
  try {    
    const response = await axios.get(url);    
    const $ = cheerio.load(response.data);    
    let downloadLinks = {};    
    
    $('script').each((i, elem) => {    
      const scriptContent = $(elem).html();    
      const high = scriptContent.match(/html5player\.setVideoUrlHigh\('([^']+)'\)/);    
      const low = scriptContent.match(/html5player\.setVideoUrlLow\('([^']+)'\)/);    
      if (high) downloadLinks.high = high[1];    
      if (low) downloadLinks.low = low[1];    
    });    
    
    return downloadLinks;    
  } catch (error) {    
    console.error(error);    
    return {};    
  }    
}