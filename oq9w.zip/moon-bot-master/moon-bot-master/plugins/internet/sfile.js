/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const cheerio = require('cheerio');
const axios = require('axios');

async function searchSFile(query, page = 1) {
    const res = await fetch(`https://sfile.mobi/search.php?q=${query}&page=${page}`);
    const $ = cheerio.load(await res.text());
    const arr = [];

    $('div.list').each((idx, el) => {
        let title = $(el).find('a').text().trim();
        let size = $(el).text().trim().split(' (')[1];
        let link = $(el).find('a').attr('href');

        if (link) {
            if (!link.startsWith('http')) {
                link = `https://sfile.mobi${link}`;
            }
            arr.push({
                title,
                size: size ? size.replace(')', '') : 'Unknown',
                link
            });
        }
    });

    return arr;
}

async function sfileDownload(url) {
    const headers = {
        'referer': url,
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        'accept-language': 'en-US,en;q=0.9',
        'user-Agent': 'Postify/1.0.0',
    };

    try {
        const response = await axios.get(url, { headers });
        headers.Cookie = response.headers['set-cookie'].map(cookie => cookie.split(';')[0]).join('; ');

        const [filename, mimetype, downloadLink] = [
            response.data.match(/<h1 class="intro">(.*?)<\/h1>/s)?.[1] || '',
            response.data.match(/<div class="list">.*? - (.*?)<\/div>/)?.[1] || '',
            response.data.match(/<a class="w3-button w3-blue w3-round" id="download" href="([^"]+)"/)?.[1]
        ];
        
        if (!downloadLink) throw new Error('Download link not found!');

        headers.Referer = downloadLink;
        const final = await axios.get(downloadLink, { headers });

        const [directLink, key, filesize] = [
            final.data.match(/<a class="w3-button w3-blue w3-round" id="download" href="([^"]+)"/)?.[1],
            final.data.match(/&k='\+(.*?)';/)?.[1]?.replace(`'`, ''),
            final.data.match(/Download File (.*?)/)?.[1]
        ];

        const result = directLink + (key ? `&k=${key}` : '');
        if (!result) throw new Error('Direct Download Link not found!');

        const data = await convertSFile(result, url);

        return {
            status: 'success',
            data: {
                filename: data.filename,
                filesize,
                mimeType: data.mimeType,
                buffer: data.buffer
            }
        };
    } catch (error) {
        return {
            status: 'error',
            message: error.message
        };
    }
}

async function convertSFile(url, directLink) {
    try {
        const init = await axios.get(url, {
            maxRedirects: 0,
            validateStatus: status => status >= 200 && status < 303,
            headers: {
                'Referer': directLink,
                'User-Agent': 'Postify/1.0.0'
            },
        });

        const cookies = init.headers['set-cookie'].map(c => c.split(';')[0]).join('; ');
        const redirect = init.headers.location;

        const final_result = await axios.get(redirect, {
            responseType: 'arraybuffer',
            headers: {
                'referer': directLink,
                'user-agent': 'Postify/1.0.0',
                'cookie': cookies,
            },
        });

        const filename = final_result.headers['content-disposition']?.match(/filename=["']?([^"';]+)["']?/)?.[1] || 'unknown';
        const mimeType = final_result.headers['content-type'] || 'application/octet-stream';

        return {
            filename,
            mimeType,
            buffer: Buffer.from(final_result.data)
        };
    } catch (error) {
        throw error;
    }
}

module.exports = {
    help: ['sfile'],
    aliases: ['sfiles'],
    tags: 'internet',
    limit: true,
    register: true,
    run: async (m, { conn, text, usedPrefix, command, Func }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingSfile = user.isProcessingSfile || false;

        if (user.isProcessingSfile) throw global.status.previously;
        if (!text) throw `Please provide a title / URL.\n\n*Example* :\n1. ${usedPrefix + command} TechBOT\n2. ${usedPrefix + command} https://sfile.mobi/bl4vRLtizQ7`;

        user.isProcessingSfile = true;
        m.react(global.react);

        try {
            const timer = 18000; // 18 detik
            conn.sfile = conn.sfile || [];

            const check = conn.sfile.find(v => v.jid === m.sender);
            const query = check ? text : text.trim();

            if (query.match(/https:\/\/sfile\.(mobi|xyz)/gi)) {
                const download = await sfileDownload(query);

                if (download.status !== 'success') throw download.message;

                let caption = `*SFILE DOWNLOAD*\n\n`;
                caption += `- *Title* : ${download.data.filename}\n`;
                caption += `- *Size* : ${download.data.filesize || 'Unknown'}\n`;
                caption += `- *Type* : ${download.data.mimeType}`;

                await conn.sendMessage(m.chat, {
                    document: download.data.buffer,
                    mimetype: download.data.mimeType,
                    fileName: download.data.filename,
                    caption: caption
                }, { quoted: m });

                return;
            }

            if (check && !isNaN(query)) {
                const num = Number(query);
                if (num > check.results.length) throw 'Exceeds the amount of Data.';

                const selected = check.results[num - 1];
                const download = await sfileDownload(selected.link);

                if (download.status !== 'success') throw download.message;

                let caption = `*SFILE DOWNLOAD*\n\n`;
                caption += `- *Title* : ${selected.title}\n`;
                caption += `- *Size* : ${selected.size}\n`;
                caption += `- *Type* : ${download.data.mimeType}`;

                await conn.sendMessage(m.chat, {
                    document: download.data.buffer,
                    mimetype: download.data.mimeType,
                    fileName: selected.title,
                    caption: caption
                }, { quoted: m });

                if (conn.sfile) conn.sfile = conn.sfile.filter(v => v.jid !== m.sender);
                if (check?.key) conn.sendMessage(m.chat, { delete: check.key });

                return;
            }

            const results = await searchSFile(query);
            if (!results.length) throw `"${text}" Not found / No results!`;

            let txt = `To download the file, use this command *${usedPrefix + command} (number)*\n`;
            txt += `*Example* : ${usedPrefix + command} 1\n\n`;
            results.forEach((v, i) => {
                txt += `[${i + 1}]\n- *Title* : ${v.title}\n`;
                txt += `- *Size* : ${v.size}\n`;
                txt += `- *Link* : ${v.link}\n\n`;
            });

            const sent = await m.reply(txt);

            const session = {
                jid: m.sender,
                results: results,
                created_at: Date.now(),
                key: sent.key
            };

            const old = conn.sfile.find(v => v.jid === m.sender);
            if (old) Object.assign(old, session);
            else conn.sfile.push(session);

            setTimeout(() => {
                const ses = conn.sfile.find(v => v.jid === m.sender);
                if (ses && Date.now() - ses.created_at > timer) {
                    conn.sendMessage(m.chat, { delete: ses.key });
                    conn.sfile = conn.sfile.filter(v => v.jid !== m.sender);
                }
            }, timer + 1000);
        } catch (e) {
            console.error(e);
            throw Func.jsonFormat(e);
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingSfile = false;
            }
        }
    }
};