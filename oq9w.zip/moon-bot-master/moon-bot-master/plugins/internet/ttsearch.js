/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require("axios");

module.exports = {
  help: ['ttsearch'],
  aliases: ['ttsv', 'tiktoksearch'],
  tags: 'internet',
  limit: true,
  register: true,      
  run: async (m, { text, Func, usedPrefix, command, conn }) => {
    try {
      let user = global.db.users[m.sender] || {};
      user.isProcessingTtsearch = user.isProcessingTtsearch || false;

      if (user.isProcessingTtsearch) throw global.status.previously
      if (!text) throw `Please provide a title.\n\n*Example* : ${usedPrefix + command} TechBOT`

      user.isProcessingTtsearch = true;

      const timer = 18000; // 18 detik
      conn.ttSearch = conn.ttSearch || [];

      const check = conn.ttSearch.find(v => v.jid === m.sender);
      const query = check ? text : text.trim();

      if (check && !isNaN(query)) {
        const num = Number(query);
        if (num > check.results.length) throw 'Exceeds the amount of Data.'

        const selectedVideo = check.results[num - 1];
        
        m.react(global.react);
        
        try {
          await conn.sendMessage(m.chat, {
            video: { url: selectedVideo.url },
            caption: `*TIKTOK VIDEO*\n\n` +
                     `- *Author* : ${selectedVideo.author}\n` +
                     `- *Title* : ${selectedVideo.title}\n` +
                     `- *Views* : ${selectedVideo.views}\n` +
                     `- *Likes* : ${selectedVideo.likes}`,
            mentions: [m.sender]
          }, { quoted: m });

          await conn.sendMessage(m.chat, {
            audio: { url: selectedVideo.url },
            mimetype: 'audio/mpeg',
            fileName: `${selectedVideo.title}.mp3`.substring(0, 100)
          }, { quoted: m });

        } catch (downloadError) {
          console.error(downloadError);
          m.reply('Failed to download video. Please try another number.');
        }

        conn.ttSearch = conn.ttSearch.filter(v => v.jid !== m.sender);
        if (check?.key) {
          try {
            await conn.sendMessage(m.chat, { delete: check.key });
          } catch (e) {
            console.log(e);
          }
        }

        return;
      }

      m.react(global.react);
      
      const results = await searchTikTok(query);
      if (!results || results.length === 0) throw `"${text}" Not found / No results!`
      
      let txt = `To download the video, use this command *${usedPrefix + command} (number)*\n`;
      txt += `*Example* : ${usedPrefix + command} 1\n\n`;
      
      results.forEach((video, i) => {
        const isPopular = parseInt(video.views.replace(/,/g, '')) >= 1000000;
        txt += `[${i + 1}]\n`;
        txt += `- *Title* : ${video.title} ${isPopular ? '(🔥Popular)' : ''}\n`;
        txt += `- *Author* : ${video.author}\n`;
        txt += `- *Views* : ${video.views}\n`;
        txt += `- *Likes* : ${video.likes}\n\n`;
      });

      const sent = await m.reply(txt);

      const session = {
        jid: m.sender,
        results: results,
        created_at: Date.now(),
        key: sent.key
      };

      const old = conn.ttSearch.find(v => v.jid === m.sender);
      if (old) Object.assign(old, session);
      else conn.ttSearch.push(session);

      setTimeout(() => {
        const ses = conn.ttSearch.find(v => v.jid === m.sender);
        if (ses && Date.now() - ses.created_at > timer) {
          try {
            conn.sendMessage(m.chat, { delete: ses.key });
          } catch (e) {
            console.log('Failed to delete message:', e);
          }
          conn.ttSearch = conn.ttSearch.filter(v => v.jid !== m.sender);
        }
      }, timer + 1000);

    } catch (e) {
      throw Func.jsonFormat(e)
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingTtsearch = false;
      }
    }
  }
};

async function searchTikTok(query) {
  try {
    const response = await axios({
      method: 'POST',
      url: 'https://tikwm.com/api/feed/search',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Cookie': 'current_language=en',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
      },
      data: {
        keywords: query,
        count: 10,
        cursor: 0,
        HD: 1
      }
    });

    const videos = response.data?.data?.videos || [];
    return videos.map((video) => ({
      title: video.title || 'No title',
      author: video.author?.nickname || 'Unknown author',
      description: video.text || '',
      views: video.stats?.playCount?.toLocaleString() || '-',
      likes: video.stats?.diggCount?.toLocaleString() || '-',
      url: video.play || video.download || video.hdplay || '',
      thumbnail: video.thumbnail || video.cover || ''
    }));
    
  } catch (error) {
    console.error(error);
    throw new Error('Failed to search TikTok');
  }
}