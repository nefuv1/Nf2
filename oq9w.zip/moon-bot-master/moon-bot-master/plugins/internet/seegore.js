/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const cheerio = require('cheerio');
const axios = require('axios');

const seegore = {
    search: async (query) => {
        const { data } = await axios.get(`https://seegore.com/?s=${query}`);
        const $ = cheerio.load(data);
        const result = [];

        $('#post-items > li').each((i, el) => {
            result.push({
                judul: $(el).find('h2 > a').text(),
                uploader: $(el).find('.bb-cat-links > a').text(),
                thumb: $(el).find('.post-thumbnail img').attr('src'),
                link: $(el).find('h2 > a').attr('href')
            });
        });

        return result;
    },

    download: async (link) => {
        const { data } = await axios.get(link);
        const $ = cheerio.load(data);
        return {
            judul: $('div.single-main-container h1').text(),
            views: $('div.s-post-meta-block span.count').first().text(),
            comment: $('div.s-post-meta-block a span.count').text(),
            link: $('video > source').attr('src')
        };
    }
};

module.exports = {
    help: ['seegore'],
    tags: 'internet',
    aliases: ['gore'],
    premium: true,
    register: true,
    limit: 30,
    private: true,
    run: async (m, { conn, text, usedPrefix, Func, command }) => {
        try {
            let user = global.db.users[m.sender] || {};
            user.isProcessingSeegore = user.isProcessingSeegore || false;
            
            if (user.isProcessingSeegore) throw global.status.previously
            if (!text) throw `Please provide a title.\n\n*Example* : ${usedPrefix + command} TechBOT`
            
            user.isProcessingSeegore = true;
            m.react(global.react);

            const results = await seegore.search(text);
            if (!results || results.length === 0) {
                throw `"${text}" Not found / No results!`
            }

            const random = results[Math.floor(Math.random() * results.length)];
            const videoInfo = await seegore.download(random.link);

            await conn.sendFile(
                m.chat,
                videoInfo.link,
                '',
                `*SEEGORE*\n\n- *Title* : ${videoInfo.judul}\n- *Views* : ${videoInfo.views}\n- *Comment* : ${videoInfo.comment}`,
                m
            );

        } catch (e) {
            console.error(e);
           throw Func.jsonFormat(e)
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingSeegore = false;
            }
        }
    }
};

module.exports.seegore = seegore;