/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const fetch = require('node-fetch');
const crypto = require('crypto');
const ytSearch = require('yt-search');

class Youtubers {
    constructor() {
        this.hex = "C5D58EF67A7584E4A29F6C35BBC4EB12";
    }

    async uint8(hex) {
        const pecahan = hex.match(/[\dA-F]{2}/gi);
        if (!pecahan) throw new Error("Invalid format");
        return new Uint8Array(pecahan.map(h => parseInt(h, 16)));
    }

    b64Byte(b64) {
        const bersih = b64.replace(/\s/g, "");
        const biner = Buffer.from(bersih, 'base64').toString('binary');
        const hasil = new Uint8Array(biner.length);
        for (let i = 0; i < biner.length; i++) hasil[i] = biner.charCodeAt(i);
        return hasil;
    }

    async key() {
        const raw = await this.uint8(this.hex);
        return await crypto.webcrypto.subtle.importKey("raw", raw, { name: "AES-CBC" }, false, ["decrypt"]);
    }

    async Data(base64Terenkripsi) {
        const byteData = this.b64Byte(base64Terenkripsi);
        if (byteData.length < 16) throw new Error("Data is too short");

        const iv = byteData.slice(0, 16);
        const data = byteData.slice(16);

        const kunci = await this.key();
        const hasil = await crypto.webcrypto.subtle.decrypt(
            { name: "AES-CBC", iv },
            kunci,
            data
        );

        const teks = new TextDecoder().decode(new Uint8Array(hasil));
        return JSON.parse(teks);
    }

    async getCDN() {
        const res = await fetch("https://media.savetube.me/api/random-cdn");
        const data = await res.json();
        return data.cdn;
    }

    async infoVideo(linkYoutube) {
        const cdn = await this.getCDN();
        const res = await fetch(`https://${cdn}/v2/info`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ url: linkYoutube }),
        });

        const hasil = await res.json();
        if (!hasil.status) throw new Error(hasil.message || "Failed to retrieve video data");

        const isi = await this.Data(hasil.data);
        return {
            judul: isi.title,
            durasi: isi.durationLabel,
            thumbnail: isi.thumbnail,
            kode: isi.key,
            kualitas: isi.video_formats.map(f => ({
                label: f.label,
                kualitas: f.height,
                default: f.default_selected
            })),
            infoLengkap: isi
        };
    }

    async getDownloadLink(kodeVideo, kualitas, type) {
        const cdn = await this.getCDN();
        const res = await fetch(`https://${cdn}/download`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                downloadType: kualitas === "128" ? "audio" : type,
                quality: kualitas,
                key: kodeVideo,
            }),
        });

        const json = await res.json();
        if (!json.status) throw new Error(json.message);
        return json.data.downloadUrl;
    }

    async downloadyt(linkYoutube, kualitas, type) {
        try {
            const data = await this.infoVideo(linkYoutube);
            const linkUnduh = await this.getDownloadLink(data.kode, kualitas, type);
            return {
                status: true,
                judul: data.judul,
                kualitasTersedia: data.kualitas,
                thumbnail: data.thumbnail,
                durasi: data.durasi,
                url: linkUnduh,
            };
        } catch (err) {
            return {
                sukses: false,
                pesan: err.message
            };
        }
    }
}

module.exports = {
    help: ['song'],
    tags: 'internet',
    aliases: ['playmp3'],
    limit: 30,
    premium: true,
    register: true,
    run: async (m, { conn, text, usedPrefix, command }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingSong = user.isProcessingSong || false;

        if (user.isProcessingSong) throw global.status.previously
        if (!text) throw `Please provide a title.\n\n*Example* : ${usedPrefix + command} TechBOT`

        user.isProcessingSong = true;
        m.react(global.react);

        try {
            let url = text;
            if (!text.includes("youtube.com") && !text.includes("youtu.be")) {
                const search = await ytSearch(text);
                const video = search.videos[0];
                if (!video) throw `"${text}" Not found / No results!`
                url = video.url;
            }

            const yt = new Youtubers();
            const hasil = await yt.downloadyt(url, "128", "audio");

            if (!hasil.status) throw `Failed to download audio : ${hasil.pesan}`

            await conn.sendMessage(m.chat, {
                audio: { url: hasil.url },
                mimetype: 'audio/mp4',
                fileName: `${hasil.judul}.mp3`,
                ptt: false
            }, { quoted: m });

        } catch (e) {
            console.error(e);
            throw Func.jsonFormat(e)
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingSong = false;
            }
        }
    }
};