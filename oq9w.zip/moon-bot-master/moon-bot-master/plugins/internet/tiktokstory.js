/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');

const query = [
    'story%20wa', 'story%20sad', 'story%20wa%20galau', 'video%20meme',
    'story%20wa%20sindiran', 'story%20wa%20bahagia', 'story%20wa%20lirik%20lagu%20overlay',
    'story%20wa%20lirik%20lagu', 'video%20viral', 'video%20lucu', 'meme'
];

async function tiktoks(q) {
    try {
        const { data } = await axios({
            method: 'POST',
            url: 'https://tikwm.com/api/feed/search',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Cookie': 'current_language=en',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
            },
            data: { keywords: q, count: 10, cursor: 0, HD: 1 }
        });

        const videos = data.data.videos;
        if (!videos || videos.length === 0) throw new Error("No videos found.");

        const vid = videos[Math.floor(Math.random() * videos.length)];
        return {
            title: vid.title,
            no_watermark: vid.play,
            music: vid.music
        };
    } catch (err) {
        throw err;
    }
}

module.exports = {
    aliases: ['ttstory', 'ttsy'],
    tags: 'internet',
    help: ['tiktokstory'],
    limit: true,
    register: true,
    run: async (m, { conn, Func }) => {
        try {
            let user = global.db.users[m.sender] || {};
            user.isProcessingTtstory = user.isProcessingTtstory || false;
            
            if (user.isProcessingTtstory) throw global.status.previously
            
            user.isProcessingTtstory = true;
            m.react(global.react);

            let randomQuery = query[Math.floor(Math.random() * query.length)];
            let videoData = await tiktoks(randomQuery);

            await conn.sendMessage(m.chat, {
                video: { url: videoData.no_watermark },
                caption: videoData.title
            }, { quoted: m });

            await conn.sendMessage(m.chat, {
                audio: { url: videoData.music },
                mimetype: 'audio/mp4',
                fileName: `${videoData.title}.mp3`
            }, { quoted: m });

        } catch (err) {
           throw Func.jsonFormat(e)
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingTtstory = false;
            }
        }
    }
};