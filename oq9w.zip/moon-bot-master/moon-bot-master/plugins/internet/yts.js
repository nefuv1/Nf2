/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const yts = require('yt-search')

module.exports = {
  help: ['ytsearch'],
  aliases: ['yts'],
  tags: 'internet',
  limit: true,
  register: true,    
  run: async (m, { text, usedPrefix, command, Func }) => {
    try {
      let user = global.db.users[m.sender] || {};
      user.isProcessingYtsearch = user.isProcessingYtsearch || false;
      
      if (user.isProcessingYtsearch) throw global.status.previously
      if (!text) throw `Please provide a title.\n\n*Example* : ${usedPrefix + command} TechBOT`
      
      user.isProcessingYtsearch = true;
      
      m.react(global.react)
      
      const searchResults = await yts(text)
      if (!searchResults.all || searchResults.all.length === 0) {
        throw `"${text}" Not found / No results!`
      }
      
      let resultText = `*YOUTUBE SEARCH*\n\n`
      searchResults.all.slice(0, 10).forEach((video, index) => {
        const isPopular = video.views >= 1000000
        resultText += `[${index + 1}]\n`
        resultText += `- *Title* : ${video.title}${isPopular ? ' (🔥Popular)' : ''}\n`
        resultText += `- *Duration* : ${video.timestamp || 'N/A'}\n`
        resultText += `- *Views* : ${video.views ? video.views.toLocaleString() : 'N/A'}\n`
        resultText += `- *Uploaded* : ${video.ago || 'N/A'}\n`
        resultText += `- *URL* : ${video.url || 'N/A'}\n\n`
      })
      
      await m.reply(resultText.trim())
      
    } catch (e) {
      console.error(e)
           throw Func.jsonFormat(e)
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingYtsearch = false;
      }
    }
  }
}