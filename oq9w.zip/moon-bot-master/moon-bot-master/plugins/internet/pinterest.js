/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');

function getRandomItem(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

const pins = async (judul) => {
  const url = `https://id.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${encodeURIComponent(judul)}%26rs%3Dtyped&data=%7B%22options%22%3A%7B%22applied_unified_filters%22%3Anull%2C%22appliedProductFilters%22%3A%22---%22%2C%22article%22%3Anull%2C%22auto_correction_disabled%22%3Afalse%2C%22corpus%22%3Anull%2C%22customized_rerank_type%22%3Anull%2C%22domains%22%3Anull%2C%22dynamicPageSizeExpGroup%22%3A%22control%22%2C%22filters%22%3Anull%2C%22journey_depth%22%3Anull%2C%22page_size%22%3A50%2C%22price_max%22%3Anull%2C%22price_min%22%3Anull%2C%22query_pin_sigs%22%3Anull%2C%22query%22%3A%22${encodeURIComponent(judul)}%22%2C%22redux_normalize_feed%22%3Atrue%2C%22request_params%22%3Anull%2C%22rs%22%3A%22typed%22%2C%22scope%22%3A%22pins%22%2C%22selected_one_bar_modules%22%3Anull%2C%22seoDrawerEnabled%22%3Afalse%2C%22source_id%22%3Anull%2C%22source_module_id%22%3Anull%2C%22source_url%22%3A%22%2Fsearch%2Fpins%2F%3Fq%3D${encodeURIComponent(judul)}%26rs%3Dtyped%22%2C%22top_pin_id%22%3Anull%2C%22top_pin_ids%22%3Anull%7D%2C%22context%22%3A%7B%7D%7D`;

  const headers = {
    'accept': 'application/json, text/javascript, */*; q=0.01',
    'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
    'priority': 'u=1, i',
    'referer': 'https://id.pinterest.com/',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
    'x-app-version': 'c056fb7',
    'x-pinterest-appstate': 'active',
    'x-pinterest-pws-handler': 'www/index.js',
    'x-pinterest-source-url': '/',
    'x-requested-with': 'XMLHttpRequest'
  };

  try {
    const res = await axios.get(url, { headers });
    const results = res?.data?.resource_response?.data?.results;

    if (!results || !results.length) return null;

    const images = results
      .map(item => item?.images)
      .filter(img => img)
      .map(img => img.orig?.url || img['564x']?.url || img['236x']?.url)
      .filter(Boolean);

    return getRandomItem(images);
  } catch (e) {
    console.error(`Pinterest error : ${e.message}`);
    return null;
  }
};

module.exports = {
  help: ['pinterest'],
  tags: 'internet',
  aliases: ['pin'],
  limit: true,
  register: true,
  run: async (m, { conn, text, usedPrefix, command, Func, args }) => {
    try {
      let user = global.db.users[m.sender] || {};
      user.isProcessingPinterest = user.isProcessingPinterest || false;
      
      if (user.isProcessingPinterest) throw global.status.previously
      if (!args[0]) throw `Please provide a title.\n\n*Example* : ${usedPrefix + command} TechBOT`
      
      user.isProcessingPinterest = true;
      m.react(global.react);

      let query = args.join(' ');
      let image = await pins(query);

      if (!image) throw `"${query}" Not found / No results!`

      await conn.sendMessage(m.chat, {
        image: { url: image },
        caption: query
      }, { quoted: m });

    } catch (e) {
      console.error(e);
      throw Func.jsonFormat(e)
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingPinterest = false;
      }
    }
  }
};