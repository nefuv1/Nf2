/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');

async function getAccessToken() {
    try {
        const client_id = 'acc6302297e040aeb6e4ac1fbdfd62c3';
        const client_secret = '0e8439a1280a43aba9a5bc0a16f3f009';
        const basic = Buffer.from(`${client_id}:${client_secret}`).toString("base64");
        const response = await axios.post('https://accounts.spotify.com/api/token', 'grant_type=client_credentials', {
            headers: {
                Authorization: `Basic ${basic}`,
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            timeout: 10000
        });
        const data = response.data;
        return data.access_token;
    } catch (error) {
        console.error('Error getting Spotify access token:', error);
        throw 'Error mendapatkan akses token Spotify.';
    }
}

async function searchSpotify(query) {
    try {
        const access_token = await getAccessToken();
        const response = await axios.get(`https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=track&limit=10`, {
            headers: {
                Authorization: `Bearer ${access_token}`,
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            timeout: 15000
        });
        
        const data = response.data;
        const tracks = data.tracks.items.map(item => ({
            name: item.name,
            artists: item.artists.map(artist => artist.name).join(', '),
            popularity: item.popularity,
            link: item.external_urls.spotify,
            image: item.album.images[0]?.url,
            duration_ms: item.duration_ms,
            album: item.album.name
        }));
        return tracks;
    } catch (error) {
        console.error('Error searching Spotify:', error);
        throw 'Error saat mencari lagu di Spotify.';
    }
}

async function spotifydl(url) {
    try {
        const spotifyResponse = await axios.get(
            `https://api.fabdl.com/spotify/get?url=${encodeURIComponent(url)}`,
            {
                headers: {
                    accept: "application/json, text/plain, */*",
                    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                    "sec-ch-ua": "\"Not)A;Brand\";v=\"24\", \"Chromium\";v=\"116\"",
                    "sec-ch-ua-mobile": "?1",
                    "sec-ch-ua-platform": "\"Android\"",
                    "sec-fetch-dest": "empty",
                    "sec-fetch-mode": "cors",
                    "sec-fetch-site": "cross-site",
                    Referer: "https://spotifydownload.org/",
                    "Referrer-Policy": "strict-origin-when-cross-origin",
                },
                timeout: 30000
            }
        );

        const spotifyData = spotifyResponse.data.result;
        if (!spotifyData || !spotifyData.gid || !spotifyData.id) {
            throw new Error('Invalid response from Spotify API');
        }

        const mp3Response = await axios.get(
            `https://api.fabdl.com/spotify/mp3-convert-task/${spotifyData.gid}/${spotifyData.id}`,
            {
                headers: {
                    accept: "application/json, text/plain, */*",
                    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                    "sec-ch-ua": "\"Not)A;Brand\";v=\"24\", \"Chromium\";v=\"116\"",
                    "sec-ch-ua-mobile": "?1",
                    "sec-ch-ua-platform": "\"Android\"",
                    "sec-fetch-dest": "empty",
                    "sec-fetch-mode": "cors",
                    "sec-fetch-site": "cross-site",
                    Referer: "https://spotifydownload.org/",
                    "Referrer-Policy": "strict-origin-when-cross-origin",
                },
                timeout: 30000
            }
        );

        const mp3Data = mp3Response.data.result;
        if (!mp3Data || !mp3Data.download_url) {
            throw new Error('Invalid response from MP3 convert task API');
        }

        return {
            title: spotifyData.name,
            type: spotifyData.type,
            artist: spotifyData.artists,
            duration: spotifyData.duration_ms,
            image: spotifyData.image,
            download: `https://api.fabdl.com${mp3Data.download_url}`
        };
    } catch (error) {
        console.error('Error during Spotify download process:', error);
        throw new Error('Failed to download the audio');
    }
}

function formatDuration(ms) {
    const minutes = Math.floor(ms / 60000);
    const seconds = ((ms % 60000) / 1000).toFixed(0);
    return minutes + ":" + (seconds < 10 ? '0' : '') + seconds;
}

module.exports = {
    help: ['spotify'],
    aliases: ['sfy', 'sps', 'sptfy'],
    tags: 'internet',
    limit: true,
    register: true,
    run: async (m, { conn, text, usedPrefix, command, Func }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingSpotify = user.isProcessingSpotify || false;

        if (user.isProcessingSpotify) throw global.status.previously;
        if (!text) throw `Please provide a title / URL.\n\n*Example* :\n1. ${usedPrefix + command} TechBOT\n2. ${usedPrefix + command} https://open.spotify.com/track/4S1VYqwfkLit9mKVY3MXoo`;

        user.isProcessingSpotify = true;
        m.react(global.react);

        try {
            const timer = 18000; // 18 detik
            conn.spotify = conn.spotify || [];

            const check = conn.spotify.find(v => v.jid === m.sender);
            const query = check ? text : text.trim();

            if (query.match(/https:\/\/open.spotify.com/gi)) {
                const download = await spotifydl(query);
            
                let caption = `*SPOTIFY DOWNLOAD*\n\n`;
                caption += `- *Title* : ${download.title}\n`;
                caption += `- *Artist* : ${download.artist}\n`;
                caption += `- *Duration* : ${formatDuration(download.duration)}\n`;
                caption += `- *Type* : ${download.type}`;
            
                await conn.sendMessageModify(m.chat, caption, m, {
                    largeThumb: true,
                    thumbnail: download.image
                });
            
                await conn.sendMessage(m.chat, {
                    audio: { url: download.download },
                    mimetype: 'audio/mpeg',
                    fileName: download.title + '.mp3'
                }, { quoted: m });
            
                return;
            }
            
            if (check && !isNaN(query)) {
                const num = Number(query);
                if (num > check.results.length) throw 'Exceeds the amount of Data.';
            
                const selected = check.results[num - 1];
                const download = await spotifydl(selected.link);
            
                let caption = `*SPOTIFY DOWNLOAD*\n\n`;
                caption += `- *Title* : ${selected.name}\n`;
                caption += `- *Artist* : ${selected.artists}\n`;
                caption += `- *Duration* : ${formatDuration(selected.duration_ms)}\n`;
                caption += `- *Popularity* : ${selected.popularity}%`;
            
                await conn.sendMessageModify(m.chat, caption, m, {
                    largeThumb: true,
                    thumbnail: selected.image
                });
            
                await conn.sendMessage(m.chat, {
                    audio: { url: download.download },
                    mimetype: 'audio/mpeg',
                    fileName: selected.name + '.mp3'
                }, { quoted: m });
            
                if (conn.spotify) conn.spotify = conn.spotify.filter(v => v.jid !== m.sender);
                if (check?.key) conn.sendMessage(m.chat, { delete: check.key });
            
                return;
            }

            const results = await searchSpotify(query);
            if (!results.length) throw `"${text}" Not found / No results!`;

            let txt = `To download the audio, use this command *${usedPrefix + command} (number)*\n`;
            txt += `*Example* : ${usedPrefix + command} 1\n\n`;
            results.forEach((v, i) => {
                const isPopular = v.popularity >= 80;
                txt += `[${i + 1}]\n- *Title* : ${v.name} ${isPopular ? '(Popular)' : ''}\n`;
                txt += `- *Artist* : ${v.artists}\n`;
                txt += `- *Duration* : ${formatDuration(v.duration_ms)}\n`;
                txt += `- *Popularity* : ${v.popularity}%\n`;
                txt += `- *Album* : ${v.album}\n\n`;
            });

            const sent = await m.reply(txt);

            const session = {
                jid: m.sender,
                results: results,
                created_at: Date.now(),
                key: sent.key
            };

            const old = conn.spotify.find(v => v.jid === m.sender);
            if (old) Object.assign(old, session);
            else conn.spotify.push(session);

            setTimeout(() => {
                const ses = conn.spotify.find(v => v.jid === m.sender);
                if (ses && Date.now() - ses.created_at > timer) {
                    conn.sendMessage(m.chat, { delete: ses.key });
                    conn.spotify = conn.spotify.filter(v => v.jid !== m.sender);
                }
            }, timer + 1000);
        } catch (e) {
            console.error(e);
            throw Func.jsonFormat(e);
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingSpotify = false;
            }
        }
    }
};