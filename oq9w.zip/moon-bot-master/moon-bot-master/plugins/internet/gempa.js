/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

module.exports = {
  help: ['gempa'],
  tags: 'internet',
  limit: true,
  register: true,
  run: async (m, { usedPrefix, command, conn }) => {
    try {
      let user = global.db.users[m.sender] || {};
      user.isProcessingGempa = user.isProcessingGempa || false;
      
      if (user.isProcessingGempa) return m.reply(global.status.previously);
      
      user.isProcessingGempa = true;
      if (typeof global?.react === 'string') m.react(global.react);

      const fetch = require('node-fetch');
      const response = await fetch('https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json');
      const { gempa } = (await response.json()).Infogempa;

      let teks = `*GEMPA INFO*\n\n`;
      teks += `- *Date* : ${gempa.Tanggal}\n`;
      teks += `- *At* : ${gempa.Jam}\n`;
      teks += `- *Magnitude* : ${gempa.Magnitude}\n`;
      teks += `- *Coordinate* : ${gempa.Coordinates}\n`;
      teks += `- *Latitude* : ${gempa.Lintang}\n`;
      teks += `- *Longitude* : ${gempa.Bujur}\n`;
      teks += `- *Depth* : ${gempa.Kedalaman}\n`;
      teks += `- *Region* : ${gempa.Wilayah}\n`;
      teks += `- *Potential* : ${gempa.Potensi}\n`;
      teks += `- *Sensed* : ${gempa.Dirasakan || '-'}`;

      const shakemapUrl = `https://data.bmkg.go.id/DataMKG/TEWS/${gempa.Shakemap}`;
      await conn.sendFile(m.chat, shakemapUrl, '', teks, m);

    } catch (e) {
      console.error(e);
           throw Func.jsonFormat(e)
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingGempa = false;
      }
    }
  }
};