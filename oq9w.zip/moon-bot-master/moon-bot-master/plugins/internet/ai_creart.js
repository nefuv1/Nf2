/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require("axios");
const FormData = require("form-data");

module.exports = {
  help: ['creart'],
  tags: 'ai',
  aliases: ['aiart', 'art'],
  limit: 10,
  register: true,
  run: async (m, { conn, usedPrefix, command, text }) => {
    let user = global.db.users[m.sender] || {};
    user.isProcessingCreart = user.isProcessingCreart || false;

    if (user.isProcessingCreart) {
      throw global.status.previously
    }

    if (!text) throw `Please provide a prompt.\n\n*Example* : ${usedPrefix + command} TechBOT`
    
    user.isProcessingCreart = true;

    try {
      
      let { key } = await m.reply('Generating images...');
      
      const translatedPrompt = await translateToEnglish(text);
      const imageBuffer = await creartTxt2Img(translatedPrompt);
      
      await conn.sendMessage(m.chat, {
        image: imageBuffer,
        caption: `${translatedPrompt}`
      }, { quoted: m });     
      
      await conn.sendMessage(m.chat, {
        text: "Done. 👍",
        edit: key,
      });
      
    } catch (e) {
      console.error(e);
           throw Func.jsonFormat(e)
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingCreart = false;
      }
    }
  }
}

/**
 * Translate teks otomatis ke bahasa Inggris
 */
async function translateToEnglish(text) {
  try {
    const url = "https://translate.googleapis.com/translate_a/single";
    const params = {
      client: "gtx",
      sl: "auto",
      tl: "en",
      dt: "t",
      q: text,
    };

    const res = await axios.get(url, { params });
    return res.data[0][0][0];
  } catch (err) {
    console.error("Translate Error :", err.message);
    return text;
  }
}

/**
 * Text2Image - bikin gambar dari teks
 */
async function creartTxt2Img(prompt) {
  try {
    const form = new FormData();
    form.append("prompt", prompt);
    form.append("input_image_type", "text2image");
    form.append("aspect_ratio", "4x5");
    form.append("guidance_scale", "9.5");
    form.append("controlnet_conditioning_scale", "0.5");

    const response = await axios.post(
      "https://api.creartai.com/api/v2/text2image",
      form,
      {
        headers: form.getHeaders(),
        responseType: "arraybuffer",
      }
    );

    return Buffer.from(response.data);
  } catch (err) {
    throw new Error("Failed to create image : " + (err?.message || err));
  }
}