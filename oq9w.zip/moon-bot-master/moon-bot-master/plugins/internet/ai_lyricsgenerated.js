/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');

module.exports = {
    help: ['lyricsgenerated'],
    aliases: ['songlyrics', 'lirikgen', 'lyrics_generated', 'lirycsgen'],
    tags: 'ai',
    limit: 3, 
    register: true,    
    run: async (m, { text, conn, Func, usedPrefix, command }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingLyrics = user.isProcessingLyrics || false;

        if (user.isProcessingLyrics) throw global.status.previously;
        user.isProcessingLyrics = true;

        try {
            if (!text) {
                throw `Please provide lyrics.\n\n*Example* : ${usedPrefix + command} TechBOT`
            }

            m.react(global.react);

            const apiUrl = 'https://lyrics-generator.tommy-ni1997.workers.dev/';
            const payload = { prompt: text };

            const headers = {
                'accept': 'application/json',
                'content-type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36',
                'Referer': 'https://aisonggenerator.io/'
            };

            const response = await axios.post(apiUrl, payload, { headers });

            if (response.data && response.data.lyrics) {
                const title = response.data.title || 'Untitled';
                const style = response.data.style || 'Unknown Style';
                const lyrics = response.data.lyrics;

                let message = `*LYRICS GENERATED*\n\n` +
                              `- *Title* : ${title}\n` +
                              `- *Style* : ${style}\n\n` +
                              `- *Lyrics* : \n\n${lyrics}`;

                await m.reply(message);
            } else {
               throw 'Failed to generate song lyrics. Please try again later.';
            }
        } catch (e) {
            console.error(e);
            throw Func.jsonFormat(e);
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingLyrics = false;
            }
        }
    }
};