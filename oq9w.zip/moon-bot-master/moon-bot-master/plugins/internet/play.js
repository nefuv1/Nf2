/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const ytSearch = require('yt-search')
const fetch = require('node-fetch')
const crypto = require('crypto')

class Youtubers {
    constructor() {
        this.hex = "C5D58EF67A7584E4A29F6C35BBC4EB12";
    }

    async uint8(hex) {
        const pecahan = hex.match(/[\dA-F]{2}/gi);
        if (!pecahan) throw new Error("Format tidak valid");
        return new Uint8Array(pecahan.map(h => parseInt(h, 16)));
    }

    b64Byte(b64) {
        const bersih = b64.replace(/\s/g, "");
        const biner = Buffer.from(bersih, 'base64').toString('binary');
        const hasil = new Uint8Array(biner.length);
        for (let i = 0; i < biner.length; i++) hasil[i] = biner.charCodeAt(i);
        return hasil;
    }

    async key() {
        const raw = await this.uint8(this.hex);
        return await crypto.webcrypto.subtle.importKey("raw", raw, { name: "AES-CBC" }, false, ["decrypt"]);
    }

    async Data(base64Terenkripsi) {
        const byteData = this.b64Byte(base64Terenkripsi);
        if (byteData.length < 16) throw new Error("Data is too short");

        const iv = byteData.slice(0, 16);
        const data = byteData.slice(16);

        const kunci = await this.key();
        const hasil = await crypto.webcrypto.subtle.decrypt(
            { name: "AES-CBC", iv },
            kunci,
            data
        );

        const teks = new TextDecoder().decode(new Uint8Array(hasil));
        return JSON.parse(teks);
    }

    async getCDN() {
        const res = await fetch("https://media.savetube.me/api/random-cdn");
        const data = await res.json();
        return data.cdn;
    }

    async infoVideo(linkYoutube) {
        const cdn = await this.getCDN();
        const res = await fetch(`https://${cdn}/v2/info`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ url: linkYoutube }),
        });

        const hasil = await res.json();
        if (!hasil.status) throw new Error(hasil.message || "Failed to retrieve video data");

        const isi = await this.Data(hasil.data);
        return {
            judul: isi.title,
            durasi: isi.durationLabel,
            thumbnail: isi.thumbnail,
            kode: isi.key,
            kualitas: isi.video_formats.map(f => ({
                label: f.label,
                kualitas: f.height,
                default: f.default_selected
            })),
            infoLengkap: isi
        };
    }

    async getDownloadLink(kodeVideo, kualitas, type) {
        const cdn = await this.getCDN();
        const res = await fetch(`https://${cdn}/download`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                downloadType: kualitas === "128" ? "audio" : type,
                quality: kualitas,
                key: kodeVideo,
            }),
        });

        const json = await res.json();
        if (!json.status) throw new Error(json.message);
        return json.data.downloadUrl;
    }

    async downloadyt(linkYoutube, kualitas, type) {
        try {
            const data = await this.infoVideo(linkYoutube);
            const linkUnduh = await this.getDownloadLink(data.kode, kualitas, type);
            return {
                status: true,
                judul: data.judul,
                kualitasTersedia: data.kualitas,
                thumbnail: data.thumbnail,
                durasi: data.durasi,
                url: linkUnduh,
            };
        } catch (err) {
            return {
                sukses: false,
                pesan: err.message
            };
        }
    }
}

module.exports = {
  help: ['play'],
  tags: 'internet',
  limit: true,
  register: true,
  run: async (m, { conn, text, usedPrefix, command, Func }) => {
    let user = global.db.users[m.sender] || {};
    user.isProcessingPlay = user.isProcessingPlay || false;

    if (user.isProcessingPlay) throw global.status.previously
    if (!text) throw `Please provide a title.\n\n*Example* : ${usedPrefix + command} TechBOT`

    user.isProcessingPlay = true;
    m.react(global.react);

    try {
      const timer = 18000 // 18 detik
      conn.play = conn.play || []

      const check = conn.play.find(v => v.jid === m.sender)
      const query = check ? text : text.trim()

      if (check && !isNaN(query)) {
        const num = Number(query)
        if (num > check.results.length) throw 'Exceeds the amount of Data.'

        const selected = check.results[num - 1]
        const yt = new Youtubers();
        const info = await yt.downloadyt(selected.url, "128", "audio");

        if (!info.status) throw `Failed to download audio : ${info.pesan}`

        let caption = `*YOUTUBE PLAY*\n\n`
        caption += `- *Title* : ${selected.title}\n`
        caption += `- *Duration* : ${selected.timestamp}\n`
        caption += `- *Views* : ${selected.views}\n`
        caption += `- *Uploaded* : ${selected.ago}`

        await conn.sendMessageModify(m.chat, caption, m, {
          largeThumb: true,
          thumbnail: selected.thumbnail
        })

        await conn.sendMessage(m.chat, {
          audio: { url: info.url },
          mimetype: 'audio/mpeg',
          fileName: selected.title + '.mp3'
        }, { quoted: m })

        if (conn.play) conn.play = conn.play.filter(v => v.jid !== m.sender)
        if (check?.key) conn.sendMessage(m.chat, { delete: check.key })

        return
      }

      const res = await ytSearch(query)
      const videos = res.videos.slice(0, 10)
      if (!videos.length) throw `"${text}" Not found / No results!`

      let txt = `To download the audio, use this command *${usedPrefix + command} (number)*\n`
      txt += `*Example* : ${usedPrefix + command} 1\n\n`
      videos.forEach((v, i) => {
        const isPopular = v.views >= 10_000_000
        txt += `[${i + 1}]\n- *Title* : ${v.title} ${isPopular ? '(🔥Popular)' : ''}\n`
        txt += `- *Duration* : ${v.timestamp}\n`
        txt += `- *Views* : ${v.views}\n`
        txt += `- *Uploaded* : ${v.ago}\n`
        txt += `- *Url* : ${v.url}\n\n`
      })

      const sent = await m.reply(txt)

      const session = {
        jid: m.sender,
        results: videos,
        created_at: Date.now(),
        key: sent.key
      }

      const old = conn.play.find(v => v.jid === m.sender)
      if (old) Object.assign(old, session)
      else conn.play.push(session)

      setTimeout(() => {
        const ses = conn.play.find(v => v.jid === m.sender)
        if (ses && Date.now() - ses.created_at > timer) {
          conn.sendMessage(m.chat, { delete: ses.key })
          conn.play = conn.play.filter(v => v.jid !== m.sender)
        }
      }, timer + 1000)
    } catch (e) {
      console.error(e)
      throw Func.jsonFormat(e)
    } finally {
      if (global.db.users[m.sender]) {
        global.db.users[m.sender].isProcessingPlay = false;
      }
    }
  }
}