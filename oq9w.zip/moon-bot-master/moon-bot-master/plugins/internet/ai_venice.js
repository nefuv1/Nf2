/**
* By : AgungDEV
* Note's : Yang nyolong fitur ini semoga jadi orang yang tidak berguna di masa depan!
* Thank's you for yourself.
*/

const axios = require('axios');
const https = require('https');
const { v4: uuidv4 } = require('uuid');

class VeniceAIClient {
    constructor() {
        this.baseUrl = 'https://outerface.venice.ai/api/inference/chat';
        this.sessionHeaders = {
            'Content-Type': 'application/json',
            'X-Venice-Version': this.getCurrentVeniceVersion(),
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
            'Referer': 'https://venice.ai/chat/2rcRSQw'
        };

        this.axiosInstance = axios.create({
            httpsAgent: new https.Agent({ keepAlive: true }),
            timeout: 30000
        });

        this.axiosInstance.interceptors.response.use(null, this.retryInterceptor);
    }

    getCurrentVeniceVersion() {
        const date = new Date();
        const formattedDate = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, '0')}${String(date.getDate()).padStart(2, '0')}`;
        return `interface@${formattedDate}.230844+7989322`;
    }

    retryInterceptor(error) {
        const config = error.config;
        if (!config || !config.retry) return Promise.reject(error);

        config.__retryCount = config.__retryCount || 0;
        if (config.__retryCount >= config.retry) {
            return Promise.reject(error);
        }

        config.__retryCount += 1;
        const delay = new Promise(resolve => setTimeout(resolve, config.retryDelay || 1000));

        return delay.then(() => this.axiosInstance(config));
    }

    generateRequestId() {
        return uuidv4().replace(/-/g, '').substring(0, 12);
    }

    async sendMessage(prompt, conversationHistory = [], modelId = 'dolphin-3.0-mistral-24b') {
        try {
            const requestId = this.generateRequestId();
            const messageId = this.generateRequestId();

            const requestData = {
                requestId,
                conversationType: "text",
                type: "text",
                modelId,
                modelName: "Venice Uncensored",
                modelType: "text",
                prompt: [...conversationHistory, { content: prompt, role: "user" }],
                systemPrompt: "",
                messageId,
                includeVeniceSystemPrompt: true,
                isCharacter: false,
                userId: "user_anon_" + Math.floor(Math.random() * 1000000000),
                simpleMode: false,
                characterId: "",
                id: "",
                textToSpeech: { voiceId: "af_sky", speed: 1 },
                webEnabled: true,
                reasoning: true,
                clientProcessingTime: 22
            };

            const response = await this.axiosInstance.post(this.baseUrl, requestData, {
                headers: this.sessionHeaders,
                retry: 3,
                retryDelay: 2000
            });

            if (response.status !== 200) {
                throw new Error(`API request failed with status ${response.status}`);
            }

            // Process the streaming response
            const contentParts = response.data
                .split('\n')
                .filter(line => line.trim() !== '')
                .map(line => {
                    try {
                        return JSON.parse(line);
                    } catch (e) {
                        return null;
                    }
                })
                .filter(obj => obj && obj.kind === 'content' && obj.content)
                .map(obj => obj.content);

            const fullResponse = contentParts.join('');
            const references = response.data
                .split('\n')
                .find(line => line.includes('"kind":"meta"'));

            return {
                response: fullResponse,
                references: references ? JSON.parse(references).references : []
            };

        } catch (error) {

            // Handle rate limiting
            if (error.response && error.response.headers['x-ratelimit-remaining'] === '0') {
                const resetTime = parseInt(error.response.headers['x-ratelimit-resets']) || Date.now() + 60000;
                const waitTime = resetTime - Date.now();
                console.log(`Rate limited. Waiting ${waitTime}ms before retrying...`);
                await new Promise(resolve => setTimeout(resolve, Math.max(waitTime, 1000)));
                return this.sendMessage(prompt, conversationHistory, modelId);
            }

            throw error;
        }
    }
}

// Main function untuk query Venice AI
async function veniceQuery(prompt, content) {
    try {
        const venice = new VeniceAIClient();
        const result = await venice.sendMessage(content);
        
        return result.response;
    } catch (err) {
        throw new Error(err.message);
    }
}

// === Command ===
module.exports = {
    help: ['venice'],
    aliases: ['veniceai', 'vai'],
    tags: 'ai',
    limit: 3,
    register: true,
    run: async (m, { conn, text, usedPrefix, command, Func }) => {
        let user = global.db.users[m.sender] || {};
        user.isProcessingVenice = user.isProcessingVenice || false;

        if (user.isProcessingVenice) throw global.status.previously;
        user.isProcessingVenice = true;

        try {
            if (!text) {
                throw `Please ask questions.\n\n*Example* : ${usedPrefix + command} TechBOT`
            }

            let waitMsg = await conn.reply(m.chat, '...', m);

            try {
                const response = await veniceQuery('Venice AI', text);
                await conn.sendMessage(m.chat, {
                    text: response,
                    edit: waitMsg.key
                });
            } catch (apiError) {
                throw `${apiError.message}`
            }

        } catch (e) {
            throw Func.jsonFormat(e);
        } finally {
            if (global.db.users[m.sender]) {
                global.db.users[m.sender].isProcessingVenice = false;
            }
        }
    }
};