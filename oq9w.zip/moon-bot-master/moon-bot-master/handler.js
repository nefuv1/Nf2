const { Function: Func, Scraper, Spam, Config: env } = new (require('@znan/wabot'))
const path = require('path')
const cron = require('node-cron')

const isSpam = new Spam({
   mode: env.spam.mode, /** command || msg || all */
   messageLimit: env.spam.limit,
   timeWindowSeconds: env.spam.time_window,
   cooldownSeconds: env.time_ban,
   maxBanTimes: env.max_ban,
   commandCooldownSeconds: env.spam.cooldown
})

module.exports = async (conn, ctx, database) => {
   var { store, m, body, prefix, plugins, plugFiles, loadCmd, loadEvt, commands, args, command, text, prefixes, core, isCommand } = ctx
   try {
      require('./lib/system/schema')(m, env)
      let groupSet = global.db.groups[m.chat]
      let chats = global.db.chats[m.chat]
      let users = global.db.users[m.sender]
      let setting = global.db.setting
      let isOwner = [conn.decodeJid(conn.user.id).replace(/@.+/, ''), env.owner, ...setting.owners].map(v => v + '@s.whatsapp.net').includes(m.sender)
      let isPrem = users && users.premium || isOwner
      let groupMetadata = m.isGroup ? await conn.getGroupMetadata(m.chat) : {}
      let participants = m.isGroup ? groupMetadata ? conn.fixLid(groupMetadata.participants) : [] : [] || []
      let adminList = m.isGroup ? participants?.filter(i => i.admin === 'admin' || i.admin === 'superadmin')?.map(i => i.id) || [] : []
      let isAdmin = m.isGroup ? adminList.includes(m.sender) : false
      let isBotAdmin = m.isGroup ? adminList.includes((conn.user.id.split`:`[0]) + '@s.whatsapp.net') : false
      let blockList = typeof await (await conn.fetchBlocklist()) != 'undefined' ? await (await conn.fetchBlocklist()) : []

      const spam = isSpam.check(conn, m, users, isCommand, command, setting)

      if (!setting.online) conn.sendPresenceUpdate('unavailable', m.chat)
      if (setting.online) {
         conn.sendPresenceUpdate('available', m.chat)
         conn.readMessages([m.key])
      }
      if (!setting.multiprefix) setting.noprefix = false
      if (setting.debug && !m.fromMe && isOwner) conn.reply(m.chat, Func.jsonFormat(m), m)
      
      // START - antibot
      if (!m.fromMe && m.isGroup && groupSet.antibot && !isOwner && isBotAdmin) {
         if (m.isBot || /interactiveMessage|buttonsMessage/.test(m.mtype)) return conn.reply(m.chat, `Sorry other bot are not allowed in this group.`, m).then(async () => {
            await Func.delay(15_000)
            conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
         })
      }
      // END - antibot
      
      if (m.isGroup && !groupSet.stay && (new Date * 1) >= groupSet.expired && groupSet.expired != 0) {
         return conn.reply(m.chat, 'The bot rental period in this group has expired and it will be leaving this group. Thank you.', m, null, {
            mentions: participants.map(v => v.id)
         }).then(async () => {
            groupSet.expired = 0
            await Func.delay(15_000).then(() => conn.groupLeave(m.chat))
         })
      }
      if (users && (new Date * 1) >= users.expired && users.expired != 0) {
         return conn.reply(m.chat, 'Your premium plan has expired, thank you for subscribing and using our services.', m).then(async () => {
            users.premium = false
            users.expired = 0
            users.limit = env.limit
         })
      }
      if (m.isGroup) groupSet.activity = new Date() * 1
      if (users) {
         if (!users.lid) {
            const { lid } = await conn.getUserId(m.sender)
            if (lid) users.lid = lid
         }
         users.name = m.pushName
         users.lastseen = new Date() * 1
      }
      if (chats) {
         chats.chat += 1
         chats.lastseen = new Date * 1
      }
      if (m.isGroup && !m.isBot && users?.afk > -1) {
         conn.reply(m.chat, `You are back online after being offline for : ${Func.texted('bold', Func.toTime(new Date - users.afk))}\n\n- ${Func.texted('bold', 'Reason')}: ${users?.afkReason || '-'}`, m)
         users.afk = -1
         users.afkReason = ''
         users.afkObj = {}
      }
      cron.schedule('00 00 * * *', async () => {
         setting.lastReset = new Date * 1
         Object.values(global.db.users).filter(v => v.limit < env.limit && !v.premium).map(v => v.limit = env.limit)
         Object.entries(global.db.statistic).map(([_, prop]) => prop.today = 0)
      }, {
         scheduled: true,
         timezone: process.env.TZ
      })
      if (m.isGroup && !m.fromMe) {
         let now = new Date() * 1
         const { lid } = await conn.getUserId(m.sender)
         if (!groupSet.member[m.sender]) {
            groupSet.member[m.sender] = {
               lid: lid,
               chat: 1,
               lastseen: now,
               warning: 0
            }
         } else {
            groupSet.member[m.sender].lastseen = now
            groupSet.member[m.sender].lid = lid
         }
      }
      if (setting.antispam && spam) {
         if (spam.status === 'ban_active') return
         if (spam.status === 'ban_temp') return conn.reply(m.chat, `[ ${spam.data.ban_times} / ${spam.data.max_ban} ] You are temporarily banned for *${spam.data.cooldown} seconds*.`, m)
         if (spam.status === 'ban_permanent') return conn.reply(m.chat, `[ ${spam.data.ban_times} / ${spam.data.max_ban} ] You have been warned multiple times! You have been permanently banned.`, m)
         if (spam.status === 'cooldown') return conn.reply(m.chat, `Too many requests!\n\nPlease try again in *${spam.data.remaining} seconds*.`, m)
      }
      // if (body && !setting.self && core.prefix != setting.onlyprefix && commands.includes(core.command) && !setting.multiprefix && !env.evaluate_chars.includes(core.command)) return conn.reply(m.chat, `*Prefix needed!*, this bot uses prefix : *[ ${setting.onlyprefix} ]*\n\n➠ ${setting.onlyprefix + core.command} ${text || ''}`, m)
      const matcher = await Func.matcher(command, commands)
         .filter(v => v.accuracy >= 60)
         .sort((a, b) => b.accuracy - a.accuracy)
         .slice(0, 3) /** max 3 */
      if (prefix && !commands.includes(command) && matcher.length > 0) {
         if (!m.isGroup || (m.isGroup && !groupSet.mute)) {
            return conn.reply(m.chat, `Unrecognized command, maybe you meant :\n\n${matcher.map(v => '- *' + (prefix ? prefix : '') + v.string + '* (' + v.accuracy.toFixed(2) + '%) Accuracy').join('\n')}`, m)
         }
      }
      if (isCommand) {
         const plugin = loadCmd.get(command)
         if (!plugin) return
         if (commands.includes(command)) {
            users.hit += 1
            users.usebot = new Date() * 1
            Func.hitstat(command)
         }
         const name = path.parse(plugin.filePath).name
         if (!m.isGroup && env.blocks.some(no => m.sender.startsWith(no))) return conn.updateBlockStatus(m.sender, 'block')
         if (setting.pluginDisable?.includes(name)) return
         if (setting.error?.includes(command)) return conn.reply(m.chat, Func.texted('bold', `Command *${(prefix ? prefix : '') + command}* disabled.`), m)
         if ((m.fromMe && m.isBot) || /broadcast|newsletter/.test(m.chat) || /Edit/.test(m.mtype)) return
         if (setting.self && !isOwner && !m.fromMe) return
         if (m.isGroup && groupSet && groupSet.adminonly && !isAdmin && !['groups', 'link', 'profile'].includes(name)) return
         if (!m.isGroup && !['owner', 'menfess', 'werewolfpc', 'premium', 'sewa', 'suit_hint', 'spy_hint', 'hacker'].includes(name) && chats && !isPrem && !isOwner && !users.banned && setting.groupmode) return conn.reply(m.chat, `Only premium users can use this command in private chat.\nYou can subscribe to premium by sending the command.\n- *Example* : ${prefixes[0]}premium\n\nIf you want to use it for free, you can use it in our group.\n- *Group link* : whatsapp.com/channel/0029VbBOMPuHAdNRvXNfId2X/102\n\n> plugins_run`, m).then(() => chats.lastchat = new Date() * 1)
         if (!['profile', 'owner', 'exec'].includes(name) && users && (users.banned || new Date - users.ban_temporary < env.timeout)) return
         if (m.isGroup && !['activation', 'groups'].includes(name) && groupSet.mute) return

         if (plugin.owner && !isOwner) return conn.reply(m.chat, global.status.owner, m)
         if (plugin.restrict && !isPrem && !isOwner && text && new RegExp('\\b' + setting.toxic.join('\\b|\\b') + '\\b').test(text.toLowerCase())) {
            return conn.reply(m.chat, `You have violated the *Terms and Conditions* of bot usage by using prohibited keywords. As punishment for your violation, your account has been banned.`, m).then(() => {
               users.banned = true
               conn.updateBlockStatus(m.sender, 'block')
            })
         }
         if (plugin.premium && !isPrem) return conn.reply(m.chat, global.status.premium, m)
         if (plugin.group && !m.isGroup) return conn.reply(m.chat, global.status.group, m)
         if (plugin.botAdmin && !isBotAdmin) return conn.reply(m.chat, global.status.botAdmin, m)
         if (plugin.admin && !isAdmin) return conn.reply(m.chat, global.status.admin, m)
         if (plugin.private && m.isGroup) return conn.reply(m.chat, global.status.private, m)
         if (plugin.register && !users.registered) return conn.reply(m.chat, global.status.register, m)       
         if (plugin.onlyprem && !m.isGroup && !isPrem) return conn.reply(m.chat, global.status.onlyprem, m)          
         if (plugin.game && m.isGroup && !db.groups[m.chat].game) return conn.reply(m.chat, global.status.game, m) 
         if (plugin.rpg && m.isGroup && !db.groups[m.chat].rpg) return conn.reply(m.chat, global.status.rpg, m)  
         try {
           if (plugin.limit && !plugin.game) {
              const limit = plugin.limit === 'Boolean' ? 1 : plugin.limit
              
              if (users.limit < 1) {
                 return conn.reply(m.chat, `You have reached the limit of using this command.\n\n*Example* : ${prefixes[0]}buylimit 1\n\nOr you can wait, you can get the limit back after 00:00, you can also subscribe to our premium.`, m)
              }              
              if (users.limit < limit) {
                 return conn.reply(m.chat, `Your limit is not enough to use this command.`, m)
              }
           }       
           await plugin.run(m, { ctx, conn, store, body, usedPrefix: prefix, plugins, plugFiles, commands, args, command, text, prefixes, core, isCommand, database, env, groupSet, chats, users, setting, isOwner, isPrem, groupMetadata, participants, isAdmin, isBotAdmin, blockList, Func, Scraper })
        
// Versi lama tanpa mengirimkan informasi limit terpakai         
//           if (plugin.limit && !plugin.game && users.limit > 0) { 
//              const limit = plugin.limit === 'Boolean' ? 1 : plugin.limit
//              if (users.limit >= limit) {
//                 users.limit -= limit
//              }
//           }

// Versi menggunakan informasi pengiriman limit terpakai 
            if (plugin.limit && !plugin.game && users.limit > 0) { 
               const limit = plugin.limit === 'Boolean' ? 1 : plugin.limit
               if (users.limit >= limit) {
                  users.limit -= limit
                  
                  const remainingLimit = users.limit
                  conn.reply(m.chat, `-${limit} Limit used!\n\n_${global.status.donate}_`, m)
               }
            }
        
        } catch (e) {
           return conn.reply(m.chat, e.toString(), m)
        }                       
      } else {
         for (const event of loadEvt) {
            const name = path.parse(event.filePath).name
            if ((m.fromMe && m.isBot) || /broadcast|newsletter/.test(m.chat) || /pollUpdate/.test(m.mtype)) continue
            if (!m.isGroup && env.blocks.some(no => m.sender.startsWith(no))) return conn.updateBlockStatus(m.sender, 'block')            
            if (m.isGroup && groupSet && groupSet.adminonly && !isAdmin && !['anti_link', 'anti_porn', 'anti_sticker', 'anti_tagsw', 'anti_toxic', 'anti_viewonce', 'anti_virtex', 'game', 'rpg', 'anti_foto', 'anti_video', 'auto_gempa', 'anti_bot', 'auto_levelup', 'auto_timer', 'auto_delusers', 'auto_mysterybox'].includes(name)) continue
            if (setting.self && !['anti_link', 'anti_porn', 'anti_sticker', 'anti_tagsw', 'anti_toxic', 'anti_viewonce', 'anti_virtex', 'game', 'rpg', 'anti_foto', 'anti_video', 'auto_gempa', 'anti_bot', 'auto_levelup', 'auto_timer', 'auto_delusers', 'auto_mysterybox'].includes(name) && !isOwner && !m.fromMe) continue
            if (!['anti_link', 'anti_porn', 'anti_sticker', 'anti_tagsw', 'anti_toxic', 'anti_viewonce', 'anti_virtex', 'game', 'rpg', 'anti_foto', 'anti_video', 'auto_gempa', 'anti_bot', 'auto_levelup', 'auto_timer', 'auto_delusers', 'auto_mysterybox'].includes(name) && users && (users.banned || new Date - users.ban_temporary < env.timeout)) continue
            if (!['anti_link', 'anti_porn', 'anti_sticker', 'anti_tagsw', 'anti_toxic', 'anti_viewonce', 'anti_virtex', 'game', 'rpg', 'anti_foto', 'anti_video', 'auto_gempa', 'anti_bot', 'anti_video', 'auto_gempa', 'anti_bot', 'auto_levelup', 'auto_timer', 'auto_delusers', 'auto_mysterybox'].includes(name) && groupSet && groupSet.mute) continue            
            if (!m.isGroup && setting.groupmode && !['menfess_ans'].includes(name) && !isPrem &&  !isOwner) return conn.reply(m.chat, `Only premium users can use this command in private chat.\nYou can subscribe to premium by sending the command.\n- *Example* : !premium\n\nIf you want to use it for free, you can use it in our group.\n- *Group link* : whatsapp.com/channel/0029VbBOMPuHAdNRvXNfId2X/102\n\n> events_run`, m).then(() => chats.lastchat = new Date() * 1)
            if (event.error) continue
            if (event.owner && !isOwner) continue
            if (event.group && !m.isGroup) continue
            if (event.botAdmin && !isBotAdmin) continue
            if (event.admin && !isAdmin) continue
            if (event.private && m.isGroup) continue
            if (event.download && body && Func.socmed(body) && !setting.autodownload && Func.generateLink(body) && Func.generateLink(body).some(v => Func.socmed(v))) continue
            try {
               await event.run(m, { ctx, conn, store, body, plugins, plugFiles, prefixes, core, isCommand, database, env, groupSet, chats, users, setting, isOwner, isPrem, groupMetadata, participants, isAdmin, isBotAdmin, blockList, Func, Scraper })
               
               if (event.limit && users.limit < 1 && body && Func.generateLink(body) && Func.generateLink(body).some(v => Func.socmed(v))) {
                  return conn.reply(m.chat, `You have reached the limit of using this command.\n\n*Example* : ${prefixes[0]}buylimit 1\n\nOr you can wait, you can get the limit back after 00:00, you can also subscribe to our premium.`, m)
               }
               
               if (event.limit && users.limit > 0 && body && Func.generateLink(body) && Func.generateLink(body).some(v => Func.socmed(v))) {
                  const limit = event.limit === 'Boolean' ? 1 : event.limit
                  users.limit -= limit
                  conn.reply(m.chat, `-${limit} Limit used.\n\n_${global.status.donate}_`, m)
               }
            } catch (e) {
               return conn.reply(m.chat, e.toString(), m)
            }
         }
      }
   } catch (e) {
      console.error(e)
   }
   Func.reload(require.resolve(__filename))
} 