const axios = require('axios');
const { writeFileSync, unlinkSync } = require('fs');
const path = require('path');

// Simpan data transaksi sementara (dalam production gunakan database)
const qrisTransactions = new Map();

module.exports = {
   help: ['qris'],
   aliases: ['qrisconverter', 'generateqris', 'qrpayment', 'cekqris'],
   tags: 'utility',
   limit: 5,
   premium: false,
   register: true,
   run: async (m, {
      conn,
      usedPrefix,
      command,
      args,
      text,
      Func
   }) => {
      let user = global.db.users[m.sender] || {};
      user.isProcessingQris = user.isProcessingQris || false;

      if (user.isProcessingQris) throw global.status.previously;

      let keyMsg;

      try {
         user.isProcessingQris = true;

         // Jika command cek status
         if (command === 'cekqris' || (text && text.toLowerCase() === 'status')) {
            return await checkQrisStatus(m, conn, usedPrefix, Func);
         }

         let { key } = await m.reply(global.status.wait);
         keyMsg = key;

         // Parse input
         let amount, qrisStatic;
         
         if (text.includes('|')) {
            const [amt, static] = text.split('|').map(s => s.trim());
            amount = amt;
            qrisStatic = static;
         } else if (args.length >= 2) {
            amount = args[0];
            qrisStatic = args.slice(1).join(' ');
         } else if (m.quoted && m.quoted.text) {
            amount = text;
            qrisStatic = m.quoted.text;
         } else {
            throw `Please provide amount and QRIS static data.\n\n*Example:*\n• ${usedPrefix + command} 10000 00020101021126570011ID.DANA.WWW011893600915373222184...\n• ${usedPrefix}cekqris - untuk cek status pembayaran`;
         }

         // Validasi amount
         if (!amount || isNaN(amount) || parseInt(amount) < 1000) {
            throw 'Amount must be a number and minimum 1000';
         }

         if (!qrisStatic) {
            throw 'QRIS static data is required';
         }

         const amountNum = parseInt(amount);
         const transactionId = 'TXN' + Date.now();

         // Simpan data transaksi
         qrisTransactions.set(transactionId, {
            userId: m.sender,
            amount: amountNum,
            qrisStatic: qrisStatic,
            createdAt: new Date(),
            status: 'pending'
         });

         // Generate QRIS
         const payload = {
            amount: amountNum.toString(),
            qris_statis: qrisStatic
         };

         const response = await axios.post('https://qrisku.my.id/api', payload, {
            headers: {
               'Content-Type': 'application/json',
               'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36'
            },
            timeout: 30000
         });

         if (!response.data.status || response.data.status !== 'success') {
            qrisTransactions.delete(transactionId);
            throw response.data.message || 'Failed to generate QRIS';
         }

         if (!response.data.qris_base64) {
            qrisTransactions.delete(transactionId);
            throw 'No QR code generated';
         }

         // Convert base64 ke buffer
         const base64Data = response.data.qris_base64.replace(/^data:image\/png;base64,/, '');
         const qrBuffer = Buffer.from(base64Data, 'base64');

         // Extract merchant info
         let merchantName = 'Unknown Merchant';
         let merchantCity = 'Unknown City';
         
         try {
            const merchantMatch = qrisStatic.match(/5911([A-Za-z0-9\s]{1,25})/);
            const cityMatch = qrisStatic.match(/6012([A-Za-z0-9\s\.]{1,15})/);
            
            if (merchantMatch) merchantName = merchantMatch[1].trim();
            if (cityMatch) merchantCity = cityMatch[1].trim();
         } catch (e) {}

         // Kirim QRIS
         await conn.sendMessage(m.chat, {
            image: qrBuffer,
            caption: `*💰 QRIS PAYMENT*\n\n` +
                   `📋 *Transaction ID* : ${transactionId}\n` +
                   `🏪 *Merchant* : ${merchantName}\n` +
                   `📍 *Location* : ${merchantCity}\n` +
                   `💵 *Amount* : Rp ${amountNum.toLocaleString('id-ID')}\n` +
                   `🕒 *Created* : ${new Date().toLocaleString('id-ID')}\n` +
                   `📊 *Status* : ⏳ Pending\n\n` +
                   `_Scan QR code to pay_\n` +
                   `_Check status with: ${usedPrefix}cekqris_`
         }, { quoted: m });

         // Simpan file temporary (optional)
         const tempDir = path.join(__dirname, '../../tmp');
         const tempFile = path.join(tempDir, `qris-${transactionId}.png`);
         writeFileSync(tempFile, qrBuffer);

         // Schedule auto status check (simulasi)
         setTimeout(async () => {
            try {
               const transaction = qrisTransactions.get(transactionId);
               if (transaction && transaction.status === 'pending') {
                  // Simulasi cek status (dalam real implementation, panggil API cek status)
                  const isPaid = Math.random() > 0.7; // 30% chance paid (simulasi)
                  
                  if (isPaid) {
                     transaction.status = 'paid';
                     transaction.paidAt = new Date();
                     
                     await conn.sendMessage(m.chat, {
                        text: `✅ *PAYMENT CONFIRMED*\n\n` +
                              `📋 *Transaction ID* : ${transactionId}\n` +
                              `💵 *Amount* : Rp ${amountNum.toLocaleString('id-ID')}\n` +
                              `🏪 *Merchant* : ${merchantName}\n` +
                              `⏰ *Paid At* : ${new Date().toLocaleString('id-ID')}\n` +
                              `📊 *Status* : ✅ Success`
                     }, { quoted: m });
                  }
               }
            } catch (e) {
               console.log('Auto status check error:', e.message);
            }
         }, 30000); // Cek setelah 30 detik

         // Cleanup file setelah 5 menit
         setTimeout(() => {
            try {
               if (unlinkSync) unlinkSync(tempFile);
            } catch (e) {}
         }, 300000);

         await conn.sendMessage(m.chat, {
            text: `✅ QRIS generated!\n📋 ID: ${transactionId}\n💵 Amount: Rp ${amountNum.toLocaleString('id-ID')}`,
            edit: keyMsg,
         });

      } catch (e) {
         throw Func.jsonFormat(e);
      } finally {
         if (global.db.users[m.sender]) {
            global.db.users[m.sender].isProcessingQris = false;
         }
      }
   }
}

// Function untuk cek status QRIS
async function checkQrisStatus(m, conn, text, usedPrefix, Func) {
   try {
      let transactionId;
      
      if (m.quoted && m.quoted.text) {
         // Cari transaction ID dari quoted message
         const quotedText = m.quoted.text;
         const idMatch = quotedText.match(/Transaction ID : (TXN\d+)/);
         if (idMatch) transactionId = idMatch[1];
      } else if (text && text !== 'status') {
         transactionId = text.trim();
      }

      if (!transactionId) {
         // Tampilkan semua transaksi user
         const userTransactions = [];
         for (let [id, transaction] of qrisTransactions.entries()) {
            if (transaction.userId === m.sender) {
               userTransactions.push({ id, ...transaction });
            }
         }

         if (userTransactions.length === 0) {
            throw `No QRIS transactions found.\nGenerate one with: ${usedPrefix}qris <amount> <qris_data>`;
         }

         let statusMsg = `*📋 YOUR QRIS TRANSACTIONS*\n\n`;
         userTransactions.forEach((txn, index) => {
            statusMsg += `*${index + 1}. ${txn.id}*\n`;
            statusMsg += `💵 Amount: Rp ${txn.amount.toLocaleString('id-ID')}\n`;
            statusMsg += `📊 Status: ${txn.status === 'paid' ? '✅ Paid' : '⏳ Pending'}\n`;
            statusMsg += `🕒 Created: ${txn.createdAt.toLocaleString('id-ID')}\n`;
            if (txn.paidAt) {
               statusMsg += `💰 Paid At: ${txn.paidAt.toLocaleString('id-ID')}\n`;
            }
            statusMsg += `\n`;
         });

         statusMsg += `_Check specific transaction: ${usedPrefix}cekqris <transaction_id>_`;
         return m.reply(statusMsg);
      }

      // Cek transaksi spesifik
      const transaction = qrisTransactions.get(transactionId);
      if (!transaction) {
         throw `Transaction ID ${transactionId} not found`;
      }

      if (transaction.userId !== m.sender) {
         throw 'You can only check your own transactions';
      }

      // Simulasi cek status (dalam real implementation, panggil API)
      let statusUpdate = transaction.status;
      if (statusUpdate === 'pending') {
         // Random check untuk simulasi
         const isPaid = Math.random() > 0.5;
         if (isPaid) {
            statusUpdate = 'paid';
            transaction.status = 'paid';
            transaction.paidAt = new Date();
         }
      }

      let statusMsg = `*📋 TRANSACTION STATUS*\n\n`;
      statusMsg += `*Transaction ID* : ${transactionId}\n`;
      statusMsg += `*Amount* : Rp ${transaction.amount.toLocaleString('id-ID')}\n`;
      statusMsg += `*Status* : ${statusUpdate === 'paid' ? '✅ PAID' : '⏳ PENDING'}\n`;
      statusMsg += `*Created* : ${transaction.createdAt.toLocaleString('id-ID')}\n`;
      
      if (statusUpdate === 'paid') {
         statusMsg += `*Paid At* : ${transaction.paidAt.toLocaleString('id-ID')}\n`;
         statusMsg += `\n🎉 *Payment successful!*`;
      } else {
         statusMsg += `\n⏳ *Waiting for payment...*`;
      }

      m.reply(statusMsg);

   } catch (e) {
      throw Func.jsonFormat(e);
   }
}