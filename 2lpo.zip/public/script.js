document.addEventListener('DOMContentLoaded', () => {
    const chatContainer = document.getElementById('chat-container');
    const chatForm = document.getElementById('chat-form');
    const messageInput = document.getElementById('message-input');
    const menuBtn = document.getElementById('menu-btn');
    const settingsBtn = document.getElementById('settings-btn');
    const sidebarLeft = document.getElementById('sidebar-left');
    const sidebarRight = document.getElementById('sidebar-right');
    const overlay = document.getElementById('overlay');
    const newChatBtn = document.getElementById('new-chat-btn');
    const historyList = document.getElementById('history-list');
    const fileInput = document.getElementById('file-input');
    const filePreviewContainer = document.getElementById('file-preview-container');
    const closeSidebarBtn = document.getElementById('close-sidebar-btn');
    const closeSettingsBtn = document.getElementById('close-settings-btn');
    const modalOverlay = document.getElementById('modal-overlay');
    const customConfirm = document.getElementById('custom-confirm');
    const welcomeScreen = document.getElementById('welcome-screen');
    const uploadFileBtn = document.getElementById('upload-file-btn');
    const sendButton = document.getElementById('send-button');

    const modelSelect = document.getElementById('model-select');
    const systemInstruction = document.getElementById('system-instruction');
    const groundingToggle = document.getElementById('grounding-toggle');
    const darkThemeToggle = document.getElementById('dark-theme-toggle');

    let chatHistory = [], currentChatId = null, attachedFiles = [], confirmCallback = null;
    marked.setOptions({ breaks: true, gfm: true });

    const formatTime = (date) => new Date(date).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    const scrollToBottom = () => chatContainer.scrollTo({ top: chatContainer.scrollHeight, behavior: 'smooth' });
    
    const closeAllSidebars = () => {
        sidebarLeft.classList.remove('open');
        sidebarRight.classList.remove('open');
        overlay.classList.remove('active');
    };

    const toggleSidebarLeft = () => {
        if (sidebarRight.classList.contains('open')) sidebarRight.classList.remove('open');
        sidebarLeft.classList.toggle('open');
        overlay.classList.toggle('active', sidebarLeft.classList.contains('open'));
    };
    const toggleSidebarRight = () => {
        if (sidebarLeft.classList.contains('open')) sidebarLeft.classList.remove('open');
        sidebarRight.classList.toggle('open');
        overlay.classList.toggle('active', sidebarRight.classList.contains('open'));
    };
    
    menuBtn.addEventListener('click', toggleSidebarLeft);
    closeSidebarBtn.addEventListener('click', closeAllSidebars);
    settingsBtn.addEventListener('click', toggleSidebarRight);
    closeSettingsBtn.addEventListener('click', closeAllSidebars);
    overlay.addEventListener('click', closeAllSidebars);
    
    const showConfirm = (callback) => { confirmCallback = callback; modalOverlay.classList.add('active'); customConfirm.classList.add('active'); };
    const hideConfirm = () => { modalOverlay.classList.remove('active'); customConfirm.classList.remove('active'); };
    [...document.querySelectorAll('.modal-button')].forEach(b => b.addEventListener('click', hideConfirm));
    document.getElementById('confirm-yes').addEventListener('click', () => { if (confirmCallback) confirmCallback(); });

    const decodeHTMLEntities = (text) => {
        const textarea = document.createElement('textarea');
        textarea.innerHTML = text;
        return textarea.value;
    };
    
    const addCitations = (text, groundingMetadata) => {
        if (!text || !groundingMetadata || !groundingMetadata.groundingSupports || !groundingMetadata.groundingChunks) {
            return text;
        }
        try {
            const supports = groundingMetadata.groundingSupports;
            const chunks = groundingMetadata.groundingChunks;
            const sortedSupports = [...supports].sort((a, b) => (b.segment?.endIndex ?? 0) - (a.segment?.endIndex ?? 0));
            
            let processedText = text;
            for (const support of sortedSupports) {
                const endIndex = support.segment?.endIndex;
                if (endIndex === undefined || !support.groundingChunkIndices?.length) continue;
                
                const citationLinks = support.groundingChunkIndices
                    .map(i => {
                        const chunk = chunks[i];
                        if (chunk?.web?.uri) {
                            return `<sup class="citation-link"><a href="${chunk.web.uri}" target="_blank">${i + 1}</a></sup>`;
                        }
                        return null;
                    })
                    .filter(Boolean);

                if (citationLinks.length > 0) {
                    const citationString = ' ' + citationLinks.join('');
                    processedText = processedText.slice(0, endIndex) + citationString + processedText.slice(endIndex);
                }
            }
            return processedText;
        } catch (e) {
            console.error("Error processing citations:", e);
            return text; 
        }
    };

    const addMessageToUI = (msg, fullResponse = null) => {
        const wrapper = document.createElement('div');
        wrapper.className = `message-wrapper ${msg.role === 'user' ? 'user' : 'ai'}`;
        wrapper.dataset.timestamp = msg.timestamp;

        const bubbleContainer = document.createElement('div');
        bubbleContainer.className = 'bubble-container';
        
        const bubble = document.createElement('div');
        bubble.className = 'chat-bubble';

        let contentHTML = '';
        msg.parts.forEach(part => {
            if (part.file) {
                 if (part.file.mimeType.startsWith('image/')) {
                    contentHTML += `<img src="${part.file.data}" class="chat-file-image">`;
                } else {
                    contentHTML += `<div class="chat-file-info"><span>${part.file.name}</span></div>`;
                }
            }
            if (part.text) {
                let textToParse = decodeHTMLEntities(part.text);
                if (msg.role === 'model' && fullResponse) {
                   textToParse = addCitations(textToParse, fullResponse.groundingMetadata);
                }
                contentHTML += marked.parse(textToParse);
            }
        });
        bubble.innerHTML = contentHTML;
        
        const time = document.createElement('div');
        time.className = 'timestamp';
        time.textContent = formatTime(msg.timestamp);

        bubbleContainer.appendChild(bubble);
        bubbleContainer.appendChild(time);
        wrapper.appendChild(bubbleContainer);
        
        if (welcomeScreen?.style.display !== 'none') welcomeScreen.style.display = 'none';
        chatContainer.appendChild(wrapper);
        scrollToBottom();
    };
    
    const showThinkingIndicator = () => {
        if (document.querySelector('.thinking-indicator')) return;
        const indicator = document.createElement('div');
        indicator.className = 'message-wrapper ai thinking-indicator';
        indicator.innerHTML = '<div class="chat-bubble"><span class="dot"></span><span class="dot"></span><span class="dot"></span></div>';
        if (welcomeScreen?.style.display !== 'none') welcomeScreen.style.display = 'none';
        chatContainer.appendChild(indicator);
        scrollToBottom();
    };
    const removeThinkingIndicator = () => document.querySelector('.thinking-indicator')?.remove();

    const processAndSendMessage = async () => {
        const userMessage = messageInput.value.trim();
        const userFiles = [...attachedFiles];
        
        if (!userMessage && userFiles.length === 0) return;

        const timestamp = new Date().toISOString();
        const parts = [];
        if(userMessage) parts.push({ text: userMessage });
        userFiles.forEach(file => parts.push({ file: file }));
        const newUserMessage = { role: "user", parts, timestamp };
        chatHistory.push(newUserMessage);
        addMessageToUI(newUserMessage);
        
        if (currentChatId === null) currentChatId = Date.now().toString();
        saveChatToStorage();
        renderHistoryList();
        
        messageInput.value = '';
        messageInput.style.height = 'auto';
        resetFileInput();
        chatForm.classList.add('processing');
        showThinkingIndicator();

        try {
            const settings = loadSettings();
            const res = await fetch('/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    history: chatHistory.slice(0, -1), message: userMessage, files: userFiles, settings
                }),
            });
            removeThinkingIndicator();
            if (!res.ok) throw new Error((await res.json()).error || 'Unknown error');
            const fullResponse = await res.json();
            const newAiMessage = { role: "model", parts: [{ text: fullResponse.text }], timestamp: new Date().toISOString() };
            chatHistory.push(newAiMessage);
            saveChatToStorage();
            addMessageToUI(newAiMessage, fullResponse);
        } catch (error) {
            removeThinkingIndicator();
            const errorMsg = { role: "model", parts: [{ text: `Aww, maaf, Elaina error nih: ${error.message || 'Gagal terhubung ke server.'}` }], timestamp: new Date().toISOString() };
            chatHistory.push(errorMsg);
            saveChatToStorage();
            addMessageToUI(errorMsg);
        } finally {
            chatForm.classList.remove('processing');
            messageInput.focus();
        }
    };
    
    chatForm.addEventListener('submit', (e) => { e.preventDefault(); processAndSendMessage(); });
    messageInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendButton.click();
        }
    });

    messageInput.addEventListener('input', () => {
        messageInput.style.height = 'auto';
        const newHeight = Math.min(messageInput.scrollHeight, 150);
        messageInput.style.height = newHeight + 'px';
    });
    
    uploadFileBtn.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', (e) => {
        const files = Array.from(e.target.files);
        if (attachedFiles.length + files.length > 5) {
            alert("Maaf, kamu cuma bisa upload maksimal 5 file yaa.");
            return;
        }
        files.forEach(file => {
            const reader = new FileReader();
            reader.onloadend = () => {
                attachedFiles.push({ data: reader.result, mimeType: file.type, name: file.name });
                renderFilePreviews();
            };
            reader.readAsDataURL(file);
        });
        fileInput.value = '';
    });

    const renderFilePreviews = () => {
        filePreviewContainer.innerHTML = '';
        filePreviewContainer.style.display = attachedFiles.length > 0 ? 'flex' : 'none';
        attachedFiles.forEach((file, index) => {
            const previewItem = document.createElement('div');
            previewItem.className = 'preview-item';
            if (file.mimeType.startsWith('image/')) {
                previewItem.innerHTML = `<img src="${file.data}" alt="Preview"><button class="remove-file-btn" data-index="${index}">&times;</button>`;
            } else {
                 previewItem.innerHTML = `<div class="file-placeholder"><span>${file.name}</span></div><button class="remove-file-btn" data-index="${index}">&times;</button>`;
            }
            filePreviewContainer.appendChild(previewItem);
        });
        document.querySelectorAll('.remove-file-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                attachedFiles.splice(parseInt(e.target.dataset.index, 10), 1);
                renderFilePreviews();
            });
        });
    };

    const resetFileInput = () => { attachedFiles = []; renderFilePreviews(); };
    const getChats = () => JSON.parse(localStorage.getItem('elaina-chan-chats')) || {};
    const saveChats = (chats) => localStorage.setItem('elaina-chan-chats', JSON.stringify(chats));
    const saveChatToStorage = () => {
        if (!currentChatId || chatHistory.length === 0) return;
        const chats = getChats();
        const firstUserMessage = chatHistory.find(m => m.role === 'user');
        const title = firstUserMessage?.parts.find(p => p.text)?.text?.substring(0, 30) || "Chat dengan File";
        chats[currentChatId] = { id: currentChatId, title, messages: chatHistory };
        saveChats(chats);
    };

    const renderHistoryList = () => {
        historyList.innerHTML = '';
        Object.values(getChats()).sort((a, b) => b.id - a.id).forEach(chat => {
            const li = document.createElement('li');
            li.className = 'history-item'; li.dataset.chatId = chat.id;
            li.innerHTML = `<span class="history-item-title">${chat.title}</span>`;
            historyList.appendChild(li);
        });
    };
    
    const loadChat = (chatId) => {
        const chat = getChats()[chatId]; if (!chat) return;
        currentChatId = chatId; chatHistory = chat.messages; chatContainer.innerHTML = '';
        chatHistory.forEach(msg => addMessageToUI(msg));
        closeAllSidebars();
    };

    const startNewChat = () => {
        currentChatId = null; chatHistory = []; resetFileInput();
        chatContainer.innerHTML = ''; chatContainer.appendChild(welcomeScreen); welcomeScreen.style.display = 'flex';
        localStorage.removeItem('elaina-active-chat-id');
        closeAllSidebars();
    };
    newChatBtn.addEventListener('click', startNewChat);

    historyList.addEventListener('click', (e) => {
        const historyItem = e.target.closest('.history-item');
        if (historyItem) loadChat(historyItem.dataset.chatId);
    });

    const loadLatestChat = () => {
        const latestChatId = localStorage.getItem('elaina-active-chat-id');
        const chats = getChats();
        if (latestChatId && chats[latestChatId]) {
            loadChat(latestChatId);
        } else {
            startNewChat();
        }
    };

    window.addEventListener('beforeunload', () => {
        if (currentChatId) localStorage.setItem('elaina-active-chat-id', currentChatId);
    });

    const saveSettings = () => {
        const settings = {
            model: modelSelect.value, systemInstruction: systemInstruction.value,
            grounding: groundingToggle.checked, darkTheme: darkThemeToggle.checked
        };
        localStorage.setItem('elaina-chan-settings', JSON.stringify(settings));
    };

    const applyTheme = (isDark) => { document.body.classList.toggle('dark-theme', isDark); };

    const loadSettings = () => {
        const savedSettings = JSON.parse(localStorage.getItem('elaina-chan-settings'));
        const defaultInstruction = "Kamu adalah asisten AI bernama Elaina Chan. Kamu sangat baik hati, imut, dan selalu ceria. Gaya bicaramu santai dan ramah. Jika menjawab pertanyaan detail, berikan jawaban yang terstruktur dengan baik, tapi kalau hanya ngobrol biasa, jawab dengan singkat dan lucu yaa~";
        if (savedSettings) {
            modelSelect.value = savedSettings.model || 'gemini-2.0-flash';
            systemInstruction.value = savedSettings.systemInstruction || defaultInstruction;
            groundingToggle.checked = savedSettings.grounding || false;
            darkThemeToggle.checked = savedSettings.darkTheme || false;
        } else {
            systemInstruction.value = defaultInstruction;
        }
        applyTheme(darkThemeToggle.checked);
        return { model: modelSelect.value, systemInstruction: systemInstruction.value, grounding: groundingToggle.checked };
    };

    [modelSelect, systemInstruction, groundingToggle, darkThemeToggle].forEach(el => el.addEventListener('change', saveSettings));
    systemInstruction.addEventListener('keyup', saveSettings);
    darkThemeToggle.addEventListener('change', () => applyTheme(darkThemeToggle.checked));
    
    document.querySelectorAll('.suggestion-chips .chip').forEach(chip => chip.addEventListener('click', () => { messageInput.value = chip.textContent.trim(); processAndSendMessage(); }));

    loadSettings();
    loadLatestChat();
    renderHistoryList();
});